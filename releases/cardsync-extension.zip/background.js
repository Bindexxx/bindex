// Service worker dell'estensione
importScripts('shared.js'); // LINGUA_MAP_SHARED, COND_NUM_MAP_SHARED, costruisciUrlFiltrato
importScripts('supabase.bundle.js', 'supabase_adapter.js'); // chiamaSupabase — vedi handler AGGIUNGI_CARTA più sotto

// ── v5.40 — VERSIONE DEL CODICE DI QUESTO FILE ───────────────────────────────
// Scritta a mano a ogni rilascio, uguale a manifest.json (lo controlla
// tools/test-estensione/prova-background.js). Serve a sapere quale motore sta
// girando davvero: chrome.runtime.getManifest() dice quale manifest è stato
// letto, non quale background.js. Se le due cose non coincidono con il
// manifest sul disco, _ricaricaSeFileAggiornati ricarica l'estensione; il
// sito la legge con CARDSYNC_GET_VERSION (campo "motore") e
// segnala_dispositivo (sql/122) la registra per ogni PC.
// v5.41: la chiede anche app.js all'apertura (CARDSYNC_VERSIONE_MOTORE): se
// questo file è di un'altra versione — o è così vecchio da non rispondere —
// la pagina ricarica l'estensione. Serve perché un motore vecchio non può
// accorgersi da solo di esserlo (il 24/10 sul PC di Claudio, dopo il bat, girava
// un motore di prima della 5.36 con manifest e pagine 5.40).
const VERSIONE_MOTORE = '5.43';

// ── v5.40 (Fase 4.6) — SVEGLIE CREATE UNA VOLTA SOLA ─────────────────────────
// Ogni avvio del service worker rieseguiva tutte le chrome.alarms.create:
// una sveglia già esistente veniva ricreata da capo e il suo conto alla
// rovescia ripartiva. Con riavvii frequenti (Chrome ferma il service worker
// dopo 30 s senza eventi) una sveglia da 1 minuto poteva non scattare mai.
// Ora si crea solo se manca o se il periodo è cambiato. Chrome non accetta
// periodi sotto i 30 s (li porta comunque a 30): li si scrive già così.
function _creaSvegliaSeManca(nome, periodoMinuti) {
  const periodInMinutes = Math.max(periodoMinuti, 0.5);
  return Promise.resolve(chrome.alarms.get(nome))
    .then((esistente) => {
      if (esistente && esistente.periodInMinutes === periodInMinutes) return;
      return chrome.alarms.create(nome, { periodInMinutes });
    })
    .catch(() => chrome.alarms.create(nome, { periodInMinutes }));
}

// ── v5.40 (Fase 4.8) — SCADENZA DELLE LETTURE IN UNA SCHEDA ──────────────────
// Al posto dei setTimeout(…, 15000) sparsi: dopo TEMPO_MAX_LETTURA_MS
// (shared.js), se la scheda non ha ancora finito di caricare (staCaricando,
// cioè la "caricata" della funzione che chiama) si aspettano una volta sola
// altri TEMPO_EXTRA_LETTURA_MS. La decisione è presa dentro il timer, senza
// attese: chiudi() della funzione non può arrivare in mezzo. rimetti(t) salva
// il nuovo timer nella variabile "timeout" del chiamante, così il suo
// clearTimeout(timeout) annulla anche l'attesa in più.
function _scadenzaLettura(staCaricando, chiudiOra, rimetti) {
  return setTimeout(() => {
    if (staCaricando()) rimetti(setTimeout(chiudiOra, TEMPO_EXTRA_LETTURA_MS));
    else chiudiOra();
  }, TEMPO_MAX_LETTURA_MS);
}

// ── v5.42 (Fase 5.2) — shared.js NELLA SCHEDA PRIMA DI LEGGERE IL PREZZO ──────
// Fino alla 5.41 shared.js era un content script dichiarato nel manifest e
// girava su ogni pagina di Cardmarket: le letture del prezzo qui sotto
// trovavano già window.rigaSoddisfaFiltriShared (filtri lingua, condizione,
// RH/1ª ed., carrello). Ora non c'è più: lo si inietta in questa scheda, una
// volta per pagina, prima di ogni lettura che lo usa. Senza, la lettura
// passerebbe in silenzio SENZA filtri (prezzo della lingua sbagliata).
// Una sola iniezione alla volta per scheda (i giri di lettura ogni 600 ms non
// devono iniettarlo due volte: le const di shared.js darebbero errore).
// Già che c'è, guarda se l'intestazione mostra l'account: prima lo diceva
// content.js (STATO_LOGIN_CARDMARKET) da ogni pagina di Cardmarket, anche da
// queste schede, e così l'esito "loggato" ricordato restava fresco mentre si
// lavora. Al massimo una scrittura al minuto.
const _iniezioniSharedInCorso = new Map();
let _ultimoLoginVistoInScheda = 0;
function _assicuraSharedInScheda(tabId) {
  if (_iniezioniSharedInCorso.has(tabId)) return _iniezioniSharedInCorso.get(tabId);
  const p = new Promise((resolve) => {
    try {
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => ({ shared: typeof window.rigaSoddisfaFiltriShared === 'function', loggato: !!document.getElementById('account-dropdown') }),
      }, (r) => {
        if (chrome.runtime.lastError) { resolve(false); return; } // pagina in navigazione: si riprova al giro dopo
        const stato = r && r[0] && r[0].result;
        if (stato && stato.loggato && Date.now() - _ultimoLoginVistoInScheda > 60 * 1000) {
          _ultimoLoginVistoInScheda = Date.now();
          _ricordaStatoLoginCardmarket(true);
        }
        if (stato && stato.shared === true) { resolve(true); return; }
        chrome.scripting.executeScript({ target: { tabId }, files: ['shared.js'] }, () => {
          resolve(!chrome.runtime.lastError);
        });
      });
    } catch (_) {
      resolve(false);
    }
  }).finally(() => _iniezioniSharedInCorso.delete(tabId));
  _iniezioniSharedInCorso.set(tabId, p);
  return p;
}

// ── APERTURA APP ──────────────────────────────────────────────────────────────
// Non creiamo più preferiti automatici né apriamo tab da soli all'avvio di
// Chrome: l'apertura dell'app è ora decisa dal sito (pulsanti "Apri l'app" e
// "Apri sempre l'app all'apertura del sito da questo dispositivo", vedi
// index.html + auth_ui.js). Qui teniamo solo l'apertura al click sull'icona
// dell'estensione, dato che non esiste più il mini-popup (default_popup
// rimosso dal manifest): se una tab con l'app è già aperta la richiama in
// primo piano, altrimenti ne apre una nuova.
async function _apriOFocalizzaTabApp() {
  const url = chrome.runtime.getURL('app.html');
  const esistenti = await chrome.tabs.query({ url: url + '*' });
  if (esistenti && esistenti.length > 0) {
    const tab = esistenti[0];
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    // FIX: prima qui si forzava sempre "#prezzi", che sovrascriveva sia
    // "Coda pendente" (pagina di default) sia qualunque logica di
    // attivaSezione() in app.js — risultato: si finiva sempre su "Controllo
    // prezzi" a ogni apertura da icona/sito. Ora si apre esplicitamente su
    // "#coda", così Coda pendente è sempre la prima cosa che si vede.
    await chrome.tabs.create({ url: url + '#coda' });
  }
}
chrome.action.onClicked.addListener(_apriOFocalizzaTabApp);

// ── v5.32 — "RIAPRI L'APP SE VIENE CHIUSA" (interruttore in app.html) ─────────
// Per-dispositivo, assente = spento. Acceso = l'app deve restare aperta: se
// non c'è nessuna scheda dell'app se ne apre una in secondo piano.
// v5.33: nella 5.32 la riapertura dipendeva dalla scheda che si
// "registrava" all'avvio (REGISTRA_SCHEDA_APP) e non è mai scattata. Ora
// non dipende da niente: si controlla dopo OGNI scheda chiusa e comunque una
// volta al minuto (alarm 'riapri-app'), oltre che all'avvio di Chrome.
// Mai quando si sta chiudendo Chrome: senza finestre normali aperte non si
// crea niente (riaprirebbe una finestra e Chrome non si chiuderebbe).
let _riaperturaInCorso = false;
async function _riapriAppSeChiusa() {
  if (_riaperturaInCorso) return;
  _riaperturaInCorso = true;
  try {
    const { riapriAppSeChiusa } = await chrome.storage.local.get('riapriAppSeChiusa');
    if (riapriAppSeChiusa !== true) return;
    const base = chrome.runtime.getURL('app.html');
    const tutte = await chrome.tabs.query({});
    if (tutte.some(t => ((t.url || t.pendingUrl || '')).startsWith(base))) return;
    const finestre = await chrome.windows.getAll({ windowTypes: ['normal'] });
    if (!finestre || finestre.length === 0) return; // Chrome si sta chiudendo
    const finestra = finestre.find(f => f.focused) || finestre[0];
    await chrome.tabs.create({ url: base + '#coda', active: false, windowId: finestra.id });
    console.log('[CardSync] app riaperta (Riapri l\'app se viene chiusa)');
  } catch (e) {
    console.warn('[CardSync] riapertura app non riuscita:', e && e.message);
  } finally {
    _riaperturaInCorso = false;
  }
}

chrome.tabs.onRemoved.addListener((tabId, info) => {
  // Attesa: se si sta chiudendo l'ultima finestra (Chrome in chiusura),
  // nel frattempo sparisce e _riapriAppSeChiusa non trova finestre.
  setTimeout(() => { _riapriAppSeChiusa(); }, info && info.isWindowClosing ? 5000 : 2000);
});

chrome.runtime.onStartup.addListener(() => {
  // Lascia tempo al ripristino delle schede di Chrome prima di decidere.
  setTimeout(() => { _riapriAppSeChiusa(); }, 8000);
});

_creaSvegliaSeManca('riapri-app', 1);

// ── v5.34 — RICARICA DA SOLA DOPO UN AGGIORNAMENTO ────────────────────────────
// Se aggiorna_cardsync.bat sostituisce i file con Chrome ancora acceso, le
// pagine dell'app si aprono già nuove ma questo service worker resta quello
// vecchio (successo il 2026-10-16: app 5.33, motore 5.30) fino a una
// ricarica a mano da chrome://extensions. Per un'estensione non
// pacchettizzata manifest.json viene letto dalla cartella sul disco: se la
// versione lì è diversa da quella in esecuzione, ci si ricarica da soli.
// Al massimo una ricarica ogni 10 minuti per la stessa versione, così un
// caso strano non diventa un ciclo di ricariche.
async function _ricaricaSeFileAggiornati() {
  try {
    const r = await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' });
    const suDisco = (await r.json()).version;
    const inUso = chrome.runtime.getManifest().version;
    if (!suDisco) return;
    if (suDisco === inUso) {
      // v5.40: manifest giusto ma motore (questo file) di un'altra versione:
      // Chrome ha letto il manifest nuovo e tiene in uso un background.js
      // vecchio. Una ricarica sola per versione sul disco: se dopo la
      // ricarica il motore è ancora diverso, ricaricare di nuovo non serve.
      if (suDisco === VERSIONE_MOTORE) return;
      const { ricaricaPerMotore } = await chrome.storage.local.get('ricaricaPerMotore');
      if (ricaricaPerMotore && ricaricaPerMotore.versione === suDisco) return;
      await chrome.storage.local.set({ ricaricaPerMotore: { versione: suDisco, il: Date.now() } });
      console.warn('[CardSync] manifest ' + suDisco + ' ma motore ' + VERSIONE_MOTORE + ': ricarico l\'estensione');
      chrome.runtime.reload();
      return;
    }
    const { ricaricaPerVersione } = await chrome.storage.local.get('ricaricaPerVersione');
    if (ricaricaPerVersione && ricaricaPerVersione.versione === suDisco && Date.now() - ricaricaPerVersione.il < 10 * 60 * 1000) return;
    await chrome.storage.local.set({ ricaricaPerVersione: { versione: suDisco, il: Date.now() } });
    console.warn('[CardSync] file aggiornati sul disco (' + suDisco + ') ma in uso la ' + inUso + ': ricarico l\'estensione');
    chrome.runtime.reload();
  } catch (_) { /* niente: si riprova al giro dopo */ }
}
_creaSvegliaSeManca('controlla-aggiornamento-file', 1);

// ── v5.40 (Fase 4.7) — VERSIONE DI QUESTO PC SUL DATABASE ─────────────────────
// sql/122: una riga per account e PC (nome di nomeDispositivo(), shared.js)
// con la versione del motore e l'ultima volta visto — serve per alzare la
// versione minima (sql/103) sapendo quali PC sono già aggiornati. Parte
// all'avvio del service worker e con la sveglia oraria; tra un invio e
// l'altro almeno 55 minuti, salvo cambio di versione o di account. Senza
// login non fa nulla; un errore non ferma niente (si riprova all'ora dopo).
async function _segnalaDispositivo() {
  try {
    const { data } = await supabaseClient.auth.getSession();
    const userId = data && data.session && data.session.user ? data.session.user.id : null;
    if (!userId) return;
    const { dispositivoSegnalato: prima } = await chrome.storage.local.get('dispositivoSegnalato');
    if (prima && prima.versione === VERSIONE_MOTORE && prima.userId === userId
      && Date.now() - prima.il < 55 * 60 * 1000) return;
    const { error } = await supabaseClient.rpc('segnala_dispositivo', {
      p_dispositivo: await nomeDispositivo(), p_versione: VERSIONE_MOTORE,
    });
    if (error) { console.warn('[CardSync] segnala_dispositivo:', error.message); return; }
    await chrome.storage.local.set({ dispositivoSegnalato: { versione: VERSIONE_MOTORE, userId, il: Date.now() } });
  } catch (e) {
    console.warn('[CardSync] segnala_dispositivo:', e && e.message);
  }
}
_creaSvegliaSeManca('segnala-dispositivo', 60);
setTimeout(() => { _segnalaDispositivo(); }, 5000);

// "Mantieni acceso" (stesso concetto del sito). v5.42 (Fase 5.4, D7): prima,
// se disattivato, qui si faceva signOut a ogni sospensione del service
// worker — cioè dopo 30 secondi senza eventi, non alla chiusura di Chrome.
// Ora la sessione sta in chrome.storage.session, che Chrome svuota da solo
// quando si chiude: vedi l'archivio della sessione in supabase_adapter.js.

// ── COMUNICAZIONE COL SITO (externally_connectable) ───────────────────────────
// Il sito, ad ogni apertura, chiede qui la versione installata per sapere
// se mostrare "sei aggiornato" o il popup di aggiornamento — vedi
// manifest.json → externally_connectable (solo il dominio del sito può
// mandare messaggi qui, nessun altro sito). Risponde con il numero di
// versione e, dalla 5.26, con id e nome dell'utente loggato qui
// (CARDSYNC_GET_UTENTE) — nessun token, nessun dato della collezione.
// Un sito web normale NON può aprire da solo una pagina chrome-extension://
// (bloccato dal browser per sicurezza) — per questo il pulsante "Apri l'app"
// del sito manda un messaggio qui invece di provare ad aprirla direttamente.
// v5.17: l'estensione NON adotta più la sessione del sito (vedi il commento
// in CARDSYNC_OPEN_APP più sotto) — ha un suo login, una volta per
// dispositivo.
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'CARDSYNC_GET_VERSION') {
    // v5.40: anche "motore" = versione di questo background.js (vedi
    // VERSIONE_MOTORE in cima): se è diversa da "versione", su questo PC sta
    // girando un service worker vecchio con i file nuovi.
    sendResponse({ versione: chrome.runtime.getManifest().version, motore: VERSIONE_MOTORE });
    return true;
  }
  // v5.26 — Il sito chiede CHI è loggato qui, per avvisare quando non è lo
  // stesso utente del sito (dalla 5.17 i due login sono separati: cambiare
  // account sul sito non cambia quello dell'estensione). Solo id e nome
  // utente (la parte prima della @), mai token o email intera.
  if (message && message.type === 'CARDSYNC_GET_UTENTE') {
    supabaseClient.auth.getSession().then(({ data }) => {
      const utente = data && data.session ? data.session.user : null;
      sendResponse({
        ok: true,
        userId: utente ? utente.id : null,
        nome: utente ? (String(utente.email || '').split('@')[0] || null) : null,
      });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_GET_AIUTA_GRUPPO') {
    // Letta e scritta SOLO in chrome.storage.local — è una preferenza legata
    // a QUESTO dispositivo/installazione dell'estensione, non all'account
    // Supabase: due dispositivi diversi con lo stesso login possono avere
    // valori diversi, di proposito (es. il PC sempre acceso la tiene su, il
    // portatile no).
    chrome.storage.local.get('aiutaGruppo').then(({ aiutaGruppo }) => {
      sendResponse({ ok: true, aiutaGruppo: aiutaGruppo ?? false });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_SET_AIUTA_GRUPPO') {
    chrome.storage.local.set({ aiutaGruppo: !!message.valore }).then(() => {
      sendResponse({ ok: true, aiutaGruppo: !!message.valore });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  // v5.25 — "Lavora anche a estensione chiusa" (per-dispositivo, come
  // aiutaGruppo). Assente = acceso: è il comportamento di sempre.
  if (message && message.type === 'CARDSYNC_GET_LAVORA_A_CHIUSO') {
    chrome.storage.local.get('lavoraAChiuso').then(({ lavoraAChiuso }) => {
      sendResponse({ ok: true, lavoraAChiuso: lavoraAChiuso !== false });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_SET_LAVORA_A_CHIUSO') {
    chrome.storage.local.set({ lavoraAChiuso: !!message.valore }).then(() => {
      sendResponse({ ok: true, lavoraAChiuso: !!message.valore });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_SET_TEMA') {
    // Come la parte "tema" di CARDSYNC_OPEN_APP, ma SENZA aprire/focalizzare
    // nessuna tab: qui il sito sta solo tenendo l'estensione allineata mentre
    // l'utente cambia tema, non chiedendo di aprire l'app. Le pagine
    // dell'estensione già aperte (se ce ne sono) si aggiornano da sole
    // tramite il loro chrome.storage.onChanged su 'selectedTheme'.
    const daScrivere = {};
    if (typeof message.tema === 'string') daScrivere.selectedTheme = message.tema;
    if (typeof message.temaScuro === 'boolean') daScrivere.cardsyncDarkMode = message.temaScuro;
    chrome.storage.local.set(daScrivere).then(() => {
      sendResponse({ ok: true });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_OPEN_APP') {
    // Tab del sito che ha chiesto l'apertura — serve dopo per riportarci il
    // focus a fine controllo login Cardmarket (vedi
    // _controlloLoginAutomaticoAperturaApp più sotto). Va letta subito: una
    // volta finita questa callback, 'sender' non è più garantito valido.
    const tabSitoChiamante = (sender && sender.tab) ? { id: sender.tab.id, windowId: sender.tab.windowId } : null;
    (async () => {
      try {
        // FIX v5.17 (sessione condivisa che si rompe da sola): prima qui
        // l'estensione adottava i token del sito (setSession), quindi sito ed
        // estensione usavano LA STESSA sessione. Supabase cambia la chiave di
        // rinnovo a ogni rinnovo e, se qualcuno ne riusa una più vecchia della
        // penultima, chiude l'intera sessione: l'estensione la rinnova ogni
        // ora, la scheda del sito chiusa resta indietro, e alla riapertura del
        // sito la sessione veniva chiusa per entrambi. Ora l'estensione ha un
        // suo login (overlay di auth_ui.js, una volta per dispositivo) e una
        // sessione sua. Eventuali token mandati da un sito vecchio vengono
        // ignorati.
        // Tema e tema scuro arrivano dal sito (stessa scelta già fatta lì) e
        // vengono scritti nello stesso storage che ogni pagina dell'estensione
        // già legge (selectedTheme, cardsyncDarkMode) — nessuna nuova UI per
        // sceglierli qui dentro, l'estensione si allinea e basta.
        const daScrivere = {};
        if (typeof message.tema === 'string') daScrivere.selectedTheme = message.tema;
        if (typeof message.temaScuro === 'boolean') daScrivere.cardsyncDarkMode = message.temaScuro;
        // Segnale letto da app.js per mostrare il popup bloccante ("sto per
        // aprire Cardmarket per il login, logga con un account secondario")
        // appena la tab dell'hub si apre o torna in primo piano — vedi
        // _controlloLoginAutomaticoAperturaApp più sotto. Il controllo vero
        // e proprio NON parte più da qui: parte solo quando l'utente clicca
        // "Ho capito" nel popup, che manda il messaggio interno
        // CARDSYNC_LOGIN_CHECK_ACK (vedi listener più sotto). Salviamo qui
        // anche la tab del sito da rifocalizzare a fine controllo, così
        // sopravvive anche se il service worker si addormenta nel frattempo
        // (l'utente potrebbe metterci un po' a leggere il popup e cliccare).
        // v5.40 (Fase 4.11, M3): il popup a tutto schermo solo se il login
        // manca davvero — prima compariva a OGNI apertura dell'app dal sito,
        // anche con il login appena confermato. Prima si verifica come i giri
        // automatici (_verificaLoginAutomatica: esito ricordato, oppure una
        // scheda in background chiusa sempre); solo se non risulta loggato si
        // scrive il segnale che fa comparire il popup (vedi
        // _avvisoLoginAperturaAppSeManca più sotto).
        await chrome.storage.local.set(daScrivere);

        await _apriOFocalizzaTabApp();
        sendResponse({ ok: true });
        _avvisoLoginAperturaAppSeManca(tabSitoChiamante);
      } catch (e) {
        sendResponse({ ok: false, errore: e.message });
      }
    })();
    return true; // risposta asincrona
  }
  // FIX (bug [17]): messaggio non riconosciuto — prima "return true"
  // incondizionato teneva il canale sendResponse aperto senza mai
  // chiamarlo, causando "message port closed before a response was
  // received" lato chiamante.
  // v5.40 (Fase 4.9): si risponde subito con un errore invece di chiudere il
  // canale in silenzio — il sito capisce che il tipo non esiste (estensione
  // più vecchia o più nuova del sito) senza aspettare il proprio timeout.
  sendResponse({ ok: false, errore: 'tipo sconosciuto' });
  return false;
});

// ── ACK DEL POPUP "STO PER APRIRE CARDMARKET" ────────────────────────────────
// Mandato da app.js quando l'utente clicca "Ho capito" sul popup mostrato da
// CARDSYNC_OPEN_APP qui sopra — SOLO a quel punto partiamo davvero con
// l'apertura della tab Cardmarket per il controllo login. Leggiamo la tab
// del sito da storage (salvata da CARDSYNC_OPEN_APP) invece di riceverla nel
// messaggio, perché il service worker potrebbe essersi riavviato nel
// frattempo — chrome.storage.local sopravvive a un riavvio del service
// worker, una variabile in memoria no.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // v5.41: versione di questo file per app.js (vedi VERSIONE_MOTORE).
  if (message && message.type === 'CARDSYNC_VERSIONE_MOTORE') {
    sendResponse({ motore: VERSIONE_MOTORE });
    return false;
  }
  if (message && message.type === 'CARDSYNC_LOGIN_CHECK_ACK') {
    chrome.storage.local.get('cardsyncLoginCheckTabSito').then(async ({ cardsyncLoginCheckTabSito }) => {
      await chrome.storage.local.remove('cardsyncLoginCheckTabSito'); // consumata, evita riusi involontari
      sendResponse({ ok: true });
      // Da qui in poi il controllo login Cardmarket gira per conto suo in
      // background e, alla fine, riporta da solo il focus sulla tab del
      // sito (vedi _controlloLoginAutomaticoAperturaApp più sotto).
      _controlloLoginAutomaticoAperturaApp(cardsyncLoginCheckTabSito || null);
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true; // risposta asincrona
  }
  return false;
});

// ── FIX (immagini sempre 403 Forbidden) ──────────────────────────────────────
// Cardmarket controlla l'intestazione "Referer" delle richieste alle proprie
// immagini e rifiuta (403) qualunque richiesta che non arrivi da una loro
// pagina — anche il fetch fatto da qui (background.js), che pure ha il
// privilegio di ignorare il CORS, viene comunque rifiutato perché il
// Referer è vuoto/sbagliato. JavaScript NON PUÒ impostare manualmente
// l'intestazione Referer su un fetch (è "protetta" dal browser per motivi
// di sicurezza) — serve intervenire a livello di rete PRIMA che la
// richiesta parta, con l'API declarativeNetRequest: questa regola dice al
// browser "per ogni richiesta verso le immagini prodotto di Cardmarket,
// riscrivi il Referer come se venisse da cardmarket.com stesso".
chrome.declarativeNetRequest.updateDynamicRules({
  removeRuleIds: [1],
  addRules: [{
    id: 1,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [
        { header: 'Referer', operation: 'set', value: 'https://www.cardmarket.com/' },
      ],
    },
    condition: {
      urlFilter: '||product-images.s3.cardmarket.com',
      resourceTypes: ['xmlhttprequest'],
    },
  }],
}).catch((e) => console.error('[immagine] impossibile impostare la regola Referer:', e.message));

// ── KEEPALIVE: evita che Chrome MV3 termini il SW durante sessioni bulk lunghe ──
// v5.40 (4.6): una sveglia in attesa NON tiene acceso il service worker: Chrome
// lo ferma dopo 30 s senza eventi. È la sveglia che, scattando ogni 30 s (il
// minimo che Chrome accetta; prima si chiedevano 20 s), lo risveglia e
// riazzera quel conto. Le attese lunghe sopravvivono comunque ai riavvii
// grazie al watchdog persistente (cfAttiveAttese) e all'heartbeat richieste.
function _avviaKeepAlive() {
  _creaSvegliaSeManca('sw-keepalive', 0.5);
}
function _fermaKeepAlive() {
  chrome.alarms.clear('sw-keepalive');
}
// Avvia subito al caricamento del SW (costo zero se non ci sono sessioni attive)
_avviaKeepAlive();

// ── POLLING ORDINI (arrivano dal sito pubblico GitHub Pages) ────────────────
// Il sito, quando l'utente preme "Controlla prezzi", scrive una riga nella
// tabella Supabase 'ordini' con stato 'pending'. Qui, ogni 30 s (stesso
// periodo del keepalive sopra; v5.40: prima 20 s chiesti, 30 s reali),
// controlliamo se c'è un ordine in attesa e lo
// "prendiamo in carico": lo marchiamo 'in_corso' e apriamo/portiamo in primo
// piano la tab app.html sulla sezione Prezzi. La sessione vera e propria
// (eseguiSessione in popup.js, dentro l'iframe di quella sezione) e la
// scrittura dello stato finale 'completato'/'errore' sono una FASE
// SUCCESSIVA, non ancora collegata a questo polling.
function _avviaPollingOrdini() {
  _creaSvegliaSeManca('ordini-poll', 0.5);
}
_avviaPollingOrdini();

// ── WORKER AUTONOMO CODA_CARTE (risoluzione senza tab/popup aperti) ─────────
// FIX (richiesta esplicita di Claudio, sessione 20/08/2026): fino ad ora
// 'coda_carte' veniva lavorata SOLO se qualcuno aveva aggiungi_carta_popup.js
// aperto in foreground (_recuperaAltreRigheDaDb, lì dentro) — vedi il commento
// sopra "aggiungi_carte" in _controllaOrdini() qui sotto, che di proposito
// NON apre nessuna tab, per non riprodurre il vecchio bug "la tab si riapre
// da sola". Qui invece si risolve DAVVERO, senza aprire app.html: un
// dispositivo con l'estensione installata e loggato (es. il PC "muletto"
// sempre acceso, incustodito) lavora la coda da solo, un elemento alla
// volta, riusando le stesse funzioni di lettura già presenti in questo file
// (_leggiNomeDaCardmarket/_leggiNomeSealedDaCardmarket) — chiamate dirette,
// nessun bisogno di passare da un messaggio, sono già nello stesso script.
//
// Governato dalla preferenza per-dispositivo 'aiutaGruppo' (stessa già in
// uso per il controllo prezzi condiviso, vedi CARDSYNC_GET/SET_AIUTA_GRUPPO
// più sopra): OFF → il dispositivo risolve comunque SEMPRE le PROPRIE carte
// in automatico; ON → risolve anche quelle del resto del gruppo (risposte di
// Claudio, sessione 20/08/2026).
//
// Righe che falliscono la risoluzione 3 volte di seguito (soglia concordata
// con Claudio) vengono spostate dalla coda di lavoro a
// 'correzioni_manuali_carte' (RPC sposta_riga_in_correzione_manuale,
// SECURITY DEFINER — chi sposta la riga, es. Bill, quasi mai coincide col
// proprietario originale A, quindi un semplice insert client-side verrebbe
// bloccato dalla RLS owner_id=auth.uid() di quella tabella) — così A la vede
// e la corregge da qualsiasi dispositivo, sezione "Carte con problemi" del
// sito, ora aggiornata per leggere da questa nuova tabella invece che da
// 'coda_carte'/stato=errore.
let _lavoroAutonomoInCorso = false;
// Backoff globale per QUESTO dispositivo dopo un sospetto blocco Cloudflare
// (nessun umano davanti al muletto per risolverlo a mano, vedi
// _risolviRigaCodaCarteAutonoma) — evita di insistere subito con lo stesso
// pattern che ha appena fatto scattare il blocco, aggravando la situazione
// IP del dispositivo mentre non c'è nessuno a controllare.
let _backoffAutonomoFinoA = 0;

// Stesse identiche costruzioni URL già in uso in aggiungi_carta_popup.js
// (urlRicerca/urlRicercaSealed) — duplicate qui apposta invece di spostarle
// in un file condiviso nuovo (regola d'oro #1, no refactor cross-file: sono
// due funzioni piccole e stabili, non vale il rischio per così poco).
// v5.36 (B18): testo codificato — prima solo gli spazi diventavano "+", e
// un "&" nel nome ("PIKACHU & ZEKROM GX", "Scarlet & Violet Booster Box")
// tagliava la ricerca a "PIKACHU " (il resto diventava un altro parametro).
function _testoRicercaCodificato(testo) {
  return encodeURIComponent((testo || '').trim().replace(/\s+/g, ' ')).replace(/%20/g, '+');
}
function _urlRicercaAutonoma(codice) {
  const query = _testoRicercaCodificato(codice);
  return `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
}
function _urlRicercaSealedAutonoma(nome, lingua) {
  const query = _testoRicercaCodificato(nome);
  let url = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
  const codiceLingua = (lingua || 'IT').toUpperCase().trim();
  const idLingua = LINGUA_MAP_SHARED[codiceLingua];
  if (idLingua) url += `&language=${idLingua}`;
  return url;
}

// v5.26 — Vero se questo PC può lavorare adesso: "Lavora anche a estensione
// chiusa" acceso (assente = acceso), oppure una scheda dell'app aperta.
// Usata dagli ordini del sito (dalla 5.31 il worker coda carte usa
// _workerCodaCartePuoLavorare, più sotto). Nella 5.25 la usava solo
// il worker, e un ordine di prezzi dal sito apriva lo stesso Cardmarket
// (verifica login) e l'app in una scheda nascosta a estensione chiusa.
// v5.29 (regola di Claudio, 2026-10-16): interruttore spento = lavora SOLO
// se una scheda dell'app è aperta, chiunque l'abbia aperta; con la scheda
// aperta lavora come sempre (anche le carte degli altri se "Aiuta il
// gruppo" è attivo). Tolta la distinzione "aperta da te / aperta da sola" e
// la chiusura automatica delle schede introdotte nella 5.27–5.28.
async function _lavoroPermessoSuQuestoPc(lavoraAChiuso) {
  if (lavoraAChiuso === undefined) ({ lavoraAChiuso } = await chrome.storage.local.get('lavoraAChiuso'));
  if (lavoraAChiuso !== false) return true;
  const schedeApp = await chrome.tabs.query({ url: chrome.runtime.getURL('app.html') + '*' });
  return !!schedeApp && schedeApp.length > 0;
}

// v5.31 — Vero se il worker in background può prendere carte dalla coda:
// nessuna scheda dell'app aperta (lì la coda la lavora la pagina) e
// "Lavora anche a estensione chiusa" acceso (assente = acceso, come
// l'interruttore in app.js).
async function _workerCodaCartePuoLavorare(lavoraAChiuso) {
  if (lavoraAChiuso === undefined) ({ lavoraAChiuso } = await chrome.storage.local.get('lavoraAChiuso'));
  if (lavoraAChiuso === false) return false;
  const schedeApp = await chrome.tabs.query({ url: chrome.runtime.getURL('app.html') + '*' });
  return !schedeApp || schedeApp.length === 0;
}

function _avviaWorkerAutonomoCodaCarte() {
  // Un elemento alla volta: stesso spirito prudente di _LOTTO_RECUPERO_DB=1
  // già usato in aggiungi_carta_popup.js — con più dispositivi online si
  // dividono il lavoro invece che accaparrarselo. v5.43: la sveglia di ogni
  // minuto fa partire il giro; dentro il giro le carte vanno di fila, con il
  // turno Cardmarket comune tra una e l'altra (vedi _lavoraCodaCarteAutonomo).
  _creaSvegliaSeManca('worker-coda-carte-autonomo', 1);
}
_avviaWorkerAutonomoCodaCarte();

// Timeout duro per singolo tentativo: se Cardmarket resta bloccata (es.
// sfida Cloudflare) e non c'è nessun umano a risolverla a mano (muletto
// incustodito, PUNTO ESPLICITO concordato con Claudio), questo worker non
// deve restare appeso per sempre — meglio contare il tentativo come fallito
// e passare oltre, lasciando che la riga torni 'pending' per un prossimo
// giro (di questo dispositivo o di un altro), o finisca in correzione
// manuale una volta raggiunta la soglia di tentativi.
const TIMEOUT_TENTATIVO_AUTONOMO_MS = 2 * 60 * 1000;
function _conTimeoutAutonomo(promessa, ms) {
  return Promise.race([
    promessa,
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout worker autonomo')), ms)),
  ]);
}

// v5.43 (Fase 6) — Carte di fila. Prima: una carta per giro e un giro al
// minuto (sveglia 'worker-coda-carte-autonomo'), quindi con slider 10-20 s
// questo PC lavorava una carta ogni minuto circa (mediana misurata su
// PC-DL8LI dal 16 al 24/10: 58 s a carta). Ora, finita una carta, si passa
// subito alla successiva aspettando solo il turno Cardmarket comune (che
// tiene la distanza degli slider dall'ultima richiesta). Ogni carta
// ricontrolla tutto da capo (login, interruttori, scheda dell'app aperta,
// precedenza degli ordini di prezzi, pausa dopo Cloudflare): appena una
// condizione manca il giro finisce, e la sveglia di ogni minuto lo fa
// ripartire quando torna possibile. Tra una carta e l'altra il segno
// "worker al lavoro" (_CHIAVE_WORKER_AUTONOMO_ATTIVO) è tolto, così un ordine
// di prezzi arrivato nel frattempo passa davanti alla carta successiva.
const _MAX_CARTE_PER_GIRO_AUTONOMO = 100; // solo una rete di sicurezza

async function _lavoraCodaCarteAutonomo() {
  if (_lavoroAutonomoInCorso) return;
  _lavoroAutonomoInCorso = true;
  try {
    for (let n = 0; n < _MAX_CARTE_PER_GIRO_AUTONOMO; n++) {
      if (Date.now() < _backoffAutonomoFinoA) break; // in pausa dopo un sospetto blocco Cloudflare
      const esito = await _lavoraUnaCartaAutonoma();
      if (esito !== 'fatta' && esito !== 'presa-da-altri') break;
    }
  } catch (e) {
    console.error('[worker-autonomo] errore imprevisto:', e);
  } finally {
    _lavoroAutonomoInCorso = false;
  }
}

// Una carta della coda: 'fatta', 'presa-da-altri' (un altro PC l'ha presa
// mentre si aspettava il turno: si prova subito la successiva) oppure il
// motivo per cui questo PC non lavora adesso (il giro si ferma).
async function _lavoraUnaCartaAutonoma() {
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return 'non-loggato'; // dispositivo non loggato — niente da fare

    const { aiutaGruppo, lavoraAChiuso } = await chrome.storage.local.get(['aiutaGruppo', 'lavoraAChiuso']);

    // v5.31 (regola di Claudio, 2026-10-16): una sola parte alla volta.
    // Scheda dell'app aperta → la coda la lavora SOLO la pagina Aggiungi
    // carte (aggiungi_carta_popup.js, caricata sempre dentro app.html).
    // Scheda chiusa → lavora questo worker, ma solo con "Lavora anche a
    // estensione chiusa" acceso. Prima (5.25–5.30) con l'app aperta
    // lavoravano entrambi: il segnale "coda della pagina attiva" che doveva
    // fermare questo worker non veniva più scritto, e sullo stesso PC
    // giravano due letture in parallelo.
    if (!(await _workerCodaCartePuoLavorare(lavoraAChiuso))) return 'non-permesso';

    // Stesso identico filtro di eleggibilità già in uso in
    // _recuperaAltreRigheDaDb (aggiungi_carta_popup.js): 'pending', o
    // 'in_corso' da più di 10 minuti (dispositivo che l'aveva presa in
    // carico spento/bloccato a metà) — considerata abbandonata e ripescabile.
    const sogliaStalloIso = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const filtroEleggibili = `stato.eq.pending,and(stato.eq.in_corso,claimed_at.lt.${sogliaStalloIso})`;

    let selectQuery = supabaseClient
      .from('coda_carte')
      .select('*')
      .or(filtroEleggibili)
      .order('creato_il', { ascending: true })
      .limit(1);
    // "Aiuta il gruppo" OFF → risolve SOLO le proprie (risposta di Claudio,
    // sessione 20/08/2026: il worker autonomo risolve sempre le proprie
    // carte a prescindere, il flag governa solo l'aiuto agli altri).
    if (!aiutaGruppo) selectQuery = selectQuery.eq('owner_id', userId);

    const { data: candidate, error: errLettura } = await selectQuery;
    if (errLettura) { console.error('[worker-autonomo] errore lettura:', errLettura.message); return 'errore'; }
    if (!candidate || candidate.length === 0) return 'coda-vuota';

    // v5.29 — un lavoro su Cardmarket alla volta (vedi
    // _precedenzaCodaCardmarket): niente carta se su questo PC gira un
    // controllo prezzi, se la pagina dell'app sta già lavorando la coda, o se
    // c'è un ordine di prezzi arrivato prima di questa carta.
    const _paginaCodaAttiva = async () => _segnaleVivo((await chrome.storage.local.get(_CHIAVE_CODA_PAGINA_ATTIVA))[_CHIAVE_CODA_PAGINA_ATTIVA]);
    if (await _paginaCodaAttiva()) return 'pagina-attiva';
    if ((await _precedenzaCodaCardmarket({ creatoIlRiga: candidate[0].creato_il, escludiWorker: true })).attendi) return 'precedenza';

    // v5.26: aspetta il turno Cardmarket comune PRIMA di prendere la riga
    // (vedi _attendiTurnoCardmarket) — prenotarlo senza una candidata
    // rallenterebbe gli altri flussi a vuoto ogni minuto.
    await _attendiTurnoCardmarket();
    if (!(await _workerCodaCartePuoLavorare())) { _chiudiTurnoCardmarket(); return 'non-permesso'; } // v5.31
    if ((await _paginaCodaAttiva()) || (await _precedenzaCodaCardmarket({ soloOccupato: true, escludiWorker: true })).attendi) { _chiudiTurnoCardmarket(); return 'precedenza'; } // v5.29
    // v5.29: da qui questo worker "occupa" Cardmarket su questo PC (tolto nel
    // finally più sotto; scade da solo se il service worker muore).
    await chrome.storage.local.set({ [_CHIAVE_WORKER_AUTONOMO_ATTIVO]: { scadenza: Date.now() + 10 * 60 * 1000 } });

    const nomeDisp = await nomeDispositivo();
    // Stesso lock ottimistico di _recuperaAltreRigheDaDb: ripetere qui lo
    // STESSO filtro di eleggibilità nella UPDATE evita che due dispositivi
    // (es. il muletto E un popup aperto altrove) claimino la stessa riga.
    const { data: claimate, error: errClaim } = await supabaseClient
      .from('coda_carte')
      .update({ stato: 'in_corso', claimed_by: userId, claimed_at: new Date().toISOString(), dispositivo: nomeDisp })
      .eq('id', candidate[0].id)
      .or(filtroEleggibili)
      .select();
    if (errClaim) { console.error('[worker-autonomo] errore claim:', errClaim.message); _chiudiTurnoCardmarket(); return 'errore'; }
    if (!claimate || claimate.length === 0) { _chiudiTurnoCardmarket(); return 'presa-da-altri'; } // già presa da un altro dispositivo

    try {
      await _risolviRigaCodaCarteAutonoma(claimate[0]);
    } finally {
      _chiudiTurnoCardmarket();
    }
    return 'fatta';
  } finally {
    // v5.29; v5.43: tolto dopo OGNI carta, anche nel giro di fila.
    await chrome.storage.local.remove(_CHIAVE_WORKER_AUTONOMO_ATTIVO).catch(() => {});
  }
}

async function _risolviRigaCodaCarteAutonoma(riga) {
  const isSealed = riga.tipo === 'sealed';
  const lingua = riga.lingua || 'IT';

  let risposta;
  let sospettoCloudflare = false;
  try {
    if (isSealed) {
      risposta = await _conTimeoutAutonomo(
        _leggiNomeSealedDaCardmarket(riga.url_diretto || _urlRicercaSealedAutonoma(riga.nome, lingua), lingua, 0, null, null),
        TIMEOUT_TENTATIVO_AUTONOMO_MS
      );
    } else {
      risposta = await _conTimeoutAutonomo(
        _leggiNomeDaCardmarket(riga.url_diretto || _urlRicercaAutonoma(riga.nome), lingua, riga.condizione || 'NM',
          riga.reverse ? 'RH' : '', !!riga.first_ed, 0, null, null,
          riga.url_diretto ? _urlRicercaAutonoma(riga.nome) : null), // v5.36 (B17): link vecchio → ricerca per nome
        TIMEOUT_TENTATIVO_AUTONOMO_MS
      );
    }
  } catch (e) {
    // Timeout duro scattato (probabile blocco Cloudflare senza nessuno a
    // risolverlo) o eccezione imprevista: tratta come tentativo fallito,
    // NON come "carta non trovata" — vedi backoff più sotto.
    sospettoCloudflare = true;
    risposta = null;
  }

  if (risposta?.rateLimited) {
    // Non conta come tentativo fallito verso la soglia di 3 (non è "carta
    // non trovata", è Cardmarket che chiede di rallentare): la riga torna
    // 'pending' com'era, e questo dispositivo si mette in pausa invece di
    // insistere subito peggiorando la situazione.
    await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({ stato: 'pending', claimed_by: null, claimed_at: null }).eq('id', riga.id), riga);
    _backoffAutonomoFinoA = Date.now() + 15 * 60 * 1000;
    return;
  }

  const urlTrovato = isSealed ? risposta?.urlProdotto : risposta?.urlSingles;
  if (!urlTrovato) {
    // v5.36: messaggi distinti in "Carte con problemi" (prima un link vecchio
    // e una carta con più versioni finivano tutti come "non trovata").
    const motivo = sospettoCloudflare
      ? 'nessuna risposta entro il timeout (possibile blocco Cardmarket senza intervento umano)'
      : risposta?.linkNonValido
        ? (risposta?.disambiguation ? 'link Cardmarket non più valido — scegli la versione giusta' : 'link Cardmarket non più valido e nessun risultato cercando per nome')
        : risposta?.disambiguation ? 'più versioni su Cardmarket — scegli quella giusta'
        : risposta?.varianteNonTrovata ? `variante ${[riga.reverse ? 'Reverse Holo' : '', riga.first_ed ? 'Prima Edizione' : ''].filter(Boolean).join(' + ') || 'richiesta'} non trovata su Cardmarket`
        : 'non trovata su Cardmarket';
    // v5.39 (Fase 3.1): più versioni, link non più valido o variante che non
    // esiste non cambiano riprovando → subito tra le "Carte con problemi" del
    // proprietario, come fa la pagina Aggiungi carte.
    const definitivo = !sospettoCloudflare && !!(risposta?.disambiguation || risposta?.linkNonValido || risposta?.varianteNonTrovata);
    await _segnaTentativoFallitoAutonomo(riga, motivo, risposta?.disambiguation ? (risposta.opzioni || []) : null, definitivo);
    // Sospetto Cloudflare → rallenta questo dispositivo prima del prossimo
    // giro, invece di ripresentarsi subito con lo stesso pattern.
    if (sospettoCloudflare) _backoffAutonomoFinoA = Date.now() + 20 * 60 * 1000;
    return;
  }

  let immagineConvertita = risposta.immagine || '';
  if (immagineConvertita) {
    try { immagineConvertita = await _immagineAUrlDati(immagineConvertita); } catch (_) { /* fallback silenzioso: URL grezzo */ }
  }

  // Stesso schema colonne (COL.*) già usato in aggiungi_carta_popup.js,
  // duplicato qui per lo stesso motivo di urlRicerca/urlRicercaSealed sopra.
  const rigaDati = isSealed ? {
    B: risposta.nome || riga.nome, C: '', D: riga.location || '', E: riga.qty || 1, F: lingua, G: 'NM',
    H: risposta.urlProdotto, I: risposta.prezzo ?? '', K: riga.nota || '', L: immagineConvertita,
  } : {
    B: risposta.nome || '', C: risposta.codice || riga.nome, D: riga.location || '', E: riga.qty || 1, F: lingua,
    G: riga.condizione || 'NM', H: risposta.urlSingles, I: risposta.prezzo ?? '', K: riga.nota || '', L: immagineConvertita,
    M: !!riga.sigillata_originale, // Fase 1 (2026-09-12): richiede coda_carte aggiornata (sql/38)
  };
  if (riga.destinazione === 'wishlist' && riga.prezzo_obiettivo != null) rigaDati.J = riga.prezzo_obiettivo;

  const esito = await _aggiungiConVerifica(rigaDati, 3, riga.tipo, riga.destinazione, riga.id);
  if (!esito || !esito.ok) {
    await _segnaTentativoFallitoAutonomo(riga, 'scrittura fallita: ' + (esito?.errore || '?'), null);
    return;
  }

  // CONTRIBUTI AL GRUPPO (migration 37, 2026-09-03). Registrato QUI e non
  // prima: e' l'unico punto in cui la carta e' stata scritta davvero
  // (_aggiungiConVerifica e' andata a buon fine e i percorsi di errore
  // sono gia' usciti con return piu' sopra). Contare al momento del claim
  // avrebbe gonfiato il numero con i tentativi falliti e con le righe
  // abbandonate a meta' da un dispositivo spento.
  // Se la riga e' tua, la RPC la scarta da sola: il worker autonomo
  // risolve sempre le proprie carte a prescindere dal flag "Aiuta il
  // gruppo", quindi contarle misurerebbe l'uso dell'app, non l'aiuto.
  await registraAiutoGruppo(supabaseClient, riga.id, riga.owner_id, 'coda_carte');

  // Scrittura di cortesia sullo stato — completa_riga_coda_carte lato RPC
  // dovrebbe già occuparsene (stesso schema di contrassegnaEsitoERimuovi in
  // aggiungi_carta_popup.js), ma un aggiornamento diretto qui non fa danno e
  // copre eventuali percorsi che non lo facessero.
  await supabaseClient.from('coda_carte')
    .update({ stato: 'completato', completato_il: new Date().toISOString() })
    .eq('id', riga.id)
    .then(({ error }) => { if (error) console.error('[worker-autonomo] scrittura stato completato:', error.message); });
}

// FIX v5.17 (carte duplicate): quando il worker rimette una riga 'pending'
// dopo un errore, la tocca SOLO se è ancora 'in_corso' e presa in carico da
// lui (riga.claimed_by, scritto al momento della presa in carico). Prima
// l'aggiornamento era sul solo id: una riga completata nel frattempo (da un
// altro dispositivo o dalla correzione manuale) tornava 'pending' e la carta
// veniva aggiunta una seconda volta. Stessa regola di _soloSeAncoraMia in
// aggiungi_carta_popup.js (duplicata apposta, regola d'oro #1).
function _soloSeAncoraMiaAutonoma(query, riga) {
  let q = query.eq('stato', 'in_corso');
  if (riga && riga.claimed_by) q = q.eq('claimed_by', riga.claimed_by);
  return q;
}

async function _segnaTentativoFallitoAutonomo(riga, motivo, opzioni, definitivo) {
  const tentativi = (riga.tentativi_falliti || 0) + 1;
  const SOGLIA_CORREZIONE_MANUALE = 3; // concordata con Claudio, sessione 20/08/2026

  if (definitivo || tentativi >= SOGLIA_CORREZIONE_MANUALE) {
    const { error } = await supabaseClient.rpc('sposta_riga_in_correzione_manuale', {
      p_riga_id: riga.id,
      p_errore_msg: definitivo ? motivo : `${motivo} (dopo ${tentativi} tentativi automatici)`,
      p_opzioni: opzioni,
    });
    if (error) {
      console.error('[worker-autonomo] impossibile spostare in correzione manuale:', error.message);
      // Rete di sicurezza: se la RPC fallisce (es. migration non ancora
      // eseguita sul DB), la riga NON deve sparire nel nulla — resta in coda
      // come 'pending', verrà ritentata (con lo stesso contatore) al
      // prossimo giro invece di bloccarsi in 'in_corso' per sempre.
      // v5.17: mai riaprire una riga già completata (vedi _soloSeAncoraMiaAutonoma).
      await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({ stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi }).eq('id', riga.id), riga);
    }
    return;
  }

  await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({
    stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi,
  }).eq('id', riga.id), riga);
}

// FIX v5.17 (ordini rimasti "in corso" per sempre): popup.js e
// aggiungi_wishlist_popup.js tengono in chrome.storage.local un segnale con
// scadenza finché un controllo prezzi sta girando (rinnovato ogni 30s, scade
// da solo dopo 3 minuti se la pagina muore). Se è attivo, qui NON si
// prendono nuovi ordini di controllo prezzi: prenderli vorrebbe dire
// ricaricare la pagina dell'app (_apriOFocalizzaAppSuSezione) e uccidere a
// metà la sessione in corso, lasciando il suo ordine "in corso" per sempre.
// Gli ordini restano 'pending' e vengono presi al primo giro dopo la fine.
const _CHIAVI_SEGNALE_OCCUPATO = ['sessionePrezziAttiva_prezzi', 'sessionePrezziAttiva_wishlist'];
const _TIPI_ORDINE_PREZZI = ['controlla_prezzi', 'controlla_prezzi_sealed', 'controlla_prezzi_wishlist'];

async function _paginaPrezziOccupata() {
  try {
    const valori = await chrome.storage.local.get(_CHIAVI_SEGNALE_OCCUPATO);
    const ora = Date.now();
    return _CHIAVI_SEGNALE_OCCUPATO.some(k => valori[k] && typeof valori[k].scadenza === 'number' && valori[k].scadenza > ora);
  } catch (_) {
    return false;
  }
}

// ── UN SOLO LAVORO SU CARDMARKET ALLA VOLTA PER PC (v5.29) ───────────────────
// FIX ("prende due ordini insieme e apre tre tab per volta"): controllo
// prezzi (carte, sealed, wishlist) e coda "Aggiungi carte" (pagina dell'app
// e worker in background) giravano in parallelo, ognuno con la sua scheda
// Cardmarket. Ora su questo PC ne gira uno alla volta e chi arriva prima
// finisce (scelta di Claudio, 2026-10-16):
// - coda al lavoro → gli ordini di prezzi restano in attesa (qui sopra in
//   _controllaOrdini) e i controlli di prezzi avviati a mano aspettano;
// - controllo prezzi al lavoro (o in partenza) → la coda non prende carte
//   nuove dal database e le carte inserite a mano aspettano;
// - la coda non prende una carta arrivata DOPO un ordine di prezzi ancora in
//   attesa che questo PC può prendere: lascia passare prima l'ordine.
// Segnali con scadenza in chrome.storage.local, così una pagina che muore
// non blocca niente per sempre.
const _CHIAVE_CODA_PAGINA_ATTIVA = 'sessioneCodaAttiva_carte';  // scritto da aggiungi_carta_popup.js
const _CHIAVE_WORKER_AUTONOMO_ATTIVO = 'workerAutonomoAttivo'; // scritto da _lavoraCodaCarteAutonomo
const _CHIAVE_PREZZI_IN_PARTENZA = 'prezziInPartenza';          // scritto da _controllaOrdini, tolto dalle pagine a fine sessione
const _ORE_PRECEDENZA_ORDINI_PREZZI = 2; // stesso limite del controllo in inattività (popup.js)

function _segnaleVivo(v) {
  return !!v && typeof v.scadenza === 'number' && v.scadenza > Date.now();
}

// Ordine di prezzi preso ma non ancora partito: verifica login in corso,
// oppure flag per la pagina dell'app non ancora letto (al massimo 2 minuti).
async function _prezziInPartenzaQui() {
  try {
    const v = await chrome.storage.local.get([_CHIAVE_PREZZI_IN_PARTENZA, 'ordinePendenteAutorun', 'ordinePendenteAutorunSealed', 'ordinePendenteAutorunWishlist']);
    const flagRecente = (f) => !!f && typeof f.messoIl === 'number' && Date.now() - f.messoIl < 2 * 60 * 1000;
    return _segnaleVivo(v[_CHIAVE_PREZZI_IN_PARTENZA])
      || flagRecente(v.ordinePendenteAutorun) || flagRecente(v.ordinePendenteAutorunSealed) || flagRecente(v.ordinePendenteAutorunWishlist);
  } catch (_) {
    return false;
  }
}

async function _controlloPrezziOccupaQuestoPc() {
  return (await _paginaPrezziOccupata()) || (await _prezziInPartenzaQui());
}

async function _codaCardmarketOccupataQui() {
  try {
    const v = await chrome.storage.local.get([_CHIAVE_CODA_PAGINA_ATTIVA, _CHIAVE_WORKER_AUTONOMO_ATTIVO]);
    return _segnaleVivo(v[_CHIAVE_CODA_PAGINA_ATTIVA]) || _segnaleVivo(v[_CHIAVE_WORKER_AUTONOMO_ATTIVO]);
  } catch (_) {
    return false;
  }
}

// Vero se ADESSO questo PC prenderebbe un ordine di prezzi (stesse
// condizioni di _controllaOrdini, duplicate apposta — regola d'oro #1).
async function _puoPrendereOrdiniPrezziQui() {
  if ((await _leggiStatoLoginRicordato()) === false) return false;
  if (!(await _verificaVersioneAggiornata())) return false;
  if (!(await _lavoroPermessoSuQuestoPc())) return false;
  return true;
}

// Ordine di prezzi in attesa arrivato PRIMA della carta della coda con
// creato_il = creatoIlRiga, che questo PC può prendere: se c'è, la coda gli
// lascia il passo. Ordini più vecchi di 2 ore non contano (vedi popup.js,
// _ORE_ORDINI_PREZZI_IN_ATTESA: uno che nessuno può prendere non deve
// fermare la coda per sempre).
async function _ordinePrezziArrivatoPrima(creatoIlRiga) {
  try {
    if (!(await _puoPrendereOrdiniPrezziQui())) return null;
    const soglia = new Date(Date.now() - _ORE_PRECEDENZA_ORDINI_PREZZI * 60 * 60 * 1000).toISOString();
    let q = supabaseClient.from('ordini').select('id, tipo, creato_il')
      .eq('stato', 'pending').in('tipo', _TIPI_ORDINE_PREZZI).gt('creato_il', soglia)
      .order('creato_il', { ascending: true }).limit(1);
    if (creatoIlRiga) q = q.lt('creato_il', creatoIlRiga);
    const { data, error } = await q;
    if (error || !data || data.length === 0) return null;
    return data[0];
  } catch (_) {
    return null;
  }
}

// Risposta per le pagine dell'app e per il worker: la coda può prendere /
// lavorare una carta adesso? { attendi, motivo }.
// soloOccupato: controlla solo i lavori già in corso, non gli ordini in
// attesa (per le carte già in coda nella pagina).
async function _precedenzaCodaCardmarket({ creatoIlRiga = null, soloOccupato = false, escludiWorker = false } = {}) {
  if (await _controlloPrezziOccupaQuestoPc()) return { attendi: true, motivo: 'controllo-prezzi' };
  if (!escludiWorker) {
    const v = await chrome.storage.local.get(_CHIAVE_WORKER_AUTONOMO_ATTIVO);
    if (_segnaleVivo(v[_CHIAVE_WORKER_AUTONOMO_ATTIVO])) return { attendi: true, motivo: 'worker' };
  }
  if (!soloOccupato && (await _ordinePrezziArrivatoPrima(creatoIlRiga))) return { attendi: true, motivo: 'ordine-prima' };
  return { attendi: false, motivo: null };
}

// FIX v5.17: chiude da solo gli ordini rimasti 'in_corso' da più di 6
// ore (pagina chiusa o ricaricata a metà, PC spento...) — prima restavano
// "in corso" per sempre sul sito. Gira al massimo ogni 10 minuti e mai
// mentre un controllo prezzi sta girando su questo PC. Se una sessione
// lunghissima finisce davvero dopo la chiusura, la sua scrittura finale
// (per id) riporta comunque l'ordine a 'completato'.
// v5.40 (Fase 4.4, sql/120): lo fa il database (chiudi_ordini_abbandonati,
// SECURITY DEFINER) per gli ordini di CHIUNQUE — prima l'UPDATE da qui, per
// le policy, chiudeva solo quelli presi da questo account, e l'ordine preso
// dal PC spento di un altro restava "in corso". Le 6 ore contano
// dall'ultima attività dell'ordine (ordini.attivo_il, scritta a ogni lotto
// prenotato), non più dall'inizio: un ordine lungo ancora al lavoro non si
// chiude. Userid non serve più: resta nella firma per i chiamanti.
// v5.42: anche mentre su questo PC gira un controllo prezzi (prima no:
// "occupato" la saltava, e con un giro in inattività da 15 ore il PC non
// puliva per 15 ore — visto il 24/10). Il blocco serviva quando le 6 ore
// contavano dall'inizio dell'ordine; con l'ultima attività un ordine al
// lavoro non si chiude. "occupato" resta nella firma per i chiamanti.
const _ORE_ORDINE_ABBANDONATO = 6; // stessa soglia di sql/120 (e di "mi unisco" in popup.js)
let _ultimaPuliziaOrdini = 0;

async function _chiudiOrdiniAbbandonati(userId, occupato) { // eslint-disable-line no-unused-vars
  if (Date.now() - _ultimaPuliziaOrdini < 10 * 60 * 1000) return;
  _ultimaPuliziaOrdini = Date.now();
  try {
    const { data, error } = await supabaseClient.rpc('chiudi_ordini_abbandonati');
    if (error) console.error('[ordini] pulizia ordini abbandonati:', error.message);
    else if (data > 0) console.log('[ordini] chiusi ' + data + ' ordini senza attività da più di ' + _ORE_ORDINE_ABBANDONATO + ' ore');
  } catch (e) {
    console.error('[ordini] pulizia ordini abbandonati:', e.message);
  }
}

// v5.18: un solo giro alla volta. Prima ogni giro durava un attimo; ora un
// ordine di prezzi può aspettare la verifica del login Cardmarket (fino a
// ~45s) e la sveglia successiva (20s) non deve partire in parallelo.
let _controlloOrdiniInCorso = false;
let _ultimoAvvisoOrdiniPrezziEsclusi = 0; // v5.23: vedi motiviEsclusione in _controllaOrdini

async function _controllaOrdini() {
  if (_controlloOrdiniInCorso) return;
  _controlloOrdiniInCorso = true;
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return; // non loggato — niente da fare

    // v5.29: occupato anche mentre un ordine di prezzi sta partendo (verifica
    // login, apertura app) — prima in quel momento si poteva prendere un
    // secondo ordine di prezzi e partivano insieme.
    const occupato = (await _paginaPrezziOccupata()) || (await _prezziInPartenzaQui());
    await _chiudiOrdiniAbbandonati(userId, occupato);

    // FIX v5.18 (punto 25): senza login su Cardmarket ogni carta risulta
    // "Esaurita" — la sessione segnava comunque tutte le carte come
    // controllate (ferme per giorni), scriveva "Prezzo non trovato..." nelle
    // loro note e contava l'aiuto al gruppo. Ora questo PC NON prende ordini
    // di prezzi se il login non è confermato: restano 'pending' per un PC
    // che è loggato. Se l'esito ricordato è già "non loggato" li esclude
    // dalla lettura (come con "occupato"), così gli altri ordini (aggiungi
    // carte/wishlist, che non usano Cardmarket) vengono presi lo stesso.
    const loginNoRicordato = (await _leggiStatoLoginRicordato()) === false;

    // FIX v5.21: un'estensione rimasta indietro di versione prendeva lo
    // stesso gli ordini di prezzi, poi la sessione si fermava subito su
    // "Estensione non aggiornata" e l'ordine finiva in 'errore' (successo il
    // 2026-10-15 dopo l'uscita della 5.20). Ora li lascia 'pending' per un
    // PC aggiornato, come quando il login Cardmarket non è confermato.
    const versioneVecchia = !(await _verificaVersioneAggiornata());

    // v5.26: "Lavora anche a estensione chiusa" spento e nessuna scheda
    // dell'app aperta → niente ordini di prezzi (aprirebbero Cardmarket e
    // l'app in una scheda nascosta). Restano 'pending' per un altro PC o per
    // quando l'app viene aperta qui.
    const chiusaNonPermesso = !(await _lavoroPermessoSuQuestoPc());

    // v5.29 — un solo lavoro su Cardmarket alla volta per PC, chi arriva
    // prima finisce: con la coda "Aggiungi carte" al lavoro qui (pagina
    // dell'app o worker in background) gli ordini di prezzi restano in
    // attesa. Vedi _codaCardmarketOccupataQui.
    const codaOccupata = await _codaCardmarketOccupataQui();

    // v5.23: prima gli ordini di prezzi venivano esclusi in silenzio — da
    // fuori non si capiva perché restassero in attesa. Ora il motivo va nella
    // console del service worker (al massimo una volta ogni 2 minuti).
    const motiviEsclusione = [
      occupato && 'un controllo prezzi sta già girando su questo PC',
      codaOccupata && 'la coda "Aggiungi carte" sta lavorando su questo PC (un lavoro su Cardmarket alla volta)',
      loginNoRicordato && 'login Cardmarket non confermato (ultimo esito ricordato)',
      versioneVecchia && 'estensione non aggiornata',
      chiusaNonPermesso && '"Lavora anche a estensione chiusa" spento e app chiusa',
    ].filter(Boolean);
    if (motiviEsclusione.length > 0 && Date.now() - _ultimoAvvisoOrdiniPrezziEsclusi > 2 * 60 * 1000) {
      _ultimoAvvisoOrdiniPrezziEsclusi = Date.now();
      console.warn('[ordini] questo PC per ora non prende ordini di prezzi:', motiviEsclusione.join('; '));
    }

    let queryPendenti = supabaseClient
      .from('ordini')
      .select('id, tipo, parametri, creato_da')
      .eq('stato', 'pending');
    if (occupato || codaOccupata || loginNoRicordato || versioneVecchia || chiusaNonPermesso) queryPendenti = queryPendenti.not('tipo', 'in', `(${_TIPI_ORDINE_PREZZI.map(t => `"${t}"`).join(',')})`);
    const { data: pendenti, error: errLettura } = await queryPendenti
      .order('creato_il', { ascending: true })
      .limit(1);
    if (errLettura) { console.error('[ordini] errore lettura:', errLettura.message); return; }
    if (!pendenti || pendenti.length === 0) return;

    const ordine = pendenti[0];

    const ordinePrezzi = _TIPI_ORDINE_PREZZI.includes(ordine.tipo);
    if (ordinePrezzi) {
      // v5.29: da qui l'ordine "sta partendo" — la coda Aggiungi carte non
      // parte finché la sessione di prezzi non è avviata (vedi
      // _CHIAVE_PREZZI_IN_PARTENZA).
      await chrome.storage.local.set({ [_CHIAVE_PREZZI_IN_PARTENZA]: { scadenza: Date.now() + 2 * 60 * 1000 } });
      // Verifica PRIMA di prendere l'ordine: scheda in background, chiusa
      // sempre, mai in primo piano (vedi _verificaLoginAutomatica).
      const login = await _verificaLoginAutomatica();
      if (!login || login.loggato !== true) {
        await chrome.storage.local.remove(_CHIAVE_PREZZI_IN_PARTENZA);
        console.warn('[ordini] login Cardmarket non confermato su questo PC — ordine di prezzi lasciato in attesa per un altro PC.');
        return;
      }
    }

    // Claim ottimistico: la condizione .eq('stato','pending') nella UPDATE fa
    // sì che, se un altro dispositivo/sessione lo ha già preso un istante
    // prima, questa update non tocchi nessuna riga (claimato.length === 0) —
    // evita che due dispositivi partano sullo stesso ordine in parallelo.
    const { data: claimato, error: errClaim } = await supabaseClient
      .from('ordini')
      .update({ stato: 'in_corso', preso_in_carico_da: userId, preso_in_carico_il: new Date().toISOString() })
      .eq('id', ordine.id)
      .eq('stato', 'pending')
      .select();
    if (errClaim || !claimato || claimato.length === 0) {
      if (ordinePrezzi) await chrome.storage.local.remove(_CHIAVE_PREZZI_IN_PARTENZA); // v5.29
      if (errClaim) console.error('[ordini] errore claim:', errClaim.message);
      return; // errore, o già preso da un altro dispositivo
    }

    if (ordine.tipo === 'controlla_prezzi') {
      // Salvato in storage (non nell'URL) così sopravvive anche se la tab
      // era già aperta su un'altra sezione e va solo "spostata" — vedi FASE
      // SUCCESSIVA per come popup.js/app.js leggeranno questo valore.
      // FIX (controllo prezzi "solo le mie" controllava le carte sbagliate):
      // serve anche creato_da — chi ha effettivamente creato la richiesta
      // dal sito — non solo i parametri. Senza questo, "solo le mie" veniva
      // interpretato come "le carte di chi esegue l'ordine", non di chi
      // l'ha chiesto (vedi uso in popup.js → leggiDatiSheet → 'leggi').
      await chrome.storage.local.set({ ordinePendenteAutorun: { id: ordine.id, tipo: ordine.tipo, parametri: ordine.parametri || {}, creatoDa: ordine.creato_da, messoIl: Date.now() } });
      await _apriOFocalizzaAppSuPrezzi(ordine.id);
    } else if (ordine.tipo === 'controlla_prezzi_wishlist') {
      // v5.37 (Fase 2): la wishlist si controlla nella sezione Prezzi, con la
      // stessa sessione delle carte (popup.js, _avviaAutorunWishlistSeRichiesto)
      // e le funzioni di gruppo di sql/118: il proprietario è chi ha creato
      // l'ordine, letto dal database. Prima la apriva la sezione Wishlist, che
      // controllava la wishlist di chi eseguiva l'ordine.
      await chrome.storage.local.set({ ordinePendenteAutorunWishlist: { id: ordine.id, tipo: ordine.tipo, creatoDa: ordine.creato_da, messoIl: Date.now() } });
      await _apriOFocalizzaAppSuPrezzi(ordine.id);
    } else if (ordine.tipo === 'controlla_prezzi_sealed') {
      // Fase 1.2 (2026-09-12): stesso schema esatto di 'controlla_prezzi'
      // (carte) sopra, ma per prodotti_sealed — apre la stessa sezione
      // 'prezzi' (popup.js gira identico sia per carte sia per sealed,
      // vedi _avviaAutorunSealedSeRichiesto in popup.js), chiave di storage
      // separata per non entrare in conflitto con un eventuale ordine
      // 'controlla_prezzi' (carte) pendente nello stesso momento.
      await chrome.storage.local.set({ ordinePendenteAutorunSealed: { id: ordine.id, tipo: ordine.tipo, parametri: ordine.parametri || {}, creatoDa: ordine.creato_da, messoIl: Date.now() } });
      await _apriOFocalizzaAppSuPrezzi(ordine.id);
    } else if (ordine.tipo === 'aggiungi_carte') {
      // FIX (tab che continuava a riaprirsi da sola): tutti i tentativi
      // precedenti (contare le righe pending, poi un "campanello" one-shot)
      // finivano comunque per riaprire la tab in automatico prima o poi. Su
      // richiesta esplicita: l'estensione NON apre più nulla da sola per
      // questo tipo di ordine. Le carte restano semplicemente in attesa in
      // 'coda_carte' (persistente, non si perdono) finché qualcuno non apre
      // DAVVERO la sezione "Aggiungi Carte" — a quel punto (vedi
      // aggiungi_carta_popup.js) parte una lettura pulita dal database, mai
      // da uno stato locale salvato. Qui ci limitiamo a marcare l'ordine
      // come completato, senza alcuna azione sulle tab.
      await supabaseClient.from('ordini').update({
        stato: 'completato', completato_il: new Date().toISOString(),
      }).eq('id', ordine.id);
    } else if (ordine.tipo === 'aggiungi_wishlist') {
      // Stesso comportamento di 'aggiungi_carte': nessuna tab aperta in
      // automatico, l'ordine si chiude e basta. Le richieste wishlist del
      // sito stanno in coda_carte (destinazione 'wishlist') e le lavora la
      // sezione Carte; la sezione Wishlist non esiste più (v5.37).
      await supabaseClient.from('ordini').update({
        stato: 'completato', completato_il: new Date().toISOString(),
      }).eq('id', ordine.id);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'errore',
        errore_msg: `Tipo ordine "${ordine.tipo}" non ancora supportato dall'estensione.`,
        completato_il: new Date().toISOString(),
      }).eq('id', ordine.id);
    }
  } catch (e) {
    console.error('[ordini] errore imprevisto nel polling:', e);
  } finally {
    _controlloOrdiniInCorso = false;
  }
}

// Apre/aggiorna in SILENZIO (senza rubare il focus) una tab già aperta
// sull'estensione (qualunque sezione), navigandola sulla sezione richiesta,
// oppure ne apre una nuova in background. Usata SOLO dal polling ordini
// (automatico): l'utente sul sito non deve accorgersi che qualcosa si è
// aperto — l'apertura MANUALE (icona estensione, bottone "Apri l'app" del
// sito) resta invece a fuoco, vedi _apriOFocalizzaTabApp più sopra.
async function _apriOFocalizzaAppSuPrezzi(ordineId) {
  return _apriOFocalizzaAppSuSezione('prezzi', ordineId);
}

async function _apriOFocalizzaAppSuSezione(sezione, ordineId) {
  const urlApp = chrome.runtime.getURL('app.html');
  // FIX: la versione precedente faceva chrome.tabs.update({url: '...#prezzi'})
  // seguito da un chrome.tabs.reload() separato, per forzare un vero
  // caricamento (un cambio di solo hash non ricarica la pagina — comportamento
  // normale dei browser). Ma le due chiamate sono asincrone e indipendenti:
  // se il reload partiva prima che il cambio di hash fosse "commesso" dal
  // browser, la tab si ricaricava sulla URL VECCHIA (altra sezione), non su
  // #<sezione> — la tab "lampeggiava" (il reload si vedeva) ma la pagina
  // giusta non partiva mai in automatico, finché non si cambiava sezione a
  // mano. Aggiungere un parametro di QUERY (non solo l'hash), diverso ad
  // ogni ordine, risolve alla radice: un cambio di query string è sempre
  // trattato dal browser come una navigazione vera, quindi un SOLO
  // chrome.tabs.update con questa URL basta — nessuna doppia chiamata,
  // nessuna race condition.
  // SILENZIOSA (v4.1): active:false ovunque, e NESSUN chrome.windows.update
  // — prima questa funzione portava la tab/finestra in primo piano, "rubando"
  // lo schermo a chi stava semplicemente guardando il sito. La sessione di
  // controllo prezzi (dentro l'iframe di app.html) gira comunque anche a
  // tab non attiva: Chrome rallenta leggermente i timer delle tab in
  // background ma non le sospende, e c'è già il keepalive con chrome.alarms.
  const urlDestinazione = `${urlApp}?ordine=${encodeURIComponent(ordineId || Date.now())}#${sezione}`;
  const tabs = await chrome.tabs.query({ url: urlApp + '*' });
  if (tabs.length > 0) {
    const tab = tabs[0];
    // v5.40 (Fase 4.1, B6): con l'app già aperta niente più ricarica — si
    // perdevano le carte scritte a mano in "Aggiungi carte" e non ancora
    // lavorate. La pagina cambia sezione da sola e la sezione Prezzi legge
    // l'ordine dallo storage (ordinePendenteAutorun*, scritto prima di
    // chiamare qui) come all'apertura. Si naviga come prima solo se la
    // scheda non risponde entro 3 s (pagina ancora in caricamento, o di una
    // versione che non conosce il messaggio).
    if (await _avvisaAppGiaAperta(tab.id, sezione, ordineId)) return;
    await chrome.tabs.update(tab.id, { active: false, url: urlDestinazione });
  } else {
    await chrome.tabs.create({ url: urlDestinazione, active: false });
  }
}

// v5.40 (Fase 4.1): true se la scheda dell'app tabId ha cambiato sezione e
// avvisato la sezione (risposta di app.js a CARDSYNC_APRI_SEZIONE_ORDINE).
function _avvisaAppGiaAperta(tabId, sezione, ordineId) {
  return new Promise((resolve) => {
    let fatto = false;
    const fine = (ok) => { if (!fatto) { fatto = true; resolve(ok); } };
    setTimeout(() => fine(false), 3000);
    try {
      chrome.runtime.sendMessage({ type: 'CARDSYNC_APRI_SEZIONE_ORDINE', tabId, sezione, ordineId: ordineId || null }, (r) => {
        void chrome.runtime.lastError;
        fine(!!(r && r.ok));
      });
    } catch (_) {
      fine(false);
    }
  });
}

// ── WORKER TAB PERSISTENTE PER SESSIONE BULK ─────────────────────────────────
// FIX (troppe tab aperte in sequenza → trigger Cloudflare): il percorso
// "felice" (nessun blocco Cloudflare) apriva comunque UNA TAB NUOVA per ogni
// singola carta/prodotto, solo per leggere il prezzo (le .article-row sono
// iniettate via JS, serve sempre una tab vera per quello). Su una lista bulk
// di N carte questo significa N cicli apri→leggi→chiudi in sequenza, un
// pattern di navigazione molto più "meccanico" di un utente reale — un
// segnale forte per l'anti-bot di Cloudflare, indipendentemente dal ritardo
// configurato tra una richiesta e l'altra.
//
// Soluzione: un'unica tab "worker" viene creata la prima volta che serve e
// poi RIUSATA (chrome.tabs.update invece di tabs.create) per tutte le carte
// o i prodotti successivi della stessa sessione bulk — stesso pattern già
// usato per i singoli fallback Cloudflare (_risolviNomeEPrezzoUnicaTab), qui
// esteso a TUTTA la sessione invece che a una sola carta. L'id della tab
// worker è salvato in chrome.storage.local (sopravvive a un eventuale
// riavvio del service worker) e viene chiusa esplicitamente dal popup a fine
// sessione bulk (messaggio CHIUDI_WORKER_TAB) o ricreata al bisogno se nel
// frattempo non esiste più (es. l'utente l'ha chiusa a mano).
//
// Due worker tab separate — 'carte' e 'sealed' — così le due pagine bulk
// possono restare aperte e in uso contemporaneamente senza interferire.
function _chiaveWorkerTab(kind) { return 'workerTab_' + kind; }

async function _getWorkerTabId(kind) {
  const key = _chiaveWorkerTab(kind);
  const saved = await new Promise(r => chrome.storage.local.get([key], r));
  const tabId = saved[key];
  if (tabId == null) return null;
  const esiste = await new Promise(r => {
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab) r(false); else r(true);
    });
  });
  if (!esiste) {
    await new Promise(r => chrome.storage.local.remove([key], r));
    return null;
  }
  return tabId;
}

async function _salvaWorkerTabId(kind, tabId) {
  await new Promise(r => chrome.storage.local.set({ [_chiaveWorkerTab(kind)]: tabId }, r));
}

// Restituisce l'id di una tab pronta da riusare (creandone una vuota se
// nessuna sessione l'ha ancora registrata): chi la userà davvero ci naviga
// sopra con chrome.tabs.update, quindi non serve un URL reale qui.
async function _prontaWorkerTabId(kind) {
  // v5.29: una sola scheda Cardmarket alla volta — passando da carte a sealed
  // (o viceversa) si chiude quella dell'altro tipo, che resterebbe aperta e
  // ferma. Passa dalla coda di quel tipo: se la stesse usando qualcuno, si
  // chiude dopo il suo lavoro.
  const altro = kind === 'carte' ? 'sealed' : 'carte';
  if ((await _getWorkerTabId(altro)) != null) _accodaSuWorkerTab(altro, () => _chiudiWorkerTab(altro));
  const esistente = await _getWorkerTabId(kind);
  if (esistente != null) return esistente;
  const tab = await new Promise(r => chrome.tabs.create({ url: 'about:blank', active: false }, r));
  await _salvaWorkerTabId(kind, tab.id);
  return tab.id;
}

async function _chiudiWorkerTab(kind) {
  const key = _chiaveWorkerTab(kind);
  const saved = await new Promise(r => chrome.storage.local.get([key], r));
  const tabId = saved[key];
  if (tabId != null) {
    chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
    await new Promise(r => chrome.storage.local.remove([key], r));
  }
}

// ── LOCK PER KIND (evita che due flussi condividano la worker tab in contemporanea) ──
// FIX (race condition worker tab): _prontaWorkerTabId restituisce lo stesso
// tabId a qualunque chiamante lo richieda, senza alcun mutex. Se una carta
// nel pannello di correzione manuale viene aggiunta MENTRE una nuova sessione
// bulk è già partita (entrambe con usaWorkerTab:true, stesso kind), i due
// flussi eseguono chrome.tabs.update sulla stessa tab quasi in contemporanea:
// uno dei due può finire per leggere la pagina navigata dall'altro, con
// rischio di assegnare prezzo/nome sbagliati alla carta sbagliata — in modo
// silenzioso, senza errore visibile. Questa coda serializza per kind: ogni
// task che vuole usare la worker tab si accoda alla precedente e parte solo
// quando quella ha finito (con la tab libera per il task successivo).
const _codaWorkerTab = { carte: Promise.resolve(), sealed: Promise.resolve() };

function _accodaSuWorkerTab(kind, taskFn) {
  const k = kind === 'sealed' ? 'sealed' : 'carte';
  const esecuzione = _codaWorkerTab[k].then(taskFn, taskFn);
  // La coda avanza sempre, anche se il task corrente fallisce — un errore
  // isolato non deve bloccare per sempre le richieste successive per lo
  // stesso kind.
  _codaWorkerTab[k] = esecuzione.then(() => {}, () => {});
  return esecuzione;
}

// ── TURNO CARDMARKET UNICO PER TUTTA L'ESTENSIONE (v5.26) ─────────────────────
// FIX ("controlla troppo veloce, mi bannano"): ogni flusso (controllo prezzi
// carte e sealed, aggiungi carte/sealed, wishlist, ricontrollo prezzo
// mancante, worker autonomo) rispettava solo la PROPRIA attesa tra una carta
// e l'altra. Girando insieme — per esempio il worker autonomo, che con l'app
// aperta continua ad aiutare, durante un controllo prezzi — le richieste a
// Cardmarket si sommavano e il ritmo reale superava quello degli slider.
// Ora c'è un solo turno: chi vuole aprire Cardmarket per una carta prenota
// il turno qui, aspetta l'orario restituito, e a lavoro finito lo chiude.
// Tra due carte qualsiasi passa sempre almeno un'attesa casuale tra
// "Delay minimo" e "Delay massimo" (+1,2 s di margine per il riuso della
// tab, vedi popup.js). In più, ogni N carte (slider "Pausa lunga ogni N
// carte", contate su TUTTI i flussi insieme) si AGGIUNGE una pausa lunga di
// 60 s. Prima ogni flusso contava per conto suo, il worker autonomo non la
// faceva mai, e in aggiungi carte/wishlist la pausa lunga (30 s) prendeva il
// POSTO dell'attesa casuale — con slider sopra i 30 s la accorciava.
// Orario e contatore sono salvati in chrome.storage.local, così
// sopravvivono a un riavvio del service worker.
// v5.43 (Fase 6.1): il turno è l'UNICO a decidere l'attesa tra due carte,
// compreso il rallentamento dopo un Cloudflare. Prima popup.js (controllo
// prezzi carte e sealed) e la pagina Aggiungi carte aspettavano anche per
// conto loro (slider + rallentamento proprio) e poi il turno: con il worker
// in background, che il rallentamento non lo aveva, i ritmi erano tre.
// Ogni Cloudflare visto (al massimo uno per carta: _segnalaCloudflareAlTurno)
// alza il livello di 1, fino a 5; ogni carta finita senza Cloudflare lo
// abbassa di 1; ogni livello aggiunge 3 s all'attesa. Livello salvato come
// orario e contatore.
const _CHIAVE_TURNO_CM = 'turnoCardmarketDa';
const _CHIAVE_CONTA_CM = 'turnoCardmarketConta';
const _CHIAVE_LIVELLO_CF_CM = 'turnoCardmarketLivelloCf';
const _PASSO_CF_CM_MS = 3000;   // come il vecchio CF_ESCALATION_STEP_SEC dei popup
const _MAX_LIVELLO_CF_CM = 5;   // come il vecchio CF_ESCALATION_MAX_LEVEL
const _MARGINE_TURNO_CM_MS = 1200;
const _PAUSA_LUNGA_CM_MS = 60 * 1000;
const _PAUSA_OGNI_VALORI_CM = [25, 50, 75, 100, Infinity]; // stesso slider di app.js/popup.js
let _turnoCmDa = null;              // cache in memoria di _CHIAVE_TURNO_CM
let _contaCm = 0;                   // carte servite (per la pausa lunga)
let _pausaLungaDopoCartaCm = false; // la carta in corso è l'N-esima
let _motivoAttesaCm = null;         // 'pausa-lunga' se l'attesa in corso la include
let _codaTurnoCm = Promise.resolve(); // serializza prenotazioni e chiusure
let _livelloCfCm = 0;               // v5.43: rallentamento dopo Cloudflare (0-5)
let _cfInQuestaCartaCm = false;     // v5.43: Cloudflare già contato per la carta in corso

async function _pausaOgniCm() {
  const { sliderPausaOgni } = await chrome.storage.local.get('sliderPausaOgni');
  return _PAUSA_OGNI_VALORI_CM[sliderPausaOgni ?? 2] ?? 75; // default come app.js
}

async function _attesaSliderCmMs() {
  const s = await chrome.storage.local.get(['sliderDelayMinSec', 'sliderDelayMaxSec']);
  const min = Number.isFinite(s.sliderDelayMinSec) ? s.sliderDelayMinSec : 10;
  const max = Math.max(Number.isFinite(s.sliderDelayMaxSec) ? s.sliderDelayMaxSec : 20, min);
  return min * 1000 + Math.floor(Math.random() * (max - min) * 1000) + _MARGINE_TURNO_CM_MS
    + _livelloCfCm * _PASSO_CF_CM_MS; // v5.43
}

function _inCodaTurnoCm(fn) {
  const p = _codaTurnoCm.then(async () => {
    if (_turnoCmDa === null) {
      const salvato = await chrome.storage.local.get([_CHIAVE_TURNO_CM, _CHIAVE_CONTA_CM, _CHIAVE_LIVELLO_CF_CM]);
      _turnoCmDa = salvato[_CHIAVE_TURNO_CM] || 0;
      _contaCm = salvato[_CHIAVE_CONTA_CM] || 0;
      _livelloCfCm = Math.min(Math.max(salvato[_CHIAVE_LIVELLO_CF_CM] || 0, 0), _MAX_LIVELLO_CF_CM);
    }
    return fn();
  });
  _codaTurnoCm = p.catch(() => {});
  return p;
}

// Prenota il prossimo turno e restituisce { da, motivo }: da = orario (ms)
// da cui si può partire, motivo = 'pausa-lunga' se l'attesa include la
// pausa lunga. Il turno successivo è subito spostato di un'attesa intera
// (più la pausa lunga, se questa è l'N-esima carta), così due prenotazioni
// ravvicinate non partono mai insieme.
function _prenotaTurnoCardmarket() {
  return _inCodaTurnoCm(async () => {
    const inizio = Math.max(Date.now(), _turnoCmDa);
    const motivo = inizio > Date.now() ? _motivoAttesaCm : null;
    _motivoAttesaCm = null;
    _contaCm++;
    _pausaLungaDopoCartaCm = _contaCm % (await _pausaOgniCm()) === 0;
    _turnoCmDa = inizio + await _attesaSliderCmMs() + (_pausaLungaDopoCartaCm ? _PAUSA_LUNGA_CM_MS : 0);
    if (_pausaLungaDopoCartaCm) _motivoAttesaCm = 'pausa-lunga';
    await chrome.storage.local.set({ [_CHIAVE_TURNO_CM]: _turnoCmDa, [_CHIAVE_CONTA_CM]: _contaCm });
    return { da: inizio, motivo, livelloCf: _livelloCfCm };
  });
}

// v5.43 (Fase 6.1): solo lettura, senza prenotare — da quando può partire la
// prossima carta e il livello di rallentamento. La usa la pagina Aggiungi
// carte per il conto alla rovescia: il turno vero lo prende questo service
// worker quando arriva la richiesta della carta (_conTurnoCardmarket).
function _quandoTurnoCardmarket() {
  return _inCodaTurnoCm(async () => {
    const da = Math.max(Date.now(), _turnoCmDa);
    return { da, motivo: da > Date.now() ? _motivoAttesaCm : null, livelloCf: _livelloCfCm };
  });
}

// v5.43 (Fase 6.1): un Cloudflare visto durante la carta in corso, da
// qualunque flusso (schede del service worker con _suonaEPortaInPrimoPiano,
// controllo prezzi di popup.js con AVVIA_AVVISO_CLOUDFLARE). Conta una volta
// per carta: la chiusura del turno azzera il segno.
function _segnalaCloudflareAlTurno() {
  return _inCodaTurnoCm(async () => {
    if (_cfInQuestaCartaCm) return;
    _cfInQuestaCartaCm = true;
    _livelloCfCm = Math.min(_livelloCfCm + 1, _MAX_LIVELLO_CF_CM);
    console.log('[turno Cardmarket] Cloudflare: rallento, livello', _livelloCfCm);
    await chrome.storage.local.set({ [_CHIAVE_LIVELLO_CF_CM]: _livelloCfCm });
  });
}

// A lavoro finito sulla carta: la prossima non parte prima di un'attesa
// intera contata da ADESSO (la lettura di una pagina può durare parecchio),
// più la pausa lunga se questa era l'N-esima carta.
// v5.43: carta senza Cloudflare → rallentamento giù di un livello, prima di
// calcolare l'attesa (come facevano i popup).
function _chiudiTurnoCardmarket() {
  return _inCodaTurnoCm(async () => {
    const pausaLunga = _pausaLungaDopoCartaCm ? _PAUSA_LUNGA_CM_MS : 0;
    _pausaLungaDopoCartaCm = false;
    if (_cfInQuestaCartaCm) _cfInQuestaCartaCm = false;
    else if (_livelloCfCm > 0) _livelloCfCm--;
    _turnoCmDa = Math.max(_turnoCmDa, Date.now() + await _attesaSliderCmMs() + pausaLunga);
    await chrome.storage.local.set({ [_CHIAVE_TURNO_CM]: _turnoCmDa, [_CHIAVE_LIVELLO_CF_CM]: _livelloCfCm });
  });
}

// Attesa dentro il service worker: a pezzi da 5 s con una chiamata API
// leggera, che tiene vivo il service worker anche senza ping dal popup.
async function _attendiTurnoCardmarket() {
  const { da, motivo } = await _prenotaTurnoCardmarket();
  if (motivo === 'pausa-lunga') console.log('[turno Cardmarket] pausa lunga fino alle', new Date(da).toLocaleTimeString());
  while (Date.now() < da) {
    await new Promise(r => setTimeout(r, Math.min(5000, da - Date.now())));
    await chrome.runtime.getPlatformInfo();
  }
}

// Esegue fn (una carta) dentro il turno. I chiamanti che hanno già preso il
// turno da soli (popup.js, messaggio TURNO_CARDMARKET) mandano
// turnoGiaPreso:true e passano dritti.
async function _conTurnoCardmarket(message, fn) {
  if (message && message.turnoGiaPreso) return fn();
  await _attendiTurnoCardmarket();
  try {
    return await fn();
  } finally {
    _chiudiTurnoCardmarket();
  }
}

// Numero massimo di retry per carta (timeout Cardmarket o errore di rete)
const BULK_MAX_RETRY = 2;

// ── HEARTBEAT RICHIESTE LUNGHE (fix "resta bloccato su una carta finché non
// ricarico la pagina") ────────────────────────────────────────────────────
// FIX: le operazioni lunghe (attesa Cloudflare, polling prezzo) vivono
// dentro Promise con setTimeout/setInterval "normali" nel service worker.
// L'alarm sw-keepalive impedisce a Chrome di terminare il SW MENTRE è
// inattivo, ma NON protegge questi timer se Chrome decide comunque di
// terminare il SW a metà di un'attesa lunga (evento raro ma non escluso in
// MV3, soprattutto con tab in background). Quando succede, tutta la catena
// di callback/Promise relativa a quella carta sparisce col SW: il popup
// resta in attesa di una risposta che non arriverà mai, bloccato fino al
// proprio timeout (dimensionato su sliderCfTimeout, fino a 10 minuti) — e a
// volte nemmeno quello lo sblocca perché il canale del messaggio non genera
// sempre un errore "port closed" in questo scenario.
//
// Soluzione: ogni richiesta lunga porta un requestId generato dal popup.
// Il background aggiorna un timestamp "ultima attività" per quel requestId
// a ogni tick del polling (ogni 600ms-2s a seconda della fase). Il popup,
// in parallelo all'attesa della risposta vera, manda un ping leggero
// (PING_RICHIESTA) ogni pochi secondi: se il SW risponde "richiesta non
// trovata" (= è stato riavviato e ha perso lo stato) o non risponde affatto
// per un paio di controlli consecutivi, il popup abbandona l'attesa e passa
// alla carta successiva invece di restare bloccato fino al timeout lungo.
const _richiesteAttive = new Map(); // requestId -> { tabId, ultimaAttivita }

function _touchRichiesta(requestId, tabId) {
  if (!requestId) return;
  const esistente = _richiesteAttive.get(requestId);
  _richiesteAttive.set(requestId, {
    tabId: tabId != null ? tabId : (esistente ? esistente.tabId : null),
    ultimaAttivita: Date.now(),
  });
}

function _rimuoviRichiesta(requestId) {
  if (!requestId) return;
  _richiesteAttive.delete(requestId);
}

// Pulizia periodica di eventuali richieste "orfane" dimenticate in mappa
// (non dovrebbe succedere: rimosse esplicitamente a fine richiesta — questo
// è solo un anti-leak di sicurezza), agganciata all'alarm già esistente.
function _pulisciRichiesteVecchie() {
  const LIMITE_MS = 20 * 60 * 1000; // 20 minuti
  const ora = Date.now();
  for (const [id, info] of _richiesteAttive.entries()) {
    if (ora - info.ultimaAttivita > LIMITE_MS) _richiesteAttive.delete(id);
  }
}

// Legge le opzioni Cloudflare configurate dall'utente, condivise con popup.js:
//   sliderCfTimeout → minuti di attesa (1–10, default 3)
//   avvisoSonoro    → suona quando Cloudflare viene rilevato (default true)
// Un'unica fonte di verità: cambiare le impostazioni in popup.js vale anche
// per il flusso bulk, senza configurazioni duplicate.
function _leggiOpzioniCf() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['sliderCfTimeout', 'avvisoSonoro'], (res) => {
      const minuti = (typeof res.sliderCfTimeout === 'number' && res.sliderCfTimeout >= 1)
        ? res.sliderCfTimeout
        : 3; // default coerente con DEFAULTS.sliderCfTimeout in popup.js
      const avvisoSonoro = res.avvisoSonoro !== false; // default true
      resolve({ cfTimeoutMs: minuti * 60 * 1000, avvisoSonoro });
    });
  });
}

let cloudflareAlarmTabId = null;
let cloudflareAlarmActive = false;

// ── WATCHDOG PERSISTENTE PER L'ATTESA CLOUDFLARE ─────────────────────────────
// FIX (bug "non rispetta l'attesa configurata"): il countdown di Cloudflare
// (sia il suono ripetuto sia la chiusura forzata dopo N minuti) viveva SOLO
// nelle variabili di modulo qui sopra (cloudflareAlarmTabId ecc.) più un
// singolo alarm one-shot 'cloudflare-timeout'. In MV3 il service worker può
// essere terminato e riavviato da Chrome in QUALSIASI momento durante
// un'attesa di più minuti (è la norma, non l'eccezione, per attese così
// lunghe) — quando succede, quelle variabili tornano a null e l'eventuale
// alarm 'cloudflare-timeout' si risveglia senza più trovare nulla da fare:
// la tab resta aperta indefinitamente, o il countdown mostrato all'utente
// smette di corrispondere a quello che succede davvero.
//
// Fix: la scadenza di ogni attesa Cloudflare attiva viene salvata in
// chrome.storage.local (sopravvive ai riavvii del SW, a differenza delle
// variabili JS), e un alarm dedicato 'cf-watchdog' — con periodo di 1 minuto,
// il minimo concesso da chrome.alarms per le estensioni pacchettizzate — la
// controlla a ogni risveglio: se una scadenza è superata, chiude la tab e
// pulisce lo stato, indipendentemente dal fatto che le variabili di modulo
// originali siano ancora vive o siano già sparite con un riavvio del SW.
// Così il tempo configurato resta un limite massimo affidabile in ogni caso.
async function _registraAttesaCf(tabId, minuti) {
  const scadenza = Date.now() + minuti * 60 * 1000;
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  attese[tabId] = scadenza;
  await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  // Un minuto basta: le attese durano minuti. v5.40: creata solo se manca,
  // così ogni nuova attesa non fa ripartire il conto della sveglia.
  _creaSvegliaSeManca('cf-watchdog', 1);
}

async function _rimuoviAttesaCf(tabId) {
  if (tabId === null || tabId === undefined) return;
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  if (attese[tabId] !== undefined) {
    delete attese[tabId];
    await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  }
}

async function _controllaWatchdogCf() {
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  const ora = Date.now();
  let cambiato = false;
  for (const [tabIdStr, scadenza] of Object.entries(attese)) {
    if (ora > scadenza) {
      const tabId = parseInt(tabIdStr, 10);
      chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
      // Notifica il popup (flusso "Avvia") esattamente come faceva prima
      // l'alarm 'cloudflare-timeout' — nessuna modifica richiesta lato
      // popup.js, che ha già un listener per questo messaggio.
      chrome.runtime.sendMessage({ type: 'CLOUDFLARE_TIMEOUT', tabId }).catch(() => {});
      delete attese[tabIdStr];
      cambiato = true;
    }
  }
  if (cambiato) await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  // Nessuna attesa attiva rimasta → l'alarm periodico non serve più finché
  // non ne riparte una nuova (_registraAttesaCf lo ricrea al bisogno).
  if (Object.keys(attese).length === 0) chrome.alarms.clear('cf-watchdog');
}

// FIX (migrazione Supabase): con il vecchio Google Apps Script serviva un
// intero sistema di verifica/tracking anti-duplicato (vedi CHANGELOG per la
// storia completa) perché un fallimento di rete lato client non garantiva
// che la scrittura non fosse comunque avvenuta lato server. Supabase
// (PostgREST) non ha questa ambiguità — vedi _aggiungiConVerifica più sotto,
// ora molto più semplice.

// FIX (migrazione Supabase): con il vecchio Google Apps Script, un timeout
// di rete lasciava un dubbio legittimo — "la scrittura è avvenuta o no?" —
// da qui tutta la logica di verifica/anti-duplicato qui sotto. Supabase
// (PostgREST) risponde in modo affidabile: o la scrittura riesce (e lo sai
// subito), o fallisce con un errore chiaro, senza stati ambigui. Questa
// funzione resta con lo stesso nome/firma (per non toccare i chiamanti) ma
// il suo corpo è ora un semplice inserimento con un paio di ritentativi in
// caso di problemi di rete transitori — niente più ricerca/dedup a valle.
// destinazione: 'wishlist' instrada alla tabella wishlist (azione
// 'aggiungiWishlist') invece che alla collezione — coda UNICA (coda_carte),
// non più due code separate, vedi coda_unificata.sql.
// ── IMMAGINE → DATA URI (bypassa CORS) ───────────────────────────────────────
// FIX (immagine mai visibile sul sito, tentativo precedente fallito): un
// primo tentativo scaricava l'immagine DENTRO la pagina Cardmarket (via
// chrome.scripting.executeScript) sperando che il referer corretto bastasse
// — ma il bucket S3 di Cardmarket non manda le intestazioni CORS, quindi
// anche da lì il download veniva bloccato dal browser (JS di pagina, CORS
// pieno). Le estensioni Chrome però hanno un privilegio speciale: un fetch
// fatto da background.js (qui, non dentro la pagina) IGNORA il CORS, a patto
// che il dominio sia dichiarato in host_permissions nel manifest — l'ho
// aggiunto (product-images.s3.cardmarket.com). Nota: i Service Worker (dove
// gira questo file in Manifest V3) non hanno FileReader — la conversione in
// base64 si fa a mano con btoa() a blocchi, per non superare il limite di
// argomenti di String.fromCharCode su immagini più pesanti.
// Nome file deterministico basato sull'URL originale (hash) — così la
// STESSA immagine (es. "Charizard ex" cercata da due persone diverse in
// momenti diversi) riusa lo stesso file su Storage invece di duplicarlo
// ogni volta.
async function _hashUrl(url) {
  const dati = new TextEncoder().encode(url);
  const buffer = await crypto.subtle.digest('SHA-256', dati);
  return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 24);
}

async function _immagineAUrlDati(url) {
  if (!url) return null;
  try {
    const resp = await fetch(url);
    if (!resp.ok) { console.warn('[immagine] risposta non ok (' + resp.status + '), tengo URL originale'); return url; }
    const buffer = await resp.arrayBuffer();
    // .split(';')[0]: ripulisce eventuali parametri extra (es.
    // "image/jpeg;charset=...") che Supabase Storage rifiuta con "Invalid
    // Content-Type header" se lasciati nel valore.
    let tipo = (resp.headers.get('content-type') || '').split(';')[0].trim();
    // FIX (upload che falliva sempre su un sottoinsieme di immagini più
    // vecchie del catalogo Cardmarket): per alcune immagini Cardmarket
    // manda un header Content-Type spazzatura — es. la stringa letterale
    // "multerS3.AUTO_CONTENT_TYPE", un residuo interno del loro sistema —
    // invece di un vero tipo MIME come "image/jpeg". Supabase Storage
    // rifiutava l'upload con "Invalid Content-Type header" e il codice
    // faceva fallback silenzioso all'URL Cardmarket grezzo, che Cardmarket
    // poi blocca in hotlinking da altri domini: l'immagine non si vedeva
    // mai. Ora, se l'header ricevuto non è un vero tipo immagine (non
    // inizia per "image/"), lo ignoriamo e ricaviamo il tipo dall'
    // estensione del file nell'URL, con image/jpeg come default.
    if (!tipo.startsWith('image/')) {
      const estensioneUrl = (url.split('?')[0].split('.').pop() || '').toLowerCase();
      tipo = estensioneUrl === 'png' ? 'image/png' : (estensioneUrl === 'webp' ? 'image/webp' : 'image/jpeg');
    }
    const estensione = tipo.includes('png') ? 'png' : (tipo.includes('webp') ? 'webp' : 'jpg');
    const nomeFile = (await _hashUrl(url)) + '.' + estensione;

    // FIX (database appesantito): prima l'immagine veniva convertita in
    // base64 e infilata direttamente nella colonna 'immagine' — con
    // 1300+ carte, decine di MB di puro testo dentro il database. Ora
    // viene caricata su Supabase Storage (fatto apposta per i file) e
    // nella colonna resta solo un link leggero.
    // FIX (bug [16]): qui c'era una chiamata a supabaseClient.auth.getSession()
    // il cui risultato non veniva mai usato nel resto della funzione —
    // overhead asincrono inutile ad ogni conversione immagine, rimossa.
    const { error: errUpload } = await supabaseClient.storage
      .from('immagini-carte')
      .upload(nomeFile, buffer, { contentType: tipo, upsert: true });
    if (errUpload) { console.error('[immagine] errore upload su Storage:', errUpload.message, errUpload); return url; }

    const { data: pub } = supabaseClient.storage.from('immagini-carte').getPublicUrl(nomeFile);
    return pub.publicUrl;
  } catch (e) {
    console.error('[immagine] errore nella conversione:', e.message, e);
    return url; // fallback silenzioso: tiene l'URL esterno originale
  }
}

async function _aggiungiConVerifica(rigaDati, tentativiMax = 3, tipo, destinazione, dbRigaId) {
  let ultimoErrore;
  for (let tentativo = 0; tentativo < tentativiMax; tentativo++) {
    try {
      const data = destinazione === 'wishlist'
        ? await chiamaSupabase('aggiungiWishlist', { rigaDati, tipo, dbRigaId })
        : await chiamaSupabase('aggiungi', { rigaDati, tipoOverride: tipo, destinazione, dbRigaId });
      return data; // successo o errore applicativo — in entrambi i casi non si ritenta
    } catch (e) {
      ultimoErrore = e;
      if (tentativo < tentativiMax - 1) await new Promise(r => setTimeout(r, 1000 * (tentativo + 1)));
    }
  }
  return { ok: false, errore: 'Impossibile aggiungere la carta dopo ' + tentativiMax + ' tentativi: ' + (ultimoErrore ? ultimoErrore.message : '?') };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'AVVIA_AVVISO_CLOUDFLARE') {
    cloudflareAlarmTabId = message.tabId;
    cloudflareAlarmActive = true;
    _segnalaCloudflareAlTurno(); // v5.43 (6.1): il controllo prezzi di popup.js rallenta dal turno
    _suonaEPortaInPrimoPiano(message.tabId, message.avvisoSonoro);
    // Avviso sonoro ogni 30 secondi (v5.40: prima chiesti 8 s, ma Chrome non
    // scende sotto i 30; best-effort: se il SW si riavvia nel
    // frattempo il suono può saltare qualche ripetizione, ma non è critico
    // — a differenza della scadenza, gestita ora dal watchdog persistente
    // qui sotto, che non dipende da queste variabili di modulo).
    _creaSvegliaSeManca('cloudflare-avviso', 0.5);
    // Timeout configurabile dall'utente (default 3 min se non specificato)
    const timeoutMinuti = (typeof message.timeoutMinuti === 'number' && message.timeoutMinuti >= 1)
      ? message.timeoutMinuti
      : 3;
    // FIX: sostituisce il vecchio alarm one-shot 'cloudflare-timeout' (perdeva
    // lo stato se il SW si riavviava prima di scattare) con il watchdog
    // persistente — vedi commento su _registraAttesaCf più sopra.
    _registraAttesaCf(message.tabId, timeoutMinuti);
    return false;
  }

  if (message.type === 'FERMA_AVVISO_CLOUDFLARE') {
    _fermaAvvisi();
    return false;
  }

  if (message.type === 'PING_RICHIESTA') {
    // FIX (bug "resta bloccato su una carta"): risposta leggera e immediata
    // — nessuna attesa di rete o tab. Se il SW è stato riavviato dopo la
    // registrazione di questa richiesta, _richiesteAttive è vuota (la mappa
    // è in memoria, non sopravvive al riavvio) e "attiva" torna false: è il
    // segnale che il popup usa per capire che la carta è da considerare
    // orfana, anche se il SW stesso ora risponde regolarmente.
    const info = _richiesteAttive.get(message.requestId);
    sendResponse({ attiva: !!info, ultimaAttivita: info ? info.ultimaAttivita : null });
    return false;
  }

  if (message.type === 'CHIUDI_WORKER_TAB') {
    // FIX (troppe tab in sequenza → Cloudflare): chiude la tab worker
    // riusata per una sessione bulk (carte o sealed), inviato dal popup a
    // fine sessione o al reset — vedi _prontaWorkerTabId più sopra.
    // v5.17: la chiusura passa dalla stessa coda per kind dei task che usano
    // la worker tab (_accodaSuWorkerTab): se un altro flusso la sta usando
    // in quel momento (es. la coda dell'hub mentre finisce il controllo
    // prezzi sealed, o la wishlist che usa la tab 'carte'), la tab si chiude
    // DOPO il suo task invece di sparirgli sotto i piedi. Il task successivo,
    // se arriva, ne apre una nuova (_prontaWorkerTabId).
    const kindChiusura = message.kind || 'carte';
    _accodaSuWorkerTab(kindChiusura, () => _chiudiWorkerTab(kindChiusura)).then(() => sendResponse({ ok: true }));
    return true;
  }

  // v5.26 — turno Cardmarket per i flussi che aprono Cardmarket da soli
  // (controllo prezzi in popup.js): 'prenota' risponde subito con l'orario
  // da cui partire (l'attesa, con il conto alla rovescia, la fa il popup),
  // 'chiudi' a lavoro finito. Vedi _prenotaTurnoCardmarket.
  // v5.29 — Le pagine dell'app chiedono se la coda "Aggiungi carte" può
  // prendere/lavorare una carta adesso (un lavoro su Cardmarket alla volta,
  // vedi _precedenzaCodaCardmarket).
  if (message.type === 'PRECEDENZA_CODA_CARDMARKET') {
    _precedenzaCodaCardmarket({ creatoIlRiga: message.creatoIlRiga || null, soloOccupato: !!message.soloOccupato })
      .then((r) => sendResponse({ ok: true, attendi: r.attendi, motivo: r.motivo }))
      .catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }

  if (message.type === 'TURNO_CARDMARKET') {
    const azione = message.fase === 'chiudi' ? _chiudiTurnoCardmarket()
      : message.fase === 'quando' ? _quandoTurnoCardmarket() // v5.43: solo lettura
      : _prenotaTurnoCardmarket();
    azione.then((r) => sendResponse({ ok: true, da: (r && r.da) || null, motivo: (r && r.motivo) || null, livelloCf: (r && r.livelloCf) || 0 }))
      .catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }

  if (message.type === 'APRI_URL_WORKER_TAB') {
    // FIX (troppe tab in sequenza → Cloudflare): il bottone 🔗 "Apri ricerca
    // Cardmarket" nel pannello di correzione manuale apriva sempre una tab
    // NUOVA con chrome.tabs.create — su una sessione con più carte/prodotti
    // da correggere a mano, ognuna apriva la propria tab in aggiunta a
    // quella già usata per la lettura automatica, accumulandone diverse in
    // sequenza: lo stesso pattern di navigazione "meccanico" che altrove in
    // questo file è già stato identificato come segnale per l'anti-bot di
    // Cloudflare. Ora riusa la STESSA worker tab della sessione bulk
    // (_prontaWorkerTabId), portandola semplicemente in primo piano con
    // l'URL di ricerca — stesso comportamento per l'utente (vede la pagina
    // di ricerca), una tab in meno da gestire.
    // FIX (race condition worker tab): questo ramo navigava la worker tab
    // con chrome.tabs.update SENZA passare dalla coda _accodaSuWorkerTab —
    // l'unico punto in tutto il file che bypassava la serializzazione per
    // kind introdotta apposta per evitare che due flussi si contendano la
    // stessa tab in contemporanea (vedi commento esteso su
    // _accodaSuWorkerTab più sopra). Un click su 🔗 mentre un'altra
    // operazione sulla stessa worker tab è ancora in corso (es. un
    // ricontrollo prezzo mancante, o un "➕ Aggiungi" di un'altra carta in
    // correzione) poteva quindi navigare la tab a metà di quella lettura,
    // facendo leggere all'altro task la pagina di ricerca sbagliata invece
    // della propria — lo stesso tipo di bug che la coda era stata introdotta
    // per prevenire. Ora anche questo ramo si accoda, come tutti gli altri
    // usi di usaWorkerTab.
    (async () => {
      const kind = message.kind || 'carte';
      await _accodaSuWorkerTab(kind, async () => {
        const tabId = await _prontaWorkerTabId(kind);
        await new Promise((resolve) => {
          chrome.tabs.update(tabId, { url: message.url, active: true }, (tab) => {
            if (chrome.runtime.lastError || !tab) {
              chrome.tabs.create({ url: message.url, active: true }, (nuovaTab) => {
                _salvaWorkerTabId(kind, nuovaTab.id).then(() => { sendResponse({ ok: true }); resolve(); });
              });
              return;
            }
            chrome.windows.update(tab.windowId, { focused: true }, () => { sendResponse({ ok: true }); resolve(); });
          });
        });
      });
    })();
    return true;
  }

  // v5.40 (Fase 4.11): tolto APRI_TAB_CONTROLLO_LOGIN (bottone "Controlla
  // connessione", scheda sempre in primo piano): il bottone ora usa
  // VERIFICA_LOGIN_SILENZIOSA come l'avvio a mano di una sessione.

  if (message.type === 'VERIFICA_LOGIN_SILENZIOSA') {
    // Usato automaticamente prima di avviare una sessione (dopo la conferma
    // sul modale "Team Rocket") — vedi _verificaLoginSilenziosa più sotto.
    // FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa un
    // kind ('carte'/'sealed'), il controllo login riusa la worker tab della
    // sessione bulk invece di aprirne una a parte — una tab in meno prima
    // di ogni sessione. Il popup principale (controllo prezzi) non ha un
    // kind/worker tab dedicato in background.js, quindi continua a passare
    // undefined e a usare il vecchio percorso "tab a sé stante".
    _verificaLoginSilenziosa(message.kind || null)
      .then(esito => sendResponse(esito))
      .catch(() => sendResponse({ loggato: null }));
    return true;
  }

  if (message.type === 'VERIFICA_LOGIN_AUTOMATICA') {
    // v5.18 (punto 25): per i giri automatici di popup.js e
    // aggiungi_wishlist_popup.js (inattività, "mi unisco") — scheda in
    // background chiusa sempre, mai in primo piano, esito ricordato. Vedi
    // _verificaLoginAutomatica. In caso di errore: non loggato (si salta).
    _verificaLoginAutomatica()
      .then(esito => sendResponse(esito))
      .catch(() => sendResponse({ loggato: false }));
    return true;
  }

  if (message.type === 'STATO_LOGIN_CARDMARKET') {
    // v5.23: content.js, su QUALUNQUE pagina Cardmarket aperta (anche a mano),
    // dice se l'intestazione mostra l'account. "Loggato" diventa subito
    // l'esito ricordato per i giri automatici: dopo un login fatto a mano gli
    // ordini di prezzi dal sito ripartono al giro successivo (20 s), senza
    // dover premere Avvia. Solo "loggato": il "non loggato" resta compito
    // delle verifiche vere (_leggiStatoLoginCardmarket).
    const daCardmarket = !!(sender && sender.tab && typeof sender.url === 'string' && sender.url.startsWith('https://www.cardmarket.com/'));
    if (daCardmarket && message.loggato === true) _ricordaStatoLoginCardmarket(true);
    return false;
  }

  // FIX (immagine mai visibile dal controllo prezzi): content.js gira
  // DENTRO la pagina Cardmarket — stesso limite di CORS di qualunque script
  // di pagina, non può scaricare l'immagine da sé (vedi _immagineAUrlDati
  // più sopra per il perché). Manda quindi solo l'URL grezzo qui, e QUI
  // (background.js, privilegio di estensione, CORS bypassato sui domini in
  // host_permissions) lo convertiamo davvero prima di scrivere sul database.
  if (message.type === 'CONVERTI_IMMAGINE') {
    _immagineAUrlDati(message.url || null).then((dataUri) => sendResponse({ immagine: dataUri }));
    return true;
  }

  if (message.type === 'AGGIUNGI_CARTA') {
    const { rigaDati, azione, codice, lingua, condizione, riga, qty, prezzo, immagine, nome, tipo, destinazione, dbRigaId } = message;

    // Nessuna azione specificata → è una nuova carta/prodotto da aggiungere.
    if (!azione) {
      _aggiungiConVerifica(rigaDati, 3, tipo, destinazione, dbRigaId)
        .then(data => sendResponse(data))
        .catch(err => sendResponse({ ok: false, errore: err.message }));
      return true;
    }

    let promessa;
    if (azione === 'cerca') {
      promessa = chiamaSupabase('cerca', { codice, lingua, condizione });
    } else if (azione === 'cercaBulk') {
      promessa = chiamaSupabase('cercaBulk', { richieste: message.richieste });
    } else if (azione === 'aggiornaQty') {
      promessa = chiamaSupabase('aggiornaQty', { riga, qty });
    } else {
      // v5.39: tolta l'azione 'aggiornaPrezzo' (ricontrollo dopo il
      // salvataggio): il prezzo mancante si rilegge prima di salvare. Un'azione
      // sconosciuta ora risponde con un errore: prima finiva qui e aggiungeva
      // una carta nuova (le aggiunte vere arrivano senza "azione", sopra).
      promessa = Promise.resolve({ ok: false, errore: `Azione "${azione}" non gestita.` });
    }
    promessa
      .then(data => sendResponse(data))
      .catch(err => sendResponse({ ok: false, errore: err.message }));
    return true;
  }

  // FIX (pulizia codice morto): rimossi gli handler 'FETCH_IMMAGINE' e
  // 'LEGGI_NOME_SEALED' — nessun punto del progetto (nessuno dei tre popup)
  // invia più questi due tipi di messaggio, superati rispettivamente da:
  // l'estrazione immagine inline nelle funzioni di lettura già esistenti
  // (_estraiImmagineDaHtml chiamata direttamente dove serve), e da
  // 'LEGGI_SEALED' (stessa logica ma completa del wiring requestId/
  // heartbeat per il watchdog anti-blocco — vedi _touchRichiesta/
  // _rimuoviRichiesta). Tenerli in giro come codice morto era un rischio
  // silenzioso: 'LEGGI_NOME_SEALED' in particolare non passava mai
  // requestId a _leggiNomeSealedDaCardmarket, quindi se richiamato per
  // errore in futuro (es. codice copiato dal punto sbagliato) avrebbe
  // fallito silenziosamente la protezione watchdog già corretta altrove,
  // lasciando una sessione bloccata su un prodotto senza alcun avviso.

  if (message.type === 'LEGGI_NOME_CARTA') {
    // FIX (troppe tab in sequenza → Cloudflare): durante una sessione bulk
    // riusiamo un'unica tab worker per leggere il prezzo di tutte le carte
    // (message.usaWorkerTab, impostato solo dal ciclo bulk) invece di aprirne
    // e chiuderne una per ciascuna — vedi _prontaWorkerTabId più sopra.
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('carte') : null;
        // FIX (bug "resta bloccato su una carta"): registra la richiesta
        // nell'heartbeat — vedi commento esteso su _richiesteAttive più sopra.
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const r = await _conTurnoCardmarket(message, () => _leggiNomeDaCardmarket(message.urlNome, message.lingua, message.condizione, message.oloType || '', !!message.firstEd, 0, tabIdWorker, requestId, message.urlRicercaRiserva || null));
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: r.nome, codice: r.codice, prezzo: r.prezzo, urlSingles: r.urlSingles, disambiguation: !!r.disambiguation, varianteNonTrovata: !!r.varianteNonTrovata, opzioni: r.opzioni || [], immagine: r.immagine || null, rateLimited: !!r.rateLimited, linkNonValido: !!r.linkNonValido, linkSostituito: !!r.linkSostituito });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: false, varianteNonTrovata: false, rateLimited: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('carte', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_SEALED') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const r = await _conTurnoCardmarket(message, () => _leggiNomeSealedDaCardmarket(message.urlNome, message.lingua, 0, tabIdWorker, requestId));
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: r.nome, urlProdotto: r.urlProdotto, prezzo: r.prezzo, immagine: r.immagine || null, disambiguation: !!r.disambiguation, opzioni: r.opzioni || [], rateLimited: !!r.rateLimited });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: false, rateLimited: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  // ── RICONTROLLO PREZZO MANCANTE ──────────────────────────────────────────
  // Usati dal bulk (carte/sealed) quando la carta/prodotto è stato inserito
  // nel foglio ma senza prezzo: dopo un delay configurabile si rilegge SOLO
  // il prezzo dalla pagina già nota (urlSingles/urlProdotto), senza rifare
  // tutta la risoluzione nome/codice.
  if (message.type === 'LEGGI_SOLO_PREZZO') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('carte') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const { prezzo, immagine, nome, codice, tabId } = await _conTurnoCardmarket(message, () => _leggiPrezzoDaSingles(message.urlConFiltri, tabIdWorker, requestId));
          _rimuoviRichiesta(requestId);
          // FIX: se la worker tab passata non era più valida, ne è stata
          // aperta una nuova al volo — aggiorna subito lo storage così la
          // prossima chiamata della sessione la trova e la riusa.
          if (tabIdWorker != null && tabId && tabId !== tabIdWorker) await _salvaWorkerTabId('carte', tabId);
          sendResponse({
            prezzo: (prezzo === 'RateLimit' ? null : prezzo) ?? null,
            immagine: immagine || null,
            // FIX: propaga nome/codice riletti dalla stessa tab del
            // ricontrollo prezzo — usati dal chiamante come rete di sicurezza
            // per le righe salvate a suo tempo senza nome (vedi background.js,
            // commento su _leggiPrezzoDaSingles/chiudi()).
            nome: nome || null,
            codice: codice || null,
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null, codice: null });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('carte', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_SOLO_PREZZO_SEALED') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const ris = await _conTurnoCardmarket(message, () => _leggiPrezzoSealed(message.urlProdotto, tabIdWorker, requestId));
          _rimuoviRichiesta(requestId);
          if (tabIdWorker != null && ris && ris.tabId && ris.tabId !== tabIdWorker) await _salvaWorkerTabId('sealed', ris.tabId);
          sendResponse({
            prezzo: (ris && !ris.rateLimited) ? (ris.prezzo ?? null) : null,
            immagine: (ris && ris.immagine) || null,
            // FIX: propaga il nome riletto dalla stessa tab del ricontrollo
            // prezzo — rete di sicurezza per i prodotti sealed salvati a suo
            // tempo senza nome.
            nome: (ris && ris.nome) || null,
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  // ── CONTROLLO PREZZI DI GRUPPO — SEALED (Fase 1.2, 2026-09-12) ───────────
  // Copia dedicata di LEGGI_SOLO_PREZZO_SEALED sopra, NON quella riusata:
  // quella squaltisce rateLimited/cloudflareTimeout dentro un prezzo:null
  // generico (va bene per il suo uso, il ricontrollo prezzo mancante nel
  // bulk), ma il loop di controllo prezzi di gruppo in popup.js
  // (eseguiSessioneSealed) deve poter distinguere i tre casi per applicare
  // pause/retry diverse — stesso motivo per cui la versione 'carte' del
  // controllo prezzi di gruppo (apriTabEAspettaPrezzo) non riusa
  // LEGGI_SOLO_PREZZO. Duplicazione intenzionale (Regola d'Oro #1): non
  // tocca il case esistente, usato da un altro flusso (bulk sealed).
  if (message.type === 'LEGGI_PREZZO_SEALED_GRUPPO') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const ris = await _conTurnoCardmarket(message, () => _leggiPrezzoSealed(message.urlProdotto, tabIdWorker, requestId));
          _rimuoviRichiesta(requestId);
          if (tabIdWorker != null && ris && ris.tabId && ris.tabId !== tabIdWorker) await _salvaWorkerTabId('sealed', ris.tabId);
          sendResponse({
            prezzo: (ris && ris.prezzo != null) ? ris.prezzo : null,
            immagine: (ris && ris.immagine) || null,
            nome: (ris && ris.nome) || null,
            rateLimited: !!(ris && ris.rateLimited),
            cloudflareTimeout: !!(ris && ris.cloudflareTimeout),
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null, rateLimited: false, cloudflareTimeout: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  return false;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'sw-keepalive') { _pulisciRichiesteVecchie(); return; }

  if (alarm.name === 'ordini-poll') { _controllaOrdini(); return; }

  if (alarm.name === 'worker-coda-carte-autonomo') { _lavoraCodaCarteAutonomo(); return; }
  if (alarm.name === 'riapri-app') { _riapriAppSeChiusa(); return; } // v5.33
  if (alarm.name === 'controlla-aggiornamento-file') { _ricaricaSeFileAggiornati(); return; } // v5.34
  if (alarm.name === 'segnala-dispositivo') { _segnalaDispositivo(); return; } // v5.40 (4.7)

  if (alarm.name === 'cloudflare-avviso' && cloudflareAlarmActive && cloudflareAlarmTabId !== null) {
    _suonaEPortaInPrimoPiano(cloudflareAlarmTabId, true);
  }

  // FIX: il vecchio alarm one-shot 'cloudflare-timeout' è stato sostituito
  // dal watchdog persistente (_controllaWatchdogCf) — vedi commento esteso
  // su _registraAttesaCf più sopra. Copre sia il flusso "Avvia" (popup.js)
  // sia le attese Cloudflare interne al flusso bulk aggiungi carta/sealed,
  // in modo uniforme e resistente ai riavvii del service worker.
  if (alarm.name === 'cf-watchdog') {
    _controllaWatchdogCf();
  }
});

function _fermaAvvisi() {
  // FIX: prima di azzerare cloudflareAlarmTabId, ripulisce anche la sua voce
  // nel watchdog persistente — altrimenti resterebbe lì fino alla propria
  // scadenza naturale anche se l'attesa è già stata risolta con successo
  // (es. prezzo trovato prima del timeout), chiudendo inutilmente una tab
  // che nel frattempo potrebbe essere già stata riusata per altro.
  if (cloudflareAlarmTabId !== null) _rimuoviAttesaCf(cloudflareAlarmTabId);
  cloudflareAlarmActive = false;
  cloudflareAlarmTabId = null;
  chrome.alarms.clear('cloudflare-avviso');
}

async function _suonaEPortaInPrimoPiano(tabId, avvisoSonoro, kind = null) {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) {
      _fermaAvvisi();
      return;
    }
    // Porta la finestra in primo piano, poi attiva la tab
    chrome.windows.update(tab.windowId, { focused: true }, () => {
      setTimeout(() => chrome.tabs.update(tabId, { active: true }), 150);
    });
  });

  // FIX (backoff adattivo): notifica i popup bulk ('carte'/'sealed') che un
  // blocco Cloudflare è appena scattato durante la sessione — usato per
  // allungare temporaneamente il delay tra una carta e la successiva invece
  // di mantenere sempre lo stesso ritmo fisso per tutta la lista. Solo un
  // broadcast leggero (nessuna risposta attesa): se nessun popup bulk è
  // aperto ad ascoltarlo, il messaggio viene semplicemente ignorato.
  // v5.43 (6.1): il rallentamento lo applica il turno Cardmarket comune
  // (_segnalaCloudflareAlTurno); il messaggio resta per la riga nel registro
  // della pagina Aggiungi carte.
  if (kind) {
    _segnalaCloudflareAlTurno();
    chrome.runtime.sendMessage({ type: 'CLOUDFLARE_HIT_BULK', kind }).catch(() => {});
  }

  if (avvisoSonoro) {
    await _suonaDaOffscreen();
  }
}

async function _suonaDaOffscreen() {
  // Crea l'offscreen document se non esiste già
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });

  if (existingContexts.length === 0) {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['AUDIO_PLAYBACK'],
      justification: 'Riproduce il suono di avviso Cloudflare',
    });
  }

  chrome.runtime.sendMessage({ type: 'SUONA' }).catch(() => {});
}

// Titoli Cloudflare — unica fonte di verità, passata come arg a executeScript.
// 'patikrinimas' = lituano; mancava nelle copie inline precedenti.
// v5.42 (Fase 5.5, D11): nelle letture dentro le schede il widget Turnstile
// (.cf-turnstile) conta come verifica Cloudflare solo se la pagina non mostra
// né offerte (.article-row) né l'h1 di una carta ("Nome (CODICE)"): da non
// loggati compare anche nel modulo di login di una pagina normale. Il titolo
// (CF_TITLES) e il markup della pagina di verifica valgono sempre. La stessa
// regola è scritta in ogni funzione iniettata (girano nella pagina, non
// possono usare funzioni di questo file) e in content.js (isCloudflare).
const CF_TITLES = [
  'just a moment', 'un attimo', 'ci siamo quasi', 'almost there',
  'checking your', 'einen moment', 'por favor', 'verifique', 'patikrinimas',
];

// ── CHALLENGE CLOUDFLARE NELL'HTML DEL FETCH STATICO (v5.17) ─────────────────
// FIX (falsi "Cloudflare" sul fetch statico): _risolviSinglesENomeFetch e
// _leggiNomeSealedFetch cercavano le frasi di CF_TITLES ('un attimo', 'por
// favor', 'verifique'...) e 'cf-turnstile' in TUTTO l'HTML: parole comuni,
// o un widget Turnstile dentro una pagina normale, bastavano a scambiare una
// pagina buona per una challenge (→ tab aperta per niente). Ora, come tutti
// i controlli fatti sulle tab (document.title):
// - le frasi di CF_TITLES si cercano SOLO nel <title>;
// - in più, marcatori che esistono SOLO nelle pagine di challenge e non
//   dipendono dalla lingua (l'opzione _cf_chl_opt e lo script
//   orchestrate/chl_page che la pagina di challenge carica, gli id del suo
//   markup). NON si usa "challenge-platform" da solo: Cloudflare inserisce
//   /cdn-cgi/challenge-platform/... anche nelle pagine NORMALI (script di
//   rilevamento bot), sarebbe un falso positivo garantito.
// Il segnale ufficiale (header cf-mitigated: challenge) è controllato prima,
// in _fetchHtml. Mancare una challenge vera è peggio di un falso positivo
// (la pagina di challenge verrebbe letta come una carta: nome "Just a
// moment"), per questo i marcatori restano larghi e indipendenti dalla lingua.
const _CF_MARCATORI_CHALLENGE = [
  '_cf_chl_opt', '/orchestrate/chl_page', 'challenge-running', 'challenge-form',
  'challenge-error-text', 'cf-chl-widget',
];

function _htmlEChallengeCloudflare(htmlMinuscolo) {
  if (!htmlMinuscolo) return false;
  const mTitolo = htmlMinuscolo.match(/<title[^>]*>([\s\S]*?)<\/title>/);
  const titolo = mTitolo ? mTitolo[1] : '';
  if (CF_TITLES.some(t => titolo.includes(t))) return true;
  return _CF_MARCATORI_CHALLENGE.some(m => htmlMinuscolo.includes(m));
}

// ── CONTROLLO LOGIN CARDMARKET (verificato dal DOM reale, 2026-07) ───────────
// Legge nell'header della home Pokémon di Cardmarket un segnale affidabile,
// verificato dal DOM reale in ENTRAMBI gli stati:
//   - Loggato:     <a id="account-dropdown" ...> presente (mostra username,
//                   credito account, menu utente)
//   - Non loggato: <div id="login-signup"> presente (form Username/Password
//                   inline + bottoni "Login"/"Registrarsi")
// Nessuno dei due elementi non è ambiguo: sono mutuamente esclusivi, sempre
// uno dei due presente nell'header su qualunque pagina Cardmarket.
// Helper condiviso: legge il segnale di login dal DOM di una tab già aperta
// su Cardmarket (polling con timeout). v5.40 (Fase 4.11): le strade sono due,
// VERIFICA_LOGIN_SILENZIOSA (avvio a mano e bottone "Controlla connessione")
// e VERIFICA_LOGIN_AUTOMATICA (giri automatici), più il controllo
// all'apertura dell'app dal sito solo quando il login manca.
function _leggiStatoLoginCardmarket(tabId) {
  return new Promise((resolve) => {
    let risolto = false;
    let pollTimer = null;
    let timeout = null;
    let timeoutTotale = null;

    function concludi(valore) {
      if (risolto) return;
      risolto = true;
      if (pollTimer) clearInterval(pollTimer);
      if (timeout) clearTimeout(timeout);
      if (timeoutTotale) clearTimeout(timeoutTotale);
      chrome.tabs.onUpdated.removeListener(onLoad);
      chrome.tabs.onRemoved.removeListener(onRimossa);
      // v5.18: un esito certo (loggato sì/no), da qualunque controllo,
      // aggiorna quello ricordato per i giri automatici — vedi
      // _verificaLoginAutomatica. "Non confermato" (null) non lo tocca.
      if (valore && (valore.loggato === true || valore.loggato === false)) _ricordaStatoLoginCardmarket(valore.loggato);
      resolve(valore);
    }

    function tentaLettura() {
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          if (document.getElementById('account-dropdown')) return { loggato: true };
          if (document.getElementById('login-signup')) return { loggato: false };
          return undefined; // pagina non ancora renderizzata → il polling riprova
        },
      }, (results) => {
        if (risolto) return;
        // v5.17: un errore qui è normale mentre la tab sta ancora navigando
        // (es. dalla about:blank della worker tab a Cardmarket) — si riprova
        // al giro dopo invece di arrendersi subito. Tab chiusa e tempo
        // scaduto sono gestiti da onRimossa e dai timeout.
        if (chrome.runtime.lastError) return;
        const val = results?.[0]?.result;
        if (val === undefined || val === null) return; // non pronto, riprova
        concludi(val);
      });
    }

    // Ogni pagina caricata (anche una navigazione arrivata DOPO che il
    // polling era già partito sulla pagina precedente) riapre la finestra di
    // 10s per trovare l'header; il polling parte una volta sola.
    function avviaLettura() {
      if (risolto) return;
      if (!pollTimer) pollTimer = setInterval(tentaLettura, 400);
      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(() => concludi({ loggato: null }), 10000);
    }

    function onLoad(id, info) {
      if (id !== tabId || info.status !== 'complete') return;
      avviaLettura();
    }
    function onRimossa(idChiusa) {
      if (idChiusa === tabId) concludi({ loggato: null }); // tab chiusa prima della fine
    }
    chrome.tabs.onUpdated.addListener(onLoad);
    chrome.tabs.onRemoved.addListener(onRimossa);
    // FIX v5.17 (M3): prima il limite di 10s partiva SOLO quando la pagina
    // finiva di caricare — se non ci arrivava mai (Cloudflare, tab chiusa,
    // oppure caricamento finito PRIMA che ci mettessimo in ascolto, possibile
    // riusando la worker tab) questa Promise non si risolveva mai, e con lei
    // la coda della worker tab (_accodaSuWorkerTab): sessione ferma su
    // "Verifico il login…" e letture successive bloccate. Ora: limite totale
    // di 45s dall'inizio, stop se la tab viene chiusa, e se la pagina è già
    // caricata si inizia a leggere subito.
    timeoutTotale = setTimeout(() => concludi({ loggato: null }), 45000);
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab) { concludi({ loggato: null }); return; }
      if (tab.status === 'complete') avviaLettura();
    });
  });
}

// ── CONTROLLO LOGIN CARDMARKET AD OGNI APERTURA APP DAL SITO ─────────────────
// Innescato da CARDSYNC_OPEN_APP (bottone "Apri l'app"/"Apri sempre l'app"
// del sito, vedi il listener più in alto): ad ogni apertura dell'hub dal
// sito, verifichiamo anche che la sessione Cardmarket sia valida — stesso
// riscontro DOM di _leggiStatoLoginCardmarket, qui su una tab dedicata. Se
// risulti già loggato la tab si chiude subito senza disturbare; se non lo
// sei resta in primo piano finché non completi il login. In entrambi i casi
// il focus torna alla fine sulla tab del SITO, non su quella dell'hub appena
// aperta (che resta comunque pronta in background per quando servirà).
function _rifocalizzaTabSito(tabSito) {
  if (!tabSito || !tabSito.id) return;
  chrome.tabs.get(tabSito.id, (tab) => {
    if (chrome.runtime.lastError || !tab) return; // tab del sito chiusa nel frattempo — niente da rifocalizzare
    chrome.tabs.update(tabSito.id, { active: true }, () => {
      void chrome.runtime.lastError;
      chrome.windows.update(tab.windowId, { focused: true }, () => { void chrome.runtime.lastError; });
    });
  });
}

// Come _leggiStatoLoginCardmarket, ma dopo la prima lettura continua a
// ricontrollare (polling ogni secondo) finché non risulta loggato, invece
// di fermarsi alla prima lettura — usata SOLO qui, per aspettare che
// l'utente completi davvero il login prima di richiudere la tab. Si ferma
// anche se l'utente chiude la tab Cardmarket a mano prima di finire.
// v5.17: prima nessun limite (polling ogni secondo all'infinito se la tab
// restava lì): ora dopo 20 minuti smette e restituisce 'scaduto' — la tab
// resta aperta, il chiamante non sposta il focus.
const _MINUTI_MAX_ATTESA_LOGIN = 20;
function _attendiLoginCardmarket(tabId) {
  return new Promise((resolve) => {
    let risolto = false;
    const timerMax = setTimeout(() => concludi('scaduto'), _MINUTI_MAX_ATTESA_LOGIN * 60 * 1000);
    const pollTimer = setInterval(() => {
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => !!document.getElementById('account-dropdown'),
      }, (results) => {
        if (risolto) return;
        if (chrome.runtime.lastError) return; // pagina in transizione/navigazione — riprova al giro dopo
        if (results && results[0] && results[0].result === true) concludi(true);
      });
    }, 1000);
    function concludi(valore) {
      if (risolto) return;
      risolto = true;
      clearInterval(pollTimer);
      clearTimeout(timerMax);
      chrome.tabs.onRemoved.removeListener(onRimossa);
      // v5.18: login completato qui → i giri automatici (ordini dal sito,
      // inattività) ripartono subito, senza aspettare la pausa di 30 minuti.
      if (valore === true) _ricordaStatoLoginCardmarket(true);
      resolve(valore);
    }
    function onRimossa(idChiusa) {
      if (idChiusa === tabId) concludi(false); // chiusa a mano prima di completare il login
    }
    chrome.tabs.onRemoved.addListener(onRimossa);
  });
}

// v5.40 (Fase 4.11): dopo CARDSYNC_OPEN_APP. Loggato (ricordato o appena
// verificato) → niente popup e nessuna scheda in primo piano. Altrimenti il
// segnale per app.js (popup "sto per aprire Cardmarket", poi
// CARDSYNC_LOGIN_CHECK_ACK → _controlloLoginAutomaticoAperturaApp, come prima).
async function _avvisoLoginAperturaAppSeManca(tabSito) {
  try {
    const esito = await _verificaLoginAutomatica();
    if (esito && esito.loggato === true) return;
    await chrome.storage.local.set({ cardsyncLoginCheckToast: Date.now(), cardsyncLoginCheckTabSito: tabSito || null });
  } catch (e) {
    console.warn('[CardSync] verifica login all\'apertura dell\'app:', e && e.message);
  }
}

async function _controlloLoginAutomaticoAperturaApp(tabSito) {
  try {
    const tab = await new Promise((resolve) => {
      chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: false }, resolve);
    });
    const esito = await _leggiStatoLoginCardmarket(tab.id);
    // v5.17: il login su Cardmarket è indispensabile (senza, i carrelli non
    // sono cliccabili e ogni carta risulta "Esaurita") — un esito NON
    // confermato (pagina lenta, Cloudflare, tab chiusa) ora si tratta come
    // "non loggato": tab in primo piano e attesa del login. Prima la tab si
    // chiudeva dopo 2s come se fosse tutto a posto.
    if (!esito || esito.loggato !== true) {
      const tabAncoraAperta = await new Promise((resolve) => chrome.tabs.update(tab.id, { active: true }, () => resolve(!chrome.runtime.lastError)));
      if (!tabAncoraAperta) return; // chiusa a mano: niente da aspettare, niente focus da spostare
      const completato = await _attendiLoginCardmarket(tab.id);
      if (completato === 'scaduto') return; // tab lasciata aperta, focus non spostato
      if (completato) chrome.tabs.remove(tab.id, () => { void chrome.runtime.lastError; });
    } else {
      // Già loggato: chiudiamo e basta. Aspettiamo
      // un paio di secondi prima di chiuderla — chiuderla ISTANTANEAMENTE
      // (nell'istante stesso in cui la tab finisce di caricare) può essere
      // scambiato dall'utente per un crash o un bug invece che per "tutto
      // ok, sei già loggato".
      await new Promise((resolve) => setTimeout(resolve, 2000));
      chrome.tabs.remove(tab.id, () => { void chrome.runtime.lastError; });
    }
    _rifocalizzaTabSito(tabSito);
  } catch (e) {
    console.error('[CardSync] Controllo login automatico (apertura app dal sito) fallito:', e && e.message);
  }
}

// Usata PRIMA di avviare una sessione (▶ Avvia / 📋 Aggiungi tutte / 📦
// Aggiungi al foglio), subito dopo la conferma sul modale "Team Rocket": il
// modale resta un promemoria proattivo, ma da solo non basta più a sbloccare
// l'avvio — c'è sempre questo riscontro oggettivo dietro. Controllo
// silenzioso: la tab si apre in background (nessun furto di focus dal
// popup se l'utente è già loggato) e viene chiusa subito senza disturbare;
// solo se risulta NON loggato viene portata in primo piano, così l'utente
// può accedere subito invece di scoprirlo a sessione già iniziata.
// FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa un kind
// ('carte'/'sealed' — Wishlist riusa 'carte', stesso kind della sua worker
// tab per LEGGI_NOME_CARTA/LEGGI_SOLO_PREZZO), il controllo login avviene
// nella STESSA worker tab già usata dalla sessione bulk imminente, invece
// di aprirne una a parte solo per questo controllo — una tab in meno prima
// di ogni sessione "📋 Aggiungi tutte"/"📦 Aggiungi al foglio"/"🗂️ Aggiungi
// alla wishlist"/"🔄 Aggiorna prezzi". Nessun kind (popup principale, che
// non ha un pool worker tab qui in background.js) → comportamento
// invariato: tab dedicata, aperta in background e chiusa subito se il
// login risulta ok.
// v5.40 (Fase 4.11): un login confermato da poco (esito ricordato, valido
// _MINUTI_VALIDITA_LOGIN_OK minuti, aggiornato anche da ogni pagina
// Cardmarket che mostra l'account) basta: nessuna scheda da aprire. Prima
// ogni avvio della coda "Aggiungi carte" (anche per una sola carta arrivata
// dal sito) riapriva Cardmarket solo per questo. "Non loggato" ricordato non
// basta: un avvio a mano è proprio il momento in cui si è appena entrati.
async function _verificaLoginSilenziosa(kind) {
  if ((await _leggiStatoLoginRicordato()) === true) return { loggato: true, ricordato: true };
  return _verificaLoginSilenziosaSuScheda(kind);
}

function _verificaLoginSilenziosaSuScheda(kind) {
  if (kind) {
    // Accodata come ogni altro uso della worker tab (vedi
    // _accodaSuWorkerTab più in alto) — senza questo, un click su "Aggiungi
    // tutte" subito dopo l'apertura pagina potrebbe far navigare la tab a
    // metà di questo controllo, facendo leggere alla prima carta la pagina
    // sbagliata (stesso tipo di race condition già risolto per
    // APRI_URL_WORKER_TAB in v2.10).
    return _accodaSuWorkerTab(kind, () => _verificaLoginSuWorkerTab(kind));
  }
  return new Promise((resolve) => {
    chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: false }, (tab) => {
      _leggiStatoLoginCardmarket(tab.id).then((esito) => {
        // v5.17: anche "non confermato" porta la tab in primo piano — il
        // chiamante non avvia la sessione (vedi _richiediConfermaLogin).
        if (!esito || esito.loggato !== true) {
          chrome.tabs.update(tab.id, { active: true }, () => {
            void chrome.runtime.lastError;
            chrome.windows.update(tab.windowId, { focused: true }, () => { void chrome.runtime.lastError; resolve(esito || { loggato: null }); });
          });
        } else {
          chrome.tabs.remove(tab.id, () => { void chrome.runtime.lastError; });
          resolve(esito);
        }
      });
    });
  });
}

function _verificaLoginSuWorkerTab(kind) {
  return new Promise(async (resolve) => {
    const tabId = await _prontaWorkerTabId(kind);

    function suTabPronta(idTab, windowIdFallback) {
      _leggiStatoLoginCardmarket(idTab).then((esito) => {
        // v5.17: anche "non confermato" porta la tab in primo piano — il
        // chiamante non avvia la sessione (vedi _richiediConfermaLogin).
        if (!esito || esito.loggato !== true) {
          chrome.tabs.update(idTab, { active: true }, (tabAgg) => {
            void chrome.runtime.lastError;
            const windowId = (tabAgg && tabAgg.windowId) || windowIdFallback;
            chrome.windows.update(windowId, { focused: true }, () => { void chrome.runtime.lastError; resolve(esito || { loggato: null }); });
          });
        } else {
          // Login ok: la tab NON viene chiusa — resta
          // pronta per essere navigata dalla prima carta/prodotto della
          // sessione bulk imminente, stesso principio del resto della
          // worker tab.
          resolve(esito);
        }
      });
    }

    chrome.tabs.update(tabId, { url: 'https://www.cardmarket.com/it/Pokemon' }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        // La worker tab registrata non esiste più (es. chiusa a mano
        // dall'utente) — ne apriamo una nuova al volo e la registriamo,
        // stesso fallback già usato altrove per il riuso della worker tab.
        chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: false }, (nuovaTab) => {
          _salvaWorkerTabId(kind, nuovaTab.id).then(() => suTabPronta(nuovaTab.id, nuovaTab.windowId));
        });
        return;
      }
      suTabPronta(tabId, tab.windowId);
    });
  });
}

// ── LOGIN CARDMARKET PER I GIRI AUTOMATICI (v5.18, punto 25) ─────────────────
// Ordini dal sito (controllo prezzi carte/sealed/wishlist), controllo in
// inattività e "mi unisco al controllo in corso" partono senza nessuno
// davanti al PC: senza login Cardmarket ogni carta risulta "Esaurita" (vedi
// rigaCarrelloCliccabileShared in shared.js) e il giro fa danni invece di
// controllare. Qui una verifica pensata per loro:
//   - scheda Cardmarket aperta in background, chiusa SEMPRE, mai portata in
//     primo piano (nessuno da avvisare, nessun focus da rubare);
//   - "non confermato" (Cloudflare, pagina lenta, scheda chiusa) conta come
//     non loggato;
//   - esito ricordato in chrome.storage.local: "non loggato" → nessun nuovo
//     tentativo per 30 minuti (altrimenti una scheda ogni 20s, a ogni giro
//     ordini); "loggato" → valido 10 minuti. Ogni controllo con esito certo
//     (bottone "Controlla connessione", avvio manuale, apertura app dal
//     sito, login completato) lo aggiorna — vedi _leggiStatoLoginCardmarket
//     e _attendiLoginCardmarket — così chi accede a Cardmarket dall'app
//     sblocca subito i giri automatici.
//   - v5.23: "non confermato" (pagina lenta, verifica Cloudflare, scheda
//     chiusa) NON vale più come "non loggato" per 30 minuti. Prima bastava
//     una verifica andata storta perché gli ordini di prezzi dal sito
//     restassero in attesa mezz'ora, finché non si premeva Avvia (che
//     rifacendo la verifica sbloccava tutto). Ora si riprova dopo 2 minuti,
//     poi 4, 8, 16, fino a 30 se continua a non confermarsi (per non aprire
//     una scheda Cardmarket ogni 2 minuti all'infinito).
//   - v5.23: anche ogni pagina Cardmarket che mostra l'account (content.js,
//     messaggio STATO_LOGIN_CARDMARKET) aggiorna l'esito a "loggato".
const _CHIAVE_STATO_LOGIN_CM = 'statoLoginCardmarket';
const _MINUTI_VALIDITA_LOGIN_OK = 10;
const _MINUTI_PAUSA_LOGIN_KO = 30;
const _MINUTI_PAUSA_LOGIN_NON_CONFERMATO = 2; // v5.23: raddoppia a ogni tentativo, massimo _MINUTI_PAUSA_LOGIN_KO

function _ricordaStatoLoginCardmarket(loggato) {
  try {
    chrome.storage.local.set({ [_CHIAVE_STATO_LOGIN_CM]: { loggato: loggato === true, quando: Date.now() } }, () => { void chrome.runtime.lastError; });
  } catch (_) { /* best effort: senza esito ricordato si verifica di nuovo al prossimo giro */ }
}

// v5.23: verifica automatica "non confermata". Conta i tentativi di fila
// (azzerati da qualunque esito certo, che riscrive la chiave senza questi
// campi) per allungare la pausa: 2, 4, 8, 16, 30 minuti.
async function _ricordaLoginNonConfermato() {
  try {
    const prec = (await chrome.storage.local.get(_CHIAVE_STATO_LOGIN_CM))[_CHIAVE_STATO_LOGIN_CM];
    const consecutivi = (prec && prec.nonConfermato === true && Number.isInteger(prec.consecutivi)) ? prec.consecutivi + 1 : 1;
    await chrome.storage.local.set({ [_CHIAVE_STATO_LOGIN_CM]: { loggato: false, quando: Date.now(), nonConfermato: true, consecutivi } });
  } catch (_) { /* best effort, come _ricordaStatoLoginCardmarket */ }
}

function _minutiPausaLoginKo(salvato) {
  if (salvato.nonConfermato !== true) return _MINUTI_PAUSA_LOGIN_KO;
  const n = Number.isInteger(salvato.consecutivi) && salvato.consecutivi > 0 ? salvato.consecutivi : 1;
  return Math.min(_MINUTI_PAUSA_LOGIN_NON_CONFERMATO * Math.pow(2, n - 1), _MINUTI_PAUSA_LOGIN_KO);
}

// true / false se l'esito ricordato è ancora valido, null se manca o è scaduto.
async function _leggiStatoLoginRicordato() {
  try {
    const salvato = (await chrome.storage.local.get(_CHIAVE_STATO_LOGIN_CM))[_CHIAVE_STATO_LOGIN_CM];
    if (!salvato || typeof salvato.quando !== 'number') return null;
    const eta = Date.now() - salvato.quando;
    if (eta < 0) return null; // orologio spostato indietro: meglio riverificare
    if (salvato.loggato === true && eta < _MINUTI_VALIDITA_LOGIN_OK * 60 * 1000) return true;
    if (salvato.loggato === false && eta < _minutiPausaLoginKo(salvato) * 60 * 1000) return false;
    return null;
  } catch (_) {
    return null;
  }
}

// Una sola verifica alla volta: chi la chiede mentre ce n'è già una in corso
// (es. giro ordini e controllo in inattività insieme) aspetta la stessa,
// invece di aprire una seconda scheda.
let _verificaLoginAutomaticaInCorso = null;

function _verificaLoginAutomatica() {
  if (_verificaLoginAutomaticaInCorso) return _verificaLoginAutomaticaInCorso;
  _verificaLoginAutomaticaInCorso = (async () => {
    const ricordato = await _leggiStatoLoginRicordato();
    if (ricordato !== null) return { loggato: ricordato, ricordato: true };

    const tab = await new Promise((resolve) => {
      chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: false }, (t) => {
        if (chrome.runtime.lastError || !t) resolve(null); else resolve(t);
      });
    });
    let esito = null;
    if (tab) {
      esito = await _leggiStatoLoginCardmarket(tab.id);
      chrome.tabs.remove(tab.id, () => { void chrome.runtime.lastError; });
    }
    // Un esito certo (loggato sì/no) l'ha già ricordato
    // _leggiStatoLoginCardmarket. v5.23: "non confermato" non diventa più
    // "non loggato" per 30 minuti — pausa breve che si allunga, vedi
    // _ricordaLoginNonConfermato. A chi chiede si risponde comunque "non
    // loggato": nessun giro senza login confermato (punto 25).
    const certo = !!esito && (esito.loggato === true || esito.loggato === false);
    if (!certo) {
      await _ricordaLoginNonConfermato();
      console.warn('[login Cardmarket] verifica automatica non confermata (pagina lenta, Cloudflare o scheda chiusa) — riprovo tra poco.');
    }
    return { loggato: !!esito && esito.loggato === true };
  })().finally(() => { _verificaLoginAutomaticaInCorso = null; });
  return _verificaLoginAutomaticaInCorso;
}

// ── LEGGI NOME E PREZZO DA CARDMARKET ─────────────────────────────────────────
//
// Flusso:
//   1. Apre urlNome (può essere /Search? oppure /Singles/).
//      - Se è /Search?: aspetta con polling che Cardmarket carichi i risultati,
//        poi prende il primo link /Singles/ dalla lista.
//      - Se è /Singles/ o redirect diretto: legge il nome dall'h1.
//   2. Se il nome non è ancora disponibile (caso /Search?→link), apre il /Singles/
//      in un'altra tab per leggere l'h1.
//   3. Apre il /Singles/ con filtri lingua+condizione e legge il prezzo con polling
//      (le .article-row vengono iniettate via JS dopo il caricamento).
//
// Restituisce: { nome, prezzo, urlSingles }
//   urlSingles = URL /Singles/ pulito (senza query) da salvare nella colonna H.

// FIX (bug "prezzo RH/1ED mostra il prezzo della stampa normale"): la pagina
// filtra le righe d'offerta in base a isReverseHolo=Y / isFirstEd=Y letti
// dalla query string (vedi rigaOk in _leggiPrezzoDaSingles / tentaLetturaPrezzo
// in _risolviNomeEPrezzoUnicaTab). Se l'URL usato per LEGGERE IL PREZZO non
// porta questi parametri, isReverseHolo/isFirstEd valgono false lato pagina,
// e la logica "!isReverseHolo && rigaERH(riga) → escludi" finisce per
// scartare proprio le righe RH/1ED, lasciando come prezzo quello della
// stampa normale. L'URL salvato nel foglio (colonna H) li aveva già —
// mancavano solo su questo URL "di lettura", usato SOLO in memoria per la
// prima chiamata a _leggiPrezzoDaSingles/_risolviNomeEPrezzoUnicaTab.
// Ricava un nome leggibile dallo slug di un URL /Singles/ quando l'estrazione
// dall'h1 non ha prodotto nulla (fallback ultimo, usato sia dal percorso
// fetch statico sia — FIX — dal percorso di fallback via tab, che prima ne
// era sprovvisto: vedi commento esteso su _leggiNomeDaCardmarket più sotto).
// Es. ".../Arcanine-SVP-EN-011" → "ARCANINE".
//
// FIX (bug "YVELTAL 046" → nome vuoto): il test dev'essere case-sensitive
// (niente /i) — i codici set reali nello slug sono SEMPRE in maiuscolo
// letterale, mentre un nome in Title Case (es. "Yveltal") non deve mai
// essere scambiato per un codice togliendo il flag case-insensitive.
function _nomeDaSlugUrlSingles(urlSingles) {
  if (!urlSingles) return null;
  const slug = urlSingles.split('/').pop() || '';
  const parti = slug.split('-');
  let endIdx = parti.length;
  for (let i = parti.length - 1; i >= 0; i--) {
    if (/^\d+$/.test(parti[i]) || /^[A-Z]{2,}\d+$/.test(parti[i]) || /^[A-Z]{2,}$/.test(parti[i])) {
      endIdx = i;
    } else { break; }
  }
  return parti.slice(0, endIdx).join(' ').toUpperCase() || null;
}

function _appendVariantParams(url, oloType, firstEd) {
  if (!url) return url;
  let u = url;
  if (oloType === 'RH') u += (u.includes('?') ? '&' : '?') + 'isReverseHolo=Y';
  if (firstEd) u += (u.includes('?') ? '&' : '?') + 'isFirstEd=Y';
  return u;
}

// FIX (v5.31, "Singole Forze Scatenate" salvata anche con la 5.30): i
// controlli della 5.30 stanno nei singoli percorsi di lettura (fetch, scheda,
// verifica candidato), ma una carta è passata lo stesso con l'URL della lista
// dell'espansione (.../Singles/Unleashed) e il titolo della lista come nome.
// Qualunque sia il percorso, TUTTE le letture di carte singole passano da
// qui prima di essere scritte (pagina Aggiungi carte e worker in background):
// controllo finale sul risultato — URL senza la carta, oppure nome che è il
// titolo di una lista, → disambiguazione (errore → correzione manuale), mai
// una carta salvata.
// v5.36 (B17, decisione Q9 di Claudio): urlRicercaRiserva = ricerca per nome
// della riga, mandata da chi parte da un url_diretto. Se quel link è vecchio
// (porta alla lista dell'espansione) si cerca subito per nome, nello stesso
// giro: carta trovata → si usa il link nuovo; più versioni → scelta tra le
// versioni vere (es. Magikarp V1/V2), con linkNonValido per il messaggio.
// v5.40 (Fase 4.10, M7): carte della coda cercate da questo PC dall'ultimo
// lotto di prezzi (chrome.storage.local, carteCodaDaUltimiPrezzi). Con la coda
// sempre piena il controllo prezzi "in inattività" non partiva mai; ora
// popup.js, ogni CARTE_CODA_PER_LOTTO_PREZZI carte, fa un lotto di prezzi
// (_avviaControlloPrezziSeInattivo). Conta qui, dove passano sia la pagina
// Aggiungi carte (LEGGI_NOME_CARTA, LEGGI_SEALED) sia il worker in
// background; i tentativi ripetuti della stessa carta non contano.
async function _contaCartaCodaPerPrezzi() {
  try {
    const { carteCodaDaUltimiPrezzi: n } = await chrome.storage.local.get('carteCodaDaUltimiPrezzi');
    await chrome.storage.local.set({ carteCodaDaUltimiPrezzi: (typeof n === 'number' && n > 0 ? n : 0) + 1 });
  } catch (_) { /* solo un conteggio */ }
}

async function _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType = '', firstEd = false, _tentativo = 0, tabIdEsterno = null, requestId = null, urlRicercaRiserva = null) {
  if (_tentativo === 0) _contaCartaCodaPerPrezzi();
  let r = await _leggiNomeDaCardmarketInterno(urlNome, lingua, condizione, oloType, firstEd, _tentativo, tabIdEsterno, requestId);
  if (r && r.linkNonValido && urlRicercaRiserva && urlRicercaRiserva !== urlNome) {
    console.warn('[CardSync] link Cardmarket non più valido, cerco per nome:', { urlNome, urlRicercaRiserva });
    await new Promise(res => setTimeout(res, 4000)); // due richieste a Cardmarket non attaccate
    const daRicerca = await _leggiNomeDaCardmarketInterno(urlRicercaRiserva, lingua, condizione, oloType, firstEd, 0, tabIdEsterno, requestId);
    r = daRicerca && daRicerca.urlSingles ? { ...daRicerca, linkSostituito: true } : { ...(daRicerca || {}), urlSingles: null, linkNonValido: true };
  }
  if (r && r.urlSingles && _ePaginaListaSingles(r.urlSingles, r.nome || '')) {
    console.warn('[CardSync] risultato scartato: non è una carta (lista espansione/disambiguazione)', { urlNome, urlSingles: r.urlSingles, nome: r.nome });
    return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: [] };
  }
  return r;
}

async function _leggiNomeDaCardmarketInterno(urlNome, lingua, condizione, oloType = '', firstEd = false, _tentativo = 0, tabIdEsterno = null, requestId = null) {
  // ── v5.43 (Fase 6.2, D5): meno richieste a Cardmarket per carta ──────────────
  // Link diretto a una carta (/Singles/Espansione/Carta): nessuna lettura
  // preliminare della pagina, si apre subito la scheda del prezzo, che legge
  // anche nome e codice dall'h1 e riconosce un link vecchio che porta alla
  // lista dell'espansione (_leggiPrezzoDaSingles). Da 2 richieste a 1.
  // Dalla ricerca: lettura della ricerca + scheda del prezzo, senza più la
  // lettura intermedia della pagina carta (_risolviSinglesENomeFetch). Da 3 a 2.
  const daLinkDiretto = urlNome.includes('/Singles/');
  if (daLinkDiretto && _ePaginaListaSingles(urlNome, '')) {
    // Link che punta già alla lista di un'espansione: non è una carta.
    return { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true };
  }

  // ── FASE 1: fetch HTML statico della ricerca (nessuna tab aperta) ────────────
  // Cardmarket serve i link /Singles/ della ricerca nell'HTML server-side.
  // Solo il prezzo richiede JS rendering → unica tab aperta, solo per quello.
  const fase1 = daLinkDiretto
    ? { urlSingles: urlNome.split('?')[0], nome: null, codice: null, immagine: null }
    : await _risolviSinglesENomeFetch(urlNome, oloType);
  console.log('[CardSync] esito fase1:', daLinkDiretto ? 'link diretto, nessuna lettura preliminare' : fase1);

  // Error 1015: nessun fallback con tab — riprovare con una tab non risolve
  // il rate limit (anzi peggiora la situazione). Propaga subito al chiamante,
  // che metterà in pausa 30 minuti prima di ritentare.
  if (fase1.rateLimited) {
    return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
  }

  // Fallback solo se Cloudflare blocca il fetch o fetch fallisce per rete.
  // Usa UNA SOLA tab per risoluzione + lettura prezzo (_risolviNomeEPrezzoUnicaTab),
  // invece delle due tab sequenziali usate in precedenza.
  if (fase1.cloudflare || fase1.fetchFailed) {
    console.log('[CardSync] passo al fallback via tab (motivo:', fase1.cloudflare ? 'cloudflare' : 'fetch fallita', ')');
    const fusa = await _risolviNomeEPrezzoUnicaTab(urlNome, lingua, condizione, oloType, firstEd, tabIdEsterno, requestId);
    // FIX (worker tab about:blank mai usata): se la worker tab passata non
    // era più valida, _risolviNomeEPrezzoUnicaTab ne ha aperta una nuova al
    // volo — aggiorniamo subito lo storage così le carte successive della
    // stessa sessione bulk la trovano e la riusano.
    if (tabIdEsterno != null && fusa && fusa.tabId && fusa.tabId !== tabIdEsterno) {
      await _salvaWorkerTabId('carte', fusa.tabId);
      tabIdEsterno = fusa.tabId;
    }
    console.log('[CardSync] esito fallback via tab:', fusa);
    if (fusa && fusa.rateLimited)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
    if (fusa && fusa.disambiguation)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: fusa.opzioni || [] };
    if (fusa && fusa.linkNonValido) // v5.36 (B17)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true };
    if (fusa && fusa.varianteNonTrovata)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, varianteNonTrovata: true };
    if (!fusa?.urlSingles) {
      // v5.36 (1.6): una carta "non trovata" non si ritenta (stesso esito).
      if (!fusa?.nonTrovata && _tentativo < BULK_MAX_RETRY) {
        await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
        return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
      }
      return { nome: null, codice: null, prezzo: null, urlSingles: null };
    }

    // FIX (bug "riga con nome vuoto, sovrascritta dalla carta successiva"):
    // questo percorso (fallback via tab) restituiva fusa.nome anche quando
    // era null — a differenza del percorso fetch statico più sotto, che ha
    // sempre applicato un fallback (nome dallo slug URL) e, se anche quello
    // falliva, si rifiutava di restituire una carta senza nome. Qui quel
    // controllo mancava del tutto: bastava che l'h1 non venisse letto bene
    // nella fase-prezzo di _risolviNomeEPrezzoUnicaTab (caso raro ma reale,
    // tipicamente quando si parte da /Search? con risultati multipli) perché
    // la carta finisse scritta nel foglio con COL.NOME vuoto pur avendo un
    // urlSingles valido — una riga così può essere scambiata da script a
    // valle per "riga ancora libera" e finire sovrascritta dalla carta
    // successiva. Stesso trattamento del percorso fetch: prova il fallback
    // dallo slug, se anche quello fallisce ritenta o va in correzione
    // manuale invece di scrivere una riga senza nome. Nessuna tab aggiuntiva:
    // si riusano solo i dati già ottenuti da _risolviNomeEPrezzoUnicaTab.
    const nomeFusa = fusa.nome || _nomeDaSlugUrlSingles(fusa.urlSingles);
    if (!nomeFusa) {
      if (_tentativo < BULK_MAX_RETRY) {
        await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
        return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
      }
      return { nome: null, codice: null, prezzo: null, urlSingles: null };
    }
    return { nome: nomeFusa, codice: fusa.codice, prezzo: fusa.prezzo, urlSingles: fusa.urlSingles, immagine: fusa.immagine || null };
  }

  if (fase1.disambiguation)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: fase1.opzioni || [] };
  if (fase1.linkNonValido) // v5.36 (B17)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true };
  if (fase1.varianteNonTrovata)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, varianteNonTrovata: true };

  const { urlSingles, nome, codice } = fase1;

  if (!urlSingles) {
    // v5.36 (1.6): prima una "non trovata" si ripeteva altre 2 volte qui e poi
    // altre 3 volte nei giri della coda (fino a 9 tentativi, 2-3 richieste a
    // Cardmarket ciascuno) per un risultato che non cambia. Si ritenta solo
    // quando il motivo può essere temporaneo.
    if (!fase1.nonTrovata && _tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  // ── FASE 2: leggi prezzo con filtri — unica tab aperta per carta ─────────────
  // FIX: qui mancava l'applicazione di isReverseHolo/isFirstEd — vedi
  // commento su _appendVariantParams più sopra. Senza questo, il prezzo letto
  // era sempre quello della stampa normale per le carte RH/1ED.
  const urlConFiltri = _appendVariantParams(costruisciUrlFiltrato(urlSingles, lingua, condizione), oloType, firstEd);
  let risPrez = await _leggiPrezzoDaSingles(urlConFiltri, tabIdEsterno, requestId);
  // FIX (troppe tab in sequenza → Cloudflare): se la worker tab passata non
  // era più valida (chiusa manualmente dall'utente, o mai creata prima),
  // _leggiPrezzoDaSingles ne ha aperta una nuova al volo — aggiorniamo
  // subito lo storage così le carte successive della stessa sessione bulk
  // la trovano e la riusano, invece di aprirne una diversa ogni volta.
  if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
    await _salvaWorkerTabId('carte', risPrez.tabId);
    tabIdEsterno = risPrez.tabId;
  }

  // v5.43 (6.2): la scheda è finita sulla lista dell'espansione. Da un link
  // diretto è un link vecchio (il chiamante cerca per nome, B17); da una
  // ricerca è una carta con più versioni → scelta manuale.
  if (risPrez.linkNonValido) {
    return daLinkDiretto
      ? { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true }
      : { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: [] };
  }

  // FIX (carte cinesi e altre espansioni "RH di base", senza stampa normale
  // separata): isReverseHolo=Y/isFirstEd=Y sono filtri NATIVI di Cardmarket
  // che presuppongono l'esistenza di una stampa non-RH da escludere. Quando
  // la variante richiesta È l'unica stampa esistente, Cardmarket può non
  // taggare nessuna riga come tale e il filtro nativo restituisce zero
  // offerte — anche se il prezzo, essendoci un'unica stampa, sarebbe
  // comunque corretto senza quel filtro. Se la lettura filtrata non trova
  // nulla, ritentiamo SENZA isReverseHolo/isFirstEd prima di arrenderci:
  // si parte sempre dal più specifico, questo è solo un fallback di
  // sicurezza per non perdere il prezzo di carte che prima (senza questo
  // fix) venivano lette correttamente proprio perché il filtro non c'era.
  // v5.43 (6.2): solo se la pagina filtrata non ha NESSUNA offerta
  // (senzaOfferte). Prima anche con offerte RH/1ª presenti ma nessuna nella
  // lingua/condizione giusta (o con Cloudflare non risolto): una pagina in
  // più, e un prezzo della stampa normale al posto di "nessun prezzo".
  if (risPrez.senzaOfferte && (oloType === 'RH' || firstEd)) {
    const urlSenzaVarianti = costruisciUrlFiltrato(urlSingles, lingua, condizione);
    const risPrezFallback = await _leggiPrezzoDaSingles(urlSenzaVarianti, tabIdEsterno, requestId);
    if (risPrezFallback.prezzo !== null && risPrezFallback.prezzo !== undefined) risPrez = risPrezFallback;
  }

  if (risPrez.prezzo === 'RateLimit') {
    return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
  }

  // v5.43 (6.2): nome e codice ora arrivano dalla scheda. Se la scheda non ha
  // letto niente (pagina mai caricata, Cloudflare non risolto) la carta NON si
  // salva col solo nome ricavato dal link: come una lettura fallita, si
  // ritenta se il motivo può essere temporaneo (Cloudflare no: riprovare
  // subito lo farebbe solo ripartire).
  if (!nome && !risPrez.nome && !risPrez.codice && (risPrez.prezzo === null || risPrez.prezzo === undefined) && !risPrez.senzaOfferte) {
    if (!risPrez.cloudflare && _tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  // Fallback ultimo: se il nome non è stato estratto dall'HTML (raro per alcune promo SVP),
  // ricavalo dallo slug dell'URL /Singles/ (es. ".../Arcanine-SVP-EN-011" → "ARCANINE").
  //
  // FIX (bug "YVELTAL 046" → riga salvata con nome vuoto e codice = query
  // grezza): i due controlli avevano il flag /i su /^[A-Z]{2,}\d+$/ e,
  // soprattutto, su /^[A-Z]{2,}$/. Con case-insensitive attivo, anche un nome
  // scritto in Title Case come "Yveltal" soddisfa /^[A-Z]{2,}$/i (equivale a
  // testare "YVELTAL"), venendo scambiato per un codice set. Il loop, che
  // scorre lo slug a ritroso "mangiandosi" i segmenti che sembrano codice,
  // finiva quindi per inghiottire anche il nome vero (non solo il suffisso
  // codice), lasciando nomefinale = '' → null. I codici set reali nell'URL
  // sono SEMPRE scritti in maiuscolo letterale (es. "PAR", "SVP", "TEF") —
  // un nome in Title Case (prima lettera maiuscola, resto minuscolo) non li
  // soddisfa più togliendo il flag /i, quindi ora resta correttamente intatto.
  // v5.43 (6.2): nome dall'h1 della scheda del prezzo (risPrez.nome) quando
  // la fase 1 non l'ha letto (link diretto, carta presa dalla ricerca).
  let nomefinale = nome || risPrez.nome || _nomeDaSlugUrlSingles(urlSingles);

  // FIX (stesso bug, parte 2): se anche dopo il fallback il nome resta
  // sconosciuto, NON scrivere comunque la riga nel foglio. Prima veniva
  // scritta lo stesso con COL.NOME vuoto e COL.CODICE forzato alla query
  // grezza digitata dall'utente (es. "YVELTAL 046" invece di un vero codice
  // set) — una riga con nome vuoto può essere scambiata da script a valle
  // per "riga ancora libera" e finire sovrascritta dalla carta successiva.
  // Meglio trattare l'estrazione fallita come le altre risoluzioni fallite:
  // qualche retry, poi instradamento al pannello di correzione manuale.
  if (!nomefinale) {
    if (_tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  // v5.43 (6.2): immagine della scheda (og:image) solo se è una foto vera; la
  // converte chi salva la carta (CONVERTI_IMMAGINE / _immagineAUrlDati), come
  // già faceva per questo ripiego.
  const immagineScheda = risPrez.immagine && !_eImmagineSegnaposto(risPrez.immagine) ? risPrez.immagine : null;
  return { nome: nomefinale, codice: codice || risPrez.codice || null, prezzo: risPrez.prezzo, urlSingles, immagine: fase1.immagine || immagineScheda || null };
}


// ── FETCH HTML STATICO ────────────────────────────────────────────────────────
// Scarica l'HTML grezzo di url senza aprire tab (niente JS/CSS/immagini).
//
// v5.36 (D16): l'ultimo "troppe richieste" (HTTP 429) resta qui, per URL.
// _fetchHtml continua a restituire null in quel caso (nessun chiamante
// cambia forma), ma chi decide se aprire una scheda di riserva lo chiede a
// _fetchHtmlEraRateLimit(url): con un 429 la risposta giusta è fermarsi
// (stessa pausa dell'Error 1015), non insistere aprendo una scheda.
const _fetchRateLimitPerUrl = new Map(); // url -> { il, retryAfter }
function _fetchHtmlEraRateLimit(url) {
  const v = _fetchRateLimitPerUrl.get(url);
  return !!v && Date.now() - v.il < 60 * 1000;
}
async function _fetchHtml(url) {
  _fetchRateLimitPerUrl.delete(url);
  try {
    const r = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
      },
      // FIX: era 'omit' — niente cookie mandati MAI, nemmeno cf_clearance.
      // Cloudflare imposta cf_clearance quando risolvi manualmente la sfida
      // in una tab reale (fallback), ma con 'omit' quel cookie non veniva
      // mai riusato dalle fetch statiche successive: ogni nuova carta del
      // bulk ripartiva "anonima" agli occhi di Cloudflare e veniva
      // ribloccata da capo, costringendo ad aprire una tab e risolvere di
      // nuovo per OGNI carta invece che una volta sola per sessione.
      // 'include' fa sì che, una volta risolta la sfida, cf_clearance venga
      // inviato anche dalle fetch statiche successive — niente più sfide
      // ripetute a raffica. Richiede host_permissions su cardmarket.com,
      // già presente in manifest.json.
      credentials: 'include',
    });
    // ── DIAGNOSI (v5.13) — SOLO LOG, NESSUN CAMBIO DI COMPORTAMENTO ───────────
    // Perché serve: fin qui `!r.ok` e l'eccezione del catch restituivano
    // ENTRAMBI lo stesso `null`, e il chiamante lo traduceva in un unico
    // `fetchFailed:true`. Da quel flag non si può distinguere un blocco di
    // Cloudflare (403/503) da un rate limit (429) da un errore di rete —
    // e nei log della sessione precedente la fase 1 falliva su TRE carte su
    // TRE, sempre con lo stesso identico sintomo.
    //
    // Conta anche per un secondo motivo, meno ovvio: i controlli
    // isPaginaRateLimit() e isCF() in _risolviSinglesENomeFetch() girano sul
    // CORPO della risposta, ma stanno DOPO il `if (!html)`. Se Cardmarket
    // serve la challenge o l'Error 1015 con uno status non-2xx, quel corpo
    // non viene mai letto e quei due controlli non vengono mai valutati:
    // si finisce nel ramo fetchFailed e si apre una tab anche in caso di
    // rate limit, cioè esattamente ciò che il commento in
    // _leggiNomeDaCardmarket dice di voler evitare.
    //
    // Qui NON si corregge niente: si registra soltanto lo status reale (più
    // gli header che Cloudflare usa per marcare le proprie risposte) così la
    // correzione, se servirà, si potrà scrivere sui fatti invece che sui
    // sospetti. Il valore di ritorno resta identico a prima in ogni ramo.
    if (r.status === 429) {
      _fetchRateLimitPerUrl.set(url, { il: Date.now(), retryAfter: r.headers.get('retry-after') });
      if (_fetchRateLimitPerUrl.size > 50) _fetchRateLimitPerUrl.delete(_fetchRateLimitPerUrl.keys().next().value);
      console.warn('[CardSync] fetch statico: 429 troppe richieste (Retry-After:', r.headers.get('retry-after'), ')', url);
    }
    if (!r.ok) {
      console.log('[CardSync] fetch statico NON OK:', {
        url,
        status: r.status,
        statusText: r.statusText,
        cfMitigated: r.headers.get('cf-mitigated'),
        cfRay: r.headers.get('cf-ray'),
        server: r.headers.get('server'),
        retryAfter: r.headers.get('retry-after'),
        contentType: r.headers.get('content-type'),
      });
      return null;
    }
    // v5.17: segnale UFFICIALE di Cloudflare ("cf-mitigated: challenge" è
    // presente su ogni risposta di challenge, qualunque sia lo status — vedi
    // developers.cloudflare.com → Challenge Pages → Detect a Challenge Page
    // response). Se arriva anche con status 2xx, la pagina NON va letta come
    // una carta: null, come per gli status non-2xx qui sopra (il chiamante
    // passa alla tab, esattamente come per "cloudflare").
    if (r.headers.get('cf-mitigated') === 'challenge') {
      console.log('[CardSync] fetch statico: challenge Cloudflare (cf-mitigated) con status', r.status, url);
      return null;
    }
    return await r.text();
  } catch (e) {
    console.log('[CardSync] fetch statico ECCEZIONE:', {
      url,
      nome: e && e.name,
      messaggio: e && e.message,
    });
    return null;
  }
}

// Estrae i link /Products/ (escluso /Singles/) dall'HTML grezzo di una pagina /Search?.
// I prodotti sealed stanno sotto percorsi come /Products/Sealed/, /Products/Displays/,
// /Products/Tins/, ecc. — tutti sotto /Products/ ma non /Singles/.
// FIX "non trova più risultati": Cardmarket può servire gli href sia assoluti
// (https://www.cardmarket.com/it/...) sia relativi (/it/...) — prima la regex
// richiedeva SEMPRE il dominio completo, quindi se il sito passava (anche solo
// in alcune pagine/varianti) a link relativi, l'estrazione trovava zero
// risultati pur essendo la pagina piena di prodotti. Ora il dominio è opzionale
// e viene riaggiunto in normalizzazione.
function _estraiLinkSealed(html) {
  const re = /href="(?:https:\/\/www\.cardmarket\.com)?(\/[a-z]{2}\/[^/]+\/Products\/(?!Singles\/)[^"?]+)"/gi;
  const trovati = new Set();
  let m;
  while ((m = re.exec(html)) !== null) {
    // Esclude pagine di categoria (solo 2 segmenti dopo /Products/): teniamo solo le pagine prodotto
    const path = m[1].split('/Products/')[1] || '';
    if (path.split('/').length >= 2) trovati.add('https://www.cardmarket.com' + m[1]);
  }
  return Array.from(trovati);
}

// FIX disambiguazione sealed troppo aggressiva: prima, appena la ricerca
// restituiva più di un link prodotto, si finiva SEMPRE nel pannello di
// correzione manuale — anche quando uno dei risultati corrispondeva
// chiaramente al nome cercato (es. "First Partner Illustration Collection
// Series 2", che su Cardmarket può comparire insieme a prodotti correlati
// con nomi simili). A differenza delle carte singole (che hanno un codice
// set univoco da matchare), i prodotti sealed vanno confrontati solo per
// nome — la condizione non si applica (Cardmarket ha solo "Mint" per i
// sealed) e la lingua viene già gestita a parte da _aggiungiLinguaSealed.
// Questa funzione prova un match esatto (o quasi) dello slug sul testo
// cercato prima di arrendersi alla disambiguazione manuale.
function _trovaMatchSealed(links, searchString) {
  if (links.length <= 1) return links[0] || null;
  if (!searchString) return null; // nessun testo su cui basare la scelta

  const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '');
  const qNorm = norm(searchString);
  if (!qNorm) return null;
  const slugNorm = (u) => norm((u.split('/').pop() || '').replace(/-/g, ' '));

  // 1. Match esatto: slug normalizzato identico alla query normalizzata.
  let candidati = links.filter(u => slugNorm(u) === qNorm);
  if (candidati.length === 1) return candidati[0];

  // 2. Match "contiene": lo slug include per intero il testo cercato
  //    (capita quando Cardmarket aggiunge suffissi tipo edizione/lingua).
  candidati = links.filter(u => slugNorm(u).includes(qNorm));
  if (candidati.length === 1) return candidati[0];

  return null; // ambiguità reale, nessun match univoco
}

// v5.36 (B16) — Formato del sito "NOME SET NUMERO" ("ZUBAT SIT 103",
// "Charizard ex OBF 125") e codice con lo spazio come nell'h1 ("BST 18").
// Prima tutte le parole non numeriche venivano unite ("zubatsit") e cercate
// nel nome dello slug ("zubat"): mai trovate → scelta manuale anche con un
// solo link giusto, oppure "non trovata" con un solo risultato.
// Restituisce { set, numero, nome } se il penultimo pezzo è una sigla
// (2-6 caratteri, almeno una lettera) e l'ultimo è il numero; altrimenti null.
function _setENumeroDaQuery(q) {
  const parti = String(q || '').trim().split(/\s+/).filter(Boolean);
  if (parti.length < 2) return null;
  const num = parti[parti.length - 1];
  const set = parti[parti.length - 2];
  if (!/^\d{1,4}$/.test(num)) return null;
  if (!/^[A-Za-z0-9]{2,6}$/.test(set) || !/[A-Za-z]/.test(set)) return null;
  return { set: set.toUpperCase(), numero: String(parseInt(num, 10)), nome: parti.slice(0, -2).join(' ') };
}

// Vero se il testo (ultimo pezzo dello slug "SIT103", oppure codice dell'h1
// "SIT 103") è esattamente SET + NUMERO, con eventuali zeri davanti al numero.
function _combaciaSetNumero(testo, sn) {
  const s = String(testo || '').toUpperCase().replace(/[\s-]+/g, '');
  return new RegExp('^' + sn.set + '0*' + sn.numero + '$').test(s);
}

// Nome della carta dallo slug, senza codice finale e senza -V1-/-V2-:
// "Flapple-V-V1-BST18" → "flapplev".
function _nomeDaSlugNormalizzato(u) {
  const segs = (u.split('/').pop() || '').split('-');
  return segs.slice(0, -1).filter(s => !/^V\d+$/i.test(s)).join('').toLowerCase().replace(/[^a-z0-9]/g, '');
}

// Scelta per SET+NUMERO (decisione di Claudio Q10: un solo risultato esatto
// si prende senza chiedere). null = questa regola non decide, si continua
// con quelle di prima.
function _sceltaPerSetNumero(links, sn) {
  const candidati = links.filter(u => _combaciaSetNumero((u.split('/').pop() || '').split('-').pop(), sn));
  if (candidati.length === 0) return null;
  if (!sn.nome) {
    // Solo due pezzi ("BST 18", "MEW 8"): la sigla potrebbe essere anche il
    // nome della carta ("MEW 8" = Wartortle MEW008 oppure un Mew numero 8).
    // Se tra i risultati c'è una carta che si chiama così, decide la regola
    // di prima (scelta manuale), così non torna il vecchio errore
    // "MEW 8 → Wartortle".
    const sigla = sn.set.toLowerCase();
    if (links.some(u => _nomeDaSlugNormalizzato(u).startsWith(sigla))) return null;
    if (candidati.length === 1) return { match: candidati[0] };
    return { disambiguation: true, opzioni: candidati };
  }
  if (candidati.length === 1) return { match: candidati[0] };
  const nomeNorm = sn.nome.toLowerCase().replace(/[^a-z0-9]/g, '');
  const perNome = candidati.filter(u => _nomeDaSlugNormalizzato(u).startsWith(nomeNorm));
  if (perNome.length === 1) return { match: perNome[0] };
  return { disambiguation: true, opzioni: perNome.length > 1 ? perNome : candidati };
}

// Distingue "codice" (nessuno spazio, es. "SV01006") da "nome + numero" (con
// spazio, es. "Eevee 55" o "Mew 8") e verifica SEMPRE la corrispondenza dello
// slug con la query, anche quando c'è un solo link candidato.
// FIX (bug "MEW 8" → apriva Wartortle): prima, se Cardmarket restituiva UN
// SOLO link (anche del tutto estraneo alla query cercata, per via della
// ricerca full-text lato sito), veniva accettato senza alcun controllo — un
// singolo risultato bastava per "vincere" a prescindere da cosa fosse
// davvero. Ora un risultato singolo viene accettato solo se la sua slug
// corrisponde realmente alla query (codice esatto, oppure nome+numero
// combinati); altrimenti si va in correzione manuale invece di salvare la
// carta sbagliata.
function _trovaMatchCartaSingola(links, searchString) {
  console.log('[CardSync] match check:', { query: searchString, links });
  const slugNorm = (u) => (u.split('/').pop() || '').toLowerCase().replace(/\s/g, '');

  // FIX (bug "MEW 8" → apriva Wartortle): l'ULTIMO segmento dello slug è
  // sempre {codiceSet}{numero} incollati (es. "MEW008" per il set "Pokémon
  // 151", che su Cardmarket usa proprio "MEW" come sigla ufficiale — non ha
  // niente a che fare col nome carta "Mew"). Confrontare il testo cercato
  // contro l'INTERO slug faceva sì che il codice-set stesso "contenesse" per
  // pura coincidenza il nome cercato (qui "mew" dentro "...-MEW008"),
  // producendo falsi positivi su carte completamente diverse. Ora il
  // confronto testo avviene SOLO sulla parte "nome" dello slug (tutti i
  // segmenti tranne l'ultimo — che può includere anche un marcatore
  // variante tipo "-V1-"), mai sul codice-set+numero finale. Il numero
  // atteso viene letto SOLO dalle cifre finali dell'ultimo segmento.
  const nomePortion = (u) => {
    const segs = (u.split('/').pop() || '').split('-');
    return (segs.length > 1 ? segs.slice(0, -1).join('') : segs[0] || '').toLowerCase();
  };
  const ultimoSegmento = (u) => {
    const segs = (u.split('/').pop() || '').split('-');
    return segs[segs.length - 1] || '';
  };

  const q = (searchString || '').trim();

  if (!q) {
    if (links.length === 1) return { match: links[0] };
    if (links.length > 1)   return { disambiguation: true, opzioni: links };
    return { match: null };
  }

  const isCodice = !/\s/.test(q); // nessuno spazio → codice set
  const qNorm = q.replace(/\s/g, '').toLowerCase();

  if (isCodice) {
    const exact = links.filter(u => slugNorm(u).endsWith(qNorm));
    if (exact.length === 1) return { match: exact[0] };
    if (exact.length > 1)   return { disambiguation: true, opzioni: exact };
    if (links.length > 1)   return { disambiguation: true, opzioni: links };
    // FIX (bug "carte vecchie non trovate", es. FST095 → Cardmarket
    // restituisce .../Singles/Fusion-Strike/Tynamo, SENZA alcun codice set
    // o numero nello slug): alcune espansioni più datate non includono
    // affatto il codice nello slug URL — solo il nome carta. Se Cardmarket ha
    // restituito UN SOLO risultato, il chiamante lo verifica leggendo il
    // codice EFFETTIVO dall'h1 della pagina (vedi _paginaCombaciaConQuery).
    if (links.length === 1) {
      return { verificaCandidato: links[0], tipoVerifica: 'codice', qNorm, q };
    }
    return { match: null }; // nessun link trovato
  }

  // ── v5.36: "NOME SET NUMERO" e "SET NUMERO" ──
  const sn = _setENumeroDaQuery(q);
  if (sn) {
    const esitoSet = _sceltaPerSetNumero(links, sn);
    if (esitoSet) return esitoSet;
  }

  // ── formato "nome + numero" ──
  // v5.36: con "NOME SET NUMERO" il confronto usa il nome senza la sigla del
  // set (prima "zubatsit" non poteva mai stare dentro lo slug "zubat").
  const parts = sn && sn.nome ? sn.nome.split(/\s+/).concat(sn.numero) : q.split(/\s+/);
  const numPart = parts.find(p => /^\d+$/.test(p));
  const textParts = parts.filter(p => !/^\d+$/.test(p)).map(p => p.toLowerCase());
  if (numPart && textParts.length > 0) {
    const numNorm = numPart.replace(/^0+/, '') || numPart;
    const textNorm = textParts.join('');
    const byNameAndNum = links.filter(u => {
      const hasText = nomePortion(u).includes(textNorm);
      const numMatch = ultimoSegmento(u).match(/(\d+)$/);
      const hasNum = numMatch && numMatch[1].replace(/^0+/, '') === numNorm;
      return hasText && hasNum;
    });
    if (byNameAndNum.length === 1) return { match: byNameAndNum[0] };
    if (byNameAndNum.length > 1)   return { disambiguation: true, opzioni: byNameAndNum };
  }
  if (links.length > 1) return { disambiguation: true, opzioni: links };
  // Stesso fallback di verifica-su-pagina-reale del ramo "codice" sopra,
  // per carte vecchie in formato "nome + numero" il cui slug non contiene
  // affatto il numero (o non nel formato atteso).
  if (links.length === 1 && numPart && textParts.length > 0) {
    return { verificaCandidato: links[0], tipoVerifica: 'nomeNumero', numNorm: numPart.replace(/^0+/, '') || numPart, textNorm: textParts.join(''), q };
  }
  return { match: null }; // un solo link ma nome+numero non confermati → NON accettarlo
}

// v5.36 — Unica regola per dire se una pagina carta (nome e codice letti
// dall'h1, slug dell'URL) è quella cercata con la query q. La usano la
// verifica del candidato singolo (fetch) e la lettura via scheda
// (_risolviNomeEPrezzoUnicaTab), che prima ne avevano due copie diverse.
//   - codice senza spazi ("SIT103"): codice dell'h1 uguale / che finisce con
//     la query (o viceversa); senza codice in pagina, lo slug deve finire così;
//   - "NOME SET NUMERO" / "SET NUMERO": codice dell'h1 = SET+NUMERO (senza
//     codice in pagina: ultimo pezzo dello slug);
//   - altrimenti nome + numero: numero del codice dell'h1 uguale e nome della
//     pagina che contiene il testo cercato (senza la sigla del set).
function _paginaCombaciaConQuery(q, nome, codice, slug) {
  q = String(q || '').trim();
  if (!q) return true;
  const codiceNorm = String(codice || '').toUpperCase().replace(/\s+/g, '');
  const slugUp = String(slug || '').toUpperCase();
  const ultimoSeg = slugUp.split('-').pop() || '';

  if (!/\s/.test(q)) {
    const qUp = q.toUpperCase();
    if (codiceNorm) return codiceNorm === qUp || codiceNorm.endsWith(qUp) || qUp.endsWith(codiceNorm);
    return slugUp.replace(/\s/g, '').endsWith(qUp);
  }

  const sn = _setENumeroDaQuery(q);
  if (sn && _combaciaSetNumero(codiceNorm || ultimoSeg, sn)) return true;

  const parti = sn && sn.nome ? sn.nome.split(/\s+/).concat(sn.numero) : q.split(/\s+/);
  const numPart = parti.find(p => /^\d+$/.test(p));
  const textNorm = parti.filter(p => !/^\d+$/.test(p)).join('').toUpperCase();
  if (!numPart || !textNorm) return false;
  const numNorm = String(parseInt(numPart, 10));
  const mNumPagina = codiceNorm.match(/(\d+)$/);
  if (mNumPagina) {
    const nomePaginaNorm = String(nome || '').toUpperCase().replace(/\s+/g, '');
    return String(parseInt(mNumPagina[1], 10)) === numNorm && nomePaginaNorm.includes(textNorm);
  }
  const segs = slugUp.split('-');
  const nomeSlug = segs.length > 1 ? segs.slice(0, -1).join('') : (segs[0] || '');
  const mNumSlug = ultimoSeg.match(/(\d+)$/);
  return nomeSlug.includes(textNorm) && !!mNumSlug && String(parseInt(mNumSlug[1], 10)) === numNorm;
}

// Verifica un candidato "incerto" (slug senza codice/numero riconoscibile,
// tipico di espansioni datate) leggendo il CODICE reale dall'h1 della sua
// pagina prodotto — molto più affidabile di qualunque euristica sullo slug.
// Restituisce ok:true solo se la pagina è davvero quella cercata
// (_paginaCombaciaConQuery); false in ogni altro caso (pagina
// irraggiungibile, lista di un'espansione, codice diverso) — mai
// un'accettazione "al buio".
async function _verificaCandidatoSuPagina(url, tipoVerifica, dati) {
  const html = await _fetchHtml(url);
  if (!html || typeof html !== 'string') return { ok: false };
  if (_ePaginaListaSingles(url, _testoH1DaHtml(html))) return { ok: false }; // FIX (v5.30)
  const { nome, codice } = _estraiNomeDaHtml(html);
  const ok = _paginaCombaciaConQuery(dati.q, nome, codice, url.split('/').pop() || '');
  return { ok, html, nome, codice };
}

// Legge il prezzo dalla pagina prodotto sealed (tab aperta con polling).
// Cardmarket mostra il prezzo minimo dei venditori nella sezione .price-container.
function _leggiPrezzoSealed(urlProdotto, tabIdEsterno, requestId = null) {
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa
    // tabIdEsterno (worker tab della sessione bulk), la navighiamo con
    // tabs.update invece di aprirne una nuova — vedi _prontaWorkerTabId in
    // testa al file. Se quella tab non esiste più (chiusa a mano), ne
    // apriamo una nuova al volo: il chiamante la registrerà come nuova
    // worker tab guardando il tabId nel risultato.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (troppe tab in sequenza → Cloudflare): se il chiamante vuole
        // riusare questa tab per tutta la sessione bulk, non la chiudiamo —
        // resta pronta per il prodotto successivo. Si chiude solo per le
        // chiamate "una tantum" (nessuna worker tab richiesta) o
        // esplicitamente a fine sessione (messaggio CHIUDI_WORKER_TAB).
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function tentaLettura() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [RATE_LIMIT_MARKERS, CF_TITLES],
          func: async (RATE_LIMIT_MARKERS, CF_TITLES) => {
            const testo = (document.title + ' ' + (document.body?.innerText?.slice(0, 2000) || '')).toLowerCase();
            if (RATE_LIMIT_MARKERS.some(m => testo.includes(m))) return { rateLimited: true };
            const title = document.title.toLowerCase();
            if (CF_TITLES.some(t => title.includes(t)) || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || ''))))
              return { cloudflare: true };
            // FIX: questa tab è già sulla pagina prodotto (ci arriviamo apposta
            // per leggere il prezzo) — è il punto giusto per estrarre anche
            // l'immagine, che prima non veniva mai letta qui.
            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            // FIX: og:image per i sealed è spesso il logo generico del sito
            // invece della foto del prodotto. Le foto vere sono sempre su
            // product-images.s3.cardmarket.com — qualunque altro dominio
            // (es. static.cardmarket.com, dove vive il logo) va scartato a
            // prescindere dal path esatto. Se scartiamo, cerchiamo un <img>
            // reale nella pagina come fallback.
            if (immagine && !immagine.includes('product-images')) immagine = null;
            if (!immagine) {
              const imgReale = Array.from(document.querySelectorAll('img'))
                .map(i => i.src)
                .find(src => src && src.includes('product-images'));
              immagine = imgReale || null;
            }
            // FIX (bug "riga con nome vuoto sovrascritta dal prodotto
            // successivo"): questa tab è già sulla pagina prodotto — costo
            // zero per rileggere anche il nome, usato come rete di
            // sicurezza quando la ricerca non l'ha già trovato (vedi
            // _leggiNomeSealedDaCardmarket).
            let nomeDom = null;
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              nomeDom = clone.textContent.trim() || null;
            }
            const selettori = ['.price-container .fw-bold', '.col-offer-price .fw-bold', '[class*="price"] .fw-bold', '.color-primary.fw-bold'];
            for (const sel of selettori) {
              const el = document.querySelector(sel);
              if (el && el.textContent.includes('€')) {
                const m = el.textContent.trim().match(/([\d,.]+)\s*€/);
                if (m) {
                  const p = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
                  return { prezzo: isNaN(p) ? null : p, immagine, nomeDom };
                }
              }
            }
            const rows = document.querySelectorAll('.article-row');
            if (rows.length === 0) return null; // non ancora caricato
            return { prezzo: null, immagine, nomeDom }; // caricato ma nessun prezzo
          },
        }, async (res) => {
          if (chrome.runtime.lastError) return;
          const val = res?.[0]?.result;
          if (val === null || val === undefined) return;
          if (val.rateLimited) { chiudi({ prezzo: null, rateLimited: true }); return; }
          if (val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'sealed');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): aggiorna l'heartbeat
              // a ogni ciclo dell'attesa Cloudflare — è qui che le sessioni
              // restano bloccate più a lungo (fino a 10 minuti configurabili).
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi({ prezzo: null, cloudflareTimeout: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  return (CF_TITLES.some(t => title.includes(t)) || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')))) ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ prezzo: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = _scadenzaLettura(() => !caricata, () => chiudi({ prezzo: null, immagine: null }), (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }
          chiudi({ prezzo: val.prezzo ?? null, immagine: await _immagineAUrlDati(val.immagine || null), nome: val.nomeDom || null });
        });
      }

      function onLoad(id, info) {
        if (id === tabId && info.status === 'complete') { caricata = true; }
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = _scadenzaLettura(() => !caricata, () => chiudi({ prezzo: null, immagine: null }), (t) => { timeout = t; });
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlProdotto }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlProdotto, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlProdotto, active: false }, avviaCon);
    }
  });
}

// Fetch + estrazione per un prodotto sealed: cerca link /Products/ (non /Singles/)
// nell'HTML della pagina di ricerca, poi legge nome dall'h1 della pagina prodotto.
async function _leggiNomeSealedFetch(urlNome, lingua) {
  const html = await _fetchHtml(urlNome);
  if (!html && _fetchHtmlEraRateLimit(urlNome)) return { urlProdotto: null, nome: null, rateLimited: true }; // v5.36 (D16)
  if (!html) return { urlProdotto: null, nome: null, fetchFailed: true };
  const lower = html.toLowerCase();
  if (isPaginaRateLimit(lower)) return { urlProdotto: null, nome: null, rateLimited: true };
  const isCF = _htmlEChallengeCloudflare(lower); // v5.17: solo <title> + marcatori di challenge
  if (isCF) return { urlProdotto: null, nome: null, cloudflare: true };

  // Se l'URL è già una pagina prodotto (non una ricerca), estrai subito il nome
  if (!urlNome.includes('/Search')) {
    const { nome } = _estraiNomeDaHtml(html);
    const immagine = await _estraiImmagineDaHtml(html);
    // FIX: prima si faceva .split('?')[0] scartando anche un eventuale
    // ?language= già presente nell'URL passato — ora si riapplica sempre
    // in modo esplicito con la lingua richiesta.
    const urlProdotto = _aggiungiLinguaSealed(urlNome.split('?')[0], lingua);
    return { urlProdotto, nome: _rimuoviCategoriaDalNome(nome, urlProdotto), immagine };
  }

  const links = _estraiLinkSealed(html);
  if (links.length === 0) return { urlProdotto: null, nome: null };

  let urlProdottoBase;
  if (links.length === 1) {
    urlProdottoBase = links[0];
  } else {
    const searchString = (() => {
      try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; }
    })();
    const match = _trovaMatchSealed(links, searchString);
    if (!match) {
      const slugLabel = (u) => (u.split('/').pop() || '').replace(/-/g, ' ').trim();
      return { urlProdotto: null, nome: null, disambiguation: true, opzioni: links.map(u => ({ urlSingles: u, label: slugLabel(u) })) };
    }
    urlProdottoBase = match;
  }

  let htmlProd = await _fetchHtml(urlProdottoBase);
  // v5.17: anche la seconda pagina può essere una challenge — mai leggerla
  // come prodotto (vedi _htmlEChallengeCloudflare); si prosegue come se il
  // fetch non fosse riuscito.
  if (htmlProd && _htmlEChallengeCloudflare(htmlProd.toLowerCase())) htmlProd = null;
  const { nome } = htmlProd ? _estraiNomeDaHtml(htmlProd) : { nome: null };
  const immagine = htmlProd ? await _estraiImmagineDaHtml(htmlProd) : null;
  // FIX: qui prima urlProdotto restava "nudo" (senza ?language=), quindi la
  // pagina del prodotto veniva aperta senza alcun filtro lingua.
  const urlProdotto = _aggiungiLinguaSealed(urlProdottoBase, lingua);
  return { urlProdotto, nome: _rimuoviCategoriaDalNome(nome, urlProdotto), immagine };
}

// Cardmarket a volte include nell'<h1> della pagina prodotto anche la
// categoria (es. "Box Sets", "Boosters", "Tins") insieme al nome vero e
// proprio — sia che venga letta col span-stripping del fetch statico, sia
// (soprattutto) leggendo il textContent grezzo dell'h1 via tab. Questa
// funzione ricava la categoria dallo slug URL (es. /Products/Box-Sets/...
// → "BOX SETS") e la toglie dal nome ovunque compaia (prefisso o suffisso),
// così il fix vale per qualsiasi categoria, non solo "Box Sets".
function _rimuoviCategoriaDalNome(nome, urlProdotto) {
  if (!nome || !urlProdotto) return nome;
  let path;
  try { path = new URL(urlProdotto).pathname; } catch (_) { return nome; }
  const segmentoCategoria = (path.split('/Products/')[1] || '').split('/')[0] || '';
  const categoriaLabel = segmentoCategoria.replace(/-/g, ' ').trim().toUpperCase();
  if (!categoriaLabel) return nome;
  const escaped = categoriaLabel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp('(^|\\s)' + escaped + '(\\s|$)', 'i');
  return nome.replace(re, ' ').replace(/\s+/g, ' ').trim() || nome;
}

// Aggiunge (o sostituisce) il parametro ?language=ID sulla URL di un PRODOTTO
// sealed già risolto — MAI sulla URL di ricerca (/Products/Search), che lo
// ignora sempre. A differenza delle Singles, i sealed non hanno minCondition
// (esiste solo "Mint"), quindi qui filtriamo solo la lingua.
// FIX: prima la lingua veniva messa solo sull'URL di ricerca (ignorato da
// Cardmarket) e mai riapplicata all'URL del prodotto trovato → il filtro
// spariva nel passaggio ricerca→prodotto.
function _aggiungiLinguaSealed(urlProdotto, lingua) {
  if (!urlProdotto) return urlProdotto;
  let url = urlProdotto
    .replace(/[?&]language=[^&]*/g, '')
    .replace(/[?&]idLanguage=[^&]*/g, '')
    .replace(/\?&/, '?').replace(/&&+/g, '&').replace(/[?&]$/, '');
  const idLingua = LINGUA_MAP_SHARED[(lingua || 'IT').toUpperCase().trim()];
  if (!idLingua) return url;
  return url + (url.includes('?') ? '&' : '?') + 'language=' + idLingua;
}

// Orchestratore sealed: fetch → prezzo via tab → fallback tab se Cloudflare
// O SE il fetch statico restituisce zero risultati. Quest'ultimo caso è
// gestito a parte perché, a differenza della ricerca Singles (i cui risultati
// sono renderizzati server-side), la pagina di ricerca prodotti Sealed sembra
// iniettare i risultati via JS: un fetch senza rendering JS può quindi
// legittimamente vedere "zero link" anche quando il prodotto esiste davvero.
// Senza questo fallback, quei prodotti risultavano sempre "non trovati".
async function _leggiNomeSealedDaCardmarket(urlNome, lingua, _tentativo = 0, tabIdEsterno = null, requestId = null) {
  if (_tentativo === 0) _contaCartaCodaPerPrezzi(); // v5.40 (4.10)
  const fase1 = await _leggiNomeSealedFetch(urlNome, lingua);

  if (fase1.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
  if (fase1.disambiguation) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: true, opzioni: fase1.opzioni || [] };

  const zeroRisultatiDaFetch = !fase1.cloudflare && !fase1.fetchFailed && !fase1.urlProdotto;

  if (fase1.cloudflare || fase1.fetchFailed || zeroRisultatiDaFetch) {
    const viaTab = await _risolviProdottoSealedTab(urlNome, lingua, tabIdEsterno, requestId);
    // FIX (worker tab about:blank mai usata): se la worker tab passata non
    // era più valida, _risolviProdottoSealedTab ne ha aperta una nuova al
    // volo — aggiorniamo subito lo storage così i prodotti successivi della
    // stessa sessione bulk la trovano e la riusano.
    if (tabIdEsterno != null && viaTab && viaTab.tabId && viaTab.tabId !== tabIdEsterno) {
      await _salvaWorkerTabId('sealed', viaTab.tabId);
      tabIdEsterno = viaTab.tabId;
    }

    if (viaTab.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
    if (viaTab.disambiguation) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: true, opzioni: viaTab.opzioni || [] };

    if (viaTab.urlProdotto) {
      const risPrez = await _leggiPrezzoSealed(viaTab.urlProdotto, tabIdEsterno, requestId);
      if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
        await _salvaWorkerTabId('sealed', risPrez.tabId);
        tabIdEsterno = risPrez.tabId;
      }
      if (risPrez.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
      // FIX: quando la scelta del prodotto avviene dalla pagina di ricerca
      // (risultati iniettati via JS — il caso più comune), viaTab.immagine è
      // sempre null perché quella tab non naviga fino alla pagina prodotto.
      // La tab aperta da _leggiPrezzoSealed invece ci arriva davvero: usiamo
      // la sua immagine come fallback.
      // FIX (bug "riga con nome vuoto sovrascritta dal prodotto successivo"):
      // stesso discorso per il nome — se viaTab non l'ha ottenuto (capita
      // quando si parte dalla lista risultati, senza mai navigare alla
      // pagina prodotto), usiamo quello riletto da _leggiPrezzoSealed, che
      // quella pagina la visita per forza. Nessuna tab in più: è la stessa
      // già aperta per il prezzo.
      const nomeFinale = _rimuoviCategoriaDalNome(viaTab.nome || risPrez.nome, viaTab.urlProdotto);
      return { nome: nomeFinale, urlProdotto: viaTab.urlProdotto, prezzo: risPrez.prezzo ?? null, immagine: viaTab.immagine || risPrez.immagine || null };
    }

    // Anche la tab reale non ha trovato nulla: qui è davvero "non trovato",
    // ma concediamo ancora un paio di retry per coprire lentezza di rete/rendering.
    if (_tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 3000 * (_tentativo + 1)));
      return _leggiNomeSealedDaCardmarket(urlNome, lingua, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, urlProdotto: null, prezzo: null, immagine: null };
  }

  // Leggi il prezzo dalla pagina prodotto (tab) — urlProdotto già noto dal fetch statico
  const risPrez = await _leggiPrezzoSealed(fase1.urlProdotto, tabIdEsterno, requestId);
  if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
    await _salvaWorkerTabId('sealed', risPrez.tabId);
  }
  if (risPrez.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };

  // FIX: stessa rete di sicurezza del ramo via-tab qui sopra — se il fetch
  // statico non è riuscito a estrarre il nome, usa quello riletto dalla tab
  // già aperta per il prezzo invece di lasciare la riga senza nome.
  const nomeFinale = _rimuoviCategoriaDalNome(fase1.nome || risPrez.nome, fase1.urlProdotto);
  return { nome: nomeFinale, urlProdotto: fase1.urlProdotto, prezzo: risPrez.prezzo ?? null, immagine: fase1.immagine || risPrez.immagine || null };
}

// Risolve il link prodotto sealed aprendo una tab REALE (con rendering JS),
// usata come fallback quando il fetch statico non basta (Cloudflare, errore
// di rete, o pagina di ricerca coi risultati iniettati via JS).
function _risolviProdottoSealedTab(urlNome, lingua, tabIdEsterno = null, requestId = null) {
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (worker tab about:blank mai usata): stesso fix di
    // _risolviNomeEPrezzoUnicaTab — questo fallback apriva sempre una tab
    // nuova, ignorando la worker tab della sessione bulk passata dal
    // chiamante.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (worker tab about:blank mai usata): non chiudere la tab se va
        // riusata per il resto della sessione bulk.
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function tentaLettura() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES],
          func: async (CF_TITLES) => {
            const testo = (document.title + ' ' + (document.body?.innerText?.slice(0, 2000) || '')).toLowerCase();
            if (testo.includes('error 1015') || testo.includes('you are being rate limited')) return { rateLimited: true };

            const title = document.title.toLowerCase();
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')));
            if (isCloudflare) return { cloudflare: true };

            const path = window.location.pathname;

            // Caso A: redirect diretto a una pagina prodotto (risultato unico)
            if (path.includes('/Products/') && !path.includes('/Products/Search')) {
              const h1 = document.querySelector('h1');
              let nome = null;
              if (h1) {
                // Come nel fetch statico: rimuove eventuali span (badge/etichette)
                // annidati nell'h1 prima di leggere il testo.
                const clone = h1.cloneNode(true);
                clone.querySelectorAll('span').forEach(s => s.remove());
                nome = clone.textContent.trim();
              }
              const metaImg = document.querySelector('meta[property="og:image"]');
              let immagine = metaImg ? metaImg.getAttribute('content') : null;
              // FIX: vedi commento analogo in _leggiPrezzoSealed — og:image per
              // i sealed è spesso il logo generico, non la foto del prodotto.
              // Accettiamo solo URL dal dominio delle foto reali; altrimenti
              // proviamo a pescare un <img> reale dalla pagina.
              if (immagine && !immagine.includes('product-images')) immagine = null;
              if (!immagine) {
                const imgReale = Array.from(document.querySelectorAll('img'))
                  .map(i => i.src)
                  .find(src => src && src.includes('product-images'));
                immagine = imgReale || null;
              }
              // Ripulisce comunque l'eventuale categoria residua (es. "Box Sets")
              // non racchiusa in uno <span>, ricavandola dallo slug dell'URL.
              return { urlProdotto: location.origin + path, nome, immagine, _path: path };
            }

            // Caso B: pagina di ricerca → estrai i link a prodotti (esclude /Singles/)
            const tuttiLink = Array.from(document.querySelectorAll('a[href*="/Products/"]'))
              .filter(a => !a.pathname.includes('/Products/Singles/'))
              .filter(a => (a.pathname.split('/Products/')[1] || '').split('/').filter(Boolean).length >= 2);
            const unici = Array.from(new Set(tuttiLink.map(a => a.origin + a.pathname)));

            if (unici.length === 0) return undefined; // non ancora renderizzato → il polling riprova

            // FIX disambiguazione troppo aggressiva: come nel percorso fetch
            // statico (_trovaMatchSealed in background.js — qui reimplementato
            // inline perché executeScript non può referenziare funzioni esterne),
            // prova prima un match per nome sul testo cercato prima di arrendersi
            // alla disambiguazione manuale.
            let scelto;
            if (unici.length === 1) {
              scelto = unici[0];
            } else {
              const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '');
              const slugNorm = (u) => norm((u.split('/').pop() || '').replace(/-/g, ' '));
              const searchString = new URLSearchParams(window.location.search).get('searchString') || '';
              const qNorm = norm(searchString);
              if (qNorm) {
                let candidati = unici.filter(u => slugNorm(u) === qNorm);
                if (candidati.length === 1) scelto = candidati[0];
                else {
                  candidati = unici.filter(u => slugNorm(u).includes(qNorm));
                  if (candidati.length === 1) scelto = candidati[0];
                }
              }
            }

            if (!scelto) {
              const slugLabel = (u) => (u.split('/').pop() || '').replace(/-/g, ' ').trim();
              return { disambiguation: true, opzioni: unici.map(u => ({ urlSingles: u, label: slugLabel(u) })) };
            }

            return { urlProdotto: scelto, nome: null };
          },
        }, async (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return; // non pronto → riprova

          if (val.rateLimited) { chiudi({ urlProdotto: null, nome: null, rateLimited: true }); return; }

          if (val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'sealed');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): vedi commento
              // analogo in _leggiPrezzoSealed.
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi({ urlProdotto: null, nome: null, cloudflareTimeout: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  return (CF_TITLES.some(t => title.includes(t)) || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')))) ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ urlProdotto: null, nome: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlProdotto: null, nome: null }), (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          if (val.disambiguation) { chiudi({ urlProdotto: null, nome: null, disambiguation: true, opzioni: val.opzioni }); return; }

          // FIX: come nel percorso fetch statico, la lingua va applicata qui
          // sull'URL del prodotto risolto — mai su quello di ricerca.
          const urlConLingua = _aggiungiLinguaSealed(val.urlProdotto, lingua);
          chiudi({
            urlProdotto: urlConLingua,
            nome: _rimuoviCategoriaDalNome(val.nome, urlConLingua),
            immagine: await _immagineAUrlDati(val.immagine || null),
          });
        });
      }

      function onLoad(id, info) { if (id === tabId && info.status === 'complete') caricata = true; }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlProdotto: null, nome: null }), (t) => { timeout = t; });
    }

    // FIX (worker tab about:blank mai usata): riusa la worker tab della
    // sessione, se passata — vedi commento analogo in
    // _risolviNomeEPrezzoUnicaTab più sopra.
    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlNome }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
    }
  });
}


// FIX "non trova più risultati": stesso motivo di _estraiLinkSealed sopra —
// il dominio nell'href ora è opzionale, e viene riaggiunto qui in normalizzazione.
// Questa è la funzione usata dal flusso "aggiungi carta" (ricerca singole).
function _estraiLinkSingles(html) {
  const re = /href="(?:https:\/\/www\.cardmarket\.com)?(\/[a-z]{2}\/[^/]+\/Products\/Singles\/[^"?]+)"/gi;
  const trovati = new Set();
  let m;
  while ((m = re.exec(html)) !== null) {
    // FIX (bug "Dedenne-V1-DAA78" → apre .../Singles/Darkness-Ablaze troncato):
    // la pagina di ricerca include anche link "di sola espansione" tipo
    // .../Singles/Darkness-Ablaze (senza il nome carta) — stesso problema già
    // risolto per _estraiLinkSealed più sotto. Un link a una carta VERA ha
    // sempre almeno 2 segmenti dopo /Singles/: {Espansione}/{Nome-Carta-Numero}.
    // Senza questo filtro, il link spurio dell'espansione (che non contiene mai
    // "-Vn-") sopravvive al filtro "senzaVariante" più in basso ed esclude il
    // fallback che dovrebbe recuperare il vero link della carta.
    const path = m[1].split('/Products/Singles/')[1] || '';
    if (path.split('/').filter(Boolean).length >= 2) {
      trovati.add('https://www.cardmarket.com' + m[1]);
    }
  }
  return Array.from(trovati);
}

// Estrae l'URL dell'immagine principale della carta dall'HTML statico di /Singles/.
// Cardmarket inserisce l'immagine nel tag <meta property="og:image"> nell'<head>,
// presente nellHTML server-side (verificato dal DOM reale 2025-06).
// Esempio: https://product-images.s3.cardmarket.com/51/CBB3C/850277/850277.jpg
// Logo generico usato da Cardmarket come og:image quando il prodotto non ha
// ancora una foto reale caricata, o — caso frequente per i SEALED — quando
// og:image punta semplicemente al logo del sito invece che alla foto del
// prodotto. Va escluso, altrimenti finisce salvato come se fosse la foto
// del prodotto.
//
// FIX: prima si escludeva solo un path specifico del logo
// ('static.cardmarket.com/img/logos/'). Se Cardmarket serve il logo da un
// path leggermente diverso il controllo non lo intercetta e passa comunque
// (bug osservato sui sealed: veniva salvato il logo al posto della foto).
// Regola più robusta: le foto REALI dei prodotti sono sempre servite dal
// dominio product-images.s3.cardmarket.com — qualunque altro dominio
// (incluso static.cardmarket.com, dove vive il logo) non è mai una foto
// prodotto vera, indipendentemente dal path esatto.
const PLACEHOLDER_IMG_MARKERS = ['static.cardmarket.com/img/logos/'];

function _eImmagineSegnaposto(url) {
  if (!url) return true;
  if (!url.includes('product-images')) return true;
  return PLACEHOLDER_IMG_MARKERS.some(m => url.includes(m));
}

async function _estraiImmagineDaHtml(html) {
  const m =
    html.match(/property="og:image"\s+content="(https:\/\/[^"]*cardmarket[^"]*\.(?:jpg|png|webp|jpeg))"/) ||
    html.match(/content="(https:\/\/[^"]*cardmarket[^"]*\.(?:jpg|png|webp|jpeg))"\s+property="og:image"/) ||
    html.match(/property="og:image"\s+content="(https:\/\/product-images[^"]+)"/) ||
    html.match(/content="(https:\/\/product-images[^"]+)"\s+property="og:image"/);
  let url = m ? (m[1] || m[3] || null) : null;

  if (_eImmagineSegnaposto(url)) {
    // FIX sealed: og:image spesso è il logo generico invece della foto del
    // prodotto. La foto vera, quando esiste, compare comunque altrove
    // nell'HTML (galleria prodotto) servita da product-images.s3.cardmarket.com
    // — la cerchiamo direttamente lì come fallback.
    const fallback = html.match(/https:\/\/product-images\.s3\.cardmarket\.com\/[^"'\s)]+\.(?:jpg|png|webp|jpeg)/i);
    url = fallback ? fallback[0] : null;
  }

  if (_eImmagineSegnaposto(url)) return null;
  // FIX (immagine mai visibile sul sito): un URL esterno viene bloccato da
  // Cardmarket se richiesto da un dominio diverso (referer sbagliato) — qui
  // però il fetch di questa pagina è già partito da background.js, che ha
  // il privilegio di ignorare il CORS sui domini in host_permissions. Un
  // solo punto di conversione invece di ripeterlo nei 5 punti che chiamano
  // questa funzione.
  return _immagineAUrlDati(url);
}

// FIX (v5.30, carte salvate col nome "Singole HeartGold e SoulSilver"):
// un URL /Singles/ non porta sempre a una carta. Se il link scelto (o
// incollato, o salvato da una disambiguazione) punta all'espansione, o se
// Cardmarket reindirizza lì una carta con più versioni, si arriva sulla
// LISTA delle singole dell'espansione: lì l'<h1> è "Singole <Espansione>" e
// veniva letto e salvato come se fosse il nome della carta, senza errore.
// Una pagina così va trattata come disambiguazione (errore → correzione
// manuale con le opzioni trovate), mai come carta valida.
// Due segnali, basta uno: meno di 2 segmenti dopo /Singles/ nell'URL
// (una carta vera è sempre {Espansione}/{Carta}), oppure <h1> che inizia
// (o finisce) con "Singole"/"Singles"/"Einzelkarten" — nessuna carta
// Pokémon ha un nome così.
const RE_H1_LISTA_SINGLES = /^(?:singole|singles|einzelkarten|cartas sueltas|cartes à l'unité|cartas avulsas)(?:\s|$)|\s(?:singole|singles|einzelkarten)$/i;

function _ePaginaListaSingles(url, testoH1) {
  const idx = (url || '').indexOf('/Singles/');
  if (idx !== -1) {
    const resto = url.slice(idx + '/Singles/'.length).split(/[?#]/)[0];
    if (resto.split('/').filter(Boolean).length < 2) return true;
  }
  return RE_H1_LISTA_SINGLES.test((testoH1 || '').trim());
}

function _testoH1DaHtml(html) {
  const m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (!m) return '';
  return m[1].replace(/<span[^>]*>[\s\S]*?<\/span>/gi, '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
}

// Opzioni da proporre quando si finisce sulla lista di un'espansione: i link
// alle carte presenti nella pagina, ristretti (se possibile) a quelli col
// nome della carta dell'URL di partenza (es. .../Pikachu → Pikachu-V1-...,
// Pikachu-V2-...).
// v5.36: parte dai link già estratti dalla pagina (la usa la lettura via
// scheda, che prima ne aveva una copia nello script iniettato). La lettura
// senza scheda non la usa più: un link diretto che porta alla lista ora è
// "link non valido" e si cerca per nome (B17).
function _opzioniDaLinkSingles(links, urlPartenza) {
  const idx = (urlPartenza || '').indexOf('/Singles/');
  const segs = idx !== -1 ? urlPartenza.slice(idx + '/Singles/'.length).split(/[?#]/)[0].split('/').filter(Boolean) : [];
  let scelti = links;
  if (segs.length >= 2) {
    const nomeCarta = (segs[segs.length - 1].split('-')[0] || '').toLowerCase();
    const filtrati = nomeCarta ? links.filter(u => (u.split('/').pop() || '').toLowerCase().startsWith(nomeCarta)) : [];
    if (filtrati.length > 0) scelti = filtrati;
  }
  return _opzioniDaLink(scelti);
}

function _opzioniDaLink(links) {
  const slugLabel = (u) => (u.split('/').pop() || '')
    .replace(/-V(\d+)-/gi, ' ★V$1 ').replace(/-/g, ' ').trim();
  return links.map(u => ({ urlSingles: u, label: slugLabel(u) }));
}

// Estrae nome e codice dall'HTML statico di una pagina /Singles/.
// Cardmarket struttura il titolo come "Nome Carta (CodiceSet)" dove il codice
// è SEMPRE nell'ULTIMA coppia di parentesi. Carte come "Unown (V) (MEW 186)"
// devono restituire nome="UNOWN (V)" e codice="MEW 186".
//
// Eccezione: le Black Star Promo SV (SVP) hanno il codice ALL'INIZIO, es:
//   "(SVP en 011) Arcanine" → nome="ARCANINE", codice="SVP EN 011"
// In quel caso lastIndexOf('(') restituisce 0, la slice prima è vuota → nome null.
// Gestiamo questo fallback cercando la prima parentesi e usando il testo DOPO di essa.
function _estraiNomeDaHtml(html) {
  const m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (!m) return { nome: null, codice: null };
  return _nomeECodiceDaTestoH1(m[1].replace(/<span[^>]*>[\s\S]*?<\/span>/gi, '').replace(/<[^>]+>/g, ''));
}

// v5.36: la stessa lettura partendo dal testo dell'h1 già ripulito dagli
// <span> (lo manda lo script iniettato nella scheda, vedi
// _decidiRisoluzioneDaScheda): prima la scheda ne aveva una copia sua.
function _nomeECodiceDaTestoH1(testoGrezzo) {
  const testo = String(testoGrezzo || '').trim();
  // Trova l'ULTIMA coppia di parentesi → è sempre il codice set su Cardmarket
  const ultimaParentesiIdx = testo.lastIndexOf('(');
  if (ultimaParentesiIdx === -1) return { nome: testo.trim(), codice: null };
  const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')'));
  const codice = codiceRaw ? codiceRaw.trim().toUpperCase() : null;
  const nomePre = testo.slice(0, ultimaParentesiIdx).trim();
  // Caso promo: codice in testa → la parte prima è vuota, il nome è dopo la parentesi chiusa
  // Es: "(SVP EN 011) Arcanine" → nomePre='', nomePost='Arcanine'
  // Fallback aggiuntivo: se il nome dopo ')' è vuoto (raro ma possibile per alcune SVP),
  // estrai il testo dall'URL della pagina tramite il chiamante (qui restituiamo null
  // e il chiamante usa lo slug come fallback).
  if (!nomePre) {
    const chiusaIdx = testo.lastIndexOf(')');
    const nomePost = chiusaIdx !== -1 ? testo.slice(chiusaIdx + 1).trim() : null;
    // Se anche nomePost è vuoto, prova a prendere il testo PRIMA della prima '('
    // (caso estremo: titolo malformato tipo "(SVP EN 011)")
    if (!nomePost) {
      const primaParentesiIdx = testo.indexOf('(');
      const nomeAnte = primaParentesiIdx > 0 ? testo.slice(0, primaParentesiIdx).trim() : null;
      return { nome: nomeAnte || null, codice };
    }
    return { nome: nomePost, codice };
  }
  return { nome: nomePre, codice };
}

// Risolve urlSingles e nome via fetch puro (nessuna tab aperta).
//
// FIX (bug Dedenne-V1-DAA78 e simili): rimossa TUTTA la logica di
// esclusione/selezione basata sullo slug -V1-/-V2-/-V3- (OLO_SLUG_CHECK,
// OLO_SLUG, ramo 'ST'). Era pensata per distinguere varianti speciali
// (Pokéball/Masterball/Stamped) ma il parametro oloType, nel flusso reale
// dell'estensione, vale SEMPRE '' oppure 'RH' — mai 'PB'/'MB'/'ST'/'PR' —
// quindi quei rami non venivano mai eseguiti. L'unico effetto pratico era il
// filtro "senzaVariante" nel ramo else, che escludeva a priori qualunque link
// con "-Vn-" nello slug: quando quello slug corrispondeva all'UNICA stampa
// esistente della carta (es. Dedenne-V1-DAA78, Floragato-V2-CBB1C02), il link
// giusto veniva scartato e, se nella pagina restava un altro link innocuo
// (es. quello di sola espansione), l'estensione finiva per aprire quello
// sbagliato. La Reverse Holo non c'entra: viene riconosciuta a valle, sulla
// pagina prodotto, tramite il badge aria-label="Reverse Holo" sulla riga
// d'offerta (vedi rigaERH/rigaEd più sotto) — non tramite lo slug dell'URL.
// Ora si sceglie sempre tra TUTTI i link trovati, con lo stesso match esatto
// su codice/nome; se restano ambiguità reali si va in disambiguazione manuale.
async function _risolviSinglesENomeFetch(urlNome, oloType) {
  const html = await _fetchHtml(urlNome);
  console.log('[CardSync] fetch statico:', { urlNome, htmlRicevuto: !!html, lunghezza: html ? html.length : 0 });
  if (!html && _fetchHtmlEraRateLimit(urlNome)) return { urlSingles: null, nome: null, codice: null, rateLimited: true }; // v5.36 (D16)
  if (!html) return { urlSingles: null, nome: null, codice: null, fetchFailed: true };

  const lower = html.toLowerCase();
  if (isPaginaRateLimit(lower)) return { urlSingles: null, nome: null, codice: null, rateLimited: true };
  const isCF = _htmlEChallengeCloudflare(lower); // v5.17: solo <title> + marcatori di challenge
  console.log('[CardSync] cloudflare rilevato su fetch statico?', isCF);
  if (isCF) return { urlSingles: null, nome: null, codice: null, cloudflare: true };

  // v5.43: _leggiNomeDaCardmarketInterno non manda più qui i link diretti
  // /Singles/ (li legge la scheda del prezzo); il ramo resta per chi la
  // chiama con un link diretto.
  if (urlNome.includes('/Singles/')) {
    // FIX (v5.30): vedi _ePaginaListaSingles — lista dell'espansione = errore.
    if (_ePaginaListaSingles(urlNome, _testoH1DaHtml(html))) {
      // v5.36 (B17): un link diretto che porta alla lista dell'espansione è
      // un link vecchio (es. Magikarp-HS72, oggi Magikarp-V1-HS72: Cardmarket
      // rimanda alla lista con "Prodotto sbagliato!"). Prima si proponevano le
      // 30 carte della prima pagina della lista, quasi mai quella giusta; ora
      // il chiamante riparte dalla ricerca per nome (_leggiNomeDaCardmarket).
      console.log('[CardSync] link Cardmarket non più valido (porta alla lista dell\'espansione):', urlNome);
      return { urlSingles: null, nome: null, codice: null, linkNonValido: true };
    }
    const { nome, codice } = _estraiNomeDaHtml(html);
    const immagine = await _estraiImmagineDaHtml(html);
    return { urlSingles: urlNome.split('?')[0], nome, codice, immagine };
  }

  const links = _estraiLinkSingles(html);
  console.log('[CardSync] link estratti dalla pagina di ricerca:', links);
  // v5.36: nonTrovata = esito che non cambia ritentando (vedi 1.6 del piano):
  // nessun risultato, nessun link che combacia, pagina letta ma diversa.
  if (links.length === 0) return { urlSingles: null, nome: null, codice: null, nonTrovata: true };

  const slugLabel = (u) => (u.split('/').pop() || '')
    .replace(/-V(\d+)-/gi, ' ★V$1 ').replace(/-/g,' ').trim();
  const toOpzione = (u) => ({ urlSingles: u, label: slugLabel(u) });

  // FIX (bug "MEW 8" → apriva Wartortle): vedi commento su
  // _trovaMatchCartaSingola. Non si accetta più un singolo link "a scatola
  // chiusa" — viene sempre verificato contro la query (codice esatto se
  // senza spazi, nome+numero combinati se con spazio).
  const searchString = (() => { try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch(_) { return ''; } })();
  const esito = _trovaMatchCartaSingola(links, searchString);
  if (esito.disambiguation) {
    return { urlSingles: null, nome: null, codice: null, disambiguation: true, opzioni: esito.opzioni.map(toOpzione) };
  }

  // FIX (bug "carte vecchie non trovate", es. FST095 su Fusion Strike):
  // lo slug da solo non basta a confermare/negare questo candidato — l'unico
  // modo per saperlo davvero è leggere il codice dalla sua pagina prodotto
  // reale. La pagina viene comunque fetchata qui sotto (serve comunque per
  // nome/codice/immagine), quindi il costo è zero: nessuna richiesta extra
  // rispetto al percorso normale, solo una verifica in più prima di
  // accettare il link invece di scartarlo alla cieca in base al solo slug.
  if (esito.verificaCandidato) {
    const verifica = await _verificaCandidatoSuPagina(esito.verificaCandidato, esito.tipoVerifica, esito);
    if (!verifica.ok) {
      return { urlSingles: null, nome: null, codice: null, nonTrovata: !!verifica.html };
    }
    const immagine = verifica.html ? await _estraiImmagineDaHtml(verifica.html) : null;
    return { urlSingles: esito.verificaCandidato, nome: verifica.nome, codice: verifica.codice, immagine };
  }

  if (!esito.match) {
    return { urlSingles: null, nome: null, codice: null, nonTrovata: true };
  }
  // v5.43 (6.2): qui si scaricava anche la pagina della carta, solo per nome,
  // codice e immagine: li legge già la scheda del prezzo, che si apre subito
  // dopo sulla stessa pagina (_leggiPrezzoDaSingles). Una richiesta in meno.
  return { urlSingles: esito.match, nome: null, codice: null, immagine: null };
}

// FIX (pulizia codice morto): rimosse due funzioni intere mai chiamate
// da nessun punto del file — _risolviSinglesENome() (fallback via tab per
// sola risoluzione nome, senza prezzo) e _leggiNomeDaSingles() (apriva una
// tab a parte solo per leggere l'h1) — entrambe superate rispettivamente
// da _risolviNomeEPrezzoUnicaTab() (versione "fusa" risoluzione+prezzo in
// una sola tab, usata davvero dal fallback Cloudflare) e dalla lettura
// nome integrata direttamente nelle funzioni di risoluzione esistenti.
// Ognuna apriva una propria tab bypassando del tutto il riuso della
// worker tab — codice morto che, se mai richiamato per errore, avrebbe
// riportato il vecchio problema "troppe tab in sequenza" già risolto.

// v5.36 — Decide cosa fare con i dati grezzi letti nella scheda (vedi
// tentaLetturaRisoluzione in _risolviNomeEPrezzoUnicaTab), con le stesse
// regole della lettura senza scheda:
//   - pagina carta: lista di un'espansione → "link non valido" se si era
//     partiti da un link diretto (B17), scelta manuale se da una ricerca;
//     altrimenti nome e codice dall'h1 e, se si veniva da una ricerca, verifica
//     che sia la carta cercata (_paginaCombaciaConQuery);
//   - pagina di ricerca: _trovaMatchCartaSingola sui link trovati.
function _decidiRisoluzioneDaScheda(val, searchStringOriginale, eraRicerca, urlNome) {
  if (val.tipo === 'singles') {
    if (_ePaginaListaSingles(val.url, val.testoH1)) {
      if (!eraRicerca) return { linkNonValido: true };
      return { disambiguation: true, opzioni: _opzioniDaLinkSingles(val.hrefs || [], urlNome) };
    }
    const { nome, codice } = _nomeECodiceDaTestoH1(val.testoH1);
    if (eraRicerca && searchStringOriginale
      && !_paginaCombaciaConQuery(searchStringOriginale, nome, codice, val.url.split('/').pop() || '')) {
      return { urlSingles: null };
    }
    return { urlSingles: val.url, nome, codice };
  }
  const q = val.searchString || searchStringOriginale;
  const esito = _trovaMatchCartaSingola(val.hrefs || [], q);
  if (esito.disambiguation) return { disambiguation: true, opzioni: _opzioniDaLink(esito.opzioni) };
  if (esito.verificaCandidato) return { urlSingles: esito.verificaCandidato, nome: null, verificaDopo: q };
  if (esito.match) return { urlSingles: esito.match, nome: null };
  return { urlSingles: null };
}

// ── RISOLUZIONE + PREZZO IN UN'UNICA TAB ──────────────────────────────────────
// Versione "fusa" del fallback: invece di aprire due tab sequenziali
// (_risolviSinglesENome poi _leggiPrezzoDaSingles), usa LA STESSA tab per
// entrambe le fasi. Dopo aver risolto nome/codice/urlSingles, naviga la tab
// già aperta (chrome.tabs.update) verso l'URL filtrato e fa polling per il prezzo.
// Dimezza il numero di navigazioni/tab aperte per carta nel caso di fallback.
function _risolviNomeEPrezzoUnicaTab(urlNome, lingua, condizione, oloType = '', firstEd = false, tabIdEsterno = null, requestId = null) {
  // Letta PRIMA della navigazione: se Cardmarket reindirizza subito a un
  // singolo risultato, window.location.search sulla pagina di arrivo può non
  // contenere più ?searchString= — serve il valore originale per poter
  // validare il redirect (vedi FIX "MEW 8" più sotto in tentaLetturaRisoluzione).
  const _searchStringOriginale = (() => {
    try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; }
  })();
  const _eraRicerca = urlNome.includes('/Search');

  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (worker tab about:blank mai usata): questo fallback (Cloudflare o
    // fetch statico fallito) apriva SEMPRE una tab nuova con tabs.create,
    // ignorando del tutto la worker tab della sessione bulk passata dal
    // chiamante — la tab about:blank pre-creata restava inutilizzata e se
    // ne apriva una in più ogni volta che scattava questo fallback. Stesso
    // pattern di riuso già applicato a _leggiPrezzoDaSingles/_leggiPrezzoSealed.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let fase = 'risoluzione'; // 'risoluzione' → 'prezzo'
      let caricata = false;
      let pollTimer, timeout;
      let risolto = {}; // { nome, codice, urlSingles } una volta nota la fase 1
      let verificaDopoPrezzo = null; // v5.36: query da verificare sull'h1 della pagina prezzo
      let variantiRitentateSenzaFiltro = false; // evita loop: un solo retry senza filtro RH/1ED

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (worker tab about:blank mai usata): se il chiamante vuole
        // riusare questa tab per tutta la sessione bulk, non la chiudiamo —
        // resta pronta per la carta successiva. Si chiude solo per le
        // chiamate "una tantum" o esplicitamente a fine sessione
        // (messaggio CHIUDI_WORKER_TAB).
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function passaAFasePrezzo(urlSingles, ignoraVarianti) {
        // FIX: stesso bug del percorso fetch statico — senza applicare qui
        // isReverseHolo/isFirstEd, il polling prezzo su questa tab leggeva
        // sempre l'offerta della stampa normale per carte RH/1ED.
        // ignoraVarianti=true è usato dal fallback più sotto per le carte
        // "RH di base" (es. molte cinesi) dove il filtro nativo troverebbe
        // zero offerte perché non esiste una stampa normale da escludere.
        const base = costruisciUrlFiltrato(urlSingles, lingua, condizione);
        const urlConFiltri = ignoraVarianti ? base : _appendVariantParams(base, oloType, firstEd);
        fase = 'prezzo';
        caricata = false;
        clearTimeout(timeout);
        chrome.tabs.update(tabId, { url: urlConFiltri }, () => {
          if (chrome.runtime.lastError) {
            chiudi({ ...risolto, prezzo: null, immagine: null });
          }
        });
        // v5.36: un candidato ancora da verificare non si accetta per timeout.
        timeout = _scadenzaLettura(() => !caricata, () => chiudi(verificaDopoPrezzo
          ? { urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }
          : { ...risolto, prezzo: null, immagine: null }), (t) => { timeout = t; });
      }

      function tentaLetturaRisoluzione() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES],
          // v5.36: lo script raccoglie solo i dati grezzi della pagina (link,
          // h1); la scelta della carta la fa il service worker con le stesse
          // regole della lettura senza scheda (_decidiRisoluzioneDaScheda).
          // Prima qui c'erano due copie della scelta, diverse da quella vera.
          func: (CF_TITLES) => {
            const title = document.title.toLowerCase();
            const corpoTesto = (title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (corpoTesto.includes('error 1015') || corpoTesto.includes('you are being rate limited')) {
              return { rateLimited: true };
            }
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')));
            if (isCloudflare) return { cloudflare: true };

            const path = window.location.pathname;
            // Link alle carte (almeno espansione + carta dopo /Singles/).
            const hrefs = Array.from(new Set(Array.from(document.querySelectorAll('a[href*="/Singles/"]'))
              .map(a => { try { const u = new URL(a.href); return u.origin + u.pathname; } catch (_) { return null; } })
              .filter(u => {
                if (!u) return false;
                const i = u.indexOf('/Singles/');
                return i !== -1 && u.slice(i + '/Singles/'.length).split('/').filter(Boolean).length >= 2;
              })));

            if (path.includes('/Singles/')) {
              const h1 = document.querySelector('h1');
              if (!h1) return undefined;
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              return { tipo: 'singles', url: location.origin + path, testoH1: clone.textContent.replace(/\s+/g, ' ').trim(), hrefs };
            }
            if (hrefs.length === 0) return undefined; // risultati non ancora caricati → riprova
            return { tipo: 'ricerca', hrefs, searchString: new URLSearchParams(window.location.search).get('searchString') || '' };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return;

          if (val && val.rateLimited) {
            // Error 1015: niente challenge da risolvere, chiudi subito e propaga.
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, rateLimited: true });
            return;
          }

          if (val && val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'carte');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            // CF_RISOLUZIONE_TIMEOUT_MS: vedi commento nell'altra occorrenza in
            // _risolviSinglesENome — stesso fix, stesso motivo, stessa fonte
            // (impostazioni utente sliderCfTimeout).
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): vedi commento
              // analogo in _leggiPrezzoSealed.
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) {
                chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, cloudflareTimeout: true });
                return;
              }
              chrome.scripting.executeScript({
                target: { tabId },
                args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  const isCF = CF_TITLES.some(t => title.includes(t))
                    || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')));
                  return isCF ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(() => {
                    if (fase === 'risoluzione') tentaLetturaRisoluzione();
                    else tentaLetturaPrezzo();
                  }, 600);
                  timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }), (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else {
                  setTimeout(aspettaRisoluzione, 1500);
                }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          // v5.36: scelta nel service worker (vedi sopra).
          const decisione = _decidiRisoluzioneDaScheda(val, _searchStringOriginale, _eraRicerca, urlNome);
          if (decisione.disambiguation || decisione.linkNonValido) {
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, ...decisione });
            return;
          }
          if (!decisione.urlSingles) {
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, nonTrovata: true });
            return;
          }

          // Nome risolto direttamente (caso /Singles/): salva e passa subito al prezzo.
          // Caso /Search? → link (nome: null): passa al prezzo, poi leggiamo comunque
          // l'h1 della pagina filtrata nella fase prezzo per recuperare nome/codice.
          // Un solo risultato da verificare (verificaDopo): si controlla il codice
          // dell'h1 nella fase prezzo, prima di accettarlo.
          risolto = { urlSingles: decisione.urlSingles, nome: decisione.nome, codice: decisione.codice || null };
          verificaDopoPrezzo = decisione.verificaDopo || null;
          passaAFasePrezzo(decisione.urlSingles);
        });
      }

      function tentaLetturaPrezzo() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        _assicuraSharedInScheda(tabId).then(() => { if (caricata) leggiPrezzoNellaScheda(); }); // v5.42 (5.2)
      }

      function leggiPrezzoNellaScheda() {
        chrome.scripting.executeScript({
          target: { tabId },
          func: async () => {
            // Error 1015: nessun challenge da risolvere, va segnalato subito.
            const _testoPagina = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (_testoPagina.includes('error 1015') || _testoPagina.includes('you are being rate limited')) {
              return { rateLimited: true };
            }

            const params = new URLSearchParams(window.location.search);
            const idLanguage   = params.get('language') || params.get('idLanguage') || null;
            const minCondition = (params.get('minCondition') || '').toLowerCase() || null;
            const isReverseHolo = params.get('isReverseHolo') === 'Y';
            const isFirstEd = params.get('isFirstEd') === 'Y';

            // FIX (duplicazione eliminata): la logica di filtro righe (lingua,
            // condizione, Reverse Holo, Prima Edizione, carrello cliccabile)
            // vive ora in un'unica fonte di verità — window.rigaSoddisfaFiltriShared,
            // definita in shared.js. v5.42: shared.js lo inietta
            // _assicuraSharedInScheda subito prima di questa lettura, nello
            // stesso "mondo isolato" dell'estensione su questa scheda — quindi è
            // già disponibile qui. Fallback fail-open (nessun filtro) nell'improbabile caso in cui
            // non sia ancora pronta, per non ripetere l'incidente "tutte le carte
            // Esaurita".
            function rigaOk(riga, ignoraVarianti) {
              if (typeof window.rigaSoddisfaFiltriShared === 'function') {
                return window.rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
              }
              console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile, nessun filtro applicato a questa riga');
              return true;
            }

            // Recupera nome/codice dall'h1 se non già noti (caso /Search? → link)
            let nomeDom = null, codiceDom = null;
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              const testo = clone.textContent.trim();
              const ultimaParentesiIdx = testo.lastIndexOf('(');
              if (ultimaParentesiIdx === -1) {
                nomeDom = testo;
              } else {
                const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')')).trim().toUpperCase();
                codiceDom = codiceRaw || null;
                const nomePre = testo.slice(0, ultimaParentesiIdx).trim();
                if (!nomePre) {
                  const chiusaIdx = testo.lastIndexOf(')');
                  const nomeDopoP = chiusaIdx !== -1 ? testo.slice(chiusaIdx + 1).trim() || null : null;
                  nomeDom = nomeDopoP || null;
                } else { nomeDom = nomePre; }
              }
            }

            const righe = Array.from(document.querySelectorAll('.article-row'));
            if (righe.length === 0) return undefined; // pagina ancora in caricamento → riprova

            let valide = righe.filter(r => rigaOk(r, false));
            // FIX (carte disponibili SOLO in Reverse Holo/Prima Edizione — tipico
            // di molte espansioni cinesi): se l'esclusione badge lascia zero
            // righe, ripeschiamo includendole invece di restituire "Esaurita"
            // per una carta che in realtà ha offerte disponibili.
            if (valide.length === 0) {
              const valideSenzaEsclusione = righe.filter(r => rigaOk(r, true));
              if (valideSenzaEsclusione.length > 0) valide = valideSenzaEsclusione;
            }

            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            if (immagine && immagine.includes('static.cardmarket.com/img/logos/')) immagine = null;

            if (valide.length === 0) return { prezzo: null, immagine, nomeDom, codiceDom };

            const selettori = [
              '.price-container .fw-bold',
              '.col-offer-price .fw-bold',
              '[class*="price"] .fw-bold',
              '.color-primary.fw-bold',
              '.price',
            ];

            for (const riga of valide) {
              for (const sel of selettori) {
                const el = riga.querySelector(sel);
                if (el && el.textContent.includes('€')) {
                  const match = el.textContent.match(/([\d,.]+)\s*€/);
                  if (match) {
                    const pulito = match[1].replace(/\./g, '').replace(',', '.');
                    return { prezzo: parseFloat(pulito) || null, immagine, nomeDom, codiceDom };
                  }
                }
              }
            }
            return { prezzo: null, immagine, nomeDom, codiceDom };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return;

          if (val.rateLimited) {
            chiudi({ ...risolto, prezzo: null, immagine: null, rateLimited: true });
            return;
          }

          // Completa nome/codice se mancanti (caso /Search? risolto solo qui)
          if (!risolto.nome && val.nomeDom && !_ePaginaListaSingles('', val.nomeDom)) risolto.nome = val.nomeDom; // FIX (v5.31)
          if (!risolto.codice && val.codiceDom) risolto.codice = val.codiceDom;

          // v5.36: un solo risultato della ricerca, slug senza codice → si
          // accetta solo se l'h1 della pagina è davvero la carta cercata.
          if (verificaDopoPrezzo) {
            const slugPagina = (risolto.urlSingles || '').split('/').pop() || '';
            if (!_paginaCombaciaConQuery(verificaDopoPrezzo, val.nomeDom, val.codiceDom, slugPagina)) {
              chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, nonTrovata: true });
              return;
            }
            verificaDopoPrezzo = null;
          }

          // FIX (carte cinesi e altre espansioni "RH di base"): vedi
          // commento esteso nel percorso fetch statico (_leggiNomeDaCardmarket).
          // Se la lettura con isReverseHolo/isFirstEd non trova prezzo,
          // ritenta UNA volta senza quei parametri prima di arrenderci.
          const prezzoTrovato = val?.prezzo ?? null;
          if (prezzoTrovato === null && (oloType === 'RH' || firstEd) && !variantiRitentateSenzaFiltro) {
            variantiRitentateSenzaFiltro = true;
            passaAFasePrezzo(risolto.urlSingles, true);
            return;
          }

          // FIX: prima l'immagine veniva convertita in base64 qui (fetch +
          // FileReader), ma quel valore veniva quasi sempre scartato più in
          // alto (vedi _leggiNomeDaCardmarket) a favore dell'URL grezzo del
          // fetch statico — lavoro sprecato. Ora si usa sempre l'URL grezzo,
          // coerente con tutto il resto dell'estensione (popup.js, flusso
          // sealed) e con sidebar.html, che si aspetta un URL da proxare
          // tramite images.weserv.nl, non un data URI.
          chiudi({ ...risolto, prezzo: prezzoTrovato, immagine: val?.immagine || null });
        });
      }

      function onLoad(id, info) {
        if (id !== tabId || info.status !== 'complete') return;
        caricata = true;
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(() => {
        if (fase === 'risoluzione') tentaLetturaRisoluzione();
        else tentaLetturaPrezzo();
      }, 600);
      timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }), (t) => { timeout = t; });
    }

    // FIX (worker tab about:blank mai usata): se il chiamante ha passato
    // una worker tab (sessione bulk), la navighiamo con tabs.update invece
    // di aprirne una nuova. Se quella tab non esiste più (es. chiusa a
    // mano dall'utente), ne apriamo una nuova al volo — il chiamante la
    // registrerà come nuova worker tab leggendo il tabId nel risultato.
    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlNome }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
    }
  });
}

// Apre l'URL /Singles/ già filtrato (con language= e minCondition=) e legge il prezzo
// con polling ogni 600ms perché le .article-row vengono iniettate via JS dopo il load.
// Applica gli stessi filtri DOM di content.js (lingua + condizione).
//
// FIX Cloudflare: questa funzione viene usata dal flusso principale
// _leggiNomeDaCardmarket quando il nome/urlSingles è già stato risolto via
// FETCH statico (fase1, nessuna tab aperta) — questa è quindi la SECONDA
// tab reale che si apre per la carta, solo per leggere il prezzo. Prima non
// c'era ALCUN rilevamento Cloudflare qui: se questa tab incappava nel
// challenge, il polling restava bloccato su ".article-row" vuoto fino al
// timeout di 15s, e la carta veniva salvata con prezzo/immagine null, senza
// nessun avviso sonoro né possibilità di risolvere il challenge. Ora si
// comporta come le altre funzioni "tab" dell'estensione: rileva Cloudflare,
// avvisa (suono + focus finestra) e aspetta la risoluzione entro il timeout
// configurato dall'utente, prima di riprendere il polling del prezzo.

function _leggiPrezzoDaSingles(urlConFiltri, tabIdEsterno, requestId = null) {
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa
    // tabIdEsterno (worker tab della sessione bulk), la navighiamo con
    // tabs.update invece di aprirne una nuova ogni volta — vedi
    // _prontaWorkerTabId in testa al file.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;
      // v5.43 (6.2): ultima lettura della pagina senza offerte (h1 e indirizzo),
      // per dire a tempo scaduto "pagina letta, nessuna offerta" (senzaOfferte).
      let ultimaPaginaSenzaOfferte = null;

      // FIX (bug "riga con nome vuoto sovrascritta dalla carta successiva"):
      // questa tab, aperta per il solo ricontrollo prezzo, era comunque già
      // sulla pagina /Singles/ della carta — un posto perfetto per rileggere
      // ANCHE nome/codice a costo zero (nessuna tab aggiuntiva), da usare
      // come rete di sicurezza quando la carta era stata inserita a suo
      // tempo senza nome (vedi chiamanti in aggiungi_carta_popup.js).
      // v5.43 (6.2): extra = { linkNonValido } (la scheda è finita sulla lista
      // dell'espansione), { senzaOfferte } (pagina letta, nessuna offerta),
      // { cloudflare } (challenge non risolto in tempo).
      function chiudi(prezzo, immagine, nome, codice, extra = null) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (troppe tab in sequenza → Cloudflare): la worker tab riusata
        // per tutta la sessione bulk NON viene mai chiusa qui — resta aperta
        // per la carta successiva. Si chiude solo per le chiamate "una
        // tantum" o esplicitamente a fine sessione (CHIUDI_WORKER_TAB).
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ prezzo, immagine: immagine || null, nome: nome || null, codice: codice || null, tabId, ...(extra || {}) });
      }

      function chiudiPerTempo() {
        if (!ultimaPaginaSenzaOfferte) { chiudi(null, null); return; }
        const letti = _nomeECodiceDaTestoH1(ultimaPaginaSenzaOfferte.testoH1);
        chiudi(null, null, letti.nome || null, letti.codice || null, { senzaOfferte: true });
      }

      function tentaLettura() {
        if (!caricata) return;
        // FIX (bug "resta bloccato su una carta"): a ogni tick di polling
        // aggiorna il timestamp heartbeat — vedi commento su _richiesteAttive.
        _touchRichiesta(requestId, tabId);
        _assicuraSharedInScheda(tabId).then(() => { if (caricata) leggiNellaScheda(); }); // v5.42 (5.2)
      }

      function leggiNellaScheda() {
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES],
          func: async (CF_TITLES) => {
            // Error 1015: nessun challenge da risolvere, va segnalato subito.
            const _testoPagina = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (_testoPagina.includes('error 1015') || _testoPagina.includes('you are being rate limited')) {
              return { rateLimited: true };
            }

            // ── Rilevamento Cloudflare ──
            // FIX: prima questo controllo non esisteva in questa funzione —
            // vedi commento sopra la dichiarazione di _leggiPrezzoDaSingles.
            const title = document.title.toLowerCase();
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')));
            if (isCloudflare) return { cloudflare: true };

            const params = new URLSearchParams(window.location.search);
            const idLanguage   = params.get('language') || params.get('idLanguage') || null;
            const minCondition = (params.get('minCondition') || '').toLowerCase() || null;
            const isReverseHolo = params.get('isReverseHolo') === 'Y';
            const isFirstEd = params.get('isFirstEd') === 'Y';

            // FIX (duplicazione eliminata): vedi commento gemello in
            // _risolviNomeEPrezzoUnicaTab più sopra — stessa logica, ora
            // centralizzata in window.rigaSoddisfaFiltriShared (shared.js),
            // iniettato in questa scheda da _assicuraSharedInScheda subito prima
            // (v5.42). Fallback fail-open se per qualche motivo non lo fosse.
            function rigaOk(riga, ignoraVarianti) {
              if (typeof window.rigaSoddisfaFiltriShared === 'function') {
                return window.rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
              }
              console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile, nessun filtro applicato a questa riga');
              return true;
            }

            // Rilettura nome/codice dall'h1 — vedi commento su chiudi() più
            // sopra: questa tab è già sulla pagina /Singles/, costo zero.
            // v5.43 (6.2): qui solo il testo dell'h1 senza gli <span>; nome e
            // codice li ricava il service worker con _nomeECodiceDaTestoH1 (la
            // stessa lettura della pagina scaricata: dalla 5.43 è la scheda
            // l'unica fonte del nome). Con l'indirizzo finale della pagina, per
            // riconoscere un link che porta alla lista dell'espansione.
            let testoH1 = '';
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              testoH1 = clone.textContent.replace(/\s+/g, ' ').trim();
            }
            const urlPagina = location.origin + location.pathname;

            const righe = Array.from(document.querySelectorAll('.article-row'));
            // Offerte non ancora caricate (o nessuna offerta) → il polling riprova.
            if (righe.length === 0) return { inAttesa: true, testoH1, urlPagina };

            let valide = righe.filter(r => rigaOk(r, false));
            // FIX (carte disponibili SOLO in Reverse Holo/Prima Edizione — tipico
            // di molte espansioni cinesi): se l'esclusione badge lascia zero
            // righe, ripeschiamo includendole invece di restituire "nessun
            // prezzo" (falso "Esaurita") per una carta che ha offerte disponibili.
            if (valide.length === 0) {
              const valideSenzaEsclusione = righe.filter(r => rigaOk(r, true));
              if (valideSenzaEsclusione.length > 0) valide = valideSenzaEsclusione;
            }
            if (valide.length === 0) return { prezzo: null, immagine: null, testoH1, urlPagina };

            const selettori = [
              '.price-container .fw-bold',
              '.col-offer-price .fw-bold',
              '[class*="price"] .fw-bold',
              '.color-primary.fw-bold',
              '.price',
            ];
            // Estrai immagine dal DOM (meta og:image, già nel DOM renderizzato)
            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            if (immagine && immagine.includes('static.cardmarket.com/img/logos/')) immagine = null;

            for (const riga of valide) {
              for (const sel of selettori) {
                const el = riga.querySelector(sel);
                if (el && el.textContent.includes('€')) {
                  const match = el.textContent.match(/([\d,.]+)\s*€/);
                  if (match) {
                    const pulito = match[1].replace(/\./g, '').replace(',', '.');
                    return { prezzo: parseFloat(pulito) || null, immagine, testoH1, urlPagina };
                  }
                }
              }
            }
            return { prezzo: null, immagine, testoH1, urlPagina };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return; // righe non ancora nel DOM → riprova
          // FIX: prima, quando nessuna riga soddisfaceva i filtri, la func
          // iniettata restituiva null e questo ramo lo trattava come
          // "risultato definitivo, nessun prezzo" — ma da quando la stessa
          // lettura recupera anche nomeDom/codiceDom, quel caso ritorna
          // sempre un oggetto (mai più null), quindi qui resta solo la
          // guardia difensiva per l'improbabile null residuo.
          if (val === null) { chiudi(null, null); return; }
          if (val.rateLimited) { chiudi('RateLimit', null); return; }

          if (val.cloudflare) {
            // FIX: prima Cloudflare qui non veniva mai gestito (vedi commento
            // sopra la funzione) — la tab restava a pollare ".article-row"
            // per sempre, senza risultati, fino al timeout di 15s, salvando
            // poi la carta senza prezzo né immagine. Ora si comporta come le
            // altre tab dell'estensione: avvisa l'utente (suono + focus) e
            // aspetta la risoluzione del challenge entro il timeout
            // configurato, prima di riprendere il polling del prezzo.
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'carte');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): vedi commento
              // analogo in _leggiPrezzoSealed.
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi(null, null, null, null, { cloudflare: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  return (CF_TITLES.some(t => title.includes(t)) || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')))) ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi(null, null); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = _scadenzaLettura(() => !caricata, chiudiPerTempo, (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          // v5.43 (6.2): link che porta alla lista dell'espansione (link vecchio:
          // Cardmarket ci rimanda, "Prodotto sbagliato!"). Prima lo scopriva la
          // lettura preliminare della pagina, ora tolta (_leggiNomeDaCardmarketInterno).
          if (val.urlPagina !== undefined && _ePaginaListaSingles(val.urlPagina, val.testoH1 || '')) {
            chiudi(null, null, null, null, { linkNonValido: true });
            return;
          }
          if (val.inAttesa) { ultimaPaginaSenzaOfferte = val; return; } // nessuna offerta (ancora) → riprova

          // FIX: come nell'altra occorrenza in _risolviNomeEPrezzoUnicaTab,
          // niente più conversione base64 — si passa sempre l'URL grezzo,
          // coerente col resto dell'estensione e con sidebar.html.
          // FIX (bug "prezzo corrotto su carte Esaurite"): era `val?.prezzo ?? val`
          // — con ?? il fallback scatta anche quando val.prezzo è null (caso
          // legittimo: pagina caricata ma nessuna offerta valida), sostituendo
          // il prezzo con l'INTERO oggetto val invece di lasciarlo null. La
          // colonna prezzo finiva così con un valore corrotto (es. un oggetto
          // serializzato) al posto di restare vuota, sia per le carte aggiunte
          // in bulk sia per il ricontrollo prezzo mancante. Nessun fallback a
          // val: se prezzo è null, deve restare null.
          const letti = _nomeECodiceDaTestoH1(val.testoH1);
          chiudi(val?.prezzo ?? null, val?.immagine || null, letti.nome || null, letti.codice || null);
        });
      }

      function onLoad(id, info) {
        if (id !== tabId || info.status !== 'complete') return;
        caricata = true;
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = _scadenzaLettura(() => !caricata, chiudiPerTempo, (t) => { timeout = t; });
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlConFiltri }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlConFiltri, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlConFiltri, active: false }, avviaCon);
    }
  });
}