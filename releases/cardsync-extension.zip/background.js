// Service worker dell'estensione.
// A ogni rilascio: VERSIONE_MOTORE = manifest.json = releases/latest-version.txt.
// Il nome nel manifest resta "CardSync Pro": aggiorna_cardsync.bat cerca l'estensione così.
// Le funzioni passate a chrome.scripting.executeScript girano nella pagina di Cardmarket:
// non vedono funzioni né variabili del service worker, solo i loro argomenti.

importScripts('shared.js');
// supabase.bundle.js col punto: con un nome sbagliato il service worker non parte (errore 15).
importScripts('supabase.bundle.js', 'supabase_adapter.js');

const VERSIONE_MOTORE = '5.82';

function _creaSvegliaSeManca(nome, periodoMinuti) {
  const periodInMinutes = Math.max(periodoMinuti, 0.5);
  return Promise.resolve(chrome.alarms.get(nome))
    .then((esistente) => {
      if (esistente && esistente.periodInMinutes === periodInMinutes) return;
      return chrome.alarms.create(nome, { periodInMinutes });
    })
    .catch(() => chrome.alarms.create(nome, { periodInMinutes }));
}

function _scadenzaLettura(staCaricando, chiudiOra, rimetti) {
  return setTimeout(() => {
    if (staCaricando()) rimetti(setTimeout(chiudiOra, TEMPO_EXTRA_LETTURA_MS));
    else chiudiOra();
  }, TEMPO_MAX_LETTURA_MS);
}

const _iniezioniSharedInCorso = new Map();
let _ultimoLoginVistoInScheda = 0;
// ultimo stato scritto (true dentro, false fuori, null non confermato): un cambio si scrive subito
let _ultimoStatoLoginScritto = null;
function _assicuraSharedInScheda(tabId) {
  if (_iniezioniSharedInCorso.has(tabId)) return _iniezioniSharedInCorso.get(tabId);
  const p = new Promise((resolve) => {
    try {
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => ({
          shared: typeof window.rigaSoddisfaFiltriShared === 'function',
          loggato: !!document.getElementById('account-dropdown'),
          fuori: !document.getElementById('account-dropdown') && !!document.getElementById('login-signup'),
        }),
      }, (r) => {
        if (chrome.runtime.lastError) { resolve(false); return; }
        const stato = r && r[0] && r[0].result;
        // ogni pagina di Cardmarket aperta dall'estensione dice se si è dentro o fuori:
        // niente schede in più solo per controllare. Un cambio (es. dentro → fuori) si scrive
        // subito, lo stesso stato al massimo una volta al minuto.
        if (stato && (stato.loggato || stato.fuori)) {
          const dentro = !!stato.loggato;
          if (dentro !== _ultimoStatoLoginScritto || Date.now() - _ultimoLoginVistoInScheda > 60 * 1000) {
            _ultimoLoginVistoInScheda = Date.now();
            _ricordaStatoLoginCardmarket(dentro);
          }
        }
        if (stato && stato.shared === true) { resolve(true); return; }
        chrome.scripting.executeScript({ target: { tabId }, files: ['shared.js'] }, () => {
          resolve(!chrome.runtime.lastError);
        });
      });
    } catch (_) {
      resolve(false);
    }
  }).finally(() => _iniezioniSharedInCorso.delete(tabId));
  _iniezioniSharedInCorso.set(tabId, p);
  return p;
}

async function _apriOFocalizzaTabApp() {
  const url = chrome.runtime.getURL('app.html');
  const esistenti = await chrome.tabs.query({ url: url + '*' });
  if (esistenti && esistenti.length > 0) {
    const tab = esistenti[0];
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: url + '#coda' });
  }
}
chrome.action.onClicked.addListener(_apriOFocalizzaTabApp);

let _riaperturaInCorso = false;
async function _riapriAppSeChiusa() {
  if (_riaperturaInCorso) return;
  _riaperturaInCorso = true;
  try {
    const { riapriAppSeChiusa } = await chrome.storage.local.get('riapriAppSeChiusa');
    if (riapriAppSeChiusa !== true) return;
    const base = chrome.runtime.getURL('app.html');
    const tutte = await chrome.tabs.query({});
    if (tutte.some(t => ((t.url || t.pendingUrl || '')).startsWith(base))) return;
    const finestre = await chrome.windows.getAll({ windowTypes: ['normal'] });
    if (!finestre || finestre.length === 0) return;
    const finestra = finestre.find(f => f.focused) || finestre[0];
    await chrome.tabs.create({ url: base + '#coda', active: false, windowId: finestra.id });
    console.log('[CardSync] app riaperta (Riapri l\'app se viene chiusa)');
  } catch (e) {
    console.warn('[CardSync] riapertura app non riuscita:', e && e.message);
  } finally {
    _riaperturaInCorso = false;
  }
}

chrome.tabs.onRemoved.addListener((tabId, info) => {
  setTimeout(() => { _riapriAppSeChiusa(); }, info && info.isWindowClosing ? 5000 : 2000);
});

chrome.runtime.onStartup.addListener(() => {
  setTimeout(() => { _riapriAppSeChiusa(); }, 8000);
});

_creaSvegliaSeManca('riapri-app', 1);

async function _ricaricaSeFileAggiornati() {
  try {
    const r = await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' });
    const suDisco = (await r.json()).version;
    const inUso = chrome.runtime.getManifest().version;
    if (!suDisco) return;
    if (suDisco === inUso) {
      if (suDisco === VERSIONE_MOTORE) return;
      const { ricaricaPerMotore } = await chrome.storage.local.get('ricaricaPerMotore');
      if (ricaricaPerMotore && ricaricaPerMotore.versione === suDisco) return;
      await chrome.storage.local.set({ ricaricaPerMotore: { versione: suDisco, il: Date.now() } });
      console.warn('[CardSync] manifest ' + suDisco + ' ma motore ' + VERSIONE_MOTORE + ': ricarico l\'estensione');
      chrome.runtime.reload();
      return;
    }
    const { ricaricaPerVersione } = await chrome.storage.local.get('ricaricaPerVersione');
    if (ricaricaPerVersione && ricaricaPerVersione.versione === suDisco && Date.now() - ricaricaPerVersione.il < 10 * 60 * 1000) return;
    await chrome.storage.local.set({ ricaricaPerVersione: { versione: suDisco, il: Date.now() } });
    console.warn('[CardSync] file aggiornati sul disco (' + suDisco + ') ma in uso la ' + inUso + ': ricarico l\'estensione');
    chrome.runtime.reload();
  } catch (_) {   }
}
_creaSvegliaSeManca('controlla-aggiornamento-file', 1);

async function _segnalaDispositivo() {
  try {
    const { data } = await supabaseClient.auth.getSession();
    const userId = data && data.session && data.session.user ? data.session.user.id : null;
    if (!userId) return;
    const { dispositivoSegnalato: prima } = await chrome.storage.local.get('dispositivoSegnalato');
    if (prima && prima.versione === VERSIONE_MOTORE && prima.userId === userId
      && Date.now() - prima.il < 55 * 60 * 1000) return;
    const { error } = await supabaseClient.rpc('segnala_dispositivo', {
      p_dispositivo: await nomeDispositivo(), p_versione: VERSIONE_MOTORE,
    });
    if (error) { console.warn('[CardSync] segnala_dispositivo:', error.message); return; }
    await chrome.storage.local.set({ dispositivoSegnalato: { versione: VERSIONE_MOTORE, userId, il: Date.now() } });
  } catch (e) {
    console.warn('[CardSync] segnala_dispositivo:', e && e.message);
  }
}
_creaSvegliaSeManca('segnala-dispositivo', 60);
setTimeout(() => { _segnalaDispositivo(); }, 5000);

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'CARDSYNC_GET_VERSION') {
    sendResponse({ versione: chrome.runtime.getManifest().version, motore: VERSIONE_MOTORE });
    return true;
  }
  if (message && message.type === 'CARDSYNC_GET_UTENTE') {
    supabaseClient.auth.getSession().then(({ data }) => {
      const utente = data && data.session ? data.session.user : null;
      sendResponse({
        ok: true,
        userId: utente ? utente.id : null,
        nome: utente ? (String(utente.email || '').split('@')[0] || null) : null,
      });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_GET_AIUTA_GRUPPO') {
    chrome.storage.local.get('aiutaGruppo').then(({ aiutaGruppo }) => {
      sendResponse({ ok: true, aiutaGruppo: aiutaGruppo ?? false });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  // Dalla 5.74 "Aiuta il gruppo" e "Lavora anche a estensione chiusa" si cambiano solo dall'app
  // (menu › Impostazioni): il sito legge soltanto "Aiuta il gruppo" per il suo widget.
  // Il sito avvisa che è stato aperto: l'app si apre se qui è acceso "Apri l'app quando apri il sito"
  // e non è già aperta (se è aperta non le si dà il fuoco: chi apre il sito resta sul sito).
  // migraApriSempre: sul sito era acceso il vecchio "Apri sempre l'app" → la scelta si copia qui, una volta.
  if (message && message.type === 'CARDSYNC_SITO_APERTO') {
    (async () => {
      try {
        const daScrivere = {};
        if (typeof message.temaScuro === 'boolean') daScrivere.cardsyncDarkMode = message.temaScuro;
        const { apriAppConIlSito } = await chrome.storage.local.get('apriAppConIlSito');
        let apri = apriAppConIlSito === true;
        if (message.migraApriSempre === true && apriAppConIlSito === undefined) {
          daScrivere.apriAppConIlSito = true;
          apri = true;
        }
        await chrome.storage.local.set(daScrivere);
        let aperta = false;
        if (apri) {
          const base = chrome.runtime.getURL('app.html');
          const esistenti = await chrome.tabs.query({ url: base + '*' });
          if (!esistenti || esistenti.length === 0) {
            await chrome.tabs.create({ url: base + '#coda' });
            aperta = true;
          }
        }
        sendResponse({ ok: true, apriAppConIlSito: apri, aperta });
      } catch (e) {
        sendResponse({ ok: false, errore: e.message });
      }
    })();
    return true;
  }
  if (message && message.type === 'CARDSYNC_SET_TEMA') {
    const daScrivere = {};
    if (typeof message.temaScuro === 'boolean') daScrivere.cardsyncDarkMode = message.temaScuro;
    chrome.storage.local.set(daScrivere).then(() => {
      sendResponse({ ok: true });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_OPEN_APP') {
    (async () => {
      try {
        const daScrivere = {};
        if (typeof message.temaScuro === 'boolean') daScrivere.cardsyncDarkMode = message.temaScuro;
        // dalla 5.74: impostazioni: true → l'app si apre sul menu Impostazioni (lo apre app.js)
        if (message.impostazioni === true) daScrivere.apriImpostazioniApp = Date.now();
        await chrome.storage.local.set(daScrivere);

        await _apriOFocalizzaTabApp();
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, errore: e.message });
      }
    })();
    return true;
  }
  sendResponse({ ok: false, errore: 'tipo sconosciuto' });
  return false;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'CARDSYNC_VERSIONE_MOTORE') {
    sendResponse({ motore: VERSIONE_MOTORE });
    return false;
  }
  return false;
});

chrome.declarativeNetRequest.updateDynamicRules({
  removeRuleIds: [1],
  addRules: [{
    id: 1,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [
        { header: 'Referer', operation: 'set', value: 'https://www.cardmarket.com/' },
      ],
    },
    condition: {
      urlFilter: '||product-images.s3.cardmarket.com',
      resourceTypes: ['xmlhttprequest'],
    },
  }],
}).catch((e) => console.error('[immagine] impossibile impostare la regola Referer:', e.message));

function _avviaKeepAlive() {
  _creaSvegliaSeManca('sw-keepalive', 0.5);
}
_avviaKeepAlive();

function _avviaPollingOrdini() {
  _creaSvegliaSeManca('ordini-poll', 0.5);
}
_avviaPollingOrdini();

let _lavoroAutonomoInCorso = false;
let _backoffAutonomoFinoA = 0;

function _testoRicercaCodificato(testo) {
  return encodeURIComponent((testo || '').trim().replace(/\s+/g, ' ')).replace(/%20/g, '+');
}
const RE_NON_SIGLA_SET = /^(?:EX|GX|V|VMAX|VSTAR|VUNION|LV|LVX|BREAK|PRIME|STAR|MEGA|TAG|TEAM|DI|DEL|DELLA|THE|OF)$/i;

function _codiceRicercaCompatto(testo) {
  const parti = String(testo || '').trim().split(/\s+/).filter(Boolean);
  if (parti.length < 2) return null;
  const ultimo = parti[parti.length - 1];
  const sigla = parti[parti.length - 2];
  const lettereUltimo = (ultimo.match(/[A-Za-z]/g) || []).length;
  const codiceGiaAttaccato = /^[A-Za-z0-9.]{4,12}$/.test(ultimo) && lettereUltimo >= 2 && /\d{2}$/.test(ultimo);
  const coppia = lettereUltimo < 3 && /^[A-Za-z]{0,3}\d{1,4}[A-Za-z]?$/.test(ultimo) && /\d/.test(ultimo)
    && /^[A-Za-z][A-Za-z0-9.]{1,6}$/.test(sigla) && sigla.replace(/\./g, '').length <= 6 && !RE_NON_SIGLA_SET.test(sigla.replace(/\./g, ''));
  if (!coppia) return codiceGiaAttaccato ? ultimo.replace(/\./g, '').toUpperCase() : null;
  if (/^(?:BA|WCD|PPS|BOO)$/i.test(sigla)) return null;
  let inizio = parti.length - 2;
  const prima = parti[inizio - 1];
  if (prima && /^(?:PPS|WCD|BOO)$/i.test(prima)) return null;
  if (prima && (/^(?:BOO\d{0,2}|PPS\d{1,2}|WCD\d{2}|BA\d{2}|CEL|TK\d{1,2})$/i.test(prima))) inizio--;
  return parti.slice(inizio).join('').replace(/\./g, '').toUpperCase();
}

// WCD e PPS senza anno/serie o senza set: "gardevoir wcd 061", "gardevoir wcd23 061", "pps twm 130",
// "morpeko pps twm 72". Cardmarket con nome + sigla + numero spesso non trova niente (o porta alla carta
// normale del set): si cerca "gardevoir wcd" / "morpeko pps twm" e si sceglie per numero.
function _promoSenzaSerieDaQuery(testo) {
  const parti = String(testo || '').trim().split(/\s+/).filter(Boolean);
  let i = -1;
  parti.forEach((t, k) => { if (/^(?:WCD(?:\d{2})?|PPS(?:\d{1,2})?|BOO(?:\d{2})?)$/i.test(t)) i = k; });
  if (i < 0) return null;
  const prefisso = parti[i].slice(0, 3).toUpperCase();
  let dopo = parti.slice(i + 1);
  // "boo pal054", "pps twm130": set e numero attaccati
  const mAttaccato = dopo.length === 1 && dopo[0].match(/^([A-Za-z][A-Za-z0-9]{1,5}?)(\d{2,3})$/);
  if (mAttaccato) dopo = [mAttaccato[1], mAttaccato[2]];
  if (dopo.length < 1 || dopo.length > 2 || !/^\d{1,3}$/.test(dopo[dopo.length - 1])) return null;
  const set = dopo.length === 2 ? dopo[0].toUpperCase() : '';
  if (set && !/^[A-Z][A-Z0-9]{1,5}$/.test(set)) return null;
  const serieTesto = parti[i].slice(3);
  const anno = serieTesto ? (prefisso === 'PPS' ? String(parseInt(serieTesto, 10)) : serieTesto) : '';
  if (anno && set) return null;
  const nome = parti.slice(0, i).join(' ');
  const numero = dopo[dopo.length - 1];
  const sigla = prefisso.toLowerCase();
  const testoRicerca = nome ? [nome, sigla, set].filter(Boolean).join(' ') : [sigla, set, set ? '' : numero].filter(Boolean).join(' ');
  return { prefisso, nome, anno, set, numero: String(parseInt(numero, 10)), numeroTesto: numero.padStart(3, '0'), testoRicerca };
}

function _promoSenzaSerieDaSlug(u) {
  const segs = (String(u || '').split(/[?#]/)[0].split('/').pop() || '').toUpperCase().split('-');
  const ultimo = segs[segs.length - 1] || '';
  let m;
  if (/^\d{1,3}$/.test(ultimo) && (m = (segs[segs.length - 2] || '').match(/^(WCD|PPS|BOO)(\d{1,2})?([A-Z][A-Z0-9]*)?$/))) {
    if (!m[2] && m[1] !== 'BOO') return null;
    return { prefisso: m[1], anno: m[1] === 'PPS' ? String(parseInt(m[2], 10)) : (m[2] || ''), set: m[3] || '', numero: String(parseInt(ultimo, 10)) };
  }
  if ((m = ultimo.match(/^WCD(\d{2})(\d{1,3})$/))) return { prefisso: 'WCD', anno: m[1], set: '', numero: String(parseInt(m[2], 10)) };
  return null;
}

function _linkPromoPerQuery(links, w) {
  const visti = new Set();
  return (links || []).map(_linkInItaliano).filter(u => {
    const c = _promoSenzaSerieDaSlug(u);
    if (!c || c.prefisso !== w.prefisso || c.numero !== w.numero) return false;
    if (w.anno && c.anno !== w.anno) return false;
    if (w.set && c.set !== w.set) return false;
    if (visti.has(u)) return false;
    visti.add(u);
    return true;
  });
}

// null = niente trovato, si va avanti con la ricerca normale. Liste lunghe ("pps twm": 40 carte) su più pagine.
async function _cercaPromoSenzaSerie(w) {
  const base = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${_testoRicercaCodificato(w.testoRicerca)}`;
  const tutti = [];
  for (let pagina = 1; pagina <= 3; pagina++) {
    if (pagina > 1) await new Promise(res => setTimeout(res, 1500));
    const url = pagina > 1 ? `${base}&site=${pagina}` : base;
    const html = await _fetchHtml(url);
    if (!html) {
      if (_fetchHtmlEraRateLimit(url)) return { rateLimited: true };
      break;
    }
    const lower = html.toLowerCase();
    if (isPaginaRateLimit(lower)) return { rateLimited: true };
    if (_htmlEChallengeCloudflare(lower)) break;
    const ogUrl = (html.match(/<meta[^>]+property="og:url"[^>]+content="([^"?#]+)/i) || html.match(/<meta[^>]+content="([^"?#]+)"[^>]+property="og:url"/i) || [])[1] || '';
    if (ogUrl.includes('/Products/Singles/') && !_ePaginaListaSingles(ogUrl, _testoH1DaHtml(html))) { tutti.push(ogUrl); break; }
    const links = _estraiLinkSingles(html);
    tutti.push(...links);
    if (links.length < 30) break;
  }
  const scelti = _linkPromoPerQuery(tutti, w);
  console.log('[CardSync] ' + w.prefisso + ' senza serie/set:', { testo: w.testoRicerca, numero: w.numero, scelti });
  if (scelti.length === 0) return null;
  if (scelti.length === 1) return { link: scelti[0] };
  return { opzioni: _opzioniDaLink(scelti) };
}

// Lingua del prodotto Cardmarket dal codice nello slug: le carte giapponesi hanno il codice
// minuscolo ("Heracross-m6001", "sv3125", "s10b055"), le cinesi finiscono con C + numero
// ("CSV2C001", "CS3bC061", "151C151"). Tutto il resto è internazionale.
function _linguaProdottoDaSlug(u) {
  const segs = (String(u || '').split(/[?#]/)[0].split('/').pop() || '').split('-');
  let codice = segs.pop() || '';
  if (/^\d+$/.test(codice) && segs.length) codice = segs.pop() + codice;
  if (/^[a-z]/.test(codice)) return 'giapponese';
  // cinesi: CS…C (CSV2C, CS3bC, CSV9.5C), CBB…C (Gem Pack), 151C (Collect 151). "30C" è 30th Celebration, internazionale
  if (/^(?:CS[A-Za-z0-9.]*C|CBB\d+C|151C)\d{2,3}$/i.test(codice)) return 'cinese';
  return 'internazionale';
}

// Quando c'è da scegliere: tiene solo le carte nella lingua della carta (JP → giapponesi,
// CHN → cinesi, le altre → internazionali), se ne resta almeno una.
// "heracross m6 001", "pikachu CSV2C 001": il codice scritto dice già la lingua del prodotto
function _linguaProdottoDaQuery(testo) {
  const parti = String(testo || '').trim().split(/\s+/).filter(Boolean);
  for (let k = 0; k < parti.length; k++) {
    const t = parti[k];
    const staccato = _staccaCodiceAsiatico(t);
    const set = staccato ? staccato.split(' ')[0]
      : (k < parti.length - 1 && /^\d{1,3}$/.test(parti[k + 1]) && !/^(?:PPS|WCD|BOO|BA|MCD|TK)/i.test(t)
         && /^(?:[A-Za-z]{1,4}\d{1,2}[A-Za-z]{0,2}|151C)$/i.test(t) ? t : null);
    if (!set) continue;
    return /^(?:CS[A-Za-z0-9.]*C|CBB\d+C|151C)$/i.test(set) ? 'cinese' : 'giapponese';
  }
  return null;
}

function _opzioniPerLingua(opzioni, lingua, linguaDaQuery = null) {
  const id = LINGUA_MAP_SHARED[String(lingua || 'IT').toUpperCase().trim()];
  const voluta = linguaDaQuery || (id === '7' ? 'giapponese' : (id === '6' || id === '11') ? 'cinese' : 'internazionale');
  const lista = opzioni || [];
  const tenute = lista.filter(o => _linguaProdottoDaSlug((o && o.urlSingles) || o) === voluta);
  return tenute.length ? tenute : lista;
}

// Numero della carta dall'ultimo pezzo dello slug. Le McDonald's hanno l'anno attaccato al numero
// ("Jigglypuff-MCD168" = MCD16 n. 8, "Lapras-MCD195" = MCD19 n. 5): lì il numero è dopo le 2 cifre dell'anno.
function _numeroDaUltimoSegmento(seg) {
  const mMcd = String(seg || '').match(/^MCD\d{2}(\d{1,3})$/i);
  if (mMcd) return String(parseInt(mMcd[1], 10));
  const m = String(seg || '').match(/(\d+)$/);
  return m ? String(parseInt(m[1], 10)) : null;
}

// ── Trainer Kit ─────────────────────────────────────────────────────────────────
// Le carte dei Trainer Kit (2004-2018, chiusi) su Cardmarket hanno codici senza una regola unica
// ("TK1Latios-2", "TK2M2", "TK31-Gold", "TK4yellow-2", "TK530Z", "TK10A30", "TK9P-11") e la ricerca
// testuale non le trova. Qui c'è l'elenco fisso dei loro link (letto da Cardmarket l'11/11/2026):
// "zubat tk 11" o "zubat trainer kit 11" cerca nome e numero qui dentro, senza chiedere a Cardmarket.
const _TRAINER_KIT_CARDMARKET = {
  "EX-Trainer-Kit": ["Latios-TK1Latios-2", "Latias-TK1Latias-4", "Torchic-TK1Latias-7", "Pikachu-TK1Latios-6", "Fire-Energy-TK1Latias-10", "Magnemite-TK1Latios-4", "Skitty-TK1Latias-6", "Zigzagoon-TK1Latios-7", "Numel-TK1Latias-5", "Electrike-TK1Latios-1", "Bagon-TK1Latias-1", "Magneton-TK1Latios-5", "Energy-Search-TK1Latias-9", "Combusken-TK1Latias-2", "Lightning-Energy-TK1Latios-10", "Delcatty-TK1Latias-3", "Potion-TK1Latias-8", "Energy-Search-TK1Latios-9", "Potion-TK1Latios-8", "Linoone-TK1Latios-3"],
  "EX-Trainer-Kit-2": ["Charmander-TK2M2", "Growlithe-TK2M4", "Psychic-Energy-TK2red-12", "Fire-Energy-TK2blue-11", "Vulpix-TK2M7", "Meowth-TK2P4", "Plusle-TK2P6", "Minun-TK2M6", "Mareep-TK2M5", "Electrike-TK2P2", "Beldum-TK2P1", "Lightning-Energy-TK2red-11", "Spoink-TK2P7", "Lightning-Energy", "Metang-TK2P5", "Charmeleon-TK2M3", "Grumpig-TK2P3", "Arcanine-TK2M1", "Energy-Search-TK2blue-9", "Potion-TK2blue-10", "Energy-Search-TK2red-8", "Potion-TK2red-9", "Professor-Cozmos-Discovery-TK2red-10", "Celios-Network-TK2blue-8"],
  "DP-Trainer-Kit": ["Geodude-Lv12-TK31-Gold", "Riolu-Lv7-TK36-Gold", "Goldeen-Lv14-TK33-Blue", "Buizel-Lv10-TK31-Blue", "Fighting-Energy-TK311-Gold", "Piplup-Lv9-TK35-Blue", "Machop-Lv20-TK35-Gold", "Starly-Lv8-TK37-Gold", "Manaphy-Lv20-TK34-Blue", "Seaking-Lv41-TK37-Blue", "Machoke-Lv39-TK34-Gold", "Graveler-Lv34-TK32-Gold", "Totodile-Lv15-TK38-Blue", "Lucario-Lv30-TK33-Gold", "Potion-TK311-Blue", "Energy-Search-TK310-Blue", "Energy-Search-TK38-Gold", "Potion-TK39-Gold", "Floatzel-Lv29-TK32-Blue", "Water-Energy-TK312-Blue", "Prinplup-Lv20-TK36-Blue", "Dusk-Ball-TK39-Blue", "Quick-Ball-TK310-Gold"],
  "HS-Trainer-Kit": ["Gyarados-V2-TK4blue-30", "Raichu-V2-TK4R30", "Meowth-V1-TK4yellow-4", "Gyarados-V1-TK4G20", "Raichu-V1-TK4yellow-19", "Pikachu-V1-TK4yellow-2", "Energy-Switch-V1-TK4blue-21", "Switch-V1-TK4blue-28", "Pokemon-Collector-V1-TK4yellow-22", "Pikachu-V2-TK4R16", "Lightning-Energy-V4-TK4R8", "Marill-V1-TK4blue-15", "Totodile-V2-TK4blue-14", "Pokemon-Communication-V1-TK4G22", "Marill-V2-TK4G24", "Totodile-V1-TK4blue-1", "Copycat-TK4yellow-21", "Meowth-V2-TK4R12", "Switch-V2-TK4yellow-24", "Flaaffy-V1-TK4yellow-3", "Moomoo-Milk-V2-TK4yellow-26", "Poke-Ball-V2-TK4yellow-25", "Pokemon-Collector-V2-TK4yellow-27", "Energy-Switch-V2-TK4yellow-29", "Water-Energy-V7-TK4G9", "Croconaw-V2-TK4blue-17", "Magikarp-V2-TK4blue-19", "Water-Energy-V10-TK4G16", "Magikarp-V1-TK4blue-12", "Croconaw-V1-TK4blue-13", "Bill-V1-TK4blue-5", "Water-Energy-V6-TK4G8", "Water-Energy-V2-TK4G3", "Lightning-Energy-V10-TK4R18", "Mareep-V2-TK4yellow-20", "Flaaffy-V2-TK4R17", "Lightning-Energy-V7-TK4R11", "Lightning-Energy-V6-TK4R10", "Mareep-V1-TK4yellow-13", "Lightning-Energy-V9-TK4R15", "Lightning-Energy-V8-TK4R14", "Lightning-Energy-V11-TK4R23", "Lightning-Energy-V1-TK4R5", "Lightning-Energy-V2-TK4R6", "Lightning-Energy-V3-TK4R7", "Lightning-Energy-V5-TK4R9", "Lightning-Energy-V12-TK4R28", "Moomoo-Milk-V1-TK4yellow-1", "Bill-V2-TK4blue-18", "Water-Energy-V1-TK4G2", "Water-Energy-V9-TK4G11", "Water-Energy-V8-TK4G10", "Poke-Ball-V1-TK4G23", "Water-Energy-V3-TK4G4", "Water-Energy-V4-TK4G6", "Water-Energy-V5-TK4G7", "Water-Energy-V12-TK4G29", "Professor-Elms-Training-Method-TK4blue-25", "Water-Energy-V11-TK4G26", "Pokemon-Communication-V2-TK4blue-27"],
  "BW-Trainer-Kit": ["Darkness-Energy-TK524Z", "Zoroark-TK530Z", "Fighting-Energy-TK58E", "Zoroark-TK517Z", "Minccino-TK519Z", "Zorua-TK523Z", "Zorua-TK513Z", "Pokemon-Communication-TK518Z", "Pidove-TK521Z", "Darkness-Energy-TK53Z", "Purrloin-TK525Z", "PlusPower-TK516E", "Audino-TK512E", "Fighting-Energy-TK528E", "Watchog-TK52Z", "Energy-Retrieval-TK516Z", "Tranquill-TK515Z", "Darkness-Energy-TK55Z", "Minccino-TK54Z", "Darkness-Energy-TK57Z", "Darkness-Energy-TK59Z", "Darkness-Energy-TK528Z", "Fighting-Energy-TK59E", "Audino-TK518E", "Excadrill-TK517E", "Herdier-TK519E", "Energy-Search-TK521E", "Drilbur-TK513E", "Potion-TK523E", "Fighting-Energy-TK53E", "Timburr-TK529E", "Darkness-Energy-TK520E", "Darkness-Energy-TK522Z", "PlusPower-TK511Z", "Darkness-Energy-TK510Z", "Patrat-TK512Z", "Pidove-TK514Z", "Darkness-Energy-TK56Z", "Darkness-Energy-TK58Z", "Darkness-Energy-TK526Z", "Energy-Search-TK527Z", "Patrat-TK529Z", "Purrloin-TK51Z", "Fighting-Energy-TK52E", "Potion-TK515E", "Timburr-TK511E", "Fighting-Energy-TK510E", "Gurdurr-TK514E", "Fighting-Energy-TK522E", "Energy-Switch-TK54E", "Fighting-Energy-TK55E", "Fighting-Energy-TK56E", "Fighting-Energy-TK57E", "Drilbur-TK525E", "Pokemon-Communication-TK524E", "Fighting-Energy-TK526E", "Lillipup-TK51E", "Online-Code-Card-Theme-Deck-TK5", "Fighting-Energy-TK520E", "Excadrill-TK530E", "Lillipup-TK527E"],
  "XY-Trainer-Kit": ["Sylveon-TK630S", "Sylveon-TK615S", "Eevee-TK613S", "Gourgeist-TK62N", "Switch-TK64S", "Arbok-TK63N", "Snubbull-TK611S", "Noibat-TK612N", "Furfrou-TK616S", "Fairy-Energy-TK617S", "Pumpkaboo-TK618N", "Furfrou-TK620N", "Darkness-Energy-TK626N", "Noivern-TK630N", "Spoink-TK61N", "Pumpkaboo-TK611N", "Poke-Ball-TK626S", "Granbull-TK629S", "Fairy-Energy-TK63S", "Psychic-Energy-TK65N", "Fairy-Energy-TK67S", "Psychic-Energy-TK67N", "Fairy-Energy-TK68S", "Fairy-Energy-TK69S", "Fairy-Energy-TK610S", "Fairy-Energy-TK612S", "Noivern-TK613N", "Ekans-TK616N", "Psychic-Energy-TK617N", "Fairy-Energy-TK618S", "Eevee-TK621S", "Darkness-Energy-TK622N", "Furfrou-TK622S", "Noibat-TK623N", "Potion-TK624S", "Psychic-Energy-TK625N", "Snubbull-TK627S", "Fletchling-TK61S", "Bunnelby-TK64N", "Fairy-Energy-TK65S", "Psychic-Energy-TK66N", "Fairy-Energy-TK66S", "Psychic-Energy-TK68N", "Psychic-Energy-TK69N", "Psychic-Energy-TK610N", "Pokemon-Catcher-TK614N", "Granbull-TK614S", "Potion-TK615N", "Fletchling-TK619S", "Darkness-Energy-TK619N", "Potion-TK620S", "Poke-Ball-TK621N", "Pokemon-Catcher-TK623S", "Professors-Letter-TK624N", "Fairy-Energy-TK625S", "Potion-TK627N", "Darkness-Energy-TK628N", "Professors-Letter-TK628S", "Switch-TK629N", "Fairy-Energy-TK62S", "Online-Code-Card-Theme-Deck-TK6"],
  "XY-Trainer-Kit-Bisharp-Wigglytuff": ["Bisharp-TK716B", "Swirlix-TK718W", "Swirlix-TK71W", "Pidgeotto-TK72W", "Fairy-Energy-TK73W", "Fairy-Energy-TK79W", "Fairy-Energy-TK710W", "Honedge-TK711B", "Jigglypuff-TK712W", "Pawniard-TK713B", "Clefairy-TK713W", "Slakoth-TK715B", "Fairy-Energy-TK717W", "Trevor-TK720B", "Potion-TK720W", "Pawniard-TK721B", "Fairy-Energy-TK722W", "Doublade-TK723B", "Honedge-TK727B", "Potion-TK729B", "Wigglytuff-TK730W", "Fletchling-TK71B", "Metal-Energy-TK72B", "Metal-Energy-TK73B", "Sentret-TK74W", "Vigoroth-TK74B", "Metal-Energy-TK75B", "Fairy-Energy-TK75W", "Metal-Energy-TK76B", "Fairy-Energy-TK76W", "Fairy-Energy-TK77W", "Metal-Energy-TK77B", "Fairy-Energy-TK78W", "Metal-Energy-TK78B", "Metal-Energy-TK79B", "Metal-Energy-TK710B", "Pidgey-TK711W", "Bidoof-TK712B", "Doublade-TK714B", "Wigglytuff-TK714W", "Potion-TK715W", "Clefable-TK716W", "Patrat-TK717B", "Metal-Energy-TK718B", "Clefairy-TK719W", "Tierno-TK719B", "Fairy-Energy-TK721W", "Metal-Energy-TK722B", "Pidgeotto-TK723W", "Metal-Energy-TK724B", "Trevor-TK724W", "Jigglypuff-TK725W", "Potion-TK725B", "Slakoth-TK726B", "Tierno-TK726W", "Fairy-Energy-TK727W", "Vigoroth-TK728B", "Clefable-TK728W", "Pidgey-TK729W", "Bisharp-TK730B", "Online-Code-Card-Theme-Deck-TK7"],
  "XY-Trainer-Kit-Latias-Latios": ["Latios-TK830O", "Latias-TK830A", "Latias-TK814A", "Tangrowth-TK812A", "Grovyle-TK827A", "Acro-Bike-TK829A", "Treecko-TK87A", "Lotad-01-TK811A", "Psychic-Energy-TK817A", "Acro-Bike-TK820A", "Fighting-Energy-TK817O", "Rhydon-TK825O", "Skitty-TK827O", "Grass-Energy-TK82A", "Grass-Energy-TK83A", "Grass-Energy-TK85A", "Lombre-TK86A", "Psychic-Energy-TK89A", "Tangela-TK813A", "Potion-TK815A", "Surskit-TK816A", "Grovyle-TK818A", "Grass-Energy-TK819A", "Psychic-Energy-TK822A", "Treecko-TK824A", "Tangrowth-TK825A", "Skitty-TK81O", "Fighting-Energy-TK83O", "Solrock-TK812O", "Latios-TK813O", "Machoke-TK814O", "Psychic-Energy-TK818O", "Delcatty-TK819O", "Acro-Bike-TK820O", "Potion-TK821O", "Machoke-TK822O", "Delcatty-TK824O", "Solrock-TK826O", "Machop-TK828O", "Grass-Energy-TK81A", "Fletchling-TK84A", "Psychic-Energy-TK88A", "Psychic-Energy-TK810A", "Lombre-TK821A", "Lotad-TK823A", "Psychic-Energy-TK828A", "Fighting-Energy-TK82O", "Rhydon-TK84O", "Fighting-Energy-TK85O", "Fighting-Energy-TK86O", "Fighting-Energy-TK87O", "Fighting-Energy-TK88O", "Fighting-Energy-TK89O", "Fighting-Energy-TK810O", "Rhyhorn-TK815O", "Psychic-Energy-TK816O", "Rhyhorn-TK823O", "Psychic-Energy-TK829O", "Tangela-TK826A", "Machop-TK811O", "Online-Code-Card-Theme-Deck-TK8"],
  "XY-Trainer-Kit-Pikachu-Libre-Suicune": ["Suicune-V2-TK9S-30", "Pikachu-Libre-V2-TK9P-30", "Pikachu-Libre-V1", "Electrike-TK9P-11", "Manectric-TK9P-13", "Electabuzz-TK9P-15", "Piplup-TK9S-16", "Purugly-TK9P-24", "Electrike-TK9P-28", "Frogadier-TK9S-6", "Froakie-TK9S-11", "Froakie-TK9S-23", "Suicune-V1", "Electivire-TK9P-4", "Taillow-TK9P-7", "Lightning-Energy-TK9P-8", "Fletchling-TK9P-16", "Manectric-TK9P-22", "Blitzle-TK9P-26", "Eevee-TK9S-4", "Goldeen-TK9S-13", "Swanna-TK9S-18", "Swanna-TK9S-27", "Glameow-TK9P-1", "Lightning-Energy-TK9P-2", "Lightning-Energy-TK9P-3", "Lightning-Energy-TK9P-5", "Lightning-Energy-TK9P-6", "Lightning-Energy-TK9P-9", "Lightning-Energy-TK9P-10", "Blitzle-TK9P-12", "Lightning-Energy-TK9P-17", "Lightning-Energy-TK9P-18", "Purugly-TK9P-19", "Tierno-TK9P-20", "Potion-TK9P-21", "Electabuzz-TK9P-23", "Electivire-TK9P-25", "Water-Energy-TK9S-1", "Water-Energy-TK9S-2", "Water-Energy-TK9S-3", "Water-Energy-TK9S-5", "Ducklett-TK9S-7", "Water-Energy-TK9S-8", "Water-Energy-TK9S-9", "Water-Energy-TK9S-10", "Seaking-TK9S-12", "Potion-TK9S-15", "Water-Energy-TK9S-19", "Tierno-TK9S-20", "Frogadier-TK9S-21", "Water-Energy-TK9S-22", "Ducklett-TK9S-24", "Seaking-TK9S-25", "Goldeen-TK9S-26", "Water-Energy-TK9S-28", "Tierno-TK9S-29", "Glameow-TK9P-27", "Lightning-Energy-TK9P-29", "Water-Energy-TK9S-17", "Online-Code-Card-Theme-Deck-TK9"],
  "SM-Trainer-Kit-Lycanroc-Alolan-Raichu": ["Alolan-Raichu-V2-TK10A30", "Pikachu-V1-TK10A14", "Alolan-Raichu-V1-TK10A17", "Pikachu-V2-TK10A29", "Lycanroc-V2-TK10L30", "Lycanroc-V1-TK10L16", "Rockruff-V1-TK10L14", "Fighting-Energy-V10-TK10L20", "Toucannon-TK10L22", "Golbat-TK10A06", "Bewear-TK10A18", "Caterpie-TK10L01", "Trumbeak-TK10L04", "Pikipek-TK10L15", "Hau-V2-TK10L23", "Drowzee-TK10A22", "Fighting-Energy-V2-TK10L03", "Yungoos-TK10L12", "Fighting-Energy-V9-TK10L17", "Fighting-Energy-V11-TK10L24", "Fighting-Energy-V12-TK10L26", "Makuhita-TK10L18", "Rockruff-V2-TK10L29", "Lightning-Energy-V6-TK10A08", "Zubat-TK10A11", "Great-Ball-V3-TK10A21", "Fighting-Energy-V1-TK10L02", "Fletchling-TK10L11", "Fletchinder-TK10L13", "Lightning-Energy-V3-TK10A03", "Lightning-Energy-V4-TK10A05", "Grubbin-TK10A16", "Psychic-Energy-V1-TK10A20", "Psychic-Energy-V2-TK10A24", "Psychic-Energy-V3-TK10A27", "Psychic-Energy-V4-TK10A28", "Togedemaru-TK10A26", "Fighting-Energy-V3-TK10L05", "Fighting-Energy-V4-TK10L06", "Fighting-Energy-V5-TK10L07", "Fighting-Energy-V6-TK10L08", "Fighting-Energy-V7-TK10L09", "Fighting-Energy-V8-TK10L10", "Fighting-Energy-V13-TK10L28", "Hau-V1-TK10L19", "Great-Ball-V1-TK10L21", "Great-Ball-V2-TK10L25", "Big-Malasada-TK10L27", "Lightning-Energy-V1-TK10A01", "Lightning-Energy-V2-TK10A02", "Lightning-Energy-V5-TK10A07", "Lightning-Energy-V7-TK10A09", "Lightning-Energy-V8-TK10A10", "Lightning-Energy-V9-TK10A12", "Stufful-TK10A04", "Potion-TK10A15", "Hau-V3-TK10A19", "Hau-V4-TK10A23", "Great-Ball-V4-TK10A25", "Online-Code-Card-SM-Trainer-Kit-Lycanroc-Alolan-Raichu", "Spearow-TK10A13", "Online-Code-Card-Theme-Deck-TK10"],
  "SM-Trainer-Kit-Alolan-Sandslash-Alolan-Ninetales": ["Alolan-Ninetales-V2-SM128", "Alolan-Ninetales-V1-SM128", "Oddish-BUS4", "Eevee-UPR104", "Jigglypuff-CIN71", "Alolan-Sandslash-V2-SM127", "Staravia-TK1182", "Starly-CIN81", "Aron-CIN65", "Staraptor-CIN83", "Alolan-Sandshrew-V2-GRI19", "Grass-Energy-V5-SUM", "Hoothoot-TK11106", "Water-Energy-V3-SUM", "Water-Energy-V4-SUM", "Water-Energy-V6-SUM", "Piplup-UPR32", "Alolan-Sandslash-V1-SM127", "Grass-Energy-V2-SUM", "Grass-Energy-V3-SUM", "Grass-Energy-V4-SUM", "Gloom-BUS5", "Skiddo-CIN10", "Stufful-TK11BUS-110", "Water-Energy-V1-SUM", "Water-Energy-V2-SUM", "Water-Energy-V5-SUM", "Metal-Energy-V2-SUM", "Metal-Energy-V5-SUM", "Metal-Energy-V6-SUM", "Prinplup-UPR33", "Hau-V1-TK11SUM-120", "Big-Malasada-SUM114", "Grass-Energy-V1-SUM", "Alolan-Vulpix-V1-GRI21", "Potion-SUM127", "Patrat-GRI107", "Great-Ball-V3-SUM119", "Hau-V4-SUM120", "Alolan-Vulpix-V2-GRI21", "Metal-Energy-V1-SUM", "Metal-Energy-V4-SUM", "Metal-Energy-V7-SUM", "Alolan-Sandshrew-V1-GRI19", "Great-Ball-V1-TK11SUM-119", "Hau-V2-TK11SUM-120", "Great-Ball-V2-TK11SUM-119", "Grass-Energy-V6-SUM", "Fairy-Energy-V1-SUM", "Fairy-Energy-V2-SUM", "Fairy-Energy-V3-SUM", "Fairy-Energy-V4-SUM", "Fairy-Energy-V5-SUM", "Fairy-Energy-V6-SUM", "Bunnelby-CIN87", "Diggersby-CIN88", "Hau-V3-SUM120", "Great-Ball-V4-SUM119", "Metal-Energy-V3-SUM", "Fairy-Energy-V7-SUM", "Online-Code-Card-SM-Trainer-Kit-Alolan-Sandslash-Alolan-Ninetales"],
};
// numero del kit per ogni espansione (TK1 … TK11)
const _TRAINER_KIT_NUMERO = Object.fromEntries(Object.keys(_TRAINER_KIT_CARDMARKET).map((k, i) => [k, i + 1]));

const _TK_NOMI_ITALIANI = {
  'ENERGIAERBA': 'GRASSENERGY', 'ENERGIAFUOCO': 'FIREENERGY', 'ENERGIAACQUA': 'WATERENERGY', 'ENERGIALAMPO': 'LIGHTNINGENERGY',
  'ENERGIAPSICO': 'PSYCHICENERGY', 'ENERGIALOTTA': 'FIGHTINGENERGY', 'ENERGIAOSCURITA': 'DARKNESSENERGY', 'ENERGIAMETALLO': 'METALENERGY',
  'ENERGIAFOLLETTO': 'FAIRYENERGY', 'POZIONE': 'POTION', 'SCAMBIO': 'SWITCH', 'RICERCAENERGIA': 'ENERGYSEARCH', 'POKEBALL': 'POKEBALL',
  'MEGABALL': 'GREATBALL', 'RECUPEROENERGIA': 'ENERGYRETRIEVAL',
};

function _tkNorm(t) {
  return String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

// "Geodude-Lv12-TK31-Gold" (kit 3) → { nome: 'GEODUDE', numero: '1' }; "Zubat-TK10A11" (kit 10) → 11.
// Il kit 11 (SM Sandslash & Ninetales) ha in gran parte i codici dei set d'origine ("Eevee-UPR104" → 104).
function _tkDaSlug(slug, kit) {
  const segs = String(slug || '').split('-');
  let i = segs.findIndex(x => new RegExp('^TK' + kit + '(?!\\d)|^TK' + kit + '(?=\\d)', 'i').test(x) && x.toUpperCase().startsWith('TK' + kit));
  let numero = null;
  if (i >= 0) {
    const resto = segs.slice(i).join('-').slice(2 + String(kit).length);
    const m = resto.match(/\d+/);
    if (m) numero = m[0];
  } else if (kit === 11) {
    i = segs.length - 1;
    const m = (segs[i] || '').match(/^[A-Z]{2,4}(\d{1,3})$/);
    if (m) numero = m[1];
  }
  if (numero == null || i < 0) return null;
  const nome = segs.slice(0, i).filter(x => !/^(?:V\d+|Lv\d+|\d+)$/i.test(x)).join('');
  return { kit, nome: _tkNorm(nome), numero: String(parseInt(numero, 10)) };
}

// "zubat tk 11", "zubat trainer kit 11", "zubat tk10 11", "tk 11" → { nome, numero, kit }
function _trainerKitDaQuery(testo) {
  let t = String(testo || '').trim().replace(/\btrainer\s*kit\b/ig, 'tk');
  const parti = t.split(/\s+/).filter(Boolean);
  const i = parti.findIndex(x => /^tk(\d{1,2})?$/i.test(x));
  if (i < 0 || parti.length < 2) return null;
  const numero = parti[parti.length - 1];
  if (!/^\d{1,3}$/.test(numero) || i === parti.length - 1) return null;
  const kit = (parti[i].match(/\d+/) || [null])[0];
  const nomeParti = parti.filter((_, k) => k !== i && k !== parti.length - 1);
  const nome = _tkNorm(nomeParti.join(''));
  return { nome: _TK_NOMI_ITALIANI[nome] || nome, numero: String(parseInt(numero, 10)), kit: kit ? parseInt(kit, 10) : null };
}

function _linkTrainerKitPerQuery(q) {
  const w = _trainerKitDaQuery(q);
  if (!w) return null;
  const tutte = [];
  Object.entries(_TRAINER_KIT_CARDMARKET).forEach(([esp, slugs]) => slugs.forEach(sl => {
    const c = _tkDaSlug(sl, _TRAINER_KIT_NUMERO[esp]);
    if (!c || c.numero !== w.numero) return;
    if (w.kit != null && c.kit !== w.kit) return;
    tutte.push({ url: `https://www.cardmarket.com/it/Pokemon/Products/Singles/${esp}/${sl}`, nome: c.nome });
  }));
  if (!w.nome) return tutte.map(x => x.url);
  const esatte = tutte.filter(x => x.nome === w.nome);
  const scelte = esatte.length ? esatte : tutte.filter(x => x.nome.startsWith(w.nome) || w.nome.startsWith(x.nome));
  return scelte.map(x => x.url);
}

function _opzioniConCodice(opzioni, codice) {
  const c = String(codice || '').toLowerCase();
  const lista = (opzioni || []).map(o => (o && o.urlSingles) || o).filter(Boolean);
  return lista.length > 0 && lista.every(u => (String(u).split(/[?#]/)[0].split('/').pop() || '').toLowerCase().replace(/-/g, '').endsWith(c));
}

// Codici giapponesi e cinesi scritti attaccati: Cardmarket li trova solo staccati
// ("m6001" → "m6 001", "sv2a151" → "sv2a 151", "CSV2C001" → "CSV2C 001", "151C151" → "151C 151").
// Il set ha almeno una cifra e il numero sono le ultime 3 cifre; non tocca PPS, WCD, BOO, BA, MCD, TK.
function _staccaCodiceAsiatico(token) {
  const t = String(token || '');
  if (/^(?:PPS|WCD|BOO|BA|MCD|TK)/i.test(t)) return null;
  // "30C151" (30th Celebration, internazionale) non si stacca: solo 151C (Collect 151, cinese)
  const m = t.match(/^([A-Za-z]{1,4}\d{1,2}[A-Za-z]{0,2})(\d{3})$/) || t.match(/^(151C)(\d{3})$/i);
  return m ? m[1] + ' ' + m[2] : null;
}

function _testoRicercaCarta(testo) {
  const parti = String(testo || '').trim().split(/\s+/).filter(Boolean);
  const staccato = parti.length ? _staccaCodiceAsiatico(parti[parti.length - 1]) : null;
  if (staccato) return parti.slice(0, -1).concat(staccato).join(' ');
  for (let i = Math.max(0, parti.length - 3); i < parti.length - 1; i++) {
    // "Mismagius BOO PAL 054", "BOO PAL054": senza l'anno il codice attaccato non basta (BOO24PAL054), resta il testo
    if (/^BOO$/i.test(parti[i])) continue;
    // "Gardevoir WCD23 061", "PPS6 130", "Mismagius BOO23 088": senza la sigla del set il codice attaccato non basta (WCD23CRE061, BOO23PAL088), resta il testo
    if (/^(?:WCD\d{2}|PPS\d{1,2}|BOO\d{2})$/i.test(parti[i]) && i === parti.length - 2 && /^\d+$/.test(parti[parti.length - 1])) continue;
    if (/^(?:BOO\d{0,2}|PPS\d{1,2}|WCD\d{2}|BA\d{2})$/i.test(parti[i]) && /\d/.test(parti[parti.length - 1])) return parti.slice(i).join('').toUpperCase();
  }
  return String(testo || '');
}
function _urlRicercaAutonoma(codice) {
  const query = _testoRicercaCodificato(_testoRicercaCarta(codice));
  return `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
}
function _urlRicercaSealedAutonoma(nome, lingua) {
  const query = _testoRicercaCodificato(nome);
  let url = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
  const codiceLingua = (lingua || 'IT').toUpperCase().trim();
  const idLingua = LINGUA_MAP_SHARED[codiceLingua];
  if (idLingua) url += `&language=${idLingua}`;
  return url;
}

async function _lavoroPermessoSuQuestoPc(lavoraAChiuso) {
  if (lavoraAChiuso === undefined) ({ lavoraAChiuso } = await chrome.storage.local.get('lavoraAChiuso'));
  if (lavoraAChiuso !== false) return true;
  const schedeApp = await chrome.tabs.query({ url: chrome.runtime.getURL('app.html') + '*' });
  return !!schedeApp && schedeApp.length > 0;
}

// Una sola parte lavora la coda: con una scheda dell'app aperta la pagina, altrimenti questo
// worker (solo con "Lavora anche a estensione chiusa" acceso).
async function _workerCodaCartePuoLavorare(lavoraAChiuso) {
  if (lavoraAChiuso === undefined) ({ lavoraAChiuso } = await chrome.storage.local.get('lavoraAChiuso'));
  if (lavoraAChiuso === false) return false;
  const schedeApp = await chrome.tabs.query({ url: chrome.runtime.getURL('app.html') + '*' });
  return !schedeApp || schedeApp.length === 0;
}

function _avviaWorkerAutonomoCodaCarte() {
  _creaSvegliaSeManca('worker-coda-carte-autonomo', 1);
}
_avviaWorkerAutonomoCodaCarte();

const TIMEOUT_TENTATIVO_AUTONOMO_MS = 2 * 60 * 1000;
function _conTimeoutAutonomo(promessa, ms) {
  return Promise.race([
    promessa,
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout worker autonomo')), ms)),
  ]);
}

const _MAX_CARTE_PER_GIRO_AUTONOMO = 100;

async function _lavoraCodaCarteAutonomo() {
  if (_lavoroAutonomoInCorso) return;
  _lavoroAutonomoInCorso = true;
  try {
    for (let n = 0; n < _MAX_CARTE_PER_GIRO_AUTONOMO; n++) {
      if (Date.now() < _backoffAutonomoFinoA) break;
      const esito = await _lavoraUnaCartaAutonoma();
      if (esito !== 'fatta' && esito !== 'presa-da-altri') break;
    }
  } catch (e) {
    console.error('[worker-autonomo] errore imprevisto:', e);
  } finally {
    _lavoroAutonomoInCorso = false;
  }
}

async function _lavoraUnaCartaAutonoma() {
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return 'non-loggato';
    // fuori da Cardmarket (o verifica Cloudflare da fare) l'estensione non lavora
    if ((await _leggiStatoLoginRicordato()) === false) return 'cardmarket-non-collegato';

    const { aiutaGruppo, lavoraAChiuso } = await chrome.storage.local.get(['aiutaGruppo', 'lavoraAChiuso']);

    if (!(await _workerCodaCartePuoLavorare(lavoraAChiuso))) return 'non-permesso';

    const sogliaStalloIso = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const filtroEleggibili = `stato.eq.pending,and(stato.eq.in_corso,claimed_at.lt.${sogliaStalloIso})`;

    let selectQuery = supabaseClient
      .from('coda_carte')
      .select('*')
      .or(filtroEleggibili)
      .order('creato_il', { ascending: true })
      .limit(1);
    if (!aiutaGruppo) selectQuery = selectQuery.eq('owner_id', userId);

    const { data: candidate, error: errLettura } = await selectQuery;
    if (errLettura) { console.error('[worker-autonomo] errore lettura:', errLettura.message); return 'errore'; }
    if (!candidate || candidate.length === 0) return 'coda-vuota';

    const _paginaCodaAttiva = async () => _segnaleVivo((await chrome.storage.local.get(_CHIAVE_CODA_PAGINA_ATTIVA))[_CHIAVE_CODA_PAGINA_ATTIVA]);
    if (await _paginaCodaAttiva()) return 'pagina-attiva';
    if ((await _precedenzaCodaCardmarket({ creatoIlRiga: candidate[0].creato_il, escludiWorker: true })).attendi) return 'precedenza';
    // "dentro" vale 5 minuti: se è più vecchio si controlla prima di prendere la carta
    const login = await _verificaLoginAutomatica();
    if (!login || login.loggato !== true) return 'cardmarket-non-collegato';

    await _attendiTurnoCardmarket();
    if (!(await _workerCodaCartePuoLavorare())) { _chiudiTurnoCardmarket(); return 'non-permesso'; }
    if ((await _paginaCodaAttiva()) || (await _precedenzaCodaCardmarket({ soloOccupato: true, escludiWorker: true })).attendi) { _chiudiTurnoCardmarket(); return 'precedenza'; }
    await chrome.storage.local.set({ [_CHIAVE_WORKER_AUTONOMO_ATTIVO]: { scadenza: Date.now() + 10 * 60 * 1000 } });

    const nomeDisp = await nomeDispositivo();
    const { data: claimate, error: errClaim } = await supabaseClient
      .from('coda_carte')
      .update({ stato: 'in_corso', claimed_by: userId, claimed_at: new Date().toISOString(), dispositivo: nomeDisp })
      .eq('id', candidate[0].id)
      .or(filtroEleggibili)
      .select();
    if (errClaim) { console.error('[worker-autonomo] errore claim:', errClaim.message); _chiudiTurnoCardmarket(); return 'errore'; }
    if (!claimate || claimate.length === 0) { _chiudiTurnoCardmarket(); return 'presa-da-altri'; }

    try {
      await _risolviRigaCodaCarteAutonoma(claimate[0]);
    } finally {
      _chiudiTurnoCardmarket();
    }
    return 'fatta';
  } finally {
    await chrome.storage.local.remove(_CHIAVE_WORKER_AUTONOMO_ATTIVO).catch(() => {});
  }
}

async function _risolviRigaCodaCarteAutonoma(riga) {
  const inizio = Date.now();
  const isSealed = riga.tipo === 'sealed';
  // le BOO esistono solo in inglese
  const lingua = isSealed ? (riga.lingua || 'IT') : linguaPerCartaShared(riga.nome, riga.lingua || 'IT');

  let risposta;
  let sospettoCloudflare = false;
  try {
    if (isSealed) {
      risposta = await _conTimeoutAutonomo(
        _leggiNomeSealedDaCardmarket(riga.url_diretto || _urlRicercaSealedAutonoma(riga.nome, lingua), lingua, 0, null, null,
          riga.destinazione !== 'wishlist' ? { integrita: riga.integrita_packaging || 'sigillato_integro' } : {}),
        TIMEOUT_TENTATIVO_AUTONOMO_MS
      );
    } else {
      risposta = await _conTimeoutAutonomo(
        _leggiNomeDaCardmarket(riga.url_diretto || _urlRicercaAutonoma(riga.nome), lingua, riga.condizione || 'NM',
          riga.reverse ? 'RH' : '', !!riga.first_ed, 0, null, null,
          riga.url_diretto ? _urlRicercaAutonoma(riga.nome) : null),
        TIMEOUT_TENTATIVO_AUTONOMO_MS
      );
    }
  } catch (e) {
    sospettoCloudflare = true;
    risposta = null;
  }

  // fuori da Cardmarket durante la lettura: la carta torna in coda senza salvarla, il giro si ferma
  if (await _uscitoDaCardmarketDa(inizio)) {
    await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({ stato: 'pending', claimed_by: null, claimed_at: null }).eq('id', riga.id), riga);
    console.warn('[worker-autonomo] uscito da Cardmarket: carta rimessa in coda, mi fermo.');
    return;
  }

  if (risposta?.rateLimited) {
    await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({ stato: 'pending', claimed_by: null, claimed_at: null }).eq('id', riga.id), riga);
    _backoffAutonomoFinoA = Date.now() + 15 * 60 * 1000;
    return;
  }

  const urlTrovato = isSealed ? risposta?.urlProdotto : risposta?.urlSingles;
  if (!urlTrovato) {
    const motivo = sospettoCloudflare
      ? 'nessuna risposta entro il timeout (possibile blocco Cardmarket senza intervento umano)'
      : risposta?.linkNonValido
        ? (risposta?.disambiguation ? 'link Cardmarket non più valido — scegli la versione giusta' : 'link Cardmarket non più valido e nessun risultato cercando per nome')
        : risposta?.disambiguation ? 'più versioni su Cardmarket — scegli quella giusta'
        : risposta?.varianteNonTrovata ? `variante ${[riga.reverse ? 'Reverse Holo' : '', riga.first_ed ? 'Prima Edizione' : ''].filter(Boolean).join(' + ') || 'richiesta'} non trovata su Cardmarket`
        : 'non trovata su Cardmarket';
    const definitivo = !sospettoCloudflare && !!(risposta?.disambiguation || risposta?.linkNonValido || risposta?.varianteNonTrovata);
    await _segnaTentativoFallitoAutonomo(riga, motivo, risposta?.disambiguation ? (risposta.opzioni || []) : null, definitivo);
    if (sospettoCloudflare) _backoffAutonomoFinoA = Date.now() + 20 * 60 * 1000;
    return;
  }

  // carta con la spunta "Sigillata" (dalla 5.76): prezzo dell'offerta sigillata, letto dopo una pausa
  let sigillata = null;
  if (!isSealed && riga.sigillata_originale && riga.destinazione !== 'wishlist') {
    try {
      await new Promise(r => setTimeout(r, 4000 + Math.floor(Math.random() * 4000)));
      sigillata = await _conTimeoutAutonomo(
        _leggiPrezzoSigillata({ urlSingles: risposta.urlSingles, lingua, condizione: riga.condizione || 'NM', oloType: riga.reverse ? 'RH' : '', firstEd: !!riga.first_ed }),
        TIMEOUT_TENTATIVO_AUTONOMO_MS);
    } catch (_) { sigillata = null; }
    if (await _uscitoDaCardmarketDa(inizio)) {
      await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({ stato: 'pending', claimed_by: null, claimed_at: null }).eq('id', riga.id), riga);
      console.warn('[worker-autonomo] uscito da Cardmarket: carta rimessa in coda, mi fermo.');
      return;
    }
    if (sigillata && sigillata.sigillata && sigillata.prezzo !== null) risposta = { ...risposta, prezzo: sigillata.prezzo };
  }

  let immagineConvertita = risposta.immagine || '';
  if (immagineConvertita) {
    try { immagineConvertita = await _immagineAUrlDati(immagineConvertita); } catch (_) {   }
  }

  const rigaDati = isSealed ? {
    B: risposta.nome || riga.nome, C: '', D: riga.location || '', E: riga.qty || 1, F: lingua, G: 'NM',
    H: risposta.urlProdotto, I: risposta.prezzo ?? '', K: riga.nota || '', L: immagineConvertita,
  } : {
    B: risposta.nome || '', C: risposta.codice || riga.nome, D: riga.location || '', E: riga.qty || 1, F: lingua,
    G: riga.condizione || 'NM', H: risposta.urlSingles, I: risposta.prezzo ?? '', K: riga.nota || '', L: immagineConvertita,
    M: !!riga.sigillata_originale,
  };
  if (riga.destinazione === 'wishlist' && riga.prezzo_obiettivo != null) rigaDati.J = riga.prezzo_obiettivo;

  const esito = await _aggiungiConVerifica(rigaDati, 3, riga.tipo, riga.destinazione, riga.id);
  if (!esito || !esito.ok) {
    await _segnaTentativoFallitoAutonomo(riga, 'scrittura fallita: ' + (esito?.errore || '?'), null);
    return;
  }

  // prodotto sealed (dalla 5.77): minimo di Cardmarket e se il prezzo è dell'integrità giusta
  if (isSealed && riga.destinazione !== 'wishlist' && risposta.integrita && esito.riga) {
    const r = await chiamaSupabase('aggiornaIntegritaRigaSealed', { riga: esito.riga, rigaCodaId: riga.id, minimo: risposta.minimoCm ?? null, daIntegrita: risposta.integrita === 'trovata' }).catch(() => null);
    if (!r || !r.ok) console.warn('[worker-autonomo] dati dell\'integrità del sealed non salvati:', r && r.errore);
  }

  if (sigillata && sigillata.sigillata && esito.riga) {
    const r = await chiamaSupabase('aggiornaSigillataRiga', { riga: esito.riga, rigaCodaId: riga.id, minimo: sigillata.minimoCm, daSigillata: sigillata.sigillata === 'trovata' }).catch(() => null);
    if (!r || !r.ok) console.warn('[worker-autonomo] dati della carta sigillata non salvati:', r && r.errore);
  }

  await registraAiutoGruppo(supabaseClient, riga.id, riga.owner_id, 'coda_carte');

  await supabaseClient.from('coda_carte')
    .update({ stato: 'completato', completato_il: new Date().toISOString() })
    .eq('id', riga.id)
    .then(({ error }) => { if (error) console.error('[worker-autonomo] scrittura stato completato:', error.message); });
}

function _soloSeAncoraMiaAutonoma(query, riga) {
  let q = query.eq('stato', 'in_corso');
  if (riga && riga.claimed_by) q = q.eq('claimed_by', riga.claimed_by);
  return q;
}

async function _segnaTentativoFallitoAutonomo(riga, motivo, opzioni, definitivo) {
  const tentativi = (riga.tentativi_falliti || 0) + 1;
  const SOGLIA_CORREZIONE_MANUALE = 3;

  if (definitivo || tentativi >= SOGLIA_CORREZIONE_MANUALE) {
    const { error } = await supabaseClient.rpc('sposta_riga_in_correzione_manuale', {
      p_riga_id: riga.id,
      p_errore_msg: definitivo ? motivo : `${motivo} (dopo ${tentativi} tentativi automatici)`,
      p_opzioni: opzioni,
    });
    if (error) {
      console.error('[worker-autonomo] impossibile spostare in correzione manuale:', error.message);
      await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({ stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi }).eq('id', riga.id), riga);
    }
    return;
  }

  await _soloSeAncoraMiaAutonoma(supabaseClient.from('coda_carte').update({
    stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi,
  }).eq('id', riga.id), riga);
}

const _CHIAVI_SEGNALE_OCCUPATO = ['sessionePrezziAttiva_prezzi', 'sessionePrezziAttiva_wishlist'];
const _TIPI_ORDINE_PREZZI = ['controlla_prezzi', 'controlla_prezzi_sealed', 'controlla_prezzi_wishlist'];

async function _paginaPrezziOccupata() {
  try {
    const valori = await chrome.storage.local.get(_CHIAVI_SEGNALE_OCCUPATO);
    const ora = Date.now();
    return _CHIAVI_SEGNALE_OCCUPATO.some(k => valori[k] && typeof valori[k].scadenza === 'number' && valori[k].scadenza > ora);
  } catch (_) {
    return false;
  }
}

const _CHIAVE_CODA_PAGINA_ATTIVA = 'sessioneCodaAttiva_carte';
const _CHIAVE_WORKER_AUTONOMO_ATTIVO = 'workerAutonomoAttivo';
const _CHIAVE_PREZZI_IN_PARTENZA = 'prezziInPartenza';
const _ORE_PRECEDENZA_ORDINI_PREZZI = 2;

function _segnaleVivo(v) {
  return !!v && typeof v.scadenza === 'number' && v.scadenza > Date.now();
}

async function _prezziInPartenzaQui() {
  try {
    const v = await chrome.storage.local.get([_CHIAVE_PREZZI_IN_PARTENZA, 'ordinePendenteAutorun', 'ordinePendenteAutorunSealed', 'ordinePendenteAutorunWishlist']);
    const flagRecente = (f) => !!f && typeof f.messoIl === 'number' && Date.now() - f.messoIl < 2 * 60 * 1000;
    return _segnaleVivo(v[_CHIAVE_PREZZI_IN_PARTENZA])
      || flagRecente(v.ordinePendenteAutorun) || flagRecente(v.ordinePendenteAutorunSealed) || flagRecente(v.ordinePendenteAutorunWishlist);
  } catch (_) {
    return false;
  }
}

async function _controlloPrezziOccupaQuestoPc() {
  return (await _paginaPrezziOccupata()) || (await _prezziInPartenzaQui());
}

async function _codaCardmarketOccupataQui() {
  try {
    const v = await chrome.storage.local.get([_CHIAVE_CODA_PAGINA_ATTIVA, _CHIAVE_WORKER_AUTONOMO_ATTIVO]);
    return _segnaleVivo(v[_CHIAVE_CODA_PAGINA_ATTIVA]) || _segnaleVivo(v[_CHIAVE_WORKER_AUTONOMO_ATTIVO]);
  } catch (_) {
    return false;
  }
}

async function _puoPrendereOrdiniPrezziQui() {
  if ((await _leggiStatoLoginRicordato()) === false) return false;
  if (!(await _verificaVersioneAggiornata())) return false;
  if (!(await _lavoroPermessoSuQuestoPc())) return false;
  return true;
}

async function _ordinePrezziArrivatoPrima(creatoIlRiga) {
  try {
    if (!(await _puoPrendereOrdiniPrezziQui())) return null;
    const soglia = new Date(Date.now() - _ORE_PRECEDENZA_ORDINI_PREZZI * 60 * 60 * 1000).toISOString();
    let q = supabaseClient.from('ordini').select('id, tipo, creato_il')
      .eq('stato', 'pending').in('tipo', _TIPI_ORDINE_PREZZI).gt('creato_il', soglia)
      .order('creato_il', { ascending: true }).limit(1);
    if (creatoIlRiga) q = q.lt('creato_il', creatoIlRiga);
    const { data, error } = await q;
    if (error || !data || data.length === 0) return null;
    return data[0];
  } catch (_) {
    return null;
  }
}

async function _precedenzaCodaCardmarket({ creatoIlRiga = null, soloOccupato = false, escludiWorker = false } = {}) {
  if (await _controlloPrezziOccupaQuestoPc()) return { attendi: true, motivo: 'controllo-prezzi' };
  if (!escludiWorker) {
    const v = await chrome.storage.local.get(_CHIAVE_WORKER_AUTONOMO_ATTIVO);
    if (_segnaleVivo(v[_CHIAVE_WORKER_AUTONOMO_ATTIVO])) return { attendi: true, motivo: 'worker' };
  }
  if (!soloOccupato && (await _ordinePrezziArrivatoPrima(creatoIlRiga))) return { attendi: true, motivo: 'ordine-prima' };
  return { attendi: false, motivo: null };
}

const _ORE_ORDINE_ABBANDONATO = 6;
let _ultimaPuliziaOrdini = 0;

async function _chiudiOrdiniAbbandonati(userId, occupato) {
  if (Date.now() - _ultimaPuliziaOrdini < 10 * 60 * 1000) return;
  _ultimaPuliziaOrdini = Date.now();
  try {
    const { data, error } = await supabaseClient.rpc('chiudi_ordini_abbandonati');
    if (error) console.error('[ordini] pulizia ordini abbandonati:', error.message);
    else if (data > 0) console.log('[ordini] chiusi ' + data + ' ordini senza attività da più di ' + _ORE_ORDINE_ABBANDONATO + ' ore');
  } catch (e) {
    console.error('[ordini] pulizia ordini abbandonati:', e.message);
  }
}

let _controlloOrdiniInCorso = false;
let _ultimoAvvisoOrdiniPrezziEsclusi = 0;

async function _controllaOrdini() {
  if (_controlloOrdiniInCorso) return;
  _controlloOrdiniInCorso = true;
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return;

    const occupato = (await _paginaPrezziOccupata()) || (await _prezziInPartenzaQui());
    await _chiudiOrdiniAbbandonati(userId, occupato);

    const loginNoRicordato = (await _leggiStatoLoginRicordato()) === false;

    const versioneVecchia = !(await _verificaVersioneAggiornata());

    const chiusaNonPermesso = !(await _lavoroPermessoSuQuestoPc());

    const codaOccupata = await _codaCardmarketOccupataQui();

    const motiviEsclusione = [
      occupato && 'un controllo prezzi sta già girando su questo PC',
      codaOccupata && 'la coda "Aggiungi carte" sta lavorando su questo PC (un lavoro su Cardmarket alla volta)',
      loginNoRicordato && 'login Cardmarket non confermato (ultimo esito ricordato)',
      versioneVecchia && 'estensione non aggiornata',
      chiusaNonPermesso && '"Lavora anche a estensione chiusa" spento e app chiusa',
    ].filter(Boolean);
    if (motiviEsclusione.length > 0 && Date.now() - _ultimoAvvisoOrdiniPrezziEsclusi > 2 * 60 * 1000) {
      _ultimoAvvisoOrdiniPrezziEsclusi = Date.now();
      console.warn('[ordini] questo PC per ora non prende ordini di prezzi:', motiviEsclusione.join('; '));
    }

    let queryPendenti = supabaseClient
      .from('ordini')
      .select('id, tipo, parametri, creato_da')
      .eq('stato', 'pending');
    if (occupato || codaOccupata || loginNoRicordato || versioneVecchia || chiusaNonPermesso) queryPendenti = queryPendenti.not('tipo', 'in', `(${_TIPI_ORDINE_PREZZI.map(t => `"${t}"`).join(',')})`);
    const { data: pendenti, error: errLettura } = await queryPendenti
      .order('creato_il', { ascending: true })
      .limit(1);
    if (errLettura) { console.error('[ordini] errore lettura:', errLettura.message); return; }
    if (!pendenti || pendenti.length === 0) return;

    const ordine = pendenti[0];

    const ordinePrezzi = _TIPI_ORDINE_PREZZI.includes(ordine.tipo);
    if (ordinePrezzi) {
      await chrome.storage.local.set({ [_CHIAVE_PREZZI_IN_PARTENZA]: { scadenza: Date.now() + 2 * 60 * 1000 } });
      const login = await _verificaLoginAutomatica();
      if (!login || login.loggato !== true) {
        await chrome.storage.local.remove(_CHIAVE_PREZZI_IN_PARTENZA);
        console.warn('[ordini] login Cardmarket non confermato su questo PC — ordine di prezzi lasciato in attesa per un altro PC.');
        return;
      }
    }

    const { data: claimato, error: errClaim } = await supabaseClient
      .from('ordini')
      .update({ stato: 'in_corso', preso_in_carico_da: userId, preso_in_carico_il: new Date().toISOString() })
      .eq('id', ordine.id)
      .eq('stato', 'pending')
      .select();
    if (errClaim || !claimato || claimato.length === 0) {
      if (ordinePrezzi) await chrome.storage.local.remove(_CHIAVE_PREZZI_IN_PARTENZA);
      if (errClaim) console.error('[ordini] errore claim:', errClaim.message);
      return;
    }

    if (ordine.tipo === 'controlla_prezzi') {
      await chrome.storage.local.set({ ordinePendenteAutorun: { id: ordine.id, tipo: ordine.tipo, parametri: ordine.parametri || {}, creatoDa: ordine.creato_da, messoIl: Date.now() } });
      await _apriOFocalizzaAppSuPrezzi(ordine.id);
    } else if (ordine.tipo === 'controlla_prezzi_wishlist') {
      await chrome.storage.local.set({ ordinePendenteAutorunWishlist: { id: ordine.id, tipo: ordine.tipo, parametri: ordine.parametri || {}, creatoDa: ordine.creato_da, messoIl: Date.now() } });
      await _apriOFocalizzaAppSuPrezzi(ordine.id);
    } else if (ordine.tipo === 'controlla_prezzi_sealed') {
      await chrome.storage.local.set({ ordinePendenteAutorunSealed: { id: ordine.id, tipo: ordine.tipo, parametri: ordine.parametri || {}, creatoDa: ordine.creato_da, messoIl: Date.now() } });
      await _apriOFocalizzaAppSuPrezzi(ordine.id);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'errore',
        errore_msg: `Tipo ordine "${ordine.tipo}" non ancora supportato dall'estensione.`,
        completato_il: new Date().toISOString(),
      }).eq('id', ordine.id);
    }
  } catch (e) {
    console.error('[ordini] errore imprevisto nel polling:', e);
  } finally {
    _controlloOrdiniInCorso = false;
  }
}

async function _apriOFocalizzaAppSuPrezzi(ordineId) {
  return _apriOFocalizzaAppSuSezione('prezzi', ordineId);
}

async function _apriOFocalizzaAppSuSezione(sezione, ordineId) {
  const urlApp = chrome.runtime.getURL('app.html');
  const urlDestinazione = `${urlApp}?ordine=${encodeURIComponent(ordineId || Date.now())}#${sezione}`;
  const tabs = await chrome.tabs.query({ url: urlApp + '*' });
  if (tabs.length > 0) {
    const tab = tabs[0];
    if (await _avvisaAppGiaAperta(tab.id, sezione, ordineId)) return;
    await chrome.tabs.update(tab.id, { active: false, url: urlDestinazione });
  } else {
    await chrome.tabs.create({ url: urlDestinazione, active: false });
  }
}

function _avvisaAppGiaAperta(tabId, sezione, ordineId) {
  return new Promise((resolve) => {
    let fatto = false;
    const fine = (ok) => { if (!fatto) { fatto = true; resolve(ok); } };
    setTimeout(() => fine(false), 3000);
    try {
      chrome.runtime.sendMessage({ type: 'CARDSYNC_APRI_SEZIONE_ORDINE', tabId, sezione, ordineId: ordineId || null }, (r) => {
        void chrome.runtime.lastError;
        fine(!!(r && r.ok));
      });
    } catch (_) {
      fine(false);
    }
  });
}

function _chiaveWorkerTab(kind) { return 'workerTab_' + kind; }

async function _getWorkerTabId(kind) {
  const key = _chiaveWorkerTab(kind);
  const saved = await new Promise(r => chrome.storage.local.get([key], r));
  const tabId = saved[key];
  if (tabId == null) return null;
  const esiste = await new Promise(r => {
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab) r(false); else r(true);
    });
  });
  if (!esiste) {
    await new Promise(r => chrome.storage.local.remove([key], r));
    return null;
  }
  return tabId;
}

async function _salvaWorkerTabId(kind, tabId) {
  await new Promise(r => chrome.storage.local.set({ [_chiaveWorkerTab(kind)]: tabId }, r));
}

async function _prontaWorkerTabId(kind) {
  const altro = kind === 'carte' ? 'sealed' : 'carte';
  if ((await _getWorkerTabId(altro)) != null) _accodaSuWorkerTab(altro, () => _chiudiWorkerTab(altro));
  const esistente = await _getWorkerTabId(kind);
  if (esistente != null) return esistente;
  const tab = await new Promise(r => chrome.tabs.create({ url: 'about:blank', active: false }, r));
  await _salvaWorkerTabId(kind, tab.id);
  return tab.id;
}

async function _chiudiWorkerTab(kind) {
  const key = _chiaveWorkerTab(kind);
  const saved = await new Promise(r => chrome.storage.local.get([key], r));
  const tabId = saved[key];
  if (tabId != null) {
    chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
    await new Promise(r => chrome.storage.local.remove([key], r));
  }
}

const _codaWorkerTab = { carte: Promise.resolve(), sealed: Promise.resolve() };

function _accodaSuWorkerTab(kind, taskFn) {
  const k = kind === 'sealed' ? 'sealed' : 'carte';
  const esecuzione = _codaWorkerTab[k].then(taskFn, taskFn);
  _codaWorkerTab[k] = esecuzione.then(() => {}, () => {});
  return esecuzione;
}

const _CHIAVE_TURNO_CM = 'turnoCardmarketDa';
const _CHIAVE_CONTA_CM = 'turnoCardmarketConta';
const _CHIAVE_LIVELLO_CF_CM = 'turnoCardmarketLivelloCf';
const _PASSO_CF_CM_MS = 3000;
const _MAX_LIVELLO_CF_CM = 5;
const _MARGINE_TURNO_CM_MS = 1200;
const _PAUSA_LUNGA_CM_MS = 60 * 1000;
const _PAUSA_OGNI_VALORI_CM = [25, 50, 75, 100, Infinity];
let _turnoCmDa = null;
let _contaCm = 0;
let _pausaLungaDopoCartaCm = false;
let _motivoAttesaCm = null;
let _codaTurnoCm = Promise.resolve();
let _livelloCfCm = 0;
let _cfInQuestaCartaCm = false;

async function _pausaOgniCm() {
  const { sliderPausaOgni } = await chrome.storage.local.get('sliderPausaOgni');
  return _PAUSA_OGNI_VALORI_CM[sliderPausaOgni ?? 2] ?? 75;
}

async function _attesaSliderCmMs() {
  const s = await chrome.storage.local.get(['sliderDelayMinSec', 'sliderDelayMaxSec']);
  const min = Number.isFinite(s.sliderDelayMinSec) ? s.sliderDelayMinSec : 10;
  const max = Math.max(Number.isFinite(s.sliderDelayMaxSec) ? s.sliderDelayMaxSec : 20, min);
  return min * 1000 + Math.floor(Math.random() * (max - min) * 1000) + _MARGINE_TURNO_CM_MS
    + _livelloCfCm * _PASSO_CF_CM_MS;
}

function _inCodaTurnoCm(fn) {
  const p = _codaTurnoCm.then(async () => {
    if (_turnoCmDa === null) {
      const salvato = await chrome.storage.local.get([_CHIAVE_TURNO_CM, _CHIAVE_CONTA_CM, _CHIAVE_LIVELLO_CF_CM]);
      _turnoCmDa = salvato[_CHIAVE_TURNO_CM] || 0;
      _contaCm = salvato[_CHIAVE_CONTA_CM] || 0;
      _livelloCfCm = Math.min(Math.max(salvato[_CHIAVE_LIVELLO_CF_CM] || 0, 0), _MAX_LIVELLO_CF_CM);
    }
    return fn();
  });
  _codaTurnoCm = p.catch(() => {});
  return p;
}

function _prenotaTurnoCardmarket() {
  return _inCodaTurnoCm(async () => {
    const inizio = Math.max(Date.now(), _turnoCmDa);
    const motivo = inizio > Date.now() ? _motivoAttesaCm : null;
    _motivoAttesaCm = null;
    _contaCm++;
    _pausaLungaDopoCartaCm = _contaCm % (await _pausaOgniCm()) === 0;
    _turnoCmDa = inizio + await _attesaSliderCmMs() + (_pausaLungaDopoCartaCm ? _PAUSA_LUNGA_CM_MS : 0);
    if (_pausaLungaDopoCartaCm) _motivoAttesaCm = 'pausa-lunga';
    await chrome.storage.local.set({ [_CHIAVE_TURNO_CM]: _turnoCmDa, [_CHIAVE_CONTA_CM]: _contaCm });
    return { da: inizio, motivo, livelloCf: _livelloCfCm };
  });
}

function _quandoTurnoCardmarket() {
  return _inCodaTurnoCm(async () => {
    const da = Math.max(Date.now(), _turnoCmDa);
    return { da, motivo: da > Date.now() ? _motivoAttesaCm : null, livelloCf: _livelloCfCm };
  });
}

function _segnalaCloudflareAlTurno() {
  return _inCodaTurnoCm(async () => {
    if (_cfInQuestaCartaCm) return;
    _cfInQuestaCartaCm = true;
    _livelloCfCm = Math.min(_livelloCfCm + 1, _MAX_LIVELLO_CF_CM);
    console.log('[turno Cardmarket] Cloudflare: rallento, livello', _livelloCfCm);
    const d = new Date();
    const oggi = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const { cloudflareOggi: prec } = await chrome.storage.local.get('cloudflareOggi');
    const nOggi = prec && prec.giorno === oggi ? (prec.n || 0) + 1 : 1;
    await chrome.storage.local.set({ [_CHIAVE_LIVELLO_CF_CM]: _livelloCfCm, cloudflareOggi: { giorno: oggi, n: nOggi } });
  });
}

function _chiudiTurnoCardmarket() {
  return _inCodaTurnoCm(async () => {
    const pausaLunga = _pausaLungaDopoCartaCm ? _PAUSA_LUNGA_CM_MS : 0;
    _pausaLungaDopoCartaCm = false;
    if (_cfInQuestaCartaCm) _cfInQuestaCartaCm = false;
    else if (_livelloCfCm > 0) _livelloCfCm--;
    _turnoCmDa = Math.max(_turnoCmDa, Date.now() + await _attesaSliderCmMs() + pausaLunga);
    await chrome.storage.local.set({ [_CHIAVE_TURNO_CM]: _turnoCmDa, [_CHIAVE_LIVELLO_CF_CM]: _livelloCfCm });
  });
}

async function _attendiTurnoCardmarket() {
  const { da, motivo } = await _prenotaTurnoCardmarket();
  if (motivo === 'pausa-lunga') console.log('[turno Cardmarket] pausa lunga fino alle', new Date(da).toLocaleTimeString());
  while (Date.now() < da) {
    await new Promise(r => setTimeout(r, Math.min(5000, da - Date.now())));
    await chrome.runtime.getPlatformInfo();
  }
}

async function _conTurnoCardmarket(message, fn) {
  if (message && message.turnoGiaPreso) return fn();
  await _attendiTurnoCardmarket();
  try {
    return await fn();
  } finally {
    _chiudiTurnoCardmarket();
  }
}

// ── Elenco dei prodotti sealed di Cardmarket (dalla 5.78, sql/151) ──────────────────────────
// Lo riempie solo l'account indicato nel DB (configurazione_app.catalogo_sealed_utente: Bill),
// quando il PC è libero: niente coda da fare, niente controllo prezzi, accesso a Cardmarket non
// perso. Una pagina-elenco alla volta col turno comune (lo stesso ritmo di coda e prezzi), sempre
// in vista galleria (mode=gallery dà la stessa pagina con qualsiasi preferenza dell'account);
// se la lettura diretta è respinta, in una scheda in background (dalla 5.79).
// Cosa leggere lo decide il DB: prima la pagina di ogni categoria (filtro "Espansione"), poi ogni
// categoria + espansione. Rallentamento, Cloudflare o pagina non scaricata: pausa di un'ora.
// Le foto (400 px WebP) vanno nel bucket sealed-foto, una prova al giorno per prodotto.
const _CATALOGO_SEALED_PAGINE_PER_GIRO = 20;
const _CATALOGO_SEALED_MAX_PAGINE_COPPIA = 12;
const _CATALOGO_SEALED_FOTO_PER_GIRO = 30;
const _CATALOGO_SEALED_LATO_FOTO = 400;
const _CATALOGO_SEALED_MAX_FOTO_BYTE = 200 * 1024;
const _CATALOGO_SEALED_PAUSA_MS = 60 * 60 * 1000;
const _CATALOGO_SEALED_BUCKET = 'sealed-foto';
const _CHIAVE_CATALOGO_SEALED_PAUSA = 'catalogoSealedPausaFino';
// dalla 5.79: segnale per la pagina Prezzi (vale 5 minuti): finché l'elenco ha pagine da leggere
// il controllo automatico dei prezzi del gruppo aspetta (decisione di Claudio del 19/11)
const _CHIAVE_CATALOGO_SEALED_IN_CORSO = 'catalogoSealedInCorso';
const _CATALOGO_SEALED_SEGNALE_MS = 5 * 60 * 1000;
const _RE_FOTO_PRODOTTO_CM = /^https:\/\/product-images\.s3\.cardmarket\.com\/(\d+)\/(\d+)\/[^"?#\s]+$/;
let _catalogoSealedInCorso = false;
let _catalogoSealedMio = { uid: null, valore: false, il: 0 };

function _avviaCatalogoSealed() {
  _creaSvegliaSeManca('catalogo-sealed', 2);
}
_avviaCatalogoSealed();

function _urlElencoSealed(categoria, idEspansione, pagina) {
  const parametri = [];
  if (idEspansione) parametri.push('idExpansion=' + idEspansione);
  parametri.push('mode=gallery');
  if (pagina > 1) parametri.push('site=' + pagina);
  return 'https://www.cardmarket.com/it/Pokemon/Products/' + categoria + '?' + parametri.join('&');
}

// Filtro "Espansione" della pagina di una categoria: [{ id, nome }] (null se il filtro manca)
function _espansioniSealedDaHtml(html) {
  const m = /<select\b[^>]*\bname="idExpansion"[^>]*>([\s\S]*?)<\/select>/i.exec(html || '');
  if (!m) return null;
  const out = [];
  const visti = new Set();
  const re = /<option\b[^>]*\bvalue="(\d+)"[^>]*>([\s\S]*?)<\/option>/gi;
  let o;
  while ((o = re.exec(m[1])) !== null) {
    const id = Number(o[1]);
    const nome = _testoDaHtml(o[2]);
    if (!id || !nome || visti.has(id)) continue;
    visti.add(id);
    out.push({ id, nome });
  }
  return out;
}

// Schede della galleria: <a href="/it/Pokemon/Products/<categoria>/<slug>" class="… galleryBox">
// con l'immagine in data-echo (product-images…/<idCategoria>/<idProdotto>/…) e il nome nell'h2.
function _prodottiSealedDaHtml(html, categoria) {
  const out = [];
  const visti = new Set();
  const re = /<a\b([^>]*\bgalleryBox\b[^>]*)>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html || '')) !== null) {
    const href = /\bhref="([^"]+)"/i.exec(m[1]);
    if (!href) continue;
    const percorso = href[1].replace(/^https:\/\/www\.cardmarket\.com/i, '').split(/[?#]/)[0];
    const pm = /^\/[a-z]{2}\/Pokemon\/Products\/([A-Za-z-]+)\/([^/?#"\s]+)$/.exec(percorso);
    if (!pm || pm[1] !== categoria) continue;
    const slug = pm[2];
    const url = 'https://www.cardmarket.com/it/Pokemon/Products/' + categoria + '/' + slug;
    if (visti.has(url)) continue;
    const attributiFoto = [...m[2].matchAll(/\b(?:data-echo|src)="([^"]+)"/gi)].map(x => x[1].split(/[?#]/)[0]);
    const fotoCm = attributiFoto.find(u => _RE_FOTO_PRODOTTO_CM.test(u)) || null;
    const titolo = /<h2\b[^>]*>([\s\S]*?)<\/h2>/i.exec(m[2]);
    const alt = /\balt="([^"]*)"/i.exec(m[2]);
    const nome = _testoDaHtml(titolo ? titolo[1] : '') || _testoDaHtml(alt ? alt[1] : '');
    if (!nome) continue;
    visti.add(url);
    out.push({ url, slug, nome, id_prodotto: fotoCm ? Number(_RE_FOTO_PRODOTTO_CM.exec(fotoCm)[2]) : null, foto_cm: fotoCm });
  }
  return out;
}

function _pagineElencoSealedDaHtml(html) {
  const m = /Pagina\s+(\d+)\s+di\s+(\d+)/i.exec(html || '');
  return m ? Math.max(1, Number(m[2])) : 1;
}

// Pagine ancora da leggere (le stesse regole di catalogo_sealed_prossimo, senza prenotare niente)
async function _catalogoSealedHaPagineDaLeggere() {
  try {
    const ora = Date.now();
    const unGiorno = new Date(ora - 24 * 60 * 60 * 1000).toISOString();
    const trentaGiorni = new Date(ora - 30 * 24 * 60 * 60 * 1000).toISOString();
    const { data, error } = await supabaseClient.from('sealed_catalogo_giri').select('id_categoria')
      .or(`letto_il.is.null,and(id_espansione.eq.0,letto_il.lt.${unGiorno}),letto_il.lt.${trentaGiorni}`)
      .limit(1);
    return !error && !!data && data.length > 0;
  } catch (_) {
    return false;
  }
}

async function _segnalaElencoSealedInCorso(attivo) {
  try {
    if (attivo) await chrome.storage.local.set({ [_CHIAVE_CATALOGO_SEALED_IN_CORSO]: { scadenza: Date.now() + _CATALOGO_SEALED_SEGNALE_MS } });
    else await chrome.storage.local.remove(_CHIAVE_CATALOGO_SEALED_IN_CORSO);
  } catch (_) {}
}

async function _catalogoSealedEMio(userId) {
  if (_catalogoSealedMio.uid === userId && Date.now() - _catalogoSealedMio.il < 10 * 60 * 1000) return _catalogoSealedMio.valore;
  let valore = false;
  try {
    const { data, error } = await supabaseClient.rpc('catalogo_sealed_e_mio');
    valore = !error && data === true;
  } catch (_) { valore = false; }
  _catalogoSealedMio = { uid: userId, valore, il: Date.now() };
  return valore;
}

// Righe della coda che questo PC lavorerebbe: se ce n'è una, l'elenco aspetta.
async function _catalogoSealedCodaInAttesa(userId) {
  try {
    const { aiutaGruppo } = await chrome.storage.local.get('aiutaGruppo');
    let q = supabaseClient.from('coda_carte').select('id').eq('stato', 'pending').limit(1);
    if (!aiutaGruppo) q = q.eq('owner_id', userId);
    const { data, error } = await q;
    if (error) return true;
    return !!data && data.length > 0;
  } catch (_) {
    return true;
  }
}

async function _catalogoSealedPcLibero(userId) {
  if ((await _leggiStatoLoginRicordato()) === false) return false;
  if (!(await _lavoroPermessoSuQuestoPc())) return false;
  if (_lavoroAutonomoInCorso) return false;
  if (await _codaCardmarketOccupataQui()) return false;
  if ((await _precedenzaCodaCardmarket()).attendi) return false;
  if (await _catalogoSealedCodaInAttesa(userId)) return false;
  return true;
}

// Dalla 5.79: la lettura diretta (fetch dal motore) oggi Cardmarket la respinge ("fetch statico
// NON OK" nella console del 19/11, come per i prezzi che ripiegano sulla scheda). In quel caso la
// pagina si legge in una scheda in background, chiusa subito dopo, e per mezz'ora si va dritti in
// scheda. Cloudflare nella scheda: niente primo piano né suono (è un lavoro di riempimento); dalla
// 5.81 si aspetta fino a 30 s che la verifica passi da sola, poi la scheda si chiude e il giro va in
// pausa.
const _ATTESA_SCHEDA_ELENCO_SEALED_MS = 30 * 1000;
// dalla 5.81: con Cloudflare nella scheda si aspetta che la verifica si risolva da sola (in una
// scheda vera di solito bastano pochi secondi; il 19/11 una verifica costava un'ora di pausa)
const _ATTESA_CF_ELENCO_SEALED_MS = 30 * 1000;
// dalla 5.81: una pagina-elenco ogni ~60 s (decisione di Claudio del 19/11: a una ogni ~20 s
// Cloudflare è scattato dopo 85 pagine, e di nuovo al primo tentativo un'ora dopo). L'attesa è
// fuori dal turno comune: coda e prezzi non aspettano l'elenco.
const _CATALOGO_SEALED_SPAZIO_MS = 60 * 1000;
const _CHIAVE_CATALOGO_SEALED_ULTIMA = 'catalogoSealedUltimaPagina';

async function _attendiSpazioElencoSealed() {
  const { [_CHIAVE_CATALOGO_SEALED_ULTIMA]: ultima } = await chrome.storage.local.get(_CHIAVE_CATALOGO_SEALED_ULTIMA);
  const spazio = _CATALOGO_SEALED_SPAZIO_MS * (0.9 + Math.random() * 0.2);
  const da = (typeof ultima === 'number' ? ultima : 0) + spazio;
  while (Date.now() < da) {
    await new Promise(r => setTimeout(r, Math.min(5000, da - Date.now())));
    await chrome.runtime.getPlatformInfo();
  }
}

function _leggiPaginaElencoSealedInScheda(url) {
  return new Promise((resolve) => {
    let tabId = null;
    let finito = false;
    let pollTimer = null;
    let scadenza = null;
    let vistoCloudflare = false;
    function chiudi(esito) {
      if (finito) return;
      finito = true;
      clearInterval(pollTimer);
      clearTimeout(scadenza);
      if (tabId != null) chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
      resolve(esito);
    }
    function tenta() {
      if (finito || tabId == null) return;
      chrome.scripting.executeScript({
        target: { tabId },
        args: [CF_TITLES, RATE_LIMIT_MARKERS],
        func: (CF_TITLES, RATE_LIMIT_MARKERS) => {
          const titolo = String(document.title || '').toLowerCase();
          const testo = (titolo + ' ' + (document.body ? document.body.textContent.slice(0, 3000) : '')).toLowerCase();
          if (RATE_LIMIT_MARKERS.some(m => testo.includes(m))) return { motivo: 'rallentato' };
          if (CF_TITLES.some(t => titolo.includes(t)) || document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running')) return { motivo: 'cloudflare' };
          if (document.readyState === 'loading' || !document.querySelector('h1')) return null;
          return { html: document.documentElement.outerHTML };
        },
      }, (res) => {
        if (chrome.runtime.lastError || finito) return;
        const v = res && res[0] && res[0].result;
        if (!v) return;
        if (v.motivo === 'cloudflare') {
          if (vistoCloudflare) return;
          // prima volta: il turno comune rallenta, e si aspetta che la verifica passi da sola
          vistoCloudflare = true;
          _segnalaCloudflareAlTurno();
          clearInterval(pollTimer);
          pollTimer = setInterval(tenta, 1500);
          clearTimeout(scadenza);
          scadenza = setTimeout(() => chiudi({ motivo: 'cloudflare' }), _ATTESA_CF_ELENCO_SEALED_MS);
          return;
        }
        chiudi(v);
      });
    }
    scadenza = setTimeout(() => chiudi({ motivo: 'non-scaricata' }), _ATTESA_SCHEDA_ELENCO_SEALED_MS);
    chrome.tabs.create({ url, active: false }, (tab) => {
      if (chrome.runtime.lastError || !tab) { chiudi({ motivo: 'scheda-non-aperta' }); return; }
      tabId = tab.id;
      if (finito) { chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; }); return; }
      pollTimer = setInterval(tenta, 600);
    });
  });
}

async function _leggiPaginaElencoSealed(url) {
  await _attendiTurnoCardmarket();
  try {
    if (!_letturaDirettaDaSaltare()) {
      const html = await _fetchHtml(url);
      if (html) {
        const lower = html.toLowerCase();
        if (isPaginaRateLimit(lower)) return { motivo: 'rallentato' };
        if (!_htmlEChallengeCloudflare(lower)) return { html };
      } else if (_fetchHtmlEraRateLimit(url)) {
        return { motivo: 'rallentato' };
      }
      _segnaLetturaDirettaRespinta();
    }
    return await _leggiPaginaElencoSealedInScheda(url);
  } finally {
    _chiudiTurnoCardmarket();
    await chrome.storage.local.set({ [_CHIAVE_CATALOGO_SEALED_ULTIMA]: Date.now() }).catch(() => {});
  }
}

// Un lavoro dato da catalogo_sealed_prossimo: { esito: 'ok'|'errore'|'stop'|'occupato', pagine }
async function _catalogoSealedFaiLavoro(lavoro, userId) {
  const categoria = String(lavoro && lavoro.categoria || '');
  const idCategoria = Number(lavoro && lavoro.id_categoria);
  const idEspansione = Number(lavoro && lavoro.id_espansione) || 0;
  if (!/^[A-Za-z-]+$/.test(categoria) || !idCategoria) return { esito: 'errore', pagine: 0 };

  if (!idEspansione) {
    const r = await _leggiPaginaElencoSealed(_urlElencoSealed(categoria, 0, 1));
    if (!r.html) return { esito: 'stop', motivo: r.motivo, pagine: 1 };
    const espansioni = _espansioniSealedDaHtml(r.html);
    if (!espansioni || espansioni.length === 0) {
      await supabaseClient.rpc('catalogo_sealed_errore', { p_id_categoria: idCategoria, p_id_espansione: 0, p_esito: 'filtro-espansioni-assente' });
      return { esito: 'errore', pagine: 1 };
    }
    const { error } = await supabaseClient.rpc('catalogo_sealed_salva_espansioni', { p_id_categoria: idCategoria, p_espansioni: espansioni });
    if (error) console.warn('[elenco sealed] salvataggio espansioni:', error.message);
    return { esito: error ? 'errore' : 'ok', pagine: 1 };
  }

  let totale = 1;
  let letti = 0;
  let pagine = 0;
  const daFotografare = [];
  for (let p = 1; p <= totale; p++) {
    if (p > 1) {
      await _attendiSpazioElencoSealed();
      await _segnalaElencoSealedInCorso(true);
      if (!(await _catalogoSealedPcLibero(userId))) return { esito: 'occupato', pagine };
    }
    const r = await _leggiPaginaElencoSealed(_urlElencoSealed(categoria, idEspansione, p));
    pagine++;
    if (!r.html) return { esito: 'stop', motivo: r.motivo, pagine };
    if (p === 1) totale = Math.min(_pagineElencoSealedDaHtml(r.html), _CATALOGO_SEALED_MAX_PAGINE_COPPIA);
    const prodotti = _prodottiSealedDaHtml(r.html, categoria);
    if (prodotti.length === 0 && !/\d+\s+Risultat/i.test(r.html)) {
      await supabaseClient.rpc('catalogo_sealed_errore', { p_id_categoria: idCategoria, p_id_espansione: idEspansione, p_esito: 'pagina-non-riconosciuta' });
      return { esito: 'errore', pagine };
    }
    letti += prodotti.length;
    const ultima = p >= totale;
    const { data, error } = await supabaseClient.rpc('catalogo_sealed_salva_pagina', {
      p_id_categoria: idCategoria, p_id_espansione: idEspansione, p_prodotti: prodotti,
      p_completa: ultima, p_totale: ultima ? letti : null,
    });
    if (error) { console.warn('[elenco sealed] salvataggio pagina:', error.message); return { esito: 'errore', pagine }; }
    if (Array.isArray(data)) daFotografare.push(...data);
  }
  await _salvaFotoCatalogoSealed(daFotografare);
  return { esito: 'ok', pagine };
}

async function _fotoSealedWebp(urlFoto) {
  const r = await fetch(urlFoto);
  if (!r || !r.ok) return null;
  const origine = await r.blob();
  const bmp = await createImageBitmap(origine);
  try {
    const scala = Math.min(1, _CATALOGO_SEALED_LATO_FOTO / Math.max(bmp.width, bmp.height, 1));
    const larghezza = Math.max(1, Math.round(bmp.width * scala));
    const altezza = Math.max(1, Math.round(bmp.height * scala));
    const tela = new OffscreenCanvas(larghezza, altezza);
    tela.getContext('2d').drawImage(bmp, 0, 0, larghezza, altezza);
    const webp = await tela.convertToBlob({ type: 'image/webp', quality: 0.82 });
    if (!webp || webp.type !== 'image/webp' || webp.size > _CATALOGO_SEALED_MAX_FOTO_BYTE) return null;
    return webp;
  } finally {
    if (bmp && typeof bmp.close === 'function') bmp.close();
  }
}

async function _salvaFotoCatalogoSealed(lista) {
  let fatte = 0;
  for (const f of (lista || []).slice(0, _CATALOGO_SEALED_FOTO_PER_GIRO)) {
    if (!f || !f.url || !f.id_prodotto || !_RE_FOTO_PRODOTTO_CM.test(String(f.foto_cm || ''))) continue;
    try {
      const webp = await _fotoSealedWebp(f.foto_cm);
      if (!webp) continue;
      const nome = Number(f.id_prodotto) + '.webp';
      const { error } = await supabaseClient.storage.from(_CATALOGO_SEALED_BUCKET)
        .upload(nome, webp, { contentType: 'image/webp', upsert: true, cacheControl: '2592000' });
      if (error) { console.warn('[elenco sealed] foto non caricata:', nome, error.message); continue; }
      await supabaseClient.rpc('catalogo_sealed_foto_salvata', { p_url: f.url, p_foto: nome });
      fatte++;
    } catch (e) {
      console.warn('[elenco sealed] foto:', f.id_prodotto, e && e.message);
    }
    await new Promise(r => setTimeout(r, 400));
  }
  return fatte;
}

async function _lavoraCatalogoSealed() {
  if (_catalogoSealedInCorso) return 'in-corso';
  _catalogoSealedInCorso = true;
  try {
    const { [_CHIAVE_CATALOGO_SEALED_PAUSA]: pausaFino } = await chrome.storage.local.get(_CHIAVE_CATALOGO_SEALED_PAUSA);
    if (typeof pausaFino === 'number' && Date.now() < pausaFino) { await _segnalaElencoSealedInCorso(false); return 'pausa'; }
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) { await _segnalaElencoSealedInCorso(false); return 'non-loggato'; }
    if (!(await _catalogoSealedEMio(userId))) { await _segnalaElencoSealedInCorso(false); return 'non-mio'; }
    if (!(await _verificaVersioneAggiornata())) { await _segnalaElencoSealedInCorso(false); return 'versione-vecchia'; }
    await _segnalaElencoSealedInCorso(await _catalogoSealedHaPagineDaLeggere());

    let pagine = 0;
    while (pagine < _CATALOGO_SEALED_PAGINE_PER_GIRO) {
      if (!(await _catalogoSealedPcLibero(userId))) return 'occupato';
      await _attendiSpazioElencoSealed();
      if (!(await _catalogoSealedPcLibero(userId))) return 'occupato';
      const { data, error } = await supabaseClient.rpc('catalogo_sealed_prossimo');
      if (error) { console.warn('[elenco sealed] prossimo lavoro:', error.message); return 'errore'; }
      const lavoro = Array.isArray(data) ? data[0] : data;
      if (!lavoro) {
        await _segnalaElencoSealedInCorso(false);
        const { data: mancanti } = await supabaseClient.rpc('catalogo_sealed_foto_mancanti', { p_limite: _CATALOGO_SEALED_FOTO_PER_GIRO });
        if (Array.isArray(mancanti) && mancanti.length) await _salvaFotoCatalogoSealed(mancanti);
        return 'finito';
      }
      const esito = await _catalogoSealedFaiLavoro(lavoro, userId);
      pagine += Math.max(1, esito.pagine || 0);
      if (esito.esito === 'stop') {
        console.warn('[elenco sealed] Cardmarket:', esito.motivo, '— riprendo tra un\'ora');
        await chrome.storage.local.set({ [_CHIAVE_CATALOGO_SEALED_PAUSA]: Date.now() + _CATALOGO_SEALED_PAUSA_MS });
        await _segnalaElencoSealedInCorso(false);
        return 'pausa';
      }
      if (esito.esito === 'occupato') return 'occupato';
      await _segnalaElencoSealedInCorso(true);
    }
    return 'giro-pieno';
  } catch (e) {
    console.error('[elenco sealed] errore imprevisto:', e);
    return 'errore';
  } finally {
    _catalogoSealedInCorso = false;
  }
}

const BULK_MAX_RETRY = 2;

const _richiesteAttive = new Map();

function _touchRichiesta(requestId, tabId) {
  if (!requestId) return;
  const esistente = _richiesteAttive.get(requestId);
  _richiesteAttive.set(requestId, {
    tabId: tabId != null ? tabId : (esistente ? esistente.tabId : null),
    ultimaAttivita: Date.now(),
  });
}

function _rimuoviRichiesta(requestId) {
  if (!requestId) return;
  _richiesteAttive.delete(requestId);
}

function _pulisciRichiesteVecchie() {
  const LIMITE_MS = 20 * 60 * 1000;
  const ora = Date.now();
  for (const [id, info] of _richiesteAttive.entries()) {
    if (ora - info.ultimaAttivita > LIMITE_MS) _richiesteAttive.delete(id);
  }
}

function _leggiOpzioniCf() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['sliderCfTimeout', 'avvisoSonoro'], (res) => {
      const minuti = (typeof res.sliderCfTimeout === 'number' && res.sliderCfTimeout >= 1)
        ? res.sliderCfTimeout
        : 3;
      const avvisoSonoro = res.avvisoSonoro !== false;
      resolve({ cfTimeoutMs: minuti * 60 * 1000, avvisoSonoro });
    });
  });
}

let cloudflareAlarmTabId = null;
let cloudflareAlarmActive = false;

async function _registraAttesaCf(tabId, minuti) {
  const scadenza = Date.now() + minuti * 60 * 1000;
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  attese[tabId] = scadenza;
  await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  _creaSvegliaSeManca('cf-watchdog', 1);
}

async function _rimuoviAttesaCf(tabId) {
  if (tabId === null || tabId === undefined) return;
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  if (attese[tabId] !== undefined) {
    delete attese[tabId];
    await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  }
}

async function _controllaWatchdogCf() {
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  const ora = Date.now();
  let cambiato = false;
  for (const [tabIdStr, scadenza] of Object.entries(attese)) {
    if (ora > scadenza) {
      const tabId = parseInt(tabIdStr, 10);
      chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
      chrome.runtime.sendMessage({ type: 'CLOUDFLARE_TIMEOUT', tabId }).catch(() => {});
      delete attese[tabIdStr];
      cambiato = true;
    }
  }
  if (cambiato) await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  if (Object.keys(attese).length === 0) chrome.alarms.clear('cf-watchdog');
}

async function _hashUrl(url) {
  const dati = new TextEncoder().encode(url);
  const buffer = await crypto.subtle.digest('SHA-256', dati);
  return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 24);
}

// Dalla 5.82: il nome del file nello storage dipende solo dall'indirizzo della foto (sha256): se il
// file c'è già si usa quello, senza riscaricare la foto né ricaricarla (il 19/11 il controllo prezzi
// riscriveva identiche ~1.400 foto al giorno). Il controllo è una HEAD sul file pubblico; se non
// risponde, si fa come prima.
async function _immagineGiaNelloStorage(url) {
  try {
    const estensioneUrl = (url.split('?')[0].split('.').pop() || '').toLowerCase();
    const estensione = estensioneUrl === 'png' ? 'png' : (estensioneUrl === 'webp' ? 'webp' : 'jpg');
    const nomeFile = (await _hashUrl(url)) + '.' + estensione;
    const { data: pub } = supabaseClient.storage.from('immagini-carte').getPublicUrl(nomeFile);
    if (!pub || !pub.publicUrl) return null;
    const r = await fetch(pub.publicUrl, { method: 'HEAD', cache: 'no-store' });
    return r && r.ok ? pub.publicUrl : null;
  } catch (_) {
    return null;
  }
}

async function _immagineAUrlDati(url) {
  if (!url) return null;
  try {
    if (/^https?:\/\//i.test(url)) {
      const giaNostra = await _immagineGiaNelloStorage(url);
      if (giaNostra) return giaNostra;
    }
    const resp = await fetch(url);
    if (!resp.ok) { console.warn('[immagine] risposta non ok (' + resp.status + '), tengo URL originale'); return url; }
    const buffer = await resp.arrayBuffer();
    let tipo = (resp.headers.get('content-type') || '').split(';')[0].trim();
    if (!tipo.startsWith('image/')) {
      const estensioneUrl = (url.split('?')[0].split('.').pop() || '').toLowerCase();
      tipo = estensioneUrl === 'png' ? 'image/png' : (estensioneUrl === 'webp' ? 'image/webp' : 'image/jpeg');
    }
    const estensione = tipo.includes('png') ? 'png' : (tipo.includes('webp') ? 'webp' : 'jpg');
    const nomeFile = (await _hashUrl(url)) + '.' + estensione;

    const { error: errUpload } = await supabaseClient.storage
      .from('immagini-carte')
      .upload(nomeFile, buffer, { contentType: tipo, upsert: true });
    if (errUpload) { console.error('[immagine] errore upload su Storage:', errUpload.message, errUpload); return url; }

    const { data: pub } = supabaseClient.storage.from('immagini-carte').getPublicUrl(nomeFile);
    return pub.publicUrl;
  } catch (e) {
    console.error('[immagine] errore nella conversione:', e.message, e);
    return url;
  }
}

async function _aggiungiConVerifica(rigaDati, tentativiMax = 3, tipo, destinazione, dbRigaId) {
  let ultimoErrore;
  for (let tentativo = 0; tentativo < tentativiMax; tentativo++) {
    try {
      const data = destinazione === 'wishlist'
        ? await chiamaSupabase('aggiungiWishlist', { rigaDati, tipo, dbRigaId })
        : await chiamaSupabase('aggiungi', { rigaDati, tipoOverride: tipo, destinazione, dbRigaId });
      return data;
    } catch (e) {
      ultimoErrore = e;
      if (tentativo < tentativiMax - 1) await new Promise(r => setTimeout(r, 1000 * (tentativo + 1)));
    }
  }
  return { ok: false, errore: 'Impossibile aggiungere la carta dopo ' + tentativiMax + ' tentativi: ' + (ultimoErrore ? ultimoErrore.message : '?') };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'AVVIA_AVVISO_CLOUDFLARE') {
    cloudflareAlarmTabId = message.tabId;
    cloudflareAlarmActive = true;
    _segnalaCloudflareAlTurno();
    const tabAvvio = message.tabId;
    const sonoroRichiesto = message.avvisoSonoro !== false;
    _leggiOpzioniCf().then(({ avvisoSonoro }) => _suonaEPortaInPrimoPiano(tabAvvio, avvisoSonoro && sonoroRichiesto));
    _creaSvegliaSeManca('cloudflare-avviso', 0.5);
    const timeoutMinuti = (typeof message.timeoutMinuti === 'number' && message.timeoutMinuti >= 1)
      ? message.timeoutMinuti
      : 3;
    _registraAttesaCf(message.tabId, timeoutMinuti);
    return false;
  }

  if (message.type === 'FERMA_AVVISO_CLOUDFLARE') {
    _fermaAvvisi();
    return false;
  }

  if (message.type === 'PING_RICHIESTA') {
    const info = _richiesteAttive.get(message.requestId);
    sendResponse({ attiva: !!info, ultimaAttivita: info ? info.ultimaAttivita : null });
    return false;
  }

  if (message.type === 'CHIUDI_WORKER_TAB') {
    const kindChiusura = message.kind || 'carte';
    _accodaSuWorkerTab(kindChiusura, () => _chiudiWorkerTab(kindChiusura)).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'PRECEDENZA_CODA_CARDMARKET') {
    _precedenzaCodaCardmarket({ creatoIlRiga: message.creatoIlRiga || null, soloOccupato: !!message.soloOccupato })
      .then((r) => sendResponse({ ok: true, attendi: r.attendi, motivo: r.motivo }))
      .catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }

  if (message.type === 'TURNO_CARDMARKET') {
    const azione = message.fase === 'chiudi' ? _chiudiTurnoCardmarket()
      : message.fase === 'quando' ? _quandoTurnoCardmarket()
      : _prenotaTurnoCardmarket();
    azione.then((r) => sendResponse({ ok: true, da: (r && r.da) || null, motivo: (r && r.motivo) || null, livelloCf: (r && r.livelloCf) || 0 }))
      .catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }

  // Accesso a Cardmarket: stato per l'app, controllo adesso, scheda per accedere
  if (message.type === 'CM_ACCESSO_CONTROLLA') {
    // forza (apertura dell'app, "Controlla adesso"): serve uno stato scritto dopo la richiesta. Se ci si è
    // agganciati a un controllo in corso che ha risposto con lo stato ricordato, si controlla di nuovo.
    const richiestaMs = Date.now();
    (async () => {
      await _verificaLoginAutomatica(!!message.forza);
      if (message.forza) {
        const s = (await chrome.storage.local.get(_CHIAVE_STATO_LOGIN_CM))[_CHIAVE_STATO_LOGIN_CM];
        if (!s || typeof s.quando !== 'number' || s.quando < richiestaMs) await _verificaLoginAutomatica(true);
      }
      return _statoAccessoCardmarket();
    })()
      .then(stato => sendResponse(stato))
      .catch(() => sendResponse({ stato: 'ignoto' }));
    return true;
  }

  if (message.type === 'CM_ACCESSO_APRI') {
    _apriSchedaAccessoCardmarket()
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, errore: e && e.message }));
    return true;
  }

  if (message.type === 'VERIFICA_LOGIN_SILENZIOSA') {
    _verificaLoginSilenziosa(message.kind || null)
      .then(esito => sendResponse(esito))
      .catch(() => sendResponse({ loggato: null }));
    return true;
  }

  if (message.type === 'VERIFICA_LOGIN_AUTOMATICA') {
    _verificaLoginAutomatica()
      .then(esito => sendResponse(esito))
      .catch(() => sendResponse({ loggato: false }));
    return true;
  }

  if (message.type === 'STATO_LOGIN_CARDMARKET') {
    const daCardmarket = !!(sender && sender.tab && typeof sender.url === 'string' && sender.url.startsWith('https://www.cardmarket.com/'));
    if (daCardmarket && (message.loggato === true || message.loggato === false)) _ricordaStatoLoginCardmarket(message.loggato);
    return false;
  }

  if (message.type === 'CONVERTI_IMMAGINE') {
    _immagineAUrlDati(message.url || null).then((dataUri) => sendResponse({ immagine: dataUri }));
    return true;
  }

  if (message.type === 'AGGIUNGI_CARTA') {
    const { rigaDati, azione, tipo, destinazione, dbRigaId } = message;

    if (!azione) {
      _aggiungiConVerifica(rigaDati, 3, tipo, destinazione, dbRigaId)
        .then(data => sendResponse(data))
        .catch(err => sendResponse({ ok: false, errore: err.message }));
      return true;
    }

    const promessa = Promise.resolve({ ok: false, errore: `Azione "${azione}" non gestita.` });
    promessa
      .then(data => sendResponse(data))
      .catch(err => sendResponse({ ok: false, errore: err.message }));
    return true;
  }

  if (message.type === 'LEGGI_NOME_CARTA') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('carte') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const r = await _conTurnoCardmarket(message, () => _leggiNomeDaCardmarket(message.urlNome, message.lingua, message.condizione, message.oloType || '', !!message.firstEd, 0, tabIdWorker, requestId, message.urlRicercaRiserva || null));
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: r.nome, codice: r.codice, prezzo: r.prezzo, urlSingles: r.urlSingles, disambiguation: !!r.disambiguation, varianteNonTrovata: !!r.varianteNonTrovata, opzioni: r.opzioni || [], immagine: r.immagine || null, rateLimited: !!r.rateLimited, linkNonValido: !!r.linkNonValido, linkSostituito: !!r.linkSostituito });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: false, varianteNonTrovata: false, rateLimited: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('carte', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_SEALED') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const r = await _conTurnoCardmarket(message, () => _leggiNomeSealedDaCardmarket(message.urlNome, message.lingua, 0, tabIdWorker, requestId, { integrita: message.integrita }));
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: r.nome, urlProdotto: r.urlProdotto, prezzo: r.prezzo, immagine: r.immagine || null, disambiguation: !!r.disambiguation, opzioni: r.opzioni || [], rateLimited: !!r.rateLimited,
            minimoCm: r.minimoCm ?? null, integrita: r.integrita || null });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: false, rateLimited: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_SOLO_PREZZO') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('carte') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const { prezzo, immagine, nome, codice, tabId } = await _conTurnoCardmarket(message, () => _leggiPrezzoDaSingles(message.urlConFiltri, tabIdWorker, requestId));
          _rimuoviRichiesta(requestId);
          if (tabIdWorker != null && tabId && tabId !== tabIdWorker) await _salvaWorkerTabId('carte', tabId);
          sendResponse({
            prezzo: (prezzo === 'RateLimit' ? null : prezzo) ?? null,
            immagine: immagine || null,
            nome: nome || null,
            codice: codice || null,
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null, codice: null });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('carte', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_PREZZO_SIGILLATA') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('carte') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const r = await _conTurnoCardmarket(message, () => _leggiPrezzoSigillata(message, tabIdWorker, requestId));
          _rimuoviRichiesta(requestId);
          if (tabIdWorker != null && r.tabId && r.tabId !== tabIdWorker) await _salvaWorkerTabId('carte', r.tabId);
          sendResponse({ prezzo: r.prezzo, minimoCm: r.minimoCm, sigillata: r.sigillata, rateLimited: !!r.rateLimited });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, minimoCm: null, sigillata: null, rateLimited: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('carte', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_SOLO_PREZZO_SEALED') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const ris = await _conTurnoCardmarket(message, () => _leggiPrezzoSealed(message.urlProdotto, tabIdWorker, requestId));
          _rimuoviRichiesta(requestId);
          if (tabIdWorker != null && ris && ris.tabId && ris.tabId !== tabIdWorker) await _salvaWorkerTabId('sealed', ris.tabId);
          sendResponse({
            prezzo: (ris && !ris.rateLimited) ? (ris.prezzo ?? null) : null,
            immagine: (ris && ris.immagine) || null,
            nome: (ris && ris.nome) || null,
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_PREZZO_SEALED_GRUPPO') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const ris = await _conTurnoCardmarket(message, () => _leggiPrezzoSealed(message.urlProdotto, tabIdWorker, requestId, { integrita: message.integrita }));
          _rimuoviRichiesta(requestId);
          if (tabIdWorker != null && ris && ris.tabId && ris.tabId !== tabIdWorker) await _salvaWorkerTabId('sealed', ris.tabId);
          sendResponse({
            prezzo: (ris && ris.prezzo != null) ? ris.prezzo : null,
            immagine: (ris && ris.immagine) || null,
            nome: (ris && ris.nome) || null,
            rateLimited: !!(ris && ris.rateLimited),
            cloudflareTimeout: !!(ris && ris.cloudflareTimeout),
            minimoCm: ris && typeof ris.minimoCm === 'number' ? ris.minimoCm : null,
            integrita: (ris && ris.integrita) || null,
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null, rateLimited: false, cloudflareTimeout: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  return false;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'sw-keepalive') { _pulisciRichiesteVecchie(); return; }

  if (alarm.name === 'ordini-poll') { _controllaOrdini(); return; }

  if (alarm.name === 'worker-coda-carte-autonomo') { _lavoraCodaCarteAutonomo(); return; }
  if (alarm.name === 'catalogo-sealed') { _lavoraCatalogoSealed(); return; }
  if (alarm.name === 'riapri-app') { _riapriAppSeChiusa(); return; }
  if (alarm.name === 'controlla-aggiornamento-file') { _ricaricaSeFileAggiornati(); return; }
  if (alarm.name === 'segnala-dispositivo') { _segnalaDispositivo(); return; }

  if (alarm.name === 'cloudflare-avviso' && cloudflareAlarmActive && cloudflareAlarmTabId !== null) {
    const tabAvviso = cloudflareAlarmTabId;
    _leggiOpzioniCf().then(({ avvisoSonoro }) => _suonaEPortaInPrimoPiano(tabAvviso, avvisoSonoro));
  }

  if (alarm.name === 'cf-watchdog') {
    _controllaWatchdogCf();
  }
});

function _fermaAvvisi() {
  if (cloudflareAlarmTabId !== null) _rimuoviAttesaCf(cloudflareAlarmTabId);
  cloudflareAlarmActive = false;
  cloudflareAlarmTabId = null;
  chrome.alarms.clear('cloudflare-avviso');
}

async function _suonaEPortaInPrimoPiano(tabId, avvisoSonoro, kind = null) {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) {
      _fermaAvvisi();
      return;
    }
    chrome.windows.update(tab.windowId, { focused: true }, () => {
      setTimeout(() => chrome.tabs.update(tabId, { active: true }), 150);
    });
  });

  if (kind) {
    _segnalaCloudflareAlTurno();
    chrome.runtime.sendMessage({ type: 'CLOUDFLARE_HIT_BULK', kind }).catch(() => {});
  }

  if (avvisoSonoro) {
    await _suonaDaOffscreen();
  }
}

async function _suonaDaOffscreen() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });

  if (existingContexts.length === 0) {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['AUDIO_PLAYBACK'],
      justification: 'Riproduce il suono di avviso Cloudflare',
    });
  }

  chrome.runtime.sendMessage({ type: 'SUONA' }).catch(() => {});
}

function _statoCloudflareNellaScheda(CF_TITLES) {
  const title = document.title.toLowerCase();
  return (CF_TITLES.some(t => title.includes(t)) || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')))) ? 'cf' : 'ok';
}

const CF_TITLES = [
  'just a moment', 'un attimo', 'ci siamo quasi', 'almost there',
  'checking your', 'einen moment', 'por favor', 'verifique', 'patikrinimas',
];

const _CF_MARCATORI_CHALLENGE = [
  '_cf_chl_opt', '/orchestrate/chl_page', 'challenge-running', 'challenge-form',
  'challenge-error-text', 'cf-chl-widget',
];

function _htmlEChallengeCloudflare(htmlMinuscolo) {
  if (!htmlMinuscolo) return false;
  const mTitolo = htmlMinuscolo.match(/<title[^>]*>([\s\S]*?)<\/title>/);
  const titolo = mTitolo ? mTitolo[1] : '';
  if (CF_TITLES.some(t => titolo.includes(t))) return true;
  return _CF_MARCATORI_CHALLENGE.some(m => htmlMinuscolo.includes(m));
}

function _leggiStatoLoginCardmarket(tabId) {
  return new Promise((resolve) => {
    let risolto = false;
    let vistoCloudflare = false;
    let pollTimer = null;
    let timeout = null;
    let timeoutTotale = null;

    function concludi(valore) {
      if (risolto) return;
      risolto = true;
      if (pollTimer) clearInterval(pollTimer);
      if (timeout) clearTimeout(timeout);
      if (timeoutTotale) clearTimeout(timeoutTotale);
      chrome.tabs.onUpdated.removeListener(onLoad);
      chrome.tabs.onRemoved.removeListener(onRimossa);
      if (valore && (valore.loggato === true || valore.loggato === false)) _ricordaStatoLoginCardmarket(valore.loggato);
      resolve(valore);
    }

    function tentaLettura() {
      chrome.scripting.executeScript({
        target: { tabId },
        func: (titoliCf) => {
          if (document.getElementById('account-dropdown')) return { loggato: true };
          if (document.getElementById('login-signup')) return { loggato: false };
          const titolo = String(document.title || '').toLowerCase();
          if (titoliCf.some(t => titolo.includes(t))) return { cloudflare: true };
          return undefined;
        },
        args: [CF_TITLES],
      }, (results) => {
        if (risolto) return;
        if (chrome.runtime.lastError) return;
        const val = results?.[0]?.result;
        if (val === undefined || val === null) return;
        // la verifica di Cloudflare a volte passa da sola: si aspetta fino alla fine
        if (val.cloudflare) { vistoCloudflare = true; return; }
        concludi(val);
      });
    }

    function avviaLettura() {
      if (risolto) return;
      if (!pollTimer) pollTimer = setInterval(tentaLettura, 400);
      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(() => concludi({ loggato: null, cloudflare: vistoCloudflare }), 10000);
    }

    function onLoad(id, info) {
      if (id !== tabId || info.status !== 'complete') return;
      avviaLettura();
    }
    function onRimossa(idChiusa) {
      if (idChiusa === tabId) concludi({ loggato: null });
    }
    chrome.tabs.onUpdated.addListener(onLoad);
    chrome.tabs.onRemoved.addListener(onRimossa);
    timeoutTotale = setTimeout(() => concludi({ loggato: null, cloudflare: vistoCloudflare }), 45000);
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab) { concludi({ loggato: null }); return; }
      if (tab.status === 'complete') avviaLettura();
    });
  });
}

// Scheda per accedere a Cardmarket (pallino, finestra di blocco dell'app, Avvia in Coda e Prezzi).
// Una sola scheda: se è già aperta si porta davanti. Quando l'accesso si vede (ogni secondo, e a ogni
// caricamento della scheda anche dopo un riavvio del service worker) la scheda si chiude e si torna all'app.
const _CHIAVE_SCHEDA_ACCESSO_CM = 'cmSchedaAccesso';
const _MINUTI_MAX_ATTESA_LOGIN = 20;
let _attesaAccessoTimer = null;

async function _apriSchedaAccessoCardmarket() {
  const salvata = (await chrome.storage.local.get(_CHIAVE_SCHEDA_ACCESSO_CM))[_CHIAVE_SCHEDA_ACCESSO_CM];
  let tab = null;
  if (salvata && salvata.id) {
    try { tab = await chrome.tabs.get(salvata.id); } catch (_) { tab = null; }
  }
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
  } else {
    tab = await chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: true });
    await chrome.storage.local.set({ [_CHIAVE_SCHEDA_ACCESSO_CM]: { id: tab.id, aperta: Date.now() } });
  }
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {   }
  _sorvegliaSchedaAccesso(tab.id);
}

function _sorvegliaSchedaAccesso(tabId) {
  if (_attesaAccessoTimer) clearInterval(_attesaAccessoTimer);
  const inizio = Date.now();
  _attesaAccessoTimer = setInterval(() => {
    if (Date.now() - inizio > _MINUTI_MAX_ATTESA_LOGIN * 60 * 1000) { clearInterval(_attesaAccessoTimer); _attesaAccessoTimer = null; return; }
    _controllaSchedaAccesso(tabId);
  }, 1000);
}

function _controllaSchedaAccesso(tabId) {
  chrome.scripting.executeScript({
    target: { tabId },
    func: () => !!document.getElementById('account-dropdown'),
  }, async (results) => {
    if (chrome.runtime.lastError) return;
    if (!(results && results[0] && results[0].result === true)) return;
    if (_attesaAccessoTimer) { clearInterval(_attesaAccessoTimer); _attesaAccessoTimer = null; }
    const salvata = (await chrome.storage.local.get(_CHIAVE_SCHEDA_ACCESSO_CM))[_CHIAVE_SCHEDA_ACCESSO_CM];
    if (!salvata || salvata.id !== tabId) return;
    await chrome.storage.local.remove(_CHIAVE_SCHEDA_ACCESSO_CM);
    _ricordaStatoLoginCardmarket(true);
    chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
    _apriOFocalizzaTabApp().catch(() => {});
  });
}

chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== 'complete') return;
  chrome.storage.local.get(_CHIAVE_SCHEDA_ACCESSO_CM).then((v) => {
    const salvata = v[_CHIAVE_SCHEDA_ACCESSO_CM];
    if (salvata && salvata.id === tabId) _controllaSchedaAccesso(tabId);
  }).catch(() => {});
});
chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.get(_CHIAVE_SCHEDA_ACCESSO_CM).then((v) => {
    const salvata = v[_CHIAVE_SCHEDA_ACCESSO_CM];
    if (salvata && salvata.id === tabId) chrome.storage.local.remove(_CHIAVE_SCHEDA_ACCESSO_CM);
  }).catch(() => {});
});

// Stato per l'app e per le pagine: 'ok', 'ko', 'cloudflare' o 'ignoto'
async function _statoAccessoCardmarket() {
  const salvato = (await chrome.storage.local.get(_CHIAVE_STATO_LOGIN_CM))[_CHIAVE_STATO_LOGIN_CM];
  const ricordato = await _leggiStatoLoginRicordato();
  if (ricordato === true) return { stato: 'ok', quando: salvato && salvato.quando };
  if (salvato && salvato.cloudflare === true && ricordato === false) return { stato: 'cloudflare', quando: salvato.quando };
  if (ricordato === false && salvato && salvato.nonConfermato !== true) return { stato: 'ko', quando: salvato.quando };
  return { stato: 'ignoto', quando: salvato && salvato.quando };
}

// Usato da "Avvia" (Coda e Prezzi) e da "Controlla connessione": stato ricordato o controllo in una scheda nascosta.
async function _verificaLoginSilenziosa() {
  if ((await _leggiStatoLoginRicordato()) === true) return { loggato: true, ricordato: true };
  return _verificaLoginAutomatica(true);
}

const _CHIAVE_STATO_LOGIN_CM = 'statoLoginCardmarket';
// "dentro" vale 5 minuti (prima 6 ore): ogni pagina di Cardmarket aperta dall'estensione lo rinnova
// o lo smentisce; da fermi, prima di partire, si controlla in una scheda nascosta.
// Stesso valore di _CM_MINUTI_VALIDITA_OK in app.js.
const _MINUTI_VALIDITA_LOGIN_OK = 5;
const _MINUTI_PAUSA_LOGIN_KO = 30;
const _MINUTI_PAUSA_LOGIN_NON_CONFERMATO = 2;

function _ricordaStatoLoginCardmarket(loggato) {
  _ultimoStatoLoginScritto = loggato === true;
  try {
    chrome.storage.local.set({ [_CHIAVE_STATO_LOGIN_CM]: { loggato: loggato === true, quando: Date.now() } }, () => { void chrome.runtime.lastError; });
  } catch (_) {   }
}

async function _ricordaLoginNonConfermato(cloudflare = false) {
  try {
    const prec = (await chrome.storage.local.get(_CHIAVE_STATO_LOGIN_CM))[_CHIAVE_STATO_LOGIN_CM];
    const consecutivi = (prec && prec.nonConfermato === true && Number.isInteger(prec.consecutivi)) ? prec.consecutivi + 1 : 1;
    await chrome.storage.local.set({ [_CHIAVE_STATO_LOGIN_CM]: { loggato: false, quando: Date.now(), nonConfermato: true, cloudflare: cloudflare === true, consecutivi } });
    _ultimoStatoLoginScritto = null;
  } catch (_) {   }
}

// "Esci" premuto su Cardmarket in una scheda qualsiasi (/{lingua}/{gioco}/PostGetAction/User_Logout):
// Cardmarket rimanda subito a un'altra pagina, quindi l'indirizzo non resta mai nella scheda; la
// richiesta si vede con webRequest, solo l'indirizzo, senza toccare la pagina. Si segna "fuori"
// quando Cardmarket ha risposto (rimando o pagina), non se la richiesta fallisce.
const _RE_USCITA_CM = /^https:\/\/www\.cardmarket\.com\/[^/?#]+\/[^/?#]+\/PostGetAction\/User_Logout(?:[?#]|$)/;
const _FILTRO_USCITA_CM = { urls: ['https://www.cardmarket.com/*/PostGetAction/User_Logout*'], types: ['main_frame', 'sub_frame', 'xmlhttprequest'] };
function _uscitaCardmarketVista(dettagli) {
  if (!dettagli || !_RE_USCITA_CM.test(dettagli.url || '')) return;
  console.log('[login Cardmarket] "Esci" premuto su Cardmarket: fuori.');
  _ricordaStatoLoginCardmarket(false);
}
try {
  if (chrome.webRequest) {
    chrome.webRequest.onBeforeRedirect.addListener(_uscitaCardmarketVista, _FILTRO_USCITA_CM);
    chrome.webRequest.onCompleted.addListener(_uscitaCardmarketVista, _FILTRO_USCITA_CM);
  }
} catch (e) {
  console.warn('[login Cardmarket] uscita da Cardmarket non sorvegliata:', e && e.message);
}

// "Fuori" visto da una pagina di Cardmarket dopo inizioMs (non un controllo non confermato)
async function _uscitoDaCardmarketDa(inizioMs) {
  try {
    const s = (await chrome.storage.local.get(_CHIAVE_STATO_LOGIN_CM))[_CHIAVE_STATO_LOGIN_CM];
    return !!s && s.loggato === false && s.nonConfermato !== true && typeof s.quando === 'number' && s.quando >= inizioMs;
  } catch (_) {
    return false;
  }
}

function _minutiPausaLoginKo(salvato) {
  if (salvato.nonConfermato !== true) return _MINUTI_PAUSA_LOGIN_KO;
  const n = Number.isInteger(salvato.consecutivi) && salvato.consecutivi > 0 ? salvato.consecutivi : 1;
  return Math.min(_MINUTI_PAUSA_LOGIN_NON_CONFERMATO * Math.pow(2, n - 1), _MINUTI_PAUSA_LOGIN_KO);
}

async function _leggiStatoLoginRicordato() {
  try {
    const salvato = (await chrome.storage.local.get(_CHIAVE_STATO_LOGIN_CM))[_CHIAVE_STATO_LOGIN_CM];
    if (!salvato || typeof salvato.quando !== 'number') return null;
    const eta = Date.now() - salvato.quando;
    if (eta < 0) return null;
    if (salvato.loggato === true && eta < _MINUTI_VALIDITA_LOGIN_OK * 60 * 1000) return true;
    if (salvato.loggato === false && eta < _minutiPausaLoginKo(salvato) * 60 * 1000) return false;
    return null;
  } catch (_) {
    return null;
  }
}

let _verificaLoginAutomaticaInCorso = null;

function _verificaLoginAutomatica(forza = false) {
  if (_verificaLoginAutomaticaInCorso) return _verificaLoginAutomaticaInCorso;
  _verificaLoginAutomaticaInCorso = (async () => {
    const ricordato = forza ? null : await _leggiStatoLoginRicordato();
    if (ricordato !== null) return { loggato: ricordato, ricordato: true };

    const tab = await new Promise((resolve) => {
      chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: false }, (t) => {
        if (chrome.runtime.lastError || !t) resolve(null); else resolve(t);
      });
    });
    let esito = null;
    if (tab) {
      esito = await _leggiStatoLoginCardmarket(tab.id);
      chrome.tabs.remove(tab.id, () => { void chrome.runtime.lastError; });
    }
    const certo = !!esito && (esito.loggato === true || esito.loggato === false);
    if (!certo) {
      await _ricordaLoginNonConfermato(!!(esito && esito.cloudflare));
      console.warn('[login Cardmarket] verifica automatica non confermata (pagina lenta, Cloudflare o scheda chiusa) — riprovo tra poco.');
    }
    return { loggato: !!esito && esito.loggato === true, cloudflare: !!(esito && esito.cloudflare) };
  })().finally(() => { _verificaLoginAutomaticaInCorso = null; });
  return _verificaLoginAutomaticaInCorso;
}

function _nomeDaSlugUrlSingles(urlSingles) {
  if (!urlSingles) return null;
  const slug = urlSingles.split('/').pop() || '';
  const parti = slug.split('-');
  let endIdx = parti.length;
  for (let i = parti.length - 1; i >= 0; i--) {
    if (/^\d+$/.test(parti[i]) || /^[A-Z]{2,}\d+$/.test(parti[i]) || /^[A-Z]{2,}$/.test(parti[i])) {
      endIdx = i;
    } else { break; }
  }
  return parti.slice(0, endIdx).join(' ').toUpperCase() || null;
}

// Carte con la spunta "Sigillata" messe in collezione dalla coda (dalla 5.76): dopo la lettura normale
// si legge la pagina della carta cercando l'offerta sigillata. Stessi filtri della lettura normale.
const _ATTESA_LETTURA_SIGILLATA_MS = 45000;
async function _leggiPrezzoSigillata(dati, tabIdEsterno = null, requestId = null) {
  const { urlSingles, lingua, condizione, oloType = '', firstEd = false } = dati || {};
  if (!urlSingles) return { prezzo: null, minimoCm: null, sigillata: null };
  const urlConFiltri = _appendVariantParams(costruisciUrlFiltrato(urlSingles, lingua, condizione), oloType, firstEd);
  let r = await _leggiPrezzoDaSingles(urlConFiltri, tabIdEsterno, requestId, { sigillata: true });
  if (r.senzaOfferte && (oloType === 'RH' || firstEd)) {
    const r2 = await _leggiPrezzoDaSingles(costruisciUrlFiltrato(urlSingles, lingua, condizione), r.tabId || tabIdEsterno, requestId, { sigillata: true });
    if (r2.sigillata) r = r2;
  }
  if (r.prezzo === 'RateLimit') return { prezzo: null, minimoCm: null, sigillata: null, rateLimited: true, tabId: r.tabId };
  return { prezzo: typeof r.prezzo === 'number' ? r.prezzo : null, minimoCm: r.minimoCm ?? null, sigillata: r.sigillata || null, tabId: r.tabId };
}

function _appendVariantParams(url, oloType, firstEd) {
  if (!url) return url;
  let u = url;
  if (oloType === 'RH') u += (u.includes('?') ? '&' : '?') + 'isReverseHolo=Y';
  if (firstEd) u += (u.includes('?') ? '&' : '?') + 'isFirstEd=Y';
  return u;
}

async function _contaCartaCodaPerPrezzi() {
  try {
    const { carteCodaDaUltimiPrezzi: n } = await chrome.storage.local.get('carteCodaDaUltimiPrezzi');
    await chrome.storage.local.set({ carteCodaDaUltimiPrezzi: (typeof n === 'number' && n > 0 ? n : 0) + 1 });
  } catch (_) {   }
}

async function _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType = '', firstEd = false, _tentativo = 0, tabIdEsterno = null, requestId = null, urlRicercaRiserva = null) {
  const r = await _leggiNomeDaCardmarketCercando(urlNome, lingua, condizione, oloType, firstEd, _tentativo, tabIdEsterno, requestId, urlRicercaRiserva);
  if (!r || !r.disambiguation || !Array.isArray(r.opzioni) || r.opzioni.length < 2) return r;
  const testoQuery = (() => { try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; } })();
  const tenute = _opzioniPerLingua(r.opzioni, lingua, _linguaProdottoDaQuery(testoQuery));
  if (tenute.length === r.opzioni.length) return r;
  console.log('[CardSync] scelta ristretta alla lingua della carta:', { lingua, prima: r.opzioni.length, dopo: tenute.length });
  if (tenute.length > 1) return { ...r, opzioni: tenute };
  await new Promise(res => setTimeout(res, 1500));
  return _leggiNomeDaCardmarketInterno(tenute[0].urlSingles || tenute[0], lingua, condizione, oloType, firstEd, BULK_MAX_RETRY, tabIdEsterno, requestId);
}

async function _leggiNomeDaCardmarketCercando(urlNome, lingua, condizione, oloType = '', firstEd = false, _tentativo = 0, tabIdEsterno = null, requestId = null, urlRicercaRiserva = null) {
  if (_tentativo === 0) _contaCartaCodaPerPrezzi();
  if (_tentativo === 0 && !String(urlNome || '').includes('/Singles/')) {
    const testo = (() => { try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; } })();
    const compatto = /\s/.test(testo.trim()) ? _codiceRicercaCompatto(testo) : null;
    const wcd = _promoSenzaSerieDaQuery(testo);
    const linkTk = _linkTrainerKitPerQuery(testo);
    if (linkTk && linkTk.length === 1) {
      console.log('[CardSync] Trainer Kit dall\'elenco:', linkTk[0]);
      return _leggiNomeDaCardmarketInterno(linkTk[0], lingua, condizione, oloType, firstEd, BULK_MAX_RETRY, tabIdEsterno, requestId);
    }
    if (linkTk && linkTk.length > 1) {
      console.log('[CardSync] Trainer Kit dall\'elenco, più carte:', linkTk.length);
      return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: _opzioniDaLink(linkTk) };
    }
    if (compatto && !wcd) {
      const urlCompatto = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${_testoRicercaCodificato(compatto)}`;
      const perCodice = await _leggiNomeDaCardmarketInterno(urlCompatto, lingua, condizione, oloType, firstEd, BULK_MAX_RETRY, tabIdEsterno, requestId);
      if (perCodice && perCodice.rateLimited) return perCodice;
      if (perCodice && perCodice.urlSingles && !_ePaginaListaSingles(perCodice.urlSingles, perCodice.nome || '')) return perCodice;
      if (perCodice && perCodice.disambiguation && _opzioniConCodice(perCodice.opzioni, compatto)) return perCodice;
      await new Promise(res => setTimeout(res, 1500));
    }
    if (wcd && wcd.prefisso === 'BOO' && wcd.set && !wcd.anno) {
      // "boo pal 054" / "boo pal054": il codice vero ha l'anno (BOO24PAL054) tranne le BOO 2022 (BOOEVS076).
      // Si prova il codice attaccato per ogni anno: Cardmarket porta dritto alla carta.
      for (const annoBoo of ['', '23', '24', '25']) {
        const codiceBoo = 'BOO' + annoBoo + wcd.set + wcd.numeroTesto;
        const urlBoo = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${_testoRicercaCodificato(codiceBoo)}`;
        const perAnno = await _leggiNomeDaCardmarketInterno(urlBoo, lingua, condizione, oloType, firstEd, BULK_MAX_RETRY, tabIdEsterno, requestId);
        if (perAnno && perAnno.rateLimited) return perAnno;
        const c = perAnno && perAnno.urlSingles && !_ePaginaListaSingles(perAnno.urlSingles, perAnno.nome || '') ? _promoSenzaSerieDaSlug(perAnno.urlSingles) : null;
        if (c && c.prefisso === 'BOO' && c.set === wcd.set && c.numero === wcd.numero) return perAnno;
        await new Promise(res => setTimeout(res, 1500));
      }
    }
    if (wcd && !(wcd.prefisso === 'BOO' && wcd.set && !wcd.nome)) {
      const esitoWcd = await _cercaPromoSenzaSerie(wcd);
      if (esitoWcd && esitoWcd.rateLimited) return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
      if (esitoWcd && esitoWcd.opzioni) return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: esitoWcd.opzioni };
      if (esitoWcd && esitoWcd.link) {
        await new Promise(res => setTimeout(res, 1500));
        return _leggiNomeDaCardmarketInterno(esitoWcd.link, lingua, condizione, oloType, firstEd, BULK_MAX_RETRY, tabIdEsterno, requestId);
      }
      await new Promise(res => setTimeout(res, 1500));
    }
  }
  let r = await _leggiNomeDaCardmarketInterno(urlNome, lingua, condizione, oloType, firstEd, _tentativo, tabIdEsterno, requestId);
  if (r && r.urlSingles && _linkProdottoPortaAltrove(urlNome, urlRicercaRiserva, r.codice)) {
    console.warn('[CardSync] il numero di prodotto porta a un\'altra carta, cerco per nome:', { urlNome, paginaLetta: r.urlSingles, codiceLetto: r.codice, urlRicercaRiserva });
    r = { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true };
  }
  if (r && r.linkNonValido && urlRicercaRiserva && urlRicercaRiserva !== urlNome) {
    console.warn('[CardSync] link Cardmarket non più valido, cerco per nome:', { urlNome, urlRicercaRiserva });
    await new Promise(res => setTimeout(res, 4000));
    const daRicerca = await _leggiNomeDaCardmarketInterno(urlRicercaRiserva, lingua, condizione, oloType, firstEd, 0, tabIdEsterno, requestId);
    r = daRicerca && daRicerca.urlSingles ? { ...daRicerca, linkSostituito: true } : { ...(daRicerca || {}), urlSingles: null, linkNonValido: true };
  }
  if (r && r.urlSingles && _ePaginaListaSingles(r.urlSingles, r.nome || '')) {
    console.warn('[CardSync] risultato scartato: non è una carta (lista espansione/disambiguazione)', { urlNome, urlSingles: r.urlSingles, nome: r.nome });
    return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: [] };
  }
  return r;
}

// Le righe scelte dal catalogo del sito, quando il catalogo non ha la pagina della carta, arrivano col
// numero di prodotto (…/Products?idProduct=N). Quel numero a volte è di un'altra carta (12/11/2026:
// "Blissey PGO 052" → pagina di Snorlax PGO 055). Il testo della riga finisce col numero della carta:
// se la pagina letta ne ha un altro, il link non vale e si cerca per nome come per un link vecchio.
// Si guarda solo il numero: le sigle di Cardmarket non sono sempre quelle del catalogo (FL e RG,
// xPRE e PRE, "TK2 M3" e "TK2M 3"). Senza numero da una delle due parti non si decide niente.
function _linkProdottoPortaAltrove(urlNome, urlRicercaRiserva, codicePagina) {
  if (!urlRicercaRiserva || !/[?&]idProduct=\d+/.test(String(urlNome || ''))) return false;
  let testo = '';
  try { testo = new URL(urlRicercaRiserva).searchParams.get('searchString') || ''; } catch (_) { return false; }
  const chiesto = (testo.match(/(\d+)\D*$/) || [])[1];
  const letto = (String(codicePagina || '').match(/(\d+)\D*$/) || [])[1];
  if (!chiesto || !letto) return false;
  return parseInt(chiesto, 10) !== parseInt(letto, 10);
}

async function _leggiNomeDaCardmarketInterno(urlNome, lingua, condizione, oloType = '', firstEd = false, _tentativo = 0, tabIdEsterno = null, requestId = null) {
  const daLinkDiretto = urlNome.includes('/Singles/');
  if (daLinkDiretto && _ePaginaListaSingles(urlNome, '')) {
    return { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true };
  }

  const saltaLetturaDiretta = !daLinkDiretto && _letturaDirettaDaSaltare();
  const fase1 = daLinkDiretto
    ? { urlSingles: urlNome.split('?')[0], nome: null, codice: null, immagine: null }
    : saltaLetturaDiretta
      ? { urlSingles: null, nome: null, codice: null, fetchFailed: true }
      : await _risolviSinglesENomeFetch(urlNome, oloType);
  if (!daLinkDiretto && !saltaLetturaDiretta && (fase1.fetchFailed || fase1.cloudflare)) _segnaLetturaDirettaRespinta();
  console.log('[CardSync] esito fase1:', daLinkDiretto ? 'link diretto, nessuna lettura preliminare' : saltaLetturaDiretta ? 'lettura diretta respinta di recente: dritto alla scheda' : fase1);

  if (fase1.rateLimited) {
    return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
  }

  if (fase1.cloudflare || fase1.fetchFailed) {
    console.log('[CardSync] passo al fallback via tab (motivo:', fase1.cloudflare ? 'cloudflare' : 'fetch fallita', ')');
    const fusa = await _risolviNomeEPrezzoUnicaTab(urlNome, lingua, condizione, oloType, firstEd, tabIdEsterno, requestId);
    if (tabIdEsterno != null && fusa && fusa.tabId && fusa.tabId !== tabIdEsterno) {
      await _salvaWorkerTabId('carte', fusa.tabId);
      tabIdEsterno = fusa.tabId;
    }
    console.log('[CardSync] esito fallback via tab:', fusa);
    if (fusa && fusa.rateLimited)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
    if (fusa && fusa.disambiguation)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: fusa.opzioni || [] };
    if (fusa && fusa.linkNonValido)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true };
    if (fusa && fusa.varianteNonTrovata)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, varianteNonTrovata: true };
    if (!fusa?.urlSingles) {
      if (!fusa?.nonTrovata && _tentativo < BULK_MAX_RETRY) {
        await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
        return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
      }
      return { nome: null, codice: null, prezzo: null, urlSingles: null };
    }

    const nomeFusa = fusa.nome || _nomeDaSlugUrlSingles(fusa.urlSingles);
    if (!nomeFusa) {
      if (_tentativo < BULK_MAX_RETRY) {
        await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
        return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
      }
      return { nome: null, codice: null, prezzo: null, urlSingles: null };
    }
    return { nome: nomeFusa, codice: fusa.codice, prezzo: fusa.prezzo, urlSingles: fusa.urlSingles, immagine: fusa.immagine || null };
  }

  if (fase1.disambiguation)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: fase1.opzioni || [] };
  if (fase1.linkNonValido)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true };
  if (fase1.varianteNonTrovata)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, varianteNonTrovata: true };

  const { urlSingles, nome, codice } = fase1;

  if (!urlSingles) {
    if (!fase1.nonTrovata && _tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  const urlConFiltri = _appendVariantParams(costruisciUrlFiltrato(urlSingles, lingua, condizione), oloType, firstEd);
  let risPrez = await _leggiPrezzoDaSingles(urlConFiltri, tabIdEsterno, requestId);
  if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
    await _salvaWorkerTabId('carte', risPrez.tabId);
    tabIdEsterno = risPrez.tabId;
  }

  if (risPrez.linkNonValido) {
    return daLinkDiretto
      ? { nome: null, codice: null, prezzo: null, urlSingles: null, linkNonValido: true }
      : { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: [] };
  }

  if (risPrez.senzaOfferte && (oloType === 'RH' || firstEd)) {
    const urlSenzaVarianti = costruisciUrlFiltrato(urlSingles, lingua, condizione);
    const risPrezFallback = await _leggiPrezzoDaSingles(urlSenzaVarianti, tabIdEsterno, requestId);
    if (risPrezFallback.prezzo !== null && risPrezFallback.prezzo !== undefined) risPrez = risPrezFallback;
  }

  if (risPrez.prezzo === 'RateLimit') {
    return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
  }

  if (!nome && !risPrez.nome && !risPrez.codice && (risPrez.prezzo === null || risPrez.prezzo === undefined) && !risPrez.senzaOfferte) {
    if (!risPrez.cloudflare && _tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  let nomefinale = nome || risPrez.nome || _nomeDaSlugUrlSingles(urlSingles);

  if (!nomefinale) {
    if (_tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  const immagineScheda = risPrez.immagine && !_eImmagineSegnaposto(risPrez.immagine) ? risPrez.immagine : null;
  return { nome: nomefinale, codice: codice || risPrez.codice || null, prezzo: risPrez.prezzo, urlSingles, immagine: fase1.immagine || immagineScheda || null };
}

// Dalla 5.80: quando Cardmarket respinge la lettura diretta del motore ("fetch statico NON OK" o
// verifica Cloudflare: succede, vedi console del 19/11), per mezz'ora la ricerca delle carte, quella
// dei sealed e l'elenco dei sealed vanno dritti alla scheda, senza la richiesta che verrebbe respinta.
// Le letture dirette senza un ripiego su scheda (ricerca delle promo) restano come sono.
const _MS_SALTA_LETTURA_DIRETTA = 30 * 60 * 1000;
let _letturaDirettaRespintaFino = 0;
function _letturaDirettaDaSaltare() {
  return Date.now() < _letturaDirettaRespintaFino;
}
function _segnaLetturaDirettaRespinta() {
  _letturaDirettaRespintaFino = Date.now() + _MS_SALTA_LETTURA_DIRETTA;
}

const _fetchRateLimitPerUrl = new Map();
function _fetchHtmlEraRateLimit(url) {
  const v = _fetchRateLimitPerUrl.get(url);
  return !!v && Date.now() - v.il < 60 * 1000;
}
async function _fetchHtml(url) {
  _fetchRateLimitPerUrl.delete(url);
  try {
    const r = await fetch(url, {
      headers: {
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
      },
      credentials: 'include',
    });
    if (r.status === 429) {
      _fetchRateLimitPerUrl.set(url, { il: Date.now(), retryAfter: r.headers.get('retry-after') });
      if (_fetchRateLimitPerUrl.size > 50) _fetchRateLimitPerUrl.delete(_fetchRateLimitPerUrl.keys().next().value);
      console.warn('[CardSync] fetch statico: 429 troppe richieste (Retry-After:', r.headers.get('retry-after'), ')', url);
    }
    if (!r.ok) {
      console.log('[CardSync] fetch statico NON OK:', {
        url,
        status: r.status,
        statusText: r.statusText,
        cfMitigated: r.headers.get('cf-mitigated'),
        cfRay: r.headers.get('cf-ray'),
        server: r.headers.get('server'),
        retryAfter: r.headers.get('retry-after'),
        contentType: r.headers.get('content-type'),
      });
      return null;
    }
    if (r.headers.get('cf-mitigated') === 'challenge') {
      console.log('[CardSync] fetch statico: challenge Cloudflare (cf-mitigated) con status', r.status, url);
      return null;
    }
    return await r.text();
  } catch (e) {
    console.log('[CardSync] fetch statico ECCEZIONE:', {
      url,
      nome: e && e.name,
      messaggio: e && e.message,
    });
    return null;
  }
}

function _estraiLinkSealed(html) {
  const re = /href="(?:https:\/\/www\.cardmarket\.com)?(\/[a-z]{2}\/[^/]+\/Products\/(?!Singles\/)[^"?]+)"/gi;
  const trovati = new Set();
  let m;
  while ((m = re.exec(html)) !== null) {
    const path = m[1].split('/Products/')[1] || '';
    if (path.split('/').length >= 2) trovati.add('https://www.cardmarket.com' + m[1]);
  }
  return Array.from(trovati);
}

function _testiLinkSealed(html) {
  const re = /<a\b[^>]*?href="(?:https:\/\/www\.cardmarket\.com)?(\/[a-z]{2}\/[^/"]+\/Products\/(?!Singles\/)[^"?#]+)(?:[?#][^"]*)?"[^>]*>([\s\S]*?)<\/a>/gi;
  const testi = new Map();
  let m;
  while ((m = re.exec(html)) !== null) {
    const path = m[1].split('/Products/')[1] || '';
    if (path.split('/').filter(Boolean).length < 2) continue;
    const url = 'https://www.cardmarket.com' + m[1];
    const testo = _nomeSealedDaTestoLink(_testoDaHtml(m[2]));
    if (!testi.has(url)) testi.set(url, []);
    if (testo && !testi.get(url).includes(testo)) testi.get(url).push(testo);
  }
  return testi;
}

function _nomeSealedDaTestoLink(testo) {
  return String(testo || '')
    .replace(/(?:\bda|\bfrom|da(?=\s*\d))?\s*\d[\d.,]*\s*€/gi, ' ')
    .replace(/\s+/g, ' ').trim();
}

function _testoDaHtml(frammento) {
  return String(frammento || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ').replace(/&quot;/gi, '"').replace(/&#0*39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
    .replace(/&([aeiou])(acute|grave);/gi, (_, v, a) => (v + (a.toLowerCase() === 'acute' ? '\u0301' : '\u0300')).normalize('NFC'))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ').trim();
}

const _PAROLE_VUOTE_SEALED = new Set(['di', 'da', 'del', 'della', 'dei', 'delle', 'the', 'of']);
function _paroleSealed(testo) {
  return String(testo || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .split(/[^a-z0-9]+/).filter(p => p && !_PAROLE_VUOTE_SEALED.has(p));
}
function _paroleInPiuSealed(paroleRicerca, nome) {
  const parole = _paroleSealed(nome);
  const presenti = new Set(parole);
  if (!paroleRicerca.every(p => presenti.has(p))) return null;
  const cercate = new Set(paroleRicerca);
  return new Set(parole.filter(p => !cercate.has(p))).size;
}

function _trovaMatchSealed(links, searchString, testiPerUrl = null) {
  if (links.length <= 1) return links[0] || null;
  if (!searchString) return null;

  const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '');
  const qNorm = norm(searchString);
  if (!qNorm) return null;
  const slugNorm = (u) => norm((u.split('/').pop() || '').replace(/-/g, ' '));

  let candidati = links.filter(u => slugNorm(u) === qNorm);
  if (candidati.length === 1) return candidati[0];

  candidati = links.filter(u => slugNorm(u).includes(qNorm));
  if (candidati.length === 1) return candidati[0];

  const paroleRicerca = _paroleSealed(searchString);
  if (paroleRicerca.length === 0) return null;
  let migliore = null;
  let pari = false;
  for (const u of links) {
    const nomi = [(u.split('/').pop() || '').replace(/-/g, ' ')].concat((testiPerUrl && testiPerUrl.get(u)) || []);
    const inPiu = nomi.map(n => _paroleInPiuSealed(paroleRicerca, n)).filter(x => x !== null);
    if (inPiu.length === 0) continue;
    const p = Math.min(...inPiu);
    if (!migliore || p < migliore.p) { migliore = { u, p }; pari = false; }
    else if (p === migliore.p) pari = true;
  }
  if (migliore && !pari) return migliore.u;

  return null;
}

function _opzioniSealed(links, testiPerUrl) {
  const slugLabel = (u) => (u.split('/').pop() || '').replace(/-/g, ' ').trim();
  return links.map(u => ({ urlSingles: u, label: ((testiPerUrl && testiPerUrl.get(u)) || [])[0] || slugLabel(u) }));
}

function _setENumeroDaQuery(q) {
  const parti = String(q || '').trim().split(/\s+/).filter(Boolean);
  if (parti.length < 2) return null;
  const num = parti[parti.length - 1];
  const set = parti[parti.length - 2];
  if (!/^\d{1,4}$/.test(num)) return null;
  if (!/^[A-Za-z0-9]{2,6}$/.test(set) || !/[A-Za-z]/.test(set)) return null;
  return { set: set.toUpperCase(), numero: String(parseInt(num, 10)), nome: parti.slice(0, -2).join(' ') };
}

function _combaciaSetNumero(testo, sn) {
  const s = String(testo || '').toUpperCase().replace(/[\s-]+/g, '');
  return new RegExp('^' + sn.set + '0*' + sn.numero + '$').test(s);
}

function _nomeDaSlugNormalizzato(u) {
  const segs = (u.split('/').pop() || '').split('-');
  return segs.slice(0, -1).filter(s => !/^V\d+$/i.test(s)).join('').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function _sceltaPerSetNumero(links, sn) {
  const candidati = links.filter(u => _combaciaSetNumero((u.split('/').pop() || '').split('-').pop(), sn));
  if (candidati.length === 0) return null;
  if (!sn.nome) {
    const sigla = sn.set.toLowerCase();
    if (links.some(u => _nomeDaSlugNormalizzato(u).startsWith(sigla))) return null;
    if (candidati.length === 1) return { match: candidati[0] };
    return { disambiguation: true, opzioni: candidati };
  }
  if (candidati.length === 1) return { match: candidati[0] };
  const nomeNorm = sn.nome.toLowerCase().replace(/[^a-z0-9]/g, '');
  const perNome = candidati.filter(u => _nomeDaSlugNormalizzato(u).startsWith(nomeNorm));
  if (perNome.length === 1) return { match: perNome[0] };
  return { disambiguation: true, opzioni: perNome.length > 1 ? perNome : candidati };
}

function _codiceCompatto(testo) {
  return String(testo || '').toUpperCase().replace(/[\s-]+/g, '').replace(/0*(\d+)$/, '$1');
}

function _codiciDaQuery(q) {
  const parti = String(q || '').trim().split(/\s+/).filter(Boolean);
  if (parti.length < 2 || !/\d/.test(parti[parti.length - 1])) return [];
  const codici = [_codiceCompatto(parti.join(''))];
  if (parti.length > 3) codici.push(_codiceCompatto(parti.slice(-3).join('')));
  if (parti.length > 2) codici.push(_codiceCompatto(parti.slice(-2).join('')));
  return codici.filter(c => /[A-Z]/.test(c) && /\d/.test(c));
}

const RE_PREFISSO_PROMO = /^(?:BOO\d{0,2}|PPS\d{1,2}|WCD\d{2}|BA\d{2})$/i;

function _codicePromoDaQuery(q) {
  const parti = String(q || '').trim().split(/\s+/).filter(Boolean);
  for (let i = Math.max(0, parti.length - 3); i < parti.length - 1; i++) {
    if (RE_PREFISSO_PROMO.test(parti[i])) return _codiceCompatto(parti.slice(i).join(''));
  }
  return null;
}

function _codiceSenzaNumeroDaQuery(q) {
  const parti = String(q || '').trim().split(/\s+/).filter(Boolean);
  if (parti.length < 2 || !/^[A-Za-z]{2,6}$/.test(parti[parti.length - 1])) return null;
  return { codice: parti[parti.length - 1].toUpperCase(), nome: parti.slice(0, -1).join(' ') };
}

function _sceltaPerCodiceSenzaNumero(links, q) {
  const sn = _codiceSenzaNumeroDaQuery(q);
  if (!sn) return null;
  const candidati = links.filter(u => ((String(u).split(/[?#]/)[0].split('/').pop() || '').split('-').pop() || '').toUpperCase() === sn.codice);
  if (candidati.length === 0) return null;
  const nomeQ = sn.nome.toLowerCase().replace(/[^a-z0-9]/g, '');
  const perNome = nomeQ ? candidati.filter(u => _nomeDaSlugNormalizzato(u).startsWith(nomeQ)) : [];
  const unici = (l) => [...new Set(l.map(_linkInItaliano))];
  if (perNome.length) {
    const lista = unici(perNome);
    return lista.length === 1 ? { match: lista[0] } : { disambiguation: true, opzioni: lista };
  }
  const lista = unici(candidati);
  if (lista.length === 1) return { verificaCandidato: lista[0], tipoVerifica: 'nome', q };
  return { disambiguation: true, opzioni: lista };
}

// Battle Academy: "ba a42", "fuecoco a42", "cinderace v c60" senza l'anno (BA20/BA22/BA24).
function _battleAcademyDaQuery(q) {
  const parti = String(q || '').trim().split(/\s+/).filter(Boolean);
  if (parti.length < 2) return null;
  const numero = parti[parti.length - 1].toUpperCase();
  if (!/^[A-Z]\d{1,3}$/.test(numero)) return null;
  const resto = parti.slice(0, -1);
  const conBA = resto.some(t => /^BA$/i.test(t));
  const nome = resto.filter(t => !/^BA$/i.test(t)).join('').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!conBA && !nome) return null;
  return { numero: _codiceCompatto(numero), conBA, nome };
}

function _sceltaPerBattleAcademy(links, q) {
  const ba = _battleAcademyDaQuery(q);
  if (!ba) return null;
  const inBA = links.filter(u => /\/Products\/Singles\/Battle-Academy/i.test(String(u)));
  if (inBA.length === 0) return null;
  const reEsatto = new RegExp('^BA\\d{2}' + ba.numero + '$');
  let esatti = inBA.filter(u => reEsatto.test(_codiceDaSlugSingles(u)));
  // alcune carte BA20/BA22 hanno nello slug il codice del set originale (Cinderace-V-FST043):
  // il numero BA si vede solo sulla pagina, quindi restano candidate da verificare o da scegliere
  let senzaCodice = inBA.filter(u => !/^BA\d{2}/.test(_codiceDaSlugSingles(u)));
  if (ba.nome) {
    const perNome = (l) => l.filter(u => _nomeDaSlugNormalizzato(u).toUpperCase().startsWith(ba.nome));
    const e = perNome(esatti), sc = perNome(senzaCodice);
    if (e.length || sc.length) { esatti = e; senzaCodice = sc; }
    else senzaCodice = [];
  }
  const tutti = esatti.concat(senzaCodice);
  if (tutti.length === 0) return null;
  if (tutti.length === 1) {
    return esatti.length ? { match: esatti[0] } : { verificaCandidato: senzaCodice[0], tipoVerifica: 'nome', q };
  }
  return { disambiguation: true, opzioni: tutti };
}

function _codiceDaSlugSingles(u) {
  const segs = (String(u || '').split(/[?#]/)[0].split('/').pop() || '').split('-');
  const ultimo = segs.pop() || '';
  return _codiceCompatto(/[A-Za-z]/.test(ultimo) ? ultimo : (segs.pop() || '') + ultimo);
}

function _linkInItaliano(u) {
  return String(u || '').replace(/^(https:\/\/www\.cardmarket\.com)?\/[a-z]{2}\//, (m, base) => (base || '') + '/it/');
}

function _sceltaPerCodiceCompatto(links, q) {
  const parti = String(q || '').trim().split(/\s+/);
  if (parti.length === 2 && /^\d+$/.test(parti[1])) return null;
  const promo = _codicePromoDaQuery(q);
  for (const codice of promo ? [promo] : _codiciDaQuery(q)) {
    const trovati = [...new Set(links.filter(u => _codiceDaSlugSingles(u) === codice).map(_linkInItaliano))];
    if (trovati.length === 1) return { match: trovati[0] };
    if (trovati.length > 1) return { disambiguation: true, opzioni: trovati };
  }
  if (promo) return links.length > 1 ? { disambiguation: true, opzioni: links } : (links.length === 1 ? { verificaCandidato: links[0], tipoVerifica: 'codice', q } : { match: null });
  return null;
}

function _trovaMatchCartaSingola(links, searchString) {
  console.log('[CardSync] match check:', { query: searchString, links });
  const slugNorm = (u) => (u.split('/').pop() || '').toLowerCase().replace(/\s/g, '');

  const nomePortion = (u) => {
    const segs = (u.split('/').pop() || '').split('-');
    return (segs.length > 1 ? segs.slice(0, -1).join('') : segs[0] || '').toLowerCase();
  };
  const ultimoSegmento = (u) => {
    const segs = (u.split('/').pop() || '').split('-');
    return segs[segs.length - 1] || '';
  };

  const q = (searchString || '').trim();

  if (!q) {
    if (links.length === 1) return { match: links[0] };
    if (links.length > 1)   return { disambiguation: true, opzioni: links };
    return { match: null };
  }

  const isCodice = !/\s/.test(q);
  const qNorm = q.replace(/\s/g, '').toLowerCase();

  if (isCodice) {
    const exact = links.filter(u => slugNorm(u).endsWith(qNorm));
    if (exact.length === 1) return { match: exact[0] };
    if (exact.length > 1)   return { disambiguation: true, opzioni: exact };
    if (links.length > 1)   return { disambiguation: true, opzioni: links };
    if (links.length === 1) {
      return { verificaCandidato: links[0], tipoVerifica: 'codice', qNorm, q };
    }
    return { match: null };
  }

  const wq = _promoSenzaSerieDaQuery(q);
  if (wq) {
    const scelti = _linkPromoPerQuery(links, wq);
    if (scelti.length === 1) return { match: scelti[0] };
    if (scelti.length > 1) return { disambiguation: true, opzioni: scelti };
    return { match: null };
  }

  const esitoBA = _sceltaPerBattleAcademy(links, q);
  if (esitoBA) return esitoBA;

  const esitoCodice = _sceltaPerCodiceCompatto(links, q);
  if (esitoCodice) return esitoCodice;

  const sn = _setENumeroDaQuery(q);
  if (sn) {
    const esitoSet = _sceltaPerSetNumero(links, sn);
    if (esitoSet) return esitoSet;
  }

  const parts = sn && sn.nome ? sn.nome.split(/\s+/).concat(sn.numero) : q.split(/\s+/);
  const numPart = parts.find(p => /^\d+$/.test(p));
  const textParts = parts.filter(p => !/^\d+$/.test(p)).map(p => p.toLowerCase());
  const siglaSoloCodice = sn && !sn.nome && !links.some(u => _nomeDaSlugNormalizzato(u) === sn.set.toLowerCase());
  if (numPart && textParts.length > 0 && !siglaSoloCodice) {
    const numNorm = numPart.replace(/^0+/, '') || numPart;
    const textNorm = textParts.join('');
    const byNameAndNum = links.filter(u => {
      const hasText = nomePortion(u).includes(textNorm);
      const hasNum = _numeroDaUltimoSegmento(ultimoSegmento(u)) === (String(parseInt(numNorm, 10)) || numNorm);
      return hasText && hasNum;
    });
    if (byNameAndNum.length === 1) return { match: byNameAndNum[0] };
    if (byNameAndNum.length > 1)   return { disambiguation: true, opzioni: byNameAndNum };
  }
  const esitoSenzaNumero = _sceltaPerCodiceSenzaNumero(links, q);
  if (esitoSenzaNumero) return esitoSenzaNumero;
  if (links.length > 1) return { disambiguation: true, opzioni: links };
  if (links.length === 1 && numPart && textParts.length > 0) {
    return { verificaCandidato: links[0], tipoVerifica: 'nomeNumero', numNorm: numPart.replace(/^0+/, '') || numPart, textNorm: textParts.join(''), q };
  }
  return { match: null };
}

function _paginaCombaciaConQuery(q, nome, codice, slug) {
  q = String(q || '').trim();
  if (!q) return true;
  const codiceNorm = String(codice || '').toUpperCase().replace(/\s+/g, '');
  const slugUp = String(slug || '').toUpperCase();
  const ultimoSeg = slugUp.split('-').pop() || '';

  if (!/\s/.test(q)) {
    const qUp = q.toUpperCase();
    if (codiceNorm) return codiceNorm === qUp || codiceNorm.endsWith(qUp) || qUp.endsWith(codiceNorm);
    return slugUp.replace(/\s/g, '').endsWith(qUp);
  }

  const wq = _promoSenzaSerieDaQuery(q);
  if (wq) {
    const m = codiceNorm.match(/^(WCD|PPS|BOO)(\d{0,2})(.*?)0*(\d+)$/);
    if (!m || m[1] !== wq.prefisso || m[4] !== wq.numero) return false;
    const annoPagina = m[1] === 'PPS' ? String(parseInt(m[2], 10)) : m[2];
    return (!wq.anno || annoPagina === wq.anno) && (!wq.set || m[3] === wq.set);
  }

  const promo = _codicePromoDaQuery(q);
  if (promo) return !!codiceNorm && _codiceCompatto(codiceNorm) === promo;

  const ba = _battleAcademyDaQuery(q);
  const mBA = String(codice || '').toUpperCase().trim().match(/^BA\d{2}\s*([A-Z]{1,3}\s*\d{0,3})$/);
  if (ba && mBA && _codiceCompatto(mBA[1]) === ba.numero) {
    if (!ba.nome) return ba.conBA;
    const nomePagina = String(nome || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    const nomeSlug = slugUp.split('-').filter(x => !/^V\d+$/.test(x)).slice(0, -1).join('').replace(/[^A-Z0-9]/g, '');
    return nomePagina.includes(ba.nome) || nomeSlug.includes(ba.nome);
  }
  if (codiceNorm && _codiciDaQuery(q).includes(_codiceCompatto(codiceNorm))) return true;

  const senzaNumero = _codiceSenzaNumeroDaQuery(q);
  if (senzaNumero && codiceNorm === senzaNumero.codice) {
    const nomeQ = senzaNumero.nome.toUpperCase().replace(/[^A-Z0-9]/g, '');
    const nomePagina = String(nome || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    const nomeSlug = slugUp.split('-').slice(0, -1).filter(x => !/^V\d+$/.test(x)).join('').replace(/[^A-Z0-9]/g, '');
    return !!nomeQ && (nomePagina.includes(nomeQ) || nomeSlug.includes(nomeQ));
  }

  const sn = _setENumeroDaQuery(q);
  if (sn && _combaciaSetNumero(codiceNorm || ultimoSeg, sn)) return true;

  const parti = sn && sn.nome ? sn.nome.split(/\s+/).concat(sn.numero) : q.split(/\s+/);
  const numPart = parti.find(p => /^\d+$/.test(p));
  const textNorm = parti.filter(p => !/^\d+$/.test(p)).join('').toUpperCase();
  if (!numPart || !textNorm) return false;
  const numNorm = String(parseInt(numPart, 10));
  // dal codice con gli spazi: "MCD16 8" → 8 (senza spazi sarebbe 168)
  const mNumPagina = String(codice || '').trim().match(/(\d+)$/);
  if (mNumPagina) {
    const nomePaginaNorm = String(nome || '').toUpperCase().replace(/\s+/g, '');
    return String(parseInt(mNumPagina[1], 10)) === numNorm && nomePaginaNorm.includes(textNorm);
  }
  const segs = slugUp.split('-');
  const nomeSlug = segs.length > 1 ? segs.slice(0, -1).join('') : (segs[0] || '');
  return nomeSlug.includes(textNorm) && _numeroDaUltimoSegmento(ultimoSeg) === numNorm;
}

async function _verificaCandidatoSuPagina(url, tipoVerifica, dati) {
  const html = await _fetchHtml(url);
  if (!html || typeof html !== 'string') return { ok: false };
  if (_ePaginaListaSingles(url, _testoH1DaHtml(html))) return { ok: false };
  const { nome, codice } = _estraiNomeDaHtml(html);
  const ok = _paginaCombaciaConQuery(dati.q, nome, codice, url.split('/').pop() || '');
  return { ok, html, nome, codice };
}

// opzioni.integrita (dalla 5.77): integrità del prodotto ('sigillato_integro', 'sigillo_danneggiato',
// 'confezione_danneggiata', 'aperto_non_sealed') → prezzo della prima offerta con quell'integrità
// (dal commento; caricando fino a 4 pagine in più), minimoCm = prima offerta valida; nel risultato
// integrita: 'trovata' | 'non-trovata'.
const _INTEGRITA_SEALED = ['sigillato_integro', 'sigillo_danneggiato', 'confezione_danneggiata', 'aperto_non_sealed'];
function _leggiPrezzoSealed(urlProdotto, tabIdEsterno, requestId = null, opzioni = {}) {
  const integritaCercata = opzioni && _INTEGRITA_SEALED.includes(opzioni.integrita) ? opzioni.integrita : null;
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;
      let ultimaPaginaSenzaOfferte = null;

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        _rimuoviAttesaCf(tabId);
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      async function chiudiPerTempo() {
        if (!ultimaPaginaSenzaOfferte) { chiudi({ prezzo: null, immagine: null }); return; }
        const { immagine, nomeDom } = ultimaPaginaSenzaOfferte;
        chiudi({ prezzo: null, immagine: await _immagineAUrlDati(immagine || null), nome: nomeDom || null });
      }

      function tentaLettura() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        _assicuraSharedInScheda(tabId).then(() => { if (caricata) leggiNellaScheda(); });
      }

      function leggiNellaScheda() {
        chrome.scripting.executeScript({
          target: { tabId },
          args: [RATE_LIMIT_MARKERS, CF_TITLES, integritaCercata],
          func: async (RATE_LIMIT_MARKERS, CF_TITLES, integritaCercata) => {
            const testo = (document.title + ' ' + (document.body?.innerText?.slice(0, 2000) || '')).toLowerCase();
            if (RATE_LIMIT_MARKERS.some(m => testo.includes(m))) return { rateLimited: true };
            const title = document.title.toLowerCase();
            if (CF_TITLES.some(t => title.includes(t)) || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || ''))))
              return { cloudflare: true };
            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            if (immagine && !immagine.includes('product-images')) immagine = null;
            if (!immagine) {
              const imgReale = Array.from(document.querySelectorAll('img'))
                .map(i => i.src)
                .find(src => src && src.includes('product-images'));
              immagine = imgReale || null;
            }
            let nomeDom = null;
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              nomeDom = clone.textContent.trim() || null;
            }
            const selettori = ['.price-container .fw-bold', '.col-offer-price .fw-bold', '[class*="price"] .fw-bold', '.color-primary.fw-bold'];
            const righe = Array.from(document.querySelectorAll('.article-row'));
            if (righe.length === 0) return { inAttesa: true, immagine, nomeDom };
            const params = new URLSearchParams(window.location.search);
            const idLanguage = params.get('language') || params.get('idLanguage') || null;
            const valida = (r) => typeof window.rigaSoddisfaFiltriShared === 'function'
              ? window.rigaSoddisfaFiltriShared(r, { idLanguage, ignoraVarianti: true })
              : true;
            // integrità del prodotto (dalla 5.77): una lettura sola per pagina (il controllo si ripete ogni 600 ms)
            if (integritaCercata && typeof window.leggiOffertaIntegritaShared === 'function' && righe.some(valida)) {
              const esiti = window.__bindexEsitiIntegrita || (window.__bindexEsitiIntegrita = {});
              if (esiti[integritaCercata]) return { ...esiti[integritaCercata], immagine, nomeDom };
              if (window.__bindexIntegritaInCorso) return null;
              window.__bindexIntegritaInCorso = true;
              const e = await window.leggiOffertaIntegritaShared(valida, integritaCercata);
              esiti[integritaCercata] = {
                prezzo: e.prezzoIntegrita !== null ? e.prezzoIntegrita : e.minimo,
                minimoCm: e.minimo,
                integrita: e.prezzoIntegrita !== null ? 'trovata' : 'non-trovata',
              };
              window.__bindexIntegritaInCorso = false;
              return { ...esiti[integritaCercata], immagine, nomeDom };
            }
            for (const riga of righe.filter(valida)) {
              for (const sel of selettori) {
                const el = riga.querySelector(sel);
                if (el && el.textContent.includes('€')) {
                  const m = el.textContent.trim().match(/([\d,.]+)\s*€/);
                  if (m) {
                    const p = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
                    return { prezzo: isNaN(p) ? null : p, immagine, nomeDom };
                  }
                }
              }
            }
            return { prezzo: null, immagine, nomeDom };
          },
        }, async (res) => {
          if (chrome.runtime.lastError) return;
          const val = res?.[0]?.result;
          if (val === null || val === undefined) return;
          if (val.rateLimited) { chiudi({ prezzo: null, rateLimited: true }); return; }
          if (val.inAttesa) { ultimaPaginaSenzaOfferte = val; return; }
          if (val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'sealed');
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi({ prezzo: null, cloudflareTimeout: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: _statoCloudflareNellaScheda,
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ prezzo: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = _scadenzaLettura(() => !caricata, chiudiPerTempo, (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }
          chiudi({ prezzo: val.prezzo ?? null, immagine: await _immagineAUrlDati(val.immagine || null), nome: val.nomeDom || null,
            ...(val.integrita ? { minimoCm: typeof val.minimoCm === 'number' ? val.minimoCm : null, integrita: val.integrita } : {}) });
        });
      }

      function onLoad(id, info) {
        if (id === tabId && info.status === 'complete') { caricata = true; }
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = integritaCercata
        ? setTimeout(chiudiPerTempo, _ATTESA_LETTURA_SIGILLATA_MS)
        : _scadenzaLettura(() => !caricata, chiudiPerTempo, (t) => { timeout = t; });
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlProdotto }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlProdotto, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlProdotto, active: false }, avviaCon);
    }
  });
}

async function _leggiNomeSealedFetch(urlNome, lingua) {
  const html = await _fetchHtml(urlNome);
  if (!html && _fetchHtmlEraRateLimit(urlNome)) return { urlProdotto: null, nome: null, rateLimited: true };
  if (!html) return { urlProdotto: null, nome: null, fetchFailed: true };
  const lower = html.toLowerCase();
  if (isPaginaRateLimit(lower)) return { urlProdotto: null, nome: null, rateLimited: true };
  const isCF = _htmlEChallengeCloudflare(lower);
  if (isCF) return { urlProdotto: null, nome: null, cloudflare: true };

  if (!urlNome.includes('/Search')) {
    const { nome } = _estraiNomeDaHtml(html);
    const immagine = await _estraiImmagineDaHtml(html);
    const urlProdotto = _aggiungiLinguaSealed(urlNome.split('?')[0], lingua);
    return { urlProdotto, nome: _rimuoviCategoriaDalNome(nome, urlProdotto), immagine };
  }

  const links = _estraiLinkSealed(html);
  if (links.length === 0) return { urlProdotto: null, nome: null };

  let urlProdottoBase;
  if (links.length === 1) {
    urlProdottoBase = links[0];
  } else {
    const searchString = (() => {
      try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; }
    })();
    const testi = _testiLinkSealed(html);
    const match = _trovaMatchSealed(links, searchString, testi);
    if (!match) {
      return { urlProdotto: null, nome: null, disambiguation: true, opzioni: _opzioniSealed(links, testi) };
    }
    urlProdottoBase = match;
  }

  let htmlProd = await _fetchHtml(urlProdottoBase);
  if (htmlProd && _htmlEChallengeCloudflare(htmlProd.toLowerCase())) htmlProd = null;
  const { nome } = htmlProd ? _estraiNomeDaHtml(htmlProd) : { nome: null };
  const immagine = htmlProd ? await _estraiImmagineDaHtml(htmlProd) : null;
  const urlProdotto = _aggiungiLinguaSealed(urlProdottoBase, lingua);
  return { urlProdotto, nome: _rimuoviCategoriaDalNome(nome, urlProdotto), immagine };
}

function _rimuoviCategoriaDalNome(nome, urlProdotto) {
  if (!nome || !urlProdotto) return nome;
  let path;
  try { path = new URL(urlProdotto).pathname; } catch (_) { return nome; }
  const segmentoCategoria = (path.split('/Products/')[1] || '').split('/')[0] || '';
  const categoriaLabel = segmentoCategoria.replace(/-/g, ' ').trim().toUpperCase();
  if (!categoriaLabel) return nome;
  const escaped = categoriaLabel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp('(^|\\s)' + escaped + '(\\s|$)', 'i');
  return nome.replace(re, ' ').replace(/\s+/g, ' ').trim() || nome;
}

function _aggiungiLinguaSealed(urlProdotto, lingua) {
  if (!urlProdotto) return urlProdotto;
  let url = urlProdotto
    .replace(/[?&]language=[^&]*/g, '')
    .replace(/[?&]idLanguage=[^&]*/g, '')
    .replace(/\?&/, '?').replace(/&&+/g, '&').replace(/[?&]$/, '');
  const idLingua = LINGUA_MAP_SHARED[(lingua || 'IT').toUpperCase().trim()];
  if (!idLingua) return url;
  return url + (url.includes('?') ? '&' : '?') + 'language=' + idLingua;
}

// opzioni.integrita (dalla 5.77): prezzo secondo l'integrità del prodotto (vedi _leggiPrezzoSealed)
async function _leggiNomeSealedDaCardmarket(urlNome, lingua, _tentativo = 0, tabIdEsterno = null, requestId = null, opzioni = {}) {
  if (_tentativo === 0) _contaCartaCodaPerPrezzi();
  const saltaLetturaDiretta = _letturaDirettaDaSaltare();
  const fase1 = saltaLetturaDiretta ? { fetchFailed: true } : await _leggiNomeSealedFetch(urlNome, lingua);
  if (!saltaLetturaDiretta && (fase1.fetchFailed || fase1.cloudflare)) _segnaLetturaDirettaRespinta();

  if (fase1.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
  if (fase1.disambiguation) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: true, opzioni: fase1.opzioni || [] };

  const zeroRisultatiDaFetch = !fase1.cloudflare && !fase1.fetchFailed && !fase1.urlProdotto;

  if (fase1.cloudflare || fase1.fetchFailed || zeroRisultatiDaFetch) {
    const viaTab = await _risolviProdottoSealedTab(urlNome, lingua, tabIdEsterno, requestId);
    if (tabIdEsterno != null && viaTab && viaTab.tabId && viaTab.tabId !== tabIdEsterno) {
      await _salvaWorkerTabId('sealed', viaTab.tabId);
      tabIdEsterno = viaTab.tabId;
    }

    if (viaTab.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
    if (viaTab.disambiguation) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: true, opzioni: viaTab.opzioni || [] };

    if (viaTab.urlProdotto) {
      const risPrez = await _leggiPrezzoSealed(viaTab.urlProdotto, tabIdEsterno, requestId, opzioni);
      if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
        await _salvaWorkerTabId('sealed', risPrez.tabId);
        tabIdEsterno = risPrez.tabId;
      }
      if (risPrez.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
      const nomeFinale = _rimuoviCategoriaDalNome(viaTab.nome || risPrez.nome, viaTab.urlProdotto);
      return { nome: nomeFinale, urlProdotto: viaTab.urlProdotto, prezzo: risPrez.prezzo ?? null, immagine: viaTab.immagine || risPrez.immagine || null,
        minimoCm: risPrez.minimoCm ?? null, integrita: risPrez.integrita || null };
    }

    if (_tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 3000 * (_tentativo + 1)));
      return _leggiNomeSealedDaCardmarket(urlNome, lingua, _tentativo + 1, tabIdEsterno, requestId, opzioni);
    }
    return { nome: null, urlProdotto: null, prezzo: null, immagine: null };
  }

  const risPrez = await _leggiPrezzoSealed(fase1.urlProdotto, tabIdEsterno, requestId, opzioni);
  if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
    await _salvaWorkerTabId('sealed', risPrez.tabId);
  }
  if (risPrez.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };

  const nomeFinale = _rimuoviCategoriaDalNome(fase1.nome || risPrez.nome, fase1.urlProdotto);
  return { nome: nomeFinale, urlProdotto: fase1.urlProdotto, prezzo: risPrez.prezzo ?? null, immagine: fase1.immagine || risPrez.immagine || null,
    minimoCm: risPrez.minimoCm ?? null, integrita: risPrez.integrita || null };
}

function _risolviProdottoSealedTab(urlNome, lingua, tabIdEsterno = null, requestId = null) {
  const _searchStringOriginale = (() => {
    try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; }
  })();
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        _rimuoviAttesaCf(tabId);
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function tentaLettura() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES, RATE_LIMIT_MARKERS],
          func: async (CF_TITLES, RATE_LIMIT_MARKERS) => {
            const testo = (document.title + ' ' + (document.body?.innerText?.slice(0, 2000) || '')).toLowerCase();
            if (RATE_LIMIT_MARKERS.some(m => testo.includes(m))) return { rateLimited: true };

            const title = document.title.toLowerCase();
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')));
            if (isCloudflare) return { cloudflare: true };

            const path = window.location.pathname;

            if (path.includes('/Products/') && !path.includes('/Products/Search')) {
              const h1 = document.querySelector('h1');
              let nome = null;
              if (h1) {
                const clone = h1.cloneNode(true);
                clone.querySelectorAll('span').forEach(s => s.remove());
                nome = clone.textContent.trim();
              }
              const metaImg = document.querySelector('meta[property="og:image"]');
              let immagine = metaImg ? metaImg.getAttribute('content') : null;
              if (immagine && !immagine.includes('product-images')) immagine = null;
              if (!immagine) {
                const imgReale = Array.from(document.querySelectorAll('img'))
                  .map(i => i.src)
                  .find(src => src && src.includes('product-images'));
                immagine = imgReale || null;
              }
              return { urlProdotto: location.origin + path, nome, immagine, _path: path };
            }

            const prodotti = new Map();
            Array.from(document.querySelectorAll('a[href*="/Products/"]'))
              .filter(a => !a.pathname.includes('/Products/Singles/'))
              .filter(a => (a.pathname.split('/Products/')[1] || '').split('/').filter(Boolean).length >= 2)
              .forEach(a => {
                const url = a.origin + a.pathname;
                const pezzi = [];
                const giro = document.createTreeWalker(a, NodeFilter.SHOW_TEXT);
                while (giro.nextNode()) pezzi.push(giro.currentNode.nodeValue);
                const testo = pezzi.join(' ').replace(/\s+/g, ' ').trim();
                if (!prodotti.has(url)) prodotti.set(url, []);
                if (testo && !prodotti.get(url).includes(testo)) prodotti.get(url).push(testo);
              });

            if (prodotti.size === 0) return undefined;
            return {
              ricerca: true,
              prodotti: Array.from(prodotti, ([url, testi]) => ({ url, testi })),
              searchString: new URLSearchParams(window.location.search).get('searchString') || '',
            };
          },
        }, async (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          if (val === undefined || val === null) return;

          if (val.rateLimited) { chiudi({ urlProdotto: null, nome: null, rateLimited: true }); return; }

          if (val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'sealed');
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi({ urlProdotto: null, nome: null, cloudflareTimeout: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: _statoCloudflareNellaScheda,
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ urlProdotto: null, nome: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlProdotto: null, nome: null }), (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          if (val.disambiguation) { chiudi({ urlProdotto: null, nome: null, disambiguation: true, opzioni: val.opzioni }); return; }

          if (val.ricerca) {
            const links = val.prodotti.map(p => p.url);
            const testi = new Map(val.prodotti.map(p => [p.url, (p.testi || []).map(_nomeSealedDaTestoLink).filter(Boolean)]));
            const scelto = _trovaMatchSealed(links, val.searchString || _searchStringOriginale, testi);
            if (!scelto) { chiudi({ urlProdotto: null, nome: null, disambiguation: true, opzioni: _opzioniSealed(links, testi) }); return; }
            const urlScelto = _aggiungiLinguaSealed(scelto, lingua);
            chiudi({ urlProdotto: urlScelto, nome: null, immagine: null });
            return;
          }

          const urlConLingua = _aggiungiLinguaSealed(val.urlProdotto, lingua);
          chiudi({
            urlProdotto: urlConLingua,
            nome: _rimuoviCategoriaDalNome(val.nome, urlConLingua),
            immagine: await _immagineAUrlDati(val.immagine || null),
          });
        });
      }

      function onLoad(id, info) { if (id === tabId && info.status === 'complete') caricata = true; }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlProdotto: null, nome: null }), (t) => { timeout = t; });
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlNome }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
    }
  });
}

function _estraiLinkSingles(html) {
  const re = /href="(?:https:\/\/www\.cardmarket\.com)?(\/[a-z]{2}\/[^/]+\/Products\/Singles\/[^"?]+)"/gi;
  const trovati = new Set();
  let m;
  while ((m = re.exec(html)) !== null) {
    const path = m[1].split('/Products/Singles/')[1] || '';
    if (path.split('/').filter(Boolean).length >= 2) {
      trovati.add('https://www.cardmarket.com' + m[1]);
    }
  }
  return Array.from(trovati);
}

const PLACEHOLDER_IMG_MARKERS = ['static.cardmarket.com/img/logos/'];

function _eImmagineSegnaposto(url) {
  if (!url) return true;
  if (!url.includes('product-images')) return true;
  return PLACEHOLDER_IMG_MARKERS.some(m => url.includes(m));
}

async function _estraiImmagineDaHtml(html) {
  const m =
    html.match(/property="og:image"\s+content="(https:\/\/[^"]*cardmarket[^"]*\.(?:jpg|png|webp|jpeg))"/) ||
    html.match(/content="(https:\/\/[^"]*cardmarket[^"]*\.(?:jpg|png|webp|jpeg))"\s+property="og:image"/) ||
    html.match(/property="og:image"\s+content="(https:\/\/product-images[^"]+)"/) ||
    html.match(/content="(https:\/\/product-images[^"]+)"\s+property="og:image"/);
  let url = m ? (m[1] || m[3] || null) : null;

  if (_eImmagineSegnaposto(url)) {
    const fallback = html.match(/https:\/\/product-images\.s3\.cardmarket\.com\/[^"'\s)]+\.(?:jpg|png|webp|jpeg)/i);
    url = fallback ? fallback[0] : null;
  }

  if (_eImmagineSegnaposto(url)) return null;
  return _immagineAUrlDati(url);
}

const RE_H1_LISTA_SINGLES = /^(?:singole|singles|einzelkarten|cartas sueltas|cartes à l'unité|cartas avulsas)(?:\s|$)|\s(?:singole|singles|einzelkarten)$/i;

function _ePaginaListaSingles(url, testoH1) {
  const idx = (url || '').indexOf('/Singles/');
  if (idx !== -1) {
    const resto = url.slice(idx + '/Singles/'.length).split(/[?#]/)[0];
    if (resto.split('/').filter(Boolean).length < 2) return true;
  }
  return RE_H1_LISTA_SINGLES.test((testoH1 || '').trim());
}

function _testoH1DaHtml(html) {
  const m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (!m) return '';
  return m[1].replace(/<span[^>]*>[\s\S]*?<\/span>/gi, '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
}

function _opzioniDaLinkSingles(links, urlPartenza) {
  const idx = (urlPartenza || '').indexOf('/Singles/');
  const segs = idx !== -1 ? urlPartenza.slice(idx + '/Singles/'.length).split(/[?#]/)[0].split('/').filter(Boolean) : [];
  let scelti = links;
  if (segs.length >= 2) {
    const nomeCarta = (segs[segs.length - 1].split('-')[0] || '').toLowerCase();
    const filtrati = nomeCarta ? links.filter(u => (u.split('/').pop() || '').toLowerCase().startsWith(nomeCarta)) : [];
    if (filtrati.length > 0) scelti = filtrati;
  }
  return _opzioniDaLink(scelti);
}

function _opzioniDaLink(links) {
  const slugLabel = (u) => (u.split('/').pop() || '')
    .replace(/-V(\d+)-/gi, ' ★V$1 ').replace(/-/g, ' ').trim();
  return links.map(u => ({ urlSingles: u, label: slugLabel(u) }));
}

function _estraiNomeDaHtml(html) {
  const m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (!m) return { nome: null, codice: null };
  return _nomeECodiceDaTestoH1(m[1].replace(/<span[^>]*>[\s\S]*?<\/span>/gi, '').replace(/<[^>]+>/g, ''));
}

function _nomeECodiceDaTestoH1(testoGrezzo) {
  const testo = String(testoGrezzo || '').trim();
  const ultimaParentesiIdx = testo.lastIndexOf('(');
  if (ultimaParentesiIdx === -1) return { nome: testo.trim(), codice: null };
  const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')'));
  const codice = codiceRaw ? codiceRaw.trim().toUpperCase() : null;
  const nomePre = testo.slice(0, ultimaParentesiIdx).trim();
  if (!nomePre) {
    const chiusaIdx = testo.lastIndexOf(')');
    const nomePost = chiusaIdx !== -1 ? testo.slice(chiusaIdx + 1).trim() : null;
    if (!nomePost) {
      const primaParentesiIdx = testo.indexOf('(');
      const nomeAnte = primaParentesiIdx > 0 ? testo.slice(0, primaParentesiIdx).trim() : null;
      return { nome: nomeAnte || null, codice };
    }
    return { nome: nomePost, codice };
  }
  return { nome: nomePre, codice };
}

async function _risolviSinglesENomeFetch(urlNome, oloType) {
  const html = await _fetchHtml(urlNome);
  console.log('[CardSync] fetch statico:', { urlNome, htmlRicevuto: !!html, lunghezza: html ? html.length : 0 });
  if (!html && _fetchHtmlEraRateLimit(urlNome)) return { urlSingles: null, nome: null, codice: null, rateLimited: true };
  if (!html) return { urlSingles: null, nome: null, codice: null, fetchFailed: true };

  const lower = html.toLowerCase();
  if (isPaginaRateLimit(lower)) return { urlSingles: null, nome: null, codice: null, rateLimited: true };
  const isCF = _htmlEChallengeCloudflare(lower);
  console.log('[CardSync] cloudflare rilevato su fetch statico?', isCF);
  if (isCF) return { urlSingles: null, nome: null, codice: null, cloudflare: true };

  if (urlNome.includes('/Singles/')) {
    if (_ePaginaListaSingles(urlNome, _testoH1DaHtml(html))) {
      console.log('[CardSync] link Cardmarket non più valido (porta alla lista dell\'espansione):', urlNome);
      return { urlSingles: null, nome: null, codice: null, linkNonValido: true };
    }
    const { nome, codice } = _estraiNomeDaHtml(html);
    const immagine = await _estraiImmagineDaHtml(html);
    return { urlSingles: urlNome.split('?')[0], nome, codice, immagine };
  }

  const searchStringRedirect = (() => { try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch(_) { return ''; } })();
  const ogUrl = (html.match(/<meta[^>]+property="og:url"[^>]+content="([^"?#]+)/i) || html.match(/<meta[^>]+content="([^"?#]+)"[^>]+property="og:url"/i) || [])[1] || '';
  if (ogUrl.includes('/Products/Singles/') && !_ePaginaListaSingles(ogUrl, _testoH1DaHtml(html))) {
    const { nome, codice } = _estraiNomeDaHtml(html);
    if (searchStringRedirect && !_paginaCombaciaConQuery(searchStringRedirect, nome, codice, ogUrl.split('/').pop() || '')) {
      return { urlSingles: null, nome: null, codice: null, nonTrovata: true };
    }
    const immagine = await _estraiImmagineDaHtml(html);
    return { urlSingles: _linkInItaliano(ogUrl), nome, codice, immagine };
  }

  const links = _estraiLinkSingles(html);
  console.log('[CardSync] link estratti dalla pagina di ricerca:', links);
  if (links.length === 0) return { urlSingles: null, nome: null, codice: null, nonTrovata: true };

  const slugLabel = (u) => (u.split('/').pop() || '')
    .replace(/-V(\d+)-/gi, ' ★V$1 ').replace(/-/g,' ').trim();
  const toOpzione = (u) => ({ urlSingles: u, label: slugLabel(u) });

  const searchString = (() => { try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch(_) { return ''; } })();
  const esito = _trovaMatchCartaSingola(links, searchString);
  if (esito.disambiguation) {
    return { urlSingles: null, nome: null, codice: null, disambiguation: true, opzioni: esito.opzioni.map(toOpzione) };
  }

  if (esito.verificaCandidato) {
    const verifica = await _verificaCandidatoSuPagina(esito.verificaCandidato, esito.tipoVerifica, esito);
    if (!verifica.ok) {
      return { urlSingles: null, nome: null, codice: null, nonTrovata: !!verifica.html };
    }
    const immagine = verifica.html ? await _estraiImmagineDaHtml(verifica.html) : null;
    return { urlSingles: esito.verificaCandidato, nome: verifica.nome, codice: verifica.codice, immagine };
  }

  if (!esito.match) {
    return { urlSingles: null, nome: null, codice: null, nonTrovata: true };
  }
  return { urlSingles: esito.match, nome: null, codice: null, immagine: null };
}

function _decidiRisoluzioneDaScheda(val, searchStringOriginale, eraRicerca, urlNome) {
  if (val.tipo === 'singles') {
    if (_ePaginaListaSingles(val.url, val.testoH1)) {
      if (!eraRicerca) return { linkNonValido: true };
      return { disambiguation: true, opzioni: _opzioniDaLinkSingles(val.hrefs || [], urlNome) };
    }
    const { nome, codice } = _nomeECodiceDaTestoH1(val.testoH1);
    if (eraRicerca && searchStringOriginale
      && !_paginaCombaciaConQuery(searchStringOriginale, nome, codice, val.url.split('/').pop() || '')) {
      return { urlSingles: null };
    }
    return { urlSingles: val.url, nome, codice };
  }
  const q = val.searchString || searchStringOriginale;
  const esito = _trovaMatchCartaSingola(val.hrefs || [], q);
  if (esito.disambiguation) return { disambiguation: true, opzioni: _opzioniDaLink(esito.opzioni) };
  if (esito.verificaCandidato) return { urlSingles: esito.verificaCandidato, nome: null, verificaDopo: q };
  if (esito.match) return { urlSingles: esito.match, nome: null };
  return { urlSingles: null };
}

function _risolviNomeEPrezzoUnicaTab(urlNome, lingua, condizione, oloType = '', firstEd = false, tabIdEsterno = null, requestId = null) {
  const _searchStringOriginale = (() => {
    try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; }
  })();
  const _eraRicerca = urlNome.includes('/Search');

  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let fase = 'risoluzione';
      let caricata = false;
      let pollTimer, timeout;
      let risolto = {};
      let verificaDopoPrezzo = null;
      let variantiRitentateSenzaFiltro = false;
      let immagineSenzaOfferte = null;

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        _rimuoviAttesaCf(tabId);
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function passaAFasePrezzo(urlSingles, ignoraVarianti) {
        const base = costruisciUrlFiltrato(urlSingles, lingua, condizione);
        const urlConFiltri = ignoraVarianti ? base : _appendVariantParams(base, oloType, firstEd);
        fase = 'prezzo';
        caricata = false;
        clearTimeout(timeout);
        chrome.tabs.update(tabId, { url: urlConFiltri }, () => {
          if (chrome.runtime.lastError) {
            chiudi({ ...risolto, prezzo: null, immagine: null });
          }
        });
        timeout = _scadenzaLettura(() => !caricata, () => chiudi(verificaDopoPrezzo
          ? { urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }
          : { ...risolto, prezzo: null, immagine: immagineSenzaOfferte }), (t) => { timeout = t; });
      }

      function tentaLetturaRisoluzione() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES, RATE_LIMIT_MARKERS],
          func: (CF_TITLES, RATE_LIMIT_MARKERS) => {
            const title = document.title.toLowerCase();
            const corpoTesto = (title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (RATE_LIMIT_MARKERS.some(m => corpoTesto.includes(m))) {
              return { rateLimited: true };
            }
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')));
            if (isCloudflare) return { cloudflare: true };

            const path = window.location.pathname;
            const hrefs = Array.from(new Set(Array.from(document.querySelectorAll('a[href*="/Singles/"]'))
              .map(a => { try { const u = new URL(a.href); return u.origin + u.pathname; } catch (_) { return null; } })
              .filter(u => {
                if (!u) return false;
                const i = u.indexOf('/Singles/');
                return i !== -1 && u.slice(i + '/Singles/'.length).split('/').filter(Boolean).length >= 2;
              })));

            if (path.includes('/Singles/')) {
              const h1 = document.querySelector('h1');
              if (!h1) return undefined;
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              return { tipo: 'singles', url: location.origin + path, testoH1: clone.textContent.replace(/\s+/g, ' ').trim(), hrefs };
            }
            if (hrefs.length === 0) return undefined;
            return { tipo: 'ricerca', hrefs, searchString: new URLSearchParams(window.location.search).get('searchString') || '' };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          if (val === undefined || val === null) return;

          if (val && val.rateLimited) {
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, rateLimited: true });
            return;
          }

          if (val && val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'carte');
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) {
                chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, cloudflareTimeout: true });
                return;
              }
              chrome.scripting.executeScript({
                target: { tabId },
                args: [CF_TITLES],
                func: _statoCloudflareNellaScheda,
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(() => {
                    if (fase === 'risoluzione') tentaLetturaRisoluzione();
                    else tentaLetturaPrezzo();
                  }, 600);
                  timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }), (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else {
                  setTimeout(aspettaRisoluzione, 1500);
                }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          const decisione = _decidiRisoluzioneDaScheda(val, _searchStringOriginale, _eraRicerca, urlNome);
          if (decisione.disambiguation || decisione.linkNonValido) {
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, ...decisione });
            return;
          }
          if (!decisione.urlSingles) {
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, nonTrovata: true });
            return;
          }

          risolto = { urlSingles: decisione.urlSingles, nome: decisione.nome, codice: decisione.codice || null };
          verificaDopoPrezzo = decisione.verificaDopo || null;
          passaAFasePrezzo(decisione.urlSingles);
        });
      }

      function tentaLetturaPrezzo() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        _assicuraSharedInScheda(tabId).then(() => { if (caricata) leggiPrezzoNellaScheda(); });
      }

      function leggiPrezzoNellaScheda() {
        chrome.scripting.executeScript({
          target: { tabId },
          args: [RATE_LIMIT_MARKERS],
          func: async (RATE_LIMIT_MARKERS) => {
            const _testoPagina = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (RATE_LIMIT_MARKERS.some(m => _testoPagina.includes(m))) {
              return { rateLimited: true };
            }

            const params = new URLSearchParams(window.location.search);
            const idLanguage   = params.get('language') || params.get('idLanguage') || null;
            const minCondition = (params.get('minCondition') || '').toLowerCase() || null;
            const isReverseHolo = params.get('isReverseHolo') === 'Y';
            const isFirstEd = params.get('isFirstEd') === 'Y';

            function rigaOk(riga, ignoraVarianti) {
              if (typeof window.rigaSoddisfaFiltriShared === 'function') {
                return window.rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
              }
              console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile, nessun filtro applicato a questa riga');
              return true;
            }

            let testoH1 = null;
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              testoH1 = clone.textContent.replace(/\s+/g, ' ').trim();
            }

            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            if (immagine && immagine.includes('static.cardmarket.com/img/logos/')) immagine = null;

            const righe = Array.from(document.querySelectorAll('.article-row'));
            if (righe.length === 0) return { inAttesa: true, immagine };

            let valide = righe.filter(r => rigaOk(r, false));
            if (valide.length === 0) {
              const valideSenzaEsclusione = righe.filter(r => rigaOk(r, true));
              if (valideSenzaEsclusione.length > 0) valide = valideSenzaEsclusione;
            }

            if (valide.length === 0) return { prezzo: null, immagine, testoH1 };

            const selettori = [
              '.price-container .fw-bold',
              '.col-offer-price .fw-bold',
              '[class*="price"] .fw-bold',
              '.color-primary.fw-bold',
              '.price',
            ];

            for (const riga of valide) {
              for (const sel of selettori) {
                const el = riga.querySelector(sel);
                if (el && el.textContent.includes('€')) {
                  const match = el.textContent.match(/([\d,.]+)\s*€/);
                  if (match) {
                    const pulito = match[1].replace(/\./g, '').replace(',', '.');
                    return { prezzo: parseFloat(pulito) || null, immagine, testoH1 };
                  }
                }
              }
            }
            return { prezzo: null, immagine, testoH1 };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          if (val === undefined || val === null) return;

          if (val.rateLimited) {
            chiudi({ ...risolto, prezzo: null, immagine: null, rateLimited: true });
            return;
          }
          // Nessuna offerta (ancora): si riprova; la foto resta per la scadenza (v5.49).
          if (val.inAttesa) { immagineSenzaOfferte = val.immagine || null; return; }

          const daH1 = val.testoH1 ? _nomeECodiceDaTestoH1(val.testoH1) : { nome: null, codice: null };
          const nomeDom = daH1.nome || null;
          const codiceDom = daH1.codice || null;
          if (!risolto.nome && nomeDom && !_ePaginaListaSingles('', nomeDom)) risolto.nome = nomeDom;
          if (!risolto.codice && codiceDom) risolto.codice = codiceDom;

          if (verificaDopoPrezzo) {
            const slugPagina = (risolto.urlSingles || '').split('/').pop() || '';
            if (!_paginaCombaciaConQuery(verificaDopoPrezzo, nomeDom, codiceDom, slugPagina)) {
              chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, nonTrovata: true });
              return;
            }
            verificaDopoPrezzo = null;
          }

          const prezzoTrovato = val?.prezzo ?? null;
          if (prezzoTrovato === null && (oloType === 'RH' || firstEd) && !variantiRitentateSenzaFiltro) {
            variantiRitentateSenzaFiltro = true;
            passaAFasePrezzo(risolto.urlSingles, true);
            return;
          }

          chiudi({ ...risolto, prezzo: prezzoTrovato, immagine: val?.immagine || null });
        });
      }

      function onLoad(id, info) {
        if (id !== tabId || info.status !== 'complete') return;
        caricata = true;
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(() => {
        if (fase === 'risoluzione') tentaLetturaRisoluzione();
        else tentaLetturaPrezzo();
      }, 600);
      timeout = _scadenzaLettura(() => !caricata, () => chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }), (t) => { timeout = t; });
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlNome }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
    }
  });
}

// opzioni.sigillata (dalla 5.76): carta con la spunta "Sigillata" → prezzo della prima offerta sigillata
// (caricando fino a 4 pagine di offerte in più), minimoCm = prima offerta che va bene; nel risultato
// sigillata: 'trovata' | 'non-trovata'.
function _leggiPrezzoDaSingles(urlConFiltri, tabIdEsterno, requestId = null, opzioni = {}) {
  const modoSigillata = !!(opzioni && opzioni.sigillata);
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;
      let ultimaPaginaSenzaOfferte = null;

      function chiudi(prezzo, immagine, nome, codice, extra = null) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        _rimuoviAttesaCf(tabId);
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ prezzo, immagine: immagine || null, nome: nome || null, codice: codice || null, tabId, ...(extra || {}) });
      }

      function chiudiPerTempo() {
        if (!ultimaPaginaSenzaOfferte) { chiudi(null, null); return; }
        const letti = _nomeECodiceDaTestoH1(ultimaPaginaSenzaOfferte.testoH1);
        chiudi(null, ultimaPaginaSenzaOfferte.immagine || null, letti.nome || null, letti.codice || null, { senzaOfferte: true });
      }

      function tentaLettura() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        _assicuraSharedInScheda(tabId).then(() => { if (caricata) leggiNellaScheda(); });
      }

      function leggiNellaScheda() {
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES, RATE_LIMIT_MARKERS, modoSigillata],
          func: async (CF_TITLES, RATE_LIMIT_MARKERS, modoSigillata) => {
            const _testoPagina = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (RATE_LIMIT_MARKERS.some(m => _testoPagina.includes(m))) {
              return { rateLimited: true };
            }

            const title = document.title.toLowerCase();
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || (!!document.querySelector('#challenge-running,#challenge-form,#cf-challenge-running') || (!!document.querySelector('.cf-turnstile') && !document.querySelector('.article-row') && !/\(.+\)/.test((document.querySelector('h1') || {}).textContent || '')));
            if (isCloudflare) return { cloudflare: true };

            const params = new URLSearchParams(window.location.search);
            const idLanguage   = params.get('language') || params.get('idLanguage') || null;
            const minCondition = (params.get('minCondition') || '').toLowerCase() || null;
            const isReverseHolo = params.get('isReverseHolo') === 'Y';
            const isFirstEd = params.get('isFirstEd') === 'Y';

            function rigaOk(riga, ignoraVarianti) {
              if (typeof window.rigaSoddisfaFiltriShared === 'function') {
                return window.rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
              }
              console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile, nessun filtro applicato a questa riga');
              return true;
            }

            let testoH1 = '';
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              testoH1 = clone.textContent.replace(/\s+/g, ' ').trim();
            }
            const urlPagina = location.origin + location.pathname;

            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            if (immagine && immagine.includes('static.cardmarket.com/img/logos/')) immagine = null;

            const righe = Array.from(document.querySelectorAll('.article-row'));
            if (righe.length === 0) return { inAttesa: true, testoH1, urlPagina, immagine };

            let valide = righe.filter(r => rigaOk(r, false));
            let ignoraVariantiUsato = false;
            if (valide.length === 0) {
              const valideSenzaEsclusione = righe.filter(r => rigaOk(r, true));
              if (valideSenzaEsclusione.length > 0) { valide = valideSenzaEsclusione; ignoraVariantiUsato = true; }
            }
            if (valide.length === 0) return { prezzo: null, immagine, testoH1, urlPagina };

            // carta sigillata: una lettura sola per pagina (il controllo si ripete ogni 600 ms)
            if (modoSigillata && typeof window.leggiOffertaSigillataShared === 'function') {
              if (window.__bindexEsitoSigillata) return { ...window.__bindexEsitoSigillata, immagine, testoH1, urlPagina };
              if (window.__bindexSigillataInCorso) return null;
              window.__bindexSigillataInCorso = true;
              const e = await window.leggiOffertaSigillataShared((r) => rigaOk(r, ignoraVariantiUsato));
              window.__bindexEsitoSigillata = {
                prezzo: e.prezzoSigillata !== null ? e.prezzoSigillata : e.minimo,
                minimoCm: e.minimo,
                sigillata: e.prezzoSigillata !== null ? 'trovata' : 'non-trovata',
              };
              window.__bindexSigillataInCorso = false;
              return { ...window.__bindexEsitoSigillata, immagine, testoH1, urlPagina };
            }

            const selettori = [
              '.price-container .fw-bold',
              '.col-offer-price .fw-bold',
              '[class*="price"] .fw-bold',
              '.color-primary.fw-bold',
              '.price',
            ];

            for (const riga of valide) {
              for (const sel of selettori) {
                const el = riga.querySelector(sel);
                if (el && el.textContent.includes('€')) {
                  const match = el.textContent.match(/([\d,.]+)\s*€/);
                  if (match) {
                    const pulito = match[1].replace(/\./g, '').replace(',', '.');
                    return { prezzo: parseFloat(pulito) || null, immagine, testoH1, urlPagina };
                  }
                }
              }
            }
            return { prezzo: null, immagine, testoH1, urlPagina };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          if (val === undefined || val === null) return;
          if (val === null) { chiudi(null, null); return; }
          if (val.rateLimited) { chiudi('RateLimit', null); return; }

          if (val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'carte');
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi(null, null, null, null, { cloudflare: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: _statoCloudflareNellaScheda,
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi(null, null); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = _scadenzaLettura(() => !caricata, chiudiPerTempo, (t) => { timeout = t; });
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          if (val.urlPagina !== undefined && _ePaginaListaSingles(val.urlPagina, val.testoH1 || '')) {
            chiudi(null, null, null, null, { linkNonValido: true });
            return;
          }
          if (val.inAttesa) { ultimaPaginaSenzaOfferte = val; return; }

          const letti = _nomeECodiceDaTestoH1(val.testoH1);
          chiudi(val?.prezzo ?? null, val?.immagine || null, letti.nome || null, letti.codice || null,
            val.sigillata ? { minimoCm: typeof val.minimoCm === 'number' ? val.minimoCm : null, sigillata: val.sigillata } : null);
        });
      }

      function onLoad(id, info) {
        if (id !== tabId || info.status !== 'complete') return;
        caricata = true;
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = modoSigillata
        ? setTimeout(chiudiPerTempo, _ATTESA_LETTURA_SIGILLATA_MS)
        : _scadenzaLettura(() => !caricata, chiudiPerTempo, (t) => { timeout = t; });
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlConFiltri }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlConFiltri, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlConFiltri, active: false }, avviaCon);
    }
  });
}
