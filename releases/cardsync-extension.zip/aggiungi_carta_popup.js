// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
assicuraLoginSupabase();

// ── COSTANTI ──────────────────────────────────────────────────────────────────
const COL = {
  NOME:              'B',
  CODICE:            'C',
  LOCATION:          'D',
  QTY:               'E',
  LINGUA:            'F',
  CONDIZIONE:        'G',
  URL:               'H',
  PREZZO_OBIETTIVO:  'J', // usato solo per righe destinate alla wishlist
  NOTE:              'K',
  IMMAGINE:          'L', // già recuperata dalla ricerca (background.js), prima mai salvata
};

const CAMPI_STORAGE = ['selectedTheme'];
const LISTA_TEMI = ['purple', 'green', 'blue', 'contrast', 'dark', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];

// ── SISTEMA PROFILI — GUSCIO VUOTO ──────────────────────────────────────────
// Il vecchio sistema (registro profili su Google Apps Script) è stato
// rimosso con la migrazione a Supabase. La tendina resta come punto di
// aggancio per un futuro sistema profili basato su Supabase.
document.getElementById('selectProfilo')?.addEventListener('change', () => {
  setStatus('ℹ️ Il sistema profili è in aggiornamento — non ancora disponibile.', 'info');
});

// FIX: il singolo slider "Delay tra carte" (preset fissi tipo "5–10s") è
// stato sostituito da due slider indipendenti — minimo e massimo, in
// secondi — coerente con la stessa modifica fatta nel popup principale
// (popup.js). Limiti dei due slider:
const DELAY_SEC_MIN = 1;
const DELAY_SEC_MAX = 60;
// Tabella usata SOLO per migrare il vecchio valore a indice (0–7) salvato
// da chi aggiorna l'estensione da una versione precedente — vedi il
// caricamento storage più sotto.
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];
// Valore predefinito per chi installa l'estensione da zero (nessun vecchio
// indice da migrare) — 10–20s è il compromesso più prudente per limitare il
// rischio di blocchi Cloudflare/rate limit fin dal primo utilizzo.
const DEFAULT_DELAY_MIN_SEC = 10;
const DEFAULT_DELAY_MAX_SEC = 20;
// Rallentamento adattivo Cloudflare: con un range continuo si aggiunge un
// margine fisso per gradino invece di spostarsi su un preset più lento.
const CF_ESCALATION_STEP_SEC = 3;
const CF_ESCALATION_MAX_LEVEL = 5;

// FIX: il messaggio LEGGI_NOME_CARTA aveva un timeout FISSO di 30s lato popup,
// mentre background.js — quando la tab incontra Cloudflare — resta in attesa
// che l'utente risolva il challenge per un tempo configurabile (sliderCfTimeout,
// condiviso con popup.js, default 3 min). Se Cloudflare impiegava più di 30s a
// essere risolto, il popup andava in timeout e passava già alla carta
// successiva (aprendo una nuova tab) mentre la tab precedente era ancora lì
// ad aspettare che l'utente risolvesse il blocco. Ora il timeout del messaggio
// viene dimensionato sullo stesso valore usato da background.js, con un
// margine di sicurezza, così il popup aspetta quanto basta prima di arrendersi.
function _timeoutLetturaCarta() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['sliderCfTimeout'], (res) => {
      const minuti = (typeof res.sliderCfTimeout === 'number' && res.sliderCfTimeout >= 1)
        ? res.sliderCfTimeout
        : 3; // default coerente con background.js
      resolve(minuti * 60 * 1000 + 20000); // + margine per rete/tab
    });
  });
}

// ── INVIO MESSAGGIO RESILIENTE AI RIAVVII DEL SERVICE WORKER ────────────────
// FIX (bug "non rispetta l'attesa Cloudflare configurata"): il service
// worker (background.js) può essere terminato da Chrome in qualunque momento
// durante un'attesa Cloudflare di alcuni minuti — è la norma in MV3 per
// attese così lunghe, non un caso raro. Quando succede MENTRE background.js
// sta ancora aspettando che l'utente risolva il blocco, il canale del
// messaggio chrome.runtime.sendMessage si chiude di colpo con un errore tipo
// "The message port closed before a response was received." — e questo
// arriva ANCHE MOLTO PRIMA che i minuti configurati siano trascorsi. Prima,
// qualunque rifiuto della Promise (compreso questo) faceva marcare subito la
// carta come fallita, dando l'impressione che l'attesa configurata non
// venisse rispettata. Questa funzione riconosce questo tipo di errore
// (connessione persa col SW, non un vero fallimento della ricerca) e
// RITENTA L'INVIO del messaggio — non l'intera sessione bulk — finché resta
// budget di tempo, invece di arrendersi al primo colpo. Nota: un retry apre
// una nuova risoluzione da capo in background.js (può quindi aprire una
// nuova tab se quella precedente non è più raggiungibile) — non è perfetto
// se l'utente era a metà di una verifica Cloudflare, ma è sempre meglio di
// un fallimento immediato dopo pochi secondi.
function _erroreConnessioneSW(msg) {
  if (!msg) return false;
  const m = msg.toLowerCase();
  return m.includes('message port closed')
      || m.includes('receiving end does not exist')
      || m.includes('context invalidated')
      || m.includes('could not establish connection');
}

function _inviaMessaggioConRetry(messaggio, timeoutTotaleMs) {
  const scadenza = Date.now() + timeoutTotaleMs;
  return new Promise((resolve, reject) => {
    function tenta() {
      const rimanente = scadenza - Date.now();
      if (rimanente <= 0) { reject(new Error('Timeout')); return; }
      const timeoutId = setTimeout(() => {
        reject(new Error('Timeout'));
      }, rimanente);
      chrome.runtime.sendMessage(messaggio, (r) => {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) {
          if (_erroreConnessioneSW(chrome.runtime.lastError.message) && Date.now() < scadenza) {
            // SW riavviato a metà attesa: non è un fallimento reale della
            // ricerca, ritenta l'invio finché c'è ancora budget di tempo.
            setTimeout(tenta, 1000);
            return;
          }
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(r);
      });
    }
    tenta();
  });
}

// ── WATCHDOG HEARTBEAT (fix "resta bloccato su una carta finché non ricarico
// la pagina") ─────────────────────────────────────────────────────────────
// FIX: _inviaMessaggioConRetry (sopra) riconosce solo l'errore "connessione
// persa" che Chrome a volte genera quando il service worker viene terminato
// a metà di un'attesa lunga — ma non SEMPRE lo genera. Se il SW viene
// terminato mentre background.js sta ancora pollando una pagina Cardmarket
// o aspettando che l'utente risolva un challenge Cloudflare, tutta quella
// catena di callback/timer sparisce con lui: nessun errore arriva mai al
// popup, che resta bloccato in attesa fino al proprio timeout interno
// (dimensionato su sliderCfTimeout, fino a 10 minuti) — a volte anche oltre,
// a seconda di come Chrome gestisce il canale del messaggio in quel caso.
//
// Qui si aggiunge un secondo livello di sicurezza: ogni richiesta lunga
// porta un requestId univoco. Il background aggiorna un "heartbeat" (vedi
// _richiesteAttive in background.js) a ogni ciclo di polling — ogni
// 600ms-2s. In parallelo all'attesa della risposta vera, il popup manda un
// ping leggero (PING_RICHIESTA) ogni pochi secondi: se il ping segnala che
// la richiesta non è più nella mappa del SW (= il SW è stato riavviato e ha
// perso lo stato), o se il ping stesso non ottiene risposta, per un paio di
// controlli consecutivi, il popup abbandona l'attesa e considera la carta
// fallita — passando a quella successiva invece di restare bloccato fino al
// timeout Cloudflare completo. Il refresh manuale della pagina non serve
// più: la sessione bulk prosegue da sola.
function _nuovoRequestId() {
  return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function _pingRichiesta(requestId) {
  return new Promise((resolve) => {
    const timeoutId = setTimeout(() => resolve(null), 5000);
    try {
      chrome.runtime.sendMessage({ type: 'PING_RICHIESTA', requestId }, (r) => {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(r || null);
      });
    } catch (_) {
      clearTimeout(timeoutId);
      resolve(null);
    }
  });
}

// Stesso comportamento di _inviaMessaggioConRetry (stesso timeout totale,
// stessi retry su disconnessione), con in più il watchdog heartbeat sopra
// descritto corso in parallelo. Usare SOLO per le richieste lunghe e
// basate su tab (LEGGI_NOME_CARTA, LEGGI_SEALED, LEGGI_SOLO_PREZZO*) — non
// serve per messaggi rapidi come AGGIUNGI_CARTA.
function _inviaMessaggioConWatchdog(messaggio, timeoutTotaleMs) {
  const requestId = _nuovoRequestId();
  const messaggioConId = Object.assign({}, messaggio, { requestId });

  let risolta = false;
  let mancatiConsecutivi = 0;
  let heartbeatTimer = null;

  const promiseMessaggio = _inviaMessaggioConRetry(messaggioConId, timeoutTotaleMs)
    .then((r) => ({ orfano: false, risposta: r }))
    .catch((e) => ({ orfano: false, errore: e }))
    .finally(() => { risolta = true; if (heartbeatTimer) clearInterval(heartbeatTimer); });

  const promiseWatchdog = new Promise((resolve) => {
    // Intervallo di 8s, servono 3 controlli consecutivi falliti (~24s) prima
    // di dichiarare la richiesta orfana — abbastanza margine da non scambiare
    // una fase legittimamente lenta (es. fetch statico su rete lenta) per un
    // SW morto, ma comunque MOLTO più veloce di aspettare fino a 10 minuti.
    heartbeatTimer = setInterval(async () => {
      if (risolta) return;
      const esito = await _pingRichiesta(requestId);
      if (risolta) return;
      if (esito && esito.attiva) {
        mancatiConsecutivi = 0;
        return;
      }
      mancatiConsecutivi++;
      if (mancatiConsecutivi >= 3) {
        if (heartbeatTimer) clearInterval(heartbeatTimer);
        resolve({ orfano: true });
      }
    }, 8000);
  });

  return Promise.race([promiseMessaggio, promiseWatchdog]).then((esito) => {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    if (esito.orfano) {
      const err = new Error('service worker riavviato durante l\'attesa — carta saltata');
      err.orfano = true;
      throw err;
    }
    if (esito.errore) throw esito.errore;
    return esito.risposta;
  });
}

// Opzioni per le tendine Lingua/Condizione nel pannello di correzione manuale
const LINGUE_CORREZIONE     = ['IT','EN','FR','DE','ES','PT','JA','KOR','CHN','CHN-T','RU','THAI','IND'];
// FIX: mancavano le varianti +/- (es. "EX+", "NM-") — coerenti con la
// stessa sintassi ora riconosciuta dal parser bulk (vedi _condizioneToken
// più sotto) e già supportata a valle nella costruzione dell'URL filtrato
// (costruisciUrlFiltrato in shared.js). Senza queste opzioni in tendina,
// una carta accodata in correzione con condizione "EX+" non poteva essere
// ri-selezionata con lo stesso valore: il <select> ricadeva silenziosamente
// sulla prima opzione (MT) non trovando alcun <option> corrispondente.
const CONDIZIONI_CORREZIONE = ['MT','NM+','NM','NM-','EX+','EX','EX-','GD+','GD','GD-','LP+','LP','LP-','PL+','PL','PL-','PO+','PO'];

// ── URL CARDMARKET ────────────────────────────────────────────────────────────
// Ricerca unificata: funziona sia per codici set (es. "JTG 176") sia per
// nome+numero (es. "Eevee 55") — Cardmarket gestisce entrambi allo stesso modo
// quando gli spazi sono codificati come "+" nella query string.
function urlRicerca(codice, nome) {
  const q = (codice || nome).trim();
  const query = q.replace(/\s+/g, '+');
  return `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
}

// FIX (ricerca sbagliata per i prodotti sealed arrivati da coda_carte con
// tipo='sealed'): i prodotti sealed (ETB, UPC, box...) vivono in una sezione
// diversa di Cardmarket dalle carte singole — questa costruisce l'URL di
// ricerca giusto, identica a quella già usata da aggiungi_sealed_popup.js
// (stessa pagina di ricerca, con in più il filtro lingua).
function urlRicercaSealed(nome, lingua) {
  const query = nome.trim().replace(/\s+/g, '+');
  let url = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
  const codiceLingua = (lingua || 'IT').toUpperCase().trim();
  const idLingua = LINGUA_MAP_SHARED[codiceLingua];
  if (idLingua) url += `&language=${idLingua}`;
  return url;
}

// FIX: prima qui c'era _immagineToBase64(), che mandava un messaggio
// 'IMMAGINE_TO_BASE64' MAI gestito da background.js (nessun case per quel
// tipo) — il fallback silenzioso restituiva comunque l'URL grezzo, quindi
// la conversione non avveniva mai. Rimossa: si usa sempre l'URL grezzo
// dell'immagine, coerente con popup.js e col flusso sealed, e compatibile
// col proxy images.weserv.nl già usato da sidebar.html.

// Alias locale → delega a shared.js
const _costruisciUrlFiltrato = costruisciUrlFiltrato;

// FIX (pulizia codice morto): rimosse oloTypeFromUrl() e firstEdFromUrl() —
// mai chiamate da nessun punto del file. Servivano a leggere la variante
// RH/1ED da un URL già presente nel foglio per il vecchio controllo
// duplicati del flusso bulk, rimosso in una versione precedente per
// velocizzare le sessioni (vedi commento "Controllo duplicati rimosso per
// velocizzare il flusso bulk" più sotto in avviaSessioneBulk) — le due
// funzioni erano rimaste orfane dopo quella rimozione.

// Aggiunge i parametri reverse holo / prima edizione all'URL, se presenti.
function _appendOloParams(url, reverse, oloType, firstEd) {
  let u = url;
  if (reverse || oloType === 'RH') {
    u = u + (u.includes('?') ? '&' : '?') + 'isReverseHolo=Y';
  }
  if (firstEd) {
    u = u + (u.includes('?') ? '&' : '?') + 'isFirstEd=Y';
  }
  return u;
}

// Restituisce la label leggibile della variante per il log/nota
function oloLabel(reverse, oloType) {
  if (reverse || oloType === 'RH') return '✨ RH';
  return '';
}

// Restituisce la label leggibile per Prima Edizione, sullo stesso modello di oloLabel.
function firstEdLabel(firstEd) {
  return firstEd ? '🅰️ 1ED' : '';
}

// FIX: quando la condizione ha il suffisso +/- (es. "EX+", "NM-"), il prezzo
// trovato non è quello della condizione nominale ma di una soglia più
// stretta (solo condizioni migliori) o più larga (anche condizioni
// peggiori) — vedi _condizioneToken/costruisciUrlFiltrato più sopra. Senza
// un promemoria visibile, rileggendo il foglio più tardi non è ovvio che
// quel prezzo/quella riga si riferisca a una soglia diversa dal solito.
// Stesso pattern di oloLabel/firstEdLabel: nota breve, combinata insieme
// alle altre nella colonna Note.
function condizioneLabel(condizione) {
  const c = (condizione || '').toUpperCase().trim();
  if (c.endsWith('+')) return `⬆️ prezzo condizione superiore (${c})`;
  if (c.endsWith('-')) return `⬇️ prezzo condizione anche inferiore (${c})`;
  return '';
}

// Combina le label (RH + 1ED + eventuale nota condizione +/-) in un'unica
// stringa, filtrando le vuote — usata ovunque si scrive/mostra la colonna
// Note.
function variantiLabel(reverse, oloType, firstEd, condizione) {
  return [oloLabel(reverse, oloType), firstEdLabel(firstEd), condizioneLabel(condizione)].filter(Boolean).join(' · ');
}

// ── PANNELLO CORREZIONE MANUALE — coda one-at-a-time ────────────────────────
// Le carte da correggere vengono accodate in _codaCorrezione e mostrate una alla
// volta: bottone esplicito per aprire la tab Cardmarket, campo URL, campo nota,
// bottoni Aggiungi/Ignora. Risolta una carta, si passa automaticamente alla successiva.
let _codaCorrezione = [];
let _codaCorrezioneTot = 0; // totale della sessione corrente (per "Carta N di tot")

// FIX (pulizia codice morto): rimossa _accodaCorrezione(), mai chiamata da
// nessun punto del file — accodava un elemento alla volta chiamando subito
// _mostraProssimaCorrezione() appena la coda passava da 0 a 1. L'unico
// chiamante reale (vedi fine di avviaSessioneBulk più sotto) accoda invece
// TUTTE le carte da correggere in un solo colpo prima di mostrare il
// pannello, apposta per evitare di mostrare "1 di tot" con un totale non
// ancora definitivo — motivo per cui _accodaCorrezione non veniva mai usata.

function _mostraProssimaCorrezione() {
  const cardCorrezione = document.getElementById('cardCorrezione');
  const pannello        = document.getElementById('pannelloCorrezione');

  if (_codaCorrezione.length === 0) {
    cardCorrezione.style.display = 'none';
    pannello.innerHTML = '';
    pannello.classList.remove('visible');
    _codaCorrezioneTot = 0;
    return;
  }

  cardCorrezione.style.display = 'flex';
  pannello.classList.add('visible');
  pannello.innerHTML = '';

  const { codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, opzioni, tipo, dbRigaId, destinazione, prezzoObiettivo } = _codaCorrezione[0];
  const isSealedCorr = tipo === 'sealed';
  const numeroCorrente = _codaCorrezioneTot - _codaCorrezione.length + 1;
  const oloTag = variantiLabel(reverse, oloType, firstEd, condizione);
  // FIX (bug [5]): un sealed non risolto automaticamente deve cercare/
  // validare su /Products/, non su /Singles/ come una carta singola.
  const urlCerca = isSealedCorr ? urlRicercaSealed(codice, lingua) : urlRicerca(codice, '');
  const haOpzioni = Array.isArray(opzioni) && opzioni.length > 0;

  const div = document.createElement('div');
  div.className = 'correzione-item';
  // FIX (pannello troppo lungo → scroll eccessivo): margini/gap ridotti
  // rispetto al CSS base, per far stare più elementi nella stessa altezza
  // visibile senza dover scrollare a ogni carta da correggere.
  div.style.gap = '4px';
  div.style.padding = '7px 8px';

  // ── Header: UNA riga sola — codice+variante+contatore a sinistra, qty a
  // destra (prima erano 2 righe separate: unite con flex space-between) ──
  const header = document.createElement('div');
  header.style.cssText = 'display:flex;justify-content:space-between;align-items:baseline;gap:6px;';
  header.innerHTML = `
    <div class="correzione-item-label" style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${isSealedCorr ? '📦 ' : ''}${codice}${oloTag ? ' · ' + oloTag : ''}</div>
    <div class="correzione-item-sub" style="flex-shrink:0;">${numeroCorrente}/${_codaCorrezioneTot} · qty ${qty}</div>`;
  div.appendChild(header);

  // ── Campi editabili Lingua / Condizione + link "apri ricerca" (icona) —
  // tutti sulla stessa riga (prima il link stava su una riga a parte insieme
  // al testo del motivo: qui basta un'icona per risparmiare spazio) ──
  const editRow = document.createElement('div');
  editRow.style.cssText = 'display:flex;align-items:center;gap:5px;margin-top:1px;';

  function _campoCompatto(testoLabel, valori, valoreDefault) {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'flex:1;display:flex;align-items:center;gap:4px;min-width:0;';
    const lbl = document.createElement('span');
    lbl.style.cssText = 'font-size:9.5px;color:var(--ink-muted);flex-shrink:0;';
    lbl.textContent = testoLabel;
    const sel = document.createElement('select');
    sel.className = 'correzione-url-input';
    sel.style.cssText = 'padding:3px 4px;font-size:10px;flex:1;min-width:0;';
    valori.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v; opt.textContent = v;
      if (v === valoreDefault) opt.selected = true;
      sel.appendChild(opt);
    });
    wrap.appendChild(lbl);
    wrap.appendChild(sel);
    return sel;
  }

  const selectLingua     = _campoCompatto('Lang', LINGUE_CORREZIONE, (lingua || 'IT').toUpperCase());
  const selectCondizione = _campoCompatto('Cond', CONDIZIONI_CORREZIONE, (condizione || 'NM').toUpperCase());
  editRow.appendChild(selectLingua.parentElement);
  editRow.appendChild(selectCondizione.parentElement);

  const linkApri = document.createElement('a');
  linkApri.href = '#';
  linkApri.textContent = '🔗';
  linkApri.title = 'Apri la pagina di ricerca su Cardmarket';
  linkApri.style.cssText = 'flex-shrink:0;font-size:13px;text-decoration:none;cursor:pointer;padding:4px 7px;border-radius:6px;border:1px solid var(--border);background:var(--surface);line-height:1;';
  linkApri.addEventListener('click', (e) => {
    e.preventDefault();
    // FIX (troppe tab in sequenza → Cloudflare): riusa la worker tab della
    // sessione bulk invece di aprirne una nuova a ogni carta da correggere.
    chrome.runtime.sendMessage({ type: 'APRI_URL_WORKER_TAB', kind: 'carte', url: urlCerca });
  });
  editRow.appendChild(linkApri);
  div.appendChild(editRow);

  // ── URL + nota sulla stessa riga (prima erano 2 righe separate: la nota
  // è quasi sempre breve, quindi condivide la riga in una colonna più
  // stretta accanto all'URL — risparmia un'intera riga per ogni carta) ──
  const urlNoteRow = document.createElement('div');
  urlNoteRow.style.cssText = 'display:flex;gap:4px;margin-top:2px;';

  const input = document.createElement('input');
  input.type = 'url';
  input.placeholder = haOpzioni
    ? "Incolla l'URL o scegli tra le varianti sotto"
    : (isSealedCorr ? "Incolla l'URL /Products/…" : "Incolla l'URL /Singles/…");
  input.title = isSealedCorr
    ? "URL della pagina prodotto su Cardmarket (deve contenere /Products/)"
    : "URL della pagina prodotto su Cardmarket (deve contenere /Singles/)";
  input.style.cssText = 'flex:1;min-width:0;font-size:10.5px;padding:5px 7px;';
  urlNoteRow.appendChild(input);

  const noteInput = document.createElement('input');
  noteInput.type = 'text';
  noteInput.placeholder = 'Nota';
  noteInput.title = 'Nota (opzionale)';
  noteInput.style.cssText = 'flex:0 0 72px;min-width:0;font-size:10.5px;padding:5px 7px;';
  urlNoteRow.appendChild(noteInput);

  div.appendChild(urlNoteRow);

  // ── Opzioni candidate trovate da background.js (es. varianti V1/V2/V3/V4…) ──
  // FIX: prima queste venivano scartate e l'utente doveva sempre cercare a
  // mano, anche quando il sistema aveva già individuato i link candidati.
  // Contenitore compatto e scorrevole (altezza massima) così un elenco lungo
  // di varianti non allunga il pannello costringendo a scorrere per arrivare
  // ai bottoni Aggiungi/Ignora più sotto. Il conteggio è già nell'header
  // sopra, quindi qui non serve un'etichetta separata.
  if (haOpzioni) {
    // FIX (pannello troppo lungo → scroll eccessivo): l'elenco varianti
    // prima era sempre aperto, occupando fino a 90px anche quando bastava
    // incollare l'URL a mano — spingendo i bottoni Aggiungi/Ignora fuori
    // dalla vista senza scrollare. Ora è collassato di default: un tap sul
    // toggle lo apre solo quando serve davvero sfogliare i candidati.
    const opzioniToggle = document.createElement('button');
    opzioniToggle.type = 'button';
    opzioniToggle.className = 'correzione-btn-salta';
    opzioniToggle.style.cssText = 'width:100%;text-align:left;margin-top:2px;font-size:10px;padding:4px 7px;';
    opzioniToggle.textContent = `▸ ${opzioni.length} variant${opzioni.length === 1 ? 'e' : 'i'} trovat${opzioni.length === 1 ? 'a' : 'e'} — mostra`;

    const opzioniWrap = document.createElement('div');
    opzioniWrap.className = 'themed-scroll';
    opzioniWrap.style.cssText = 'display:none;flex-direction:column;gap:3px;margin-top:2px;max-height:110px;overflow-y:auto;';
    opzioni.forEach((opz) => {
      const btnOpz = document.createElement('button');
      btnOpz.className = 'correzione-btn';
      btnOpz.style.cssText = 'width:100%;text-align:left;white-space:normal;line-height:1.2;padding:4px 7px;font-size:10px;';
      btnOpz.textContent = '▸ ' + (opz.label || opz.urlSingles);
      btnOpz.addEventListener('click', () => {
        input.value = opz.urlSingles;
        input.style.borderColor = '';
      });
      opzioniWrap.appendChild(btnOpz);
    });

    opzioniToggle.addEventListener('click', () => {
      const aperto = opzioniWrap.style.display !== 'none';
      opzioniWrap.style.display = aperto ? 'none' : 'flex';
      opzioniToggle.textContent = aperto
        ? `▸ ${opzioni.length} variant${opzioni.length === 1 ? 'e' : 'i'} trovat${opzioni.length === 1 ? 'a' : 'e'} — mostra`
        : '▾ nascondi varianti';
    });

    div.appendChild(opzioniToggle);
    div.appendChild(opzioniWrap);
  }

  // ── Bottoni Aggiungi / Ignora ──
  const azioniRow = document.createElement('div');
  azioniRow.className = 'correzione-url-row';
  azioniRow.style.marginTop = '4px';

  const btnAdd = document.createElement('button');
  btnAdd.className = 'correzione-btn';
  btnAdd.style.flex = '1';
  btnAdd.textContent = '➕ Aggiungi';

  const btnSalta = document.createElement('button');
  btnSalta.className = 'correzione-btn-salta';
  btnSalta.title = 'Ignora questa carta';
  btnSalta.textContent = '✕ Ignora';

  btnAdd.addEventListener('click', async () => {
    const urlManuale = input.value.trim();
    // FIX (bug [5]): un sealed valida su /Products/, una carta singola su
    // /Singles/ — prima era sempre /Singles/, quindi un sealed non poteva
    // mai essere completato da qui (né incollando l'URL a mano né
    // cliccando una delle opzioni trovate, che per un sealed sono sempre
    // /Products/...).
    const marcatoreAtteso = isSealedCorr ? '/Products/' : '/Singles/';
    if (!urlManuale || !urlManuale.includes(marcatoreAtteso)) {
      input.style.borderColor = 'red';
      return;
    }
    input.style.borderColor = '';
    if (!(await verificaAccessoValido())) return; // account bannato/eliminato: overlay già mostrato da auth_ui.js
    btnAdd.disabled = true;
    btnSalta.disabled = true;
    btnAdd.textContent = '⏳';

    // Valori (eventualmente corretti dall'utente) al momento del salvataggio
    const linguaFinale     = selectLingua.value;
    const condizioneFinale = selectCondizione.value;
    const notaManuale = noteInput.value.trim();

    try {
      const timeoutMs = await _timeoutLetturaCarta();
      const risposta = isSealedCorr
        ? await _inviaMessaggioConWatchdog({
            type: 'LEGGI_SEALED',
            urlNome: urlManuale.split('?')[0],
            lingua: linguaFinale,
            usaWorkerTab: true,
          }, timeoutMs)
        : await _inviaMessaggioConWatchdog({
            type: 'LEGGI_NOME_CARTA',
            urlNome: urlManuale.split('?')[0],
            lingua: linguaFinale, condizione: condizioneFinale,
            oloType: oloType || (reverse ? 'RH' : ''),
            // FIX: mancava firstEd — senza inoltrarlo, il prezzo letto per
            // le correzioni manuali di carte Prima Edizione era sempre
            // quello della stampa normale (vedi fix in background.js).
            firstEd: !!firstEd,
            // FIX (troppe tab in sequenza → Cloudflare): riusa la stessa worker
            // tab della sessione bulk anche per le correzioni manuali, invece di
            // aprirne una a parte.
            usaWorkerTab: true,
          }, timeoutMs);

      // FIX (nota libera in bulk): notaBulk arriva dal formato con virgola
      // in bulk (es. "FST007, NM error"), notaManuale è quella digitata
      // direttamente nel campo del pannello di correzione — entrambe
      // combinate con le note automatiche RH/1ED/condizione.
      const notaFinale = isSealedCorr
        ? [notaBulk, notaManuale].filter(Boolean).join(' | ')
        : [notaBulk, notaManuale, variantiLabel(reverse, oloType, firstEd, condizioneFinale)].filter(Boolean).join(' | ');
      // FIX (bug [5]): rigaDati per un sealed segue lo stesso schema già
      // corretto e in uso in aggiungi_sealed_popup.js — niente CODICE
      // (colonna non pertinente ai sealed), CONDIZIONE fissa 'NM' (nessun
      // concetto di usura per un prodotto sigillato), URL preso grezzo
      // dall'input invece di passare per _costruisciUrlFiltrato/
      // _appendOloParams (pensate solo per le pagine /Singles/).
      const rigaDati = isSealedCorr ? {
        [COL.NOME]:       risposta?.nome || codice,
        [COL.CODICE]:     '',
        [COL.LOCATION]:   _leggiLocationCorrente(),
        [COL.QTY]:        qty,
        [COL.LINGUA]:     linguaFinale,
        [COL.CONDIZIONE]: 'NM',
        [COL.URL]:        urlManuale.split('?')[0],
        ['I']:            risposta?.prezzo ?? '',
        [COL.NOTE]:       notaFinale,
      } : {
        [COL.NOME]:       risposta?.nome || '',
        [COL.CODICE]:     risposta?.codice || codice,
        [COL.LOCATION]:   _leggiLocationCorrente(),
        [COL.QTY]:        qty,
        [COL.LINGUA]:     linguaFinale,
        [COL.CONDIZIONE]: condizioneFinale,
        [COL.URL]:        _appendOloParams(_costruisciUrlFiltrato(urlManuale.split('?')[0], linguaFinale, condizioneFinale), reverse, oloType, firstEd),
        ['I']:            risposta?.prezzo ?? '',
        // FIX: colonna M (immagine) rimossa su richiesta — non serve più.
        [COL.NOTE]:       notaFinale,
      };
      // FIX (bug [6]): se la riga in wishlist aveva un prezzo obiettivo
      // originale, portarlo fino in fondo — stesso campo già gestito dal
      // flusso automatico (_elaboraCarta).
      if (destinazione === 'wishlist' && prezzoObiettivo != null) rigaDati[COL.PREZZO_OBIETTIVO] = prezzoObiettivo;

      const data = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          // FIX (bug [6]): prima mancavano tipo/dbRigaId/destinazione — un
          // sealed veniva scritto come carta singola, e una carta della
          // coda condivisa (dbRigaId) risultava intestata a chi corregge
          // invece che al vero richiedente (owner_id sbagliato lato
          // supabase_adapter.js). Stesso schema già in uso nel flusso
          // automatico (_elaboraCarta) e in aggiungi_sealed_popup.js.
          { type: 'AGGIUNGI_CARTA', rigaDati, tipo: tipo || undefined, destinazione: destinazione || undefined, dbRigaId: dbRigaId || undefined },
          (r) => { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r); }
        );
      });

      if (data.ok) {
        aggiungiLog(`R${data.riga} · ${rigaDati[COL.CODICE] || rigaDati[COL.NOME]} · ${linguaFinale} · ${condizioneFinale}${oloTag ? ' · ' + oloTag : ''} (manuale)`, 'ok');
        setStatus(`✅ "${rigaDati[COL.CODICE] || rigaDati[COL.NOME]}" aggiunta alla riga ${data.riga}!`, 'ok');
      } else {
        aggiungiLog(`${codice} — errore: ${data.errore || '?'}`, 'err');
        setStatus(`❌ Errore: ${data.errore || 'risposta sconosciuta'}`, 'errore');
      }
    } catch (e) {
      aggiungiLog(`${codice} — ${e.message}`, 'err');
      setStatus(`❌ Errore: ${e.message}`, 'errore');
    }

    _codaCorrezione.shift();
    _mostraProssimaCorrezione();
  });

  btnSalta.addEventListener('click', () => {
    aggiungiLog(`${codice} — ignorata manualmente`, 'err');
    _codaCorrezione.shift();
    _mostraProssimaCorrezione();
  });

  azioniRow.appendChild(btnAdd);
  azioniRow.appendChild(btnSalta);
  div.appendChild(azioniRow);

  // Il contatore "N di tot" è già nell'header sopra: qui non serve ripeterlo
  // in fondo — risparmia un'intera riga extra nel pannello.

  pannello.appendChild(div);
  setTimeout(() => cardCorrezione.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 100);
}

// ── INIT ──────────────────────────────────────────────────────────────────────
let logCount   = 0;
let logEntries = []; // array dati per copia/esporta



// ── LOCATION (condivisa con Sealed e Wishlist) ───────────────────────────────
// Le location vivono nella scheda dedicata "LOCATION" (colonna B, valori da
// riga 2) — quella collegata alla validazione dati della tendina Location
// nell'Inventario. Il campo qui sotto legge quell'elenco (autocompletamento)
// e, se si scrive un valore nuovo mai visto, lo registra al volo in quella
// scheda all'avvio della sessione bulk (vedi _registraLocationSeNuova) —
// così da quel momento compare anche nella tendina nativa del foglio, non
// solo nelle carte appena aggiunte. Il valore scelto vale per tutte le carte
// della sessione bulk corrente (non per singola riga) ed è condiviso in
// storage con le altre pagine "aggiungi".
const LOCATION_TAB_NAME = 'LOCATION';
const LOCATION_TAB_COL = 'B';
const LOCATION_TAB_RIGA_INIZIO = 2;
let _locationConosciute = [];

function _leggiLocationCorrente() {
  const val = document.getElementById('inputLocation')?.value.trim();
  return val || '?';
}

document.getElementById('inputLocation')?.addEventListener('input', (e) => {
  chrome.storage.local.set({ bulkLocation: e.target.value });
});

async function _popolaDatalistLocation() {
  const datalist = document.getElementById('locationOptions');
  if (!datalist) return;
  try {
    const data = await chiamaSupabase('elencaLocationTab', {});
    if (!data.ok) return;
    _locationConosciute = data.location || [];
    datalist.innerHTML = '';
    _locationConosciute.forEach((loc) => {
      const opt = document.createElement('option');
      opt.value = loc;
      datalist.appendChild(opt);
    });
  } catch (_) {
    // Silenzioso: connessione non ancora configurata/raggiungibile — il
    // campo resta comunque utilizzabile in scrittura libera.
  }
}

// Se il valore scelto non è tra quelli già noti nella scheda LOCATION, lo
// registra lì al volo prima di usarlo per la sessione bulk — è così che
// "scrivere una location nuova qui" la fa comparire anche nella tendina
// nativa del foglio. Chiamata all'avvio di ogni sessione bulk.
async function _registraLocationSeNuova() {
  const nome = document.getElementById('inputLocation')?.value.trim();
  if (!nome || _locationConosciute.includes(nome)) return;
  try {
    const data = await chiamaSupabase('aggiungiLocationTab', { nome });
    if (data.ok) {
      _locationConosciute.push(nome);
      window.parent.postMessage({ type: 'CARDSYNC_LOCATION_ADDED' }, '*');
    }
  } catch (_) {
    // Silenzioso: se la registrazione fallisce, la carta viene comunque
    // scritta con questo valore in Location — solo la tendina nativa del
    // foglio non lo includerà finché non si riprova.
  }
}

chrome.storage.local.get([...CAMPI_STORAGE, 'bulkUltimoUtilizzo', 'bulkLocation', 'cardsyncDarkMode'], (saved) => {
  applicaTema(saved.selectedTheme || 'purple');
  document.body.classList.toggle('modo-scuro', saved.cardsyncDarkMode === true);
  const _inputLocationEl = document.getElementById('inputLocation');
  if (_inputLocationEl && saved.bulkLocation) _inputLocationEl.value = saved.bulkLocation;

  if (saved.bulkUltimoUtilizzo) {
    const { ts, ok } = saved.bulkUltimoUtilizzo;
    document.getElementById('ultimaCarta').textContent =
      `🕐 ${formattaDataOra(ts)} · ${ok} cart${ok === 1 ? 'a aggiunta' : 'e aggiunte'}`;
  }

  _popolaDatalistLocation();

  // FASE ordini "aggiungi_carte" (coda persistente su Supabase): appena la
  // pagina è pronta, controlla subito se c'è lavoro in attesa nella tabella
  // 'coda_carte' — vedi _recuperaAltreRigheDaDb più sotto. Copre sia il
  // primo avvio sia la ripresa dopo un riavvio del PC/estensione.
  _recuperaAltreRigheDaDb();
});

// Impostazioni bulk sempre visibili (rimossa la modalità singola)


// ── PARSER BULK ───────────────────────────────────────────────────────────────
// Token riconosciuti: LINGUA (IT EN FR DE ES PT JA KOR CHN CHN-T RU THAI IND),
// CONDIZIONE (MT NM EX GD LP PL PO), CODICE (tutto il resto).
// Default: IT, NM. QTY NON è un token del parser (FIX bug [19], solo
// commento: il vecchio testo lasciava intendere che un numero nella riga
// incollata impostasse la quantità — in realtà qty è sempre 1 all'ingresso
// in tabella, si regola dopo coi pulsanti +/- per riga).
const CONDIZIONI_VALIDE = new Set(['MT','NM','EX','GD','LP','PL','PO']);

// FIX: il parser bulk riconosceva SOLO i codici condizione base (MT/NM/EX/…),
// mai con il suffisso +/- documentato nella legenda ("EX+" = solo condizioni
// migliori di EX, "EX-" = anche condizioni peggiori). Un token come "EX+"
// non soddisfaceva CONDIZIONI_VALIDE.has("EX+") (il Set contiene solo "EX"),
// quindi restava non riconosciuto: nel formato con virgola veniva scartato
// silenziosamente, in quello storico finiva "mangiato" dentro il nome/codice
// — in entrambi i casi la condizione restava sempre quella di default (NM)
// invece del valore realmente scritto dall'utente. Questa funzione riconosce
// anche la forma con suffisso, verificando che la parte base sia valida.
function _condizioneToken(tok) {
  const up = (tok || '').toUpperCase();
  if (CONDIZIONI_VALIDE.has(up)) return up;
  const ultimo = up.slice(-1);
  if (ultimo === '+' || ultimo === '-') {
    const base = up.slice(0, -1);
    if (CONDIZIONI_VALIDE.has(base)) return up;
  }
  return null;
}

// Mappa alias → codice canonico (quello che usa il resto dell'estensione)
// Copre: sigle brevi, sigle lunghe, nomi completi in italiano e inglese
const LINGUA_ALIAS_MAP = {
  // Italiano
  'IT':'IT','ITA':'IT','ITALIANO':'IT','ITALIAN':'IT',
  // Inglese
  'EN':'EN','ENG':'EN','INGLESE':'EN','ENGLISH':'EN',
  // Francese
  'FR':'FR','FRA':'FR','FRANCESE':'FR','FRENCH':'FR',
  // Tedesco
  'DE':'DE','DEU':'DE','GER':'DE','TEDESCO':'DE','GERMAN':'DE','DEUTSCH':'DE',
  // Spagnolo
  'ES':'ES','ESP':'ES','SPAGNOLO':'ES','SPANISH':'ES','ESPAÑOL':'ES',
  // Portoghese
  'PT':'PT','POR':'PT','PORTOGHESE':'PT','PORTUGUESE':'PT',
  // Giapponese
  'JA':'JA','JP':'JA','JAP':'JA','JPN':'JA','GIAPPONESE':'JA','JAPANESE':'JA',
  // Coreano
  'KOR':'KOR','KO':'KOR','KR':'KOR','COREANO':'KOR','KOREAN':'KOR',
  // Cinese semplificato
  'CHN':'CHN','ZH':'CHN','CN':'CHN','CHS':'CHN','CINESE':'CHN','CHINESE':'CHN','CINESE-S':'CHN','CHINESE-S':'CHN',
  // Cinese tradizionale
  'CHN-T':'CHN-T','ZHT':'CHN-T','TW':'CHN-T','CHT':'CHN-T','CINESE-T':'CHN-T','CHINESE-T':'CHN-T',
  // Russo
  'RU':'RU','RUS':'RU','RUSSO':'RU','RUSSIAN':'RU',
  // Tailandese
  'THAI':'THAI','TH':'THAI','TAILANDESE':'THAI','THAI':'THAI',
  // Indonesiano
  'IND':'IND','ID':'IND','INDONESIANO':'IND','INDONESIAN':'IND',
};

// Token per reverse holo (unica variante riconosciuta dal parser bulk)
const REVERSE_TOKEN = new Set(['RH','REV','REVERSE','REVERSEHOLO','REVERSE-HOLO']);

// Token per Prima Edizione — stesso pattern di REVERSE_TOKEN sopra.
const FIRST_ED_TOKEN = new Set(['1ED','1STED','1ST-ED','FIRSTED','FIRST-ED','PRIMAED','PRIMA-ED']);

function parsaBulkRiga(riga) {
  const rigaTrim = riga.trim();
  if (!rigaTrim) return null;

  // ── FORMATO CON VIRGOLA (esplicito) ──────────────────────────────────────
  // FIX ambiguità "Mew EX" (carte moderne con suffisso "-ex"): senza un
  // separatore esplicito, ogni token della riga viene testato contro le
  // condizioni valide — "EX" viene quindi letto come condizione (Excellent)
  // invece che come parte del nome, lasciando il nome ridotto a solo "MEW".
  // La textarea forza tutto in maiuscolo mentre si digita, quindi il
  // problema non è risolvibile guardando il case (a differenza di altri
  // punti dell'estensione): l'unica soluzione affidabile è un separatore
  // esplicito. Se la riga contiene una virgola, tutto ciò che sta PRIMA
  // viene usato come nome/codice per intero, senza scandagliarlo alla
  // ricerca di token lingua/condizione/variante; tutto ciò che sta DOPO
  // viene letto come modificatori (separabili da spazi e/o altre virgole).
  const virgolaIdx = rigaTrim.indexOf(',');
  if (virgolaIdx !== -1) {
    const nomeParte = rigaTrim.slice(0, virgolaIdx).trim();
    const modificatoriParte = rigaTrim.slice(virgolaIdx + 1).trim();
    if (!nomeParte) return null;

    let lingua = 'IT', condizione = 'NM', reverse = false, firstEd = false;
    // FIX (nota libera in bulk): i token dopo la virgola che non
    // corrispondono a nessun modificatore noto (lingua/condizione/RH/1ED)
    // venivano prima scartati silenziosamente. Ora vengono raccolti come
    // testo libero e scritti nella colonna Note (K), uniti a eventuali
    // altre note automatiche (RH/1ED/condizione +/-) — vedi variantiLabel()
    // e il punto di scrittura rigaDati[COL.NOTE] in avviaSessioneBulk.
    // Esempio: "FST007, NM error" → condizione NM, nota "ERROR".
    const notaTokens = [];
    const tokensModificatori = modificatoriParte.split(/[\s,]+/).filter(Boolean);
    for (const t of tokensModificatori) {
      const up = t.toUpperCase();
      if (REVERSE_TOKEN.has(up))        { reverse = true;   continue; }
      if (FIRST_ED_TOKEN.has(up))       { firstEd = true;    continue; }
      const _condTokV = _condizioneToken(up);
      if (_condTokV)                    { condizione = _condTokV; continue; }
      const lc = LINGUA_ALIAS_MAP[up];
      if (lc)                           { lingua = lc;       continue; }
      // Non è un modificatore noto: fa parte della nota libera.
      notaTokens.push(t);
    }
    const notaBulk = notaTokens.join(' ');
    return { codice: nomeParte, lingua, condizione, qty: 1, reverse, oloType: '', firstEd, notaBulk };
  }

  // ── FORMATO STORICO (nessuna virgola) ────────────────────────────────────
  // Ogni token è testato come lingua, condizione, reverse holo o prima
  // edizione; tutto il resto è parte della query (codice set oppure
  // nome+numero — la ricerca Cardmarket è unificata). Mantenuto per
  // compatibilità con le liste già scritte così — ma ambiguo per nomi che
  // contengono parole-modificatore (es. "Mew EX" verrebbe letto come "Mew"
  // + condizione EX). Per questi casi usa il formato con virgola sopra.
  //
  // Nota bene: qui NON è possibile aggiungere una nota libera come nel
  // formato con virgola — un token non riconosciuto in questo formato è
  // sempre parte del nome/codice (es. "Eevee 55"), non c'è modo affidabile
  // di distinguere "parola in più del nome" da "nota libera finale" senza
  // il separatore esplicito. Per aggiungere una nota usa il formato con
  // virgola: "CODICE, CONDIZIONE nota libera".
  const tokens = rigaTrim.split(/\s+/);
  const tokensCodice = [];
  let lingua = 'IT', condizione = 'NM', reverse = false, firstEd = false;

  for (const t of tokens) {
    const up = t.toUpperCase();
    if (REVERSE_TOKEN.has(up))        { reverse = true;   continue; }
    if (FIRST_ED_TOKEN.has(up))       { firstEd = true;    continue; }
    const _condTok = _condizioneToken(up);
    if (_condTok)                     { condizione = _condTok; continue; }
    const lc = LINGUA_ALIAS_MAP[up];
    if (lc)                           { lingua = lc;       continue; }
    tokensCodice.push(t);
  }

  const codice = tokensCodice.join(' ').trim();
  if (!codice) return null;
  return { codice, lingua, condizione, qty: 1, reverse, oloType: '', firstEd, notaBulk: '' };
}

// ── AGGIUNGI BULK ─────────────────────────────────────────────────────────────
// FIX (tabella streaming): riusata dal motore a coda più sotto — non
// significa più "una sessione batch è in corso" ma "il ciclo di
// elaborazione della coda è attivo in questo momento" (può fermarsi e
// ripartire più volte nella stessa apertura di pagina, ogni volta che la
// coda si svuota e poi arriva una nuova riga).
let _bulkAttivo = false;

// ── BACKOFF ADATTIVO CLOUDFLARE ──────────────────────────────────────────────
// FIX (troppi blocchi Cloudflare durante liste lunghe): prima il delay tra
// una carta e la successiva restava sempre quello scelto nello slider,
// anche se durante la sessione Cloudflare era appena scattato — nessuna
// reazione al segnale più diretto possibile che il ritmo attuale sta
// destando sospetti. background.js (vedi _suonaEPortaInPrimoPiano) ora
// trasmette un evento leggero ogni volta che rileva davvero un challenge
// Cloudflare in questo flusso ('carte'). _cfEscalationLevel sale di un
// gradino a ogni blocco (fino al massimo consentito dagli stessi range
// dello slider Delay) e scende di un gradino a ogni carta processata senza
// nuovi blocchi — il ritmo si allunga temporaneamente dopo un blocco e
// torna da solo a quello scelto dall'utente una volta che la sessione
// prosegue pulita.
let _cfEscalationLevel = 0;
let _cfHitPendente = false;

chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'CLOUDFLARE_HIT_BULK' && message.kind === 'carte') {
    _cfHitPendente = true;
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// MOTORE A CODA (tabella streaming) — sostituisce il vecchio avviaSessioneBulk
// basato su array fisso. Ogni riga confermata nella tabella (Invio / incolla
// / file / pannello "Incolla lista" / ripresa sessione) entra in _codaInvio
// e viene elaborata una alla volta, non appena possibile — non serve più un
// bottone "avvia" separato: la coda parte da sola alla prima conferma e
// continua a "mangiare" nuove righe finché arrivano o finché l'utente preme
// "🛑 Ferma coda". Riusa IDENTICI: worker tab (_inviaMessaggioConWatchdog),
// backoff Cloudflare (_cfEscalationLevel/_cfHitPendente, dichiarati sopra),
// gestione rate limit, pannello di correzione manuale esistente
// (_codaCorrezione/_mostraProssimaCorrezione), modale login "Team Rocket",
// audio keep-alive. Vedi mockup_tabella_carte.html per il comportamento di
// riferimento su cui questo motore è stato modellato.
let _codaInvio = [];           // righe confermate, non ancora completate
let _stopRichiesto = false;    // true quando l'utente preme "🛑 Ferma coda"
let _posizioneAssoluta = 0;    // per "pausa ogni N carte" e numerazione, persistita per la ripresa
let _rigaApertaRefs = null;    // riferimenti della riga vuota "in scrittura" in fondo alla tabella
let _numRigaTabella = 0;       // solo per il numero progressivo mostrato nella colonna #
let _okSessione = 0;           // contatore vivo per il messaggio "✔ aggiunta/e" sotto la tabella

function aggiornaCodaBadge() {
  const badge = document.getElementById('codaBadge');
  if (badge) badge.textContent = `${_codaInvio.length} in coda`;
}

function _creaSelectMini(opzioni, valoreDefault) {
  const sel = document.createElement('select');
  opzioni.forEach((o) => {
    const opt = document.createElement('option');
    opt.value = o; opt.textContent = o;
    if (o === valoreDefault) opt.selected = true;
    sel.appendChild(opt);
  });
  return sel;
}

// Applica dati già interpretati (da parsaBulkRiga, o da una riga salvata per
// la ripresa sessione) ai controlli di una riga della tabella — usata da
// incolla, "Incolla lista", caricamento file e ripresa sessione, così tutti
// e quattro i percorsi si comportano allo stesso modo.
function _applicaDatiARiga(refs, dati) {
  refs.inputCodice.value = dati.codice || '';
  refs.selLingua.value = LINGUE_CORREZIONE.includes(dati.lingua) ? dati.lingua : 'IT';
  refs.selCond.value = CONDIZIONI_CORREZIONE.includes(dati.condizione) ? dati.condizione : 'NM';
  refs.btnRh.classList.toggle('on', !!dati.reverse || dati.oloType === 'RH');
  refs.btn1ed.classList.toggle('on', !!dati.firstEd);
  refs.inputQty.value = dati.qty || 1;
  refs.inputNote.value = dati.notaBulk || '';
}

// Crea una nuova riga vuota "pronta per la carta successiva" in fondo alla
// tabella e la registra come _rigaApertaRefs — l'unica riga non ancora
// confermata in ogni momento (invariante mantenuta da confermaRigaTabella).
function nuovaRigaTabella() {
  const tbodyCarte = document.getElementById('tbodyCarte');
  _numRigaTabella++;
  const tr = document.createElement('tr');
  tr.className = 'riga-nuova';

  const tdNum = document.createElement('td');
  tdNum.className = 'num-riga';
  tdNum.textContent = _numRigaTabella;
  tr.appendChild(tdNum);

  const tdCodice = document.createElement('td');
  const inputCodice = document.createElement('input');
  inputCodice.type = 'text';
  inputCodice.placeholder = 'es. MEW008, Eevee 55…';
  tdCodice.appendChild(inputCodice);
  tr.appendChild(tdCodice);

  const tdLingua = document.createElement('td');
  tdLingua.className = 'col-lang';
  const selLingua = _creaSelectMini(LINGUE_CORREZIONE, 'IT');
  tdLingua.appendChild(selLingua);
  tr.appendChild(tdLingua);

  const tdCond = document.createElement('td');
  tdCond.className = 'col-cond';
  const selCond = _creaSelectMini(CONDIZIONI_CORREZIONE, 'NM');
  tdCond.appendChild(selCond);
  tr.appendChild(tdCond);

  const tdRh = document.createElement('td');
  tdRh.className = 'col-var';
  const btnRh = document.createElement('div');
  btnRh.className = 'var-toggle';
  btnRh.textContent = 'RH';
  btnRh.title = 'Reverse Holo';
  btnRh.addEventListener('click', () => btnRh.classList.toggle('on'));
  tdRh.appendChild(btnRh);
  tr.appendChild(tdRh);

  const td1ed = document.createElement('td');
  td1ed.className = 'col-var';
  const btn1ed = document.createElement('div');
  btn1ed.className = 'var-toggle';
  btn1ed.textContent = '1ª';
  btn1ed.title = 'Prima Edizione';
  btn1ed.addEventListener('click', () => btn1ed.classList.toggle('on'));
  td1ed.appendChild(btn1ed);
  tr.appendChild(td1ed);

  const tdQty = document.createElement('td');
  tdQty.className = 'col-qty';
  const qtyRow = document.createElement('div');
  qtyRow.className = 'qty-row';
  const btnMinus = document.createElement('button');
  btnMinus.type = 'button'; btnMinus.className = 'qty-btn'; btnMinus.textContent = '−';
  const inputQty = document.createElement('input');
  inputQty.type = 'text'; inputQty.value = '1';
  const btnPlus = document.createElement('button');
  btnPlus.type = 'button'; btnPlus.className = 'qty-btn'; btnPlus.textContent = '+';
  btnMinus.addEventListener('click', () => { inputQty.value = Math.max(1, (parseInt(inputQty.value, 10) || 1) - 1); });
  btnPlus.addEventListener('click', () => { inputQty.value = (parseInt(inputQty.value, 10) || 1) + 1; });
  qtyRow.appendChild(btnMinus); qtyRow.appendChild(inputQty); qtyRow.appendChild(btnPlus);
  tdQty.appendChild(qtyRow);
  tr.appendChild(tdQty);

  const tdNote = document.createElement('td');
  tdNote.className = 'col-note';
  const inputNote = document.createElement('input');
  inputNote.type = 'text';
  inputNote.placeholder = 'facoltativa';
  inputNote.title = 'Nota libera per questa carta (colonna Note)';
  tdNote.appendChild(inputNote);
  tr.appendChild(tdNote);

  const tdStato = document.createElement('td');
  tdStato.className = 'col-stato';
  tdStato.innerHTML = '<span class="stato-nuova">in scrittura…</span>';
  tr.appendChild(tdStato);

  const tdRemove = document.createElement('td');
  const btnRemove = document.createElement('button');
  btnRemove.type = 'button';
  btnRemove.className = 'btn-remove-riga';
  btnRemove.textContent = '✕';
  btnRemove.title = 'Rimuovi riga';
  btnRemove.addEventListener('click', () => {
    // FIX: se la riga è già stata presa in carico dal ciclo di elaborazione
    // (spostata da _codaInvio a "in lettura"), non la troviamo più
    // nell'array — rimuoverla dal DOM in quel caso lascia comunque
    // completare la richiesta in corso in background (stessa cosa che
    // succederebbe cambiando pagina): il log/foglio restano coerenti, solo
    // la riga sparisce dalla vista un po' prima del previsto.
    const idx = _codaInvio.findIndex((it) => it.tr === tr);
    if (idx !== -1) { _codaInvio.splice(idx, 1); aggiornaCodaBadge(); _salvaStatoSessione(); }
    tr.remove();
  });
  tdRemove.appendChild(btnRemove);
  tr.appendChild(tdRemove);

  tbodyCarte.appendChild(tr);

  const refs = { tr, inputCodice, selLingua, selCond, btnRh, btn1ed, inputQty, inputNote, tdStato, btnRemove };

  // Auto-maiuscolo sul campo codice, coerente col resto dell'estensione.
  inputCodice.addEventListener('input', (e) => {
    const el = e.target;
    const start = el.selectionStart, end = el.selectionEnd;
    el.value = el.value.toUpperCase();
    el.setSelectionRange(start, end);
  });

  inputCodice.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); confermaRigaTabella(refs); }
  });
  // Invio anche dal campo Note conferma la riga — comodo per chi ci passa
  // per aggiungere una nota prima di confermare.
  inputNote.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); confermaRigaTabella(refs); }
  });

  // Incolla (anche una sola riga): passa dal parser bulk esistente
  // (parsaBulkRiga, invariato) così lingua/condizione/RH/1ED/nota scritti
  // nel testo copiato con la sintassi di sempre (es. "OBF205 EN" o
  // "Mew EX, EX RH") vengono riconosciuti e popolano i controlli invece di
  // restare testo grezzo nel campo Codice. Ogni riga incollata conferma la
  // riga aperta corrente e ne apre una nuova, in sequenza — _rigaApertaRefs
  // punta sempre alla riga vuota giusta, aggiornata da confermaRigaTabella.
  inputCodice.addEventListener('paste', (e) => {
    e.preventDefault();
    const testo = (e.clipboardData || window.clipboardData).getData('text');
    const righe = testo.split('\n').map((r) => r.trim()).filter(Boolean);
    _confermaRigheInBlocco(righe, parsaBulkRiga);
  });

  inputCodice.focus();
  _rigaApertaRefs = refs;
  return refs;
}

// Rimuove dalla tabella una carta riuscita (o fallita/ambigua, dopo averla
// già instradata al pannello di correzione manuale) con una breve
// animazione — vedi mockup_tabella_carte.html. La tabella mostra così
// sempre solo ciò che è ancora "vivo" (in coda o in lettura).
function rimuoviRigaConRitardo(tr, attesaMs) {
  setTimeout(() => {
    tr.classList.add('riga-in-uscita');
    setTimeout(() => {
      tr.classList.add('riga-collassa');
      setTimeout(() => tr.remove(), 360);
    }, 350);
  }, attesaMs);
}

function contrassegnaEsitoERimuovi(item, tipo, testoPill, opzioni) {
  item.tr.className = tipo === 'ok' ? 'riga-ok' : 'riga-err';
  item.tdStato.innerHTML = `<span class="stato-pill stato-${tipo}">${testoPill}</span>`;
  if (item.btnRemove) item.btnRemove.style.visibility = 'hidden';
  rimuoviRigaConRitardo(item.tr, tipo === 'ok' ? 900 : 700);

  // FASE ordini "aggiungi_carte" (coda persistente su Supabase): se questa
  // riga proviene da 'coda_carte' (dbRigaId presente — vedi
  // _confermaRigheDaDb più sotto), scrive subito l'esito sulla riga del
  // database. Così l'esito sopravvive anche se questa tab/PC si spegne
  // subito dopo, e resta visibile da qualunque altro dispositivo.
  if (item.dbRigaId) {
    if (tipo === 'ok') {
      supabaseClient.from('coda_carte')
        .update({ stato: 'completato', completato_il: new Date().toISOString() })
        .eq('id', item.dbRigaId)
        .then(({ error }) => { if (error) console.error('[coda_carte] impossibile scrivere l\'esito:', error.message); });
    } else {
      // FIX (sessione 21/08/2026, gap segnalato: questo flusso manuale
      // scriveva stato='errore' su coda_carte e finiva lì — index.html non
      // legge più quello stato, solo 'correzioni_manuali_carte' (vedi
      // sposta_riga_in_correzione_manuale). Stessa soglia/pattern del
      // worker autonomo (background.js/_segnaTentativoFallitoAutonomo):
      // sotto i 3 tentativi torna 'pending' e viene ritentata (da questo
      // stesso popup, ogni 20s, o da un altro dispositivo/dal worker
      // autonomo); al 3° fallimento va in correzione manuale via RPC.
      // Nessuna esclusione del device che ha appena fallito dal re-claim
      // immediato (opzione 1, confermata da Claudio) — cadenza ravvicinata
      // accettata come rischio pratico basso.
      const tentativi = (item.tentativiFalliti || 0) + 1;
      const SOGLIA_CORREZIONE_MANUALE = 3; // stessa soglia del worker autonomo
      const opzioniValide = (Array.isArray(opzioni) && opzioni.length > 0) ? opzioni : null;

      if (tentativi >= SOGLIA_CORREZIONE_MANUALE) {
        supabaseClient.rpc('sposta_riga_in_correzione_manuale', {
          p_riga_id: item.dbRigaId,
          p_errore_msg: `${testoPill} (dopo ${tentativi} tentativi)`,
          p_opzioni: opzioniValide,
        }).then(({ error }) => {
          if (error) {
            console.error('[coda_carte] impossibile spostare in correzione manuale:', error.message);
            // Rete di sicurezza: se la RPC fallisce (es. migration non
            // eseguita), la riga NON deve sparire — resta 'pending', verrà
            // ritentata con lo stesso contatore invece di bloccarsi.
            supabaseClient.from('coda_carte')
              .update({ stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi })
              .eq('id', item.dbRigaId)
              .then(({ error: errFallback }) => { if (errFallback) console.error('[coda_carte] fallback pending fallito:', errFallback.message); });
          }
        });
      } else {
        supabaseClient.from('coda_carte').update({
          stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi,
          errore_msg: testoPill,
          // FIX (disambiguazioni invisibili sul sito): prima le opzioni
          // trovate (es. 3 possibili corrispondenze) restavano visibili
          // solo qui nell'estensione — sul sito arrivava solo un
          // messaggio generico "non trovata". Ora, quando ci sono, le
          // salviamo così la sezione "Carte con problemi" del sito può
          // mostrarle come scelte cliccabili invece di far ridigitare il
          // nome a mano e sperare.
          opzioni_disambiguazione: opzioniValide,
        }).eq('id', item.dbRigaId).then(({ error }) => {
          if (error) console.error('[coda_carte] impossibile scrivere l\'esito:', error.message);
        });
      }
    }
  }
}

// Accoda una carta non risolta automaticamente nel pannello di correzione
// manuale ESISTENTE (_codaCorrezione/_mostraProssimaCorrezione, invariati)
// invece di duplicare quella UI dentro la tabella — stessa esperienza
// collaudata di sempre, ora alimentata carta per carta invece che in blocco
// a fine sessione.
function _accodaCorrezioneReale(dati) {
  _codaCorrezione.push({
    codice: dati.codice, lingua: dati.lingua, condizione: dati.condizione, qty: dati.qty,
    oloType: dati.oloType, reverse: dati.reverse, firstEd: dati.firstEd, notaBulk: dati.notaBulk,
    opzioni: dati.opzioni || [],
    // FIX (bug [5]+[6]): prima questi 4 campi andavano persi appena una riga
    // entrava in correzione manuale — un sealed non risolto finiva in un
    // vicolo cieco (pannello sempre instradato su carta singola/Singles), e
    // una carta della coda condivisa (dbRigaId) completata a mano finiva
    // intestata a chi corregge invece che al vero richiedente. La location
    // resta INVARIATA di proposito (quella del dispositivo che corregge —
    // decisione esplicita di Claudio, 20/08/2026).
    tipo: dati.tipo, dbRigaId: dati.dbRigaId, destinazione: dati.destinazione,
    prezzoObiettivo: dati.prezzoObiettivo,
  });
  _codaCorrezioneTot++;
  _mostraProssimaCorrezione();
}

function confermaRigaTabella(refs, extra = {}) {
  const codice = refs.inputCodice.value.trim();
  if (!codice) return;

  refs.tr.className = 'riga-coda';
  refs.tr.querySelectorAll('input, select').forEach((el) => { el.disabled = true; });
  refs.tr.querySelectorAll('.var-toggle').forEach((el) => { el.style.pointerEvents = 'none'; el.style.opacity = '0.65'; });
  refs.tdStato.innerHTML = '<span class="stato-pill stato-coda">⏳ in coda</span>';

  const item = {
    tr: refs.tr, tdStato: refs.tdStato, btnRemove: refs.btnRemove,
    codice,
    lingua: refs.selLingua.value,
    condizione: refs.selCond.value,
    reverse: refs.btnRh.classList.contains('on'),
    oloType: refs.btnRh.classList.contains('on') ? 'RH' : '',
    firstEd: refs.btn1ed.classList.contains('on'),
    qty: parseInt(refs.inputQty.value, 10) || 1,
    notaBulk: refs.inputNote.value.trim(),
    rateLimitRetries: 0,
    ...extra, // FASE ordini: dbRigaId, se la riga viene da coda_carte
  };
  _codaInvio.push(item);
  aggiornaCodaBadge();
  _salvaStatoSessione();
  avviaElaborazioneCoda();

  if (refs === _rigaApertaRefs) nuovaRigaTabella();
}

// FIX (bug "Chrome freeza incollando una lista"): oltre al debounce dello
// storage (vedi _salvaStatoSessione), anche la sola CREAZIONE di centinaia
// di righe tabella una dietro l'altra nello stesso istante sincrono
// (ognuna con ~15 nodi DOM tra select/input/toggle) può bloccare
// percettibilmente il thread principale su liste molto lunghe. Questo
// helper condiviso da incolla/file/"Metti in coda"/ripresa sessione
// elabora un lotto di righe alla volta e poi cede il controllo al browser
// (un giro di setTimeout) prima di continuare — la pagina resta reattiva
// (si vede la coda popolarsi progressivamente) invece di "sparire" per
// tutta la durata dell'inserimento.
const _LOTTO_CONFERMA_RIGHE = 25;
async function _confermaRigheInBlocco(elementi, parseFn) {
  for (let i = 0; i < elementi.length; i++) {
    const parsed = parseFn(elementi[i]);
    if (parsed) {
      _applicaDatiARiga(_rigaApertaRefs, parsed);
      confermaRigaTabella(_rigaApertaRefs, {
        ...(parsed.dbRigaId ? { dbRigaId: parsed.dbRigaId } : {}),
        ...(parsed.location ? { location: parsed.location } : {}),
        ...(parsed.tipo ? { tipo: parsed.tipo } : {}),
        ...(parsed.destinazione ? { destinazione: parsed.destinazione } : {}),
        ...(parsed.prezzoObiettivo != null ? { prezzoObiettivo: parsed.prezzoObiettivo } : {}),
        ...(parsed.urlDiretto ? { urlDiretto: parsed.urlDiretto } : {}),
        ...(parsed.tentativiFalliti != null ? { tentativiFalliti: parsed.tentativiFalliti } : {}),
      });
    }
    if ((i + 1) % _LOTTO_CONFERMA_RIGHE === 0) {
      await new Promise((r) => setTimeout(r, 0));
    }
  }
}

// Serializza SOLO i dati (mai i riferimenti DOM) della coda non ancora
// completata, per la ripresa di una sessione interrotta digitata/incollata
// A MANO (nessun dbRigaId). Le righe arrivate da 'coda_carte' (dbRigaId
// presente) sono ESCLUSE di proposito: hanno già la propria persistenza sul
// database (stato/claimed_at nella tabella coda_carte + rilascio immediato
// alla chiusura, vedi _rilasciaClaimAllaChiusura) — includerle ANCHE qui
// significava una doppia ripresa: al riavvio, _avviaAutorunSeRichiesto/la
// ripresa automatica qui sotto le rimetteva in coda dalla copia locale, E
// _recuperaAltreRigheDaDb le ripescava ANCHE dal database (tornate
// 'pending' proprio grazie al rilascio alla chiusura) — stessa carta
// accodata due volte, cercata e aggiunta due volte alla collezione.
function _serializzaCoda() {
  return _codaInvio
    .filter((it) => !it.dbRigaId)
    .map((it) => ({
      codice: it.codice, lingua: it.lingua, condizione: it.condizione, qty: it.qty,
      oloType: it.oloType, reverse: it.reverse, firstEd: it.firstEd, notaBulk: it.notaBulk,
    }));
}

// FIX (bug "Chrome freeza incollando una lista"): confermaRigaTabella
// chiamava questa funzione ad OGNI riga confermata — durante un incolla/
// caricamento file/"Metti in coda" con centinaia di righe, questo
// significava centinaia di chiamate sincrone consecutive, ognuna che
// riserializza l'INTERA coda accumulata fino a quel momento
// (_serializzaCoda è O(n)) e scrive su chrome.storage.local: lavoro totale
// O(n²), abbastanza da bloccare percettibilmente il thread principale su
// liste lunghe. Debounce: durante un ciclo di conferme ravvicinate, solo
// l'ULTIMA chiamata produce davvero una scrittura, ~350ms dopo l'ultima
// modifica — nessuna perdita di dati per la ripresa sessione, dato che i
// veri "tick" di elaborazione carte sono comunque distanziati di secondi.
let _salvaStatoTimer = null;
function _salvaStatoSessione() {
  if (_salvaStatoTimer) clearTimeout(_salvaStatoTimer);
  _salvaStatoTimer = setTimeout(() => {
    _salvaStatoTimer = null;
    const righe = _serializzaCoda();
    if (righe.length === 0) { chrome.storage.local.remove('bulkSessione'); return; }
    chrome.storage.local.set({ bulkSessione: { righe, posizioneAssoluta: _posizioneAssoluta } });
  }, 350);
}

// Il bottone "🛑 Ferma coda"/"▶ Riprendi coda" (id invariato: btnBulkAggiungi,
// stesso di sempre — vedi CSS/temi che già lo targetizzano) cambia stato in
// base a cosa sta succedendo, invece di avviare la sessione come prima:
// nascosto quando non c'è nulla da fare, "Ferma" mentre la coda è attiva,
// "Riprendi" se sono rimaste righe in coda ma l'elaborazione si è fermata
// (stop manuale, o login non riuscito).
function aggiornaBottoneFerma() {
  const btn = document.getElementById('btnBulkAggiungi');
  if (!btn) return;
  if (_bulkAttivo) {
    btn.style.display = '';
    btn.disabled = false;
    btn.textContent = '🛑 Ferma coda';
    btn.onclick = () => {
      _stopRichiesto = true;
      btn.disabled = true;
      btn.textContent = '⏱️ Arresto…';
      setStatus('⏳ Finisco la carta attuale e mi fermo…', 'info');
    };
  } else if (_codaInvio.length > 0) {
    btn.style.display = '';
    btn.disabled = false;
    btn.textContent = '▶ Riprendi coda';
    btn.onclick = () => avviaElaborazioneCoda();
  } else {
    btn.style.display = 'none';
  }
}

async function avviaElaborazioneCoda() {
  if (_bulkAttivo) return; // il ciclo già in corso prenderà da solo la nuova riga
  _bulkAttivo = true;
  _stopRichiesto = false;
  aggiornaBottoneFerma();
  avviaAudioKeepAlive();

  if (!(await verificaAccessoValido())) {
    _bulkAttivo = false;
    fermaAudioKeepAlive();
    aggiornaBottoneFerma();
    return; // account bannato/eliminato: overlay già mostrato da auth_ui.js
  }

  const loginOk = await _richiediConfermaLogin();
  if (!loginOk) {
    _bulkAttivo = false;
    fermaAudioKeepAlive();
    aggiornaBottoneFerma(); // mostrerà "▶ Riprendi coda" se sono rimaste righe
    return;
  }
  await _loopElaborazioneCoda();
}

async function _loopElaborazioneCoda() {
  while (!_stopRichiesto) {
    if (_codaInvio.length === 0) {
      // Con lotti da 1 (vedi _LOTTO_RECUPERO_DB), il tempo naturale di
      // ricerca/elaborazione di ogni carta (diversi secondi, per non
      // sembrare un bot su Cardmarket) è già sufficiente a lasciare spazio
      // ad altri dispositivi online per reclamare la carta successiva —
      // nessuna pausa artificiale aggiuntiva necessaria qui: appena finita
      // una carta, si controlla subito se ce n'è un'altra ancora libera.
      //
      // FIX: se due dispositivi scelgono la STESSA riga nello stesso
      // istante, uno dei due "perde" quel singolo tentativo (la vede già
      // presa quando prova a claimarla) — _codaInvio resta vuota anche se
      // la coda in realtà ha ancora altre carte in attesa. Prima questo
      // faceva chiudere subito la sessione ("completata"), lasciando quel
      // dispositivo fermo fino al prossimo giro periodico (fino a 20s).
      // Qualche breve nuovo tentativo qui, prima di arrendersi davvero,
      // risolve il caso senza dover aspettare.
      for (let tentativo = 0; tentativo < 3 && _codaInvio.length === 0; tentativo++) {
        if (tentativo > 0) await new Promise(r => setTimeout(r, 400 + Math.floor(Math.random() * 400)));
        await _recuperaAltreRigheDaDb();
      }
      if (_codaInvio.length === 0) break;
    }
    const item = _codaInvio.shift();
    aggiornaCodaBadge();
    const completata = await _elaboraCarta(item);
    // FIX: se la carta è stata rimessa in coda (stop richiesto durante una
    // pausa rate-limit — vedi _elaboraCarta) NON va contata come processata,
    // altrimenti "pausa ogni N carte" perderebbe il conteggio corretto.
    if (completata) _posizioneAssoluta++;
    _salvaStatoSessione();
    if (_stopRichiesto) break;
    if (_codaInvio.length > 0) await _attendiDelayCoda();
  }

  _bulkAttivo = false;
  fermaAudioKeepAlive();
  const timerRiga = document.getElementById('timerRigaAttiva');
  if (timerRiga) timerRiga.classList.remove('visible');
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'carte' });

  if (_codaInvio.length === 0) {
    setStatus(`✅ Coda completata — ${_okSessione} cart${_okSessione === 1 ? 'a aggiunta' : 'e aggiunte'} in questa sessione.`, 'ok');
  } else if (_stopRichiesto) {
    setStatus(`🛑 Interrotto. ${_codaInvio.length} cart${_codaInvio.length === 1 ? 'a' : 'e'} ancora in coda — "▶ Riprendi coda" per continuare.`, 'info');
  }
  aggiornaBottoneFerma();
  _stopRichiesto = false;
}

async function _attendiConCountdownCoda(ms, etichetta) {
  const fineAttesa = Date.now() + ms;
  const timerRiga = document.getElementById('timerRigaAttiva');
  const timerCountdown = document.getElementById('timerCountdownAttiva');
  if (timerRiga) timerRiga.classList.add('visible');
  while (Date.now() < fineAttesa) {
    if (_stopRichiesto) return;
    const restante = Math.max(0, fineAttesa - Date.now());
    const totSec = Math.ceil(restante / 1000);
    const m = Math.floor(totSec / 60), s = totSec % 60;
    const testo = `${m > 0 ? m + 'm ' : ''}${s}s`;
    if (timerCountdown) timerCountdown.textContent = etichetta ? `${etichetta} ${testo}` : testo;
    await new Promise((r) => setTimeout(r, 1000));
  }
}

// Stesso ritmo anti-blocco di sempre (delay min/max configurabile, pausa
// ogni N carte, backoff adattivo Cloudflare) — solo _posizioneAssoluta al
// posto dell'indice nell'array fisso di prima.
async function _attendiDelayCoda() {
  const savedPausa = await new Promise((r) => chrome.storage.local.get(
    ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderPausaOgni'], r));
  const pausaOgniValues = [25, 50, 75, 100, Infinity];
  const pausaOgniN = pausaOgniValues[savedPausa.sliderPausaOgni ?? 1] ?? 50;

  if (_cfHitPendente) {
    _cfEscalationLevel = Math.min(_cfEscalationLevel + 1, CF_ESCALATION_MAX_LEVEL);
    _cfHitPendente = false;
    aggiungiLog('⚠️ Cloudflare rilevato — rallento temporaneamente il ritmo tra le carte', '');
  } else if (_cfEscalationLevel > 0) {
    _cfEscalationLevel--;
  }

  if (_posizioneAssoluta > 0 && _posizioneAssoluta % pausaOgniN === 0) {
    await _attendiConCountdownCoda(30000, 'Pausa anti-quota —');
  } else {
    let dMinSec = savedPausa.sliderDelayMinSec;
    let dMaxSec = savedPausa.sliderDelayMaxSec;
    if (dMinSec === undefined || dMaxSec === undefined) {
      if (typeof savedPausa.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[savedPausa.sliderDelay]) {
        [dMinSec, dMaxSec] = LEGACY_DELAY_RANGES_SEC[savedPausa.sliderDelay];
      } else {
        dMinSec = DEFAULT_DELAY_MIN_SEC;
        dMaxSec = DEFAULT_DELAY_MAX_SEC;
      }
    }
    const dMin = dMinSec * 1000;
    const dMax = Math.max(dMaxSec, dMinSec) * 1000;
    const MARGINE_RIUSO_TAB_MS = 1200;
    const margineCfMs = _cfEscalationLevel * CF_ESCALATION_STEP_SEC * 1000;
    const delayMs = dMin + Math.floor(Math.random() * (dMax - dMin)) + MARGINE_RIUSO_TAB_MS + margineCfMs;
    await _attendiConCountdownCoda(delayMs, _cfEscalationLevel > 0 ? 'Prossima tra (rallentato)' : 'Prossima tra');
  }
}

// Se la carta è stata inserita ma senza prezzo, aspetta il delay
// configurato e rilegge SOLO il prezzo dalla pagina già risolta — identica
// a prima, non tocca la tabella (opera sulla riga già scritta nel foglio).
async function _ricontrollaPrezzoMancante(riga, urlConFiltri, etichetta, nomeMancante = false) {
  if (!riga || !urlConFiltri) return;
  const saved = await new Promise((r) => chrome.storage.local.get(['sliderRicontrollo'], r));
  const idx = saved.sliderRicontrollo ?? 2;
  const secondi = RICONTROLLO_SECONDI[idx] ?? 20;
  if (secondi <= 0 || _stopRichiesto) return;

  aggiungiLog(`${etichetta} — prezzo mancante, ricontrollo tra ${secondi}s…`, '');
  await _attendiConCountdownCoda(secondi * 1000, 'Ricontrollo prezzo tra');
  if (_stopRichiesto) return;

  try {
    const timeoutMsRicontrollo = await _timeoutLetturaCarta();
    const ris = await _inviaMessaggioConWatchdog({ type: 'LEGGI_SOLO_PREZZO', urlConFiltri, usaWorkerTab: true }, timeoutMsRicontrollo);

    const aggiornamenti = {};
    if (ris && ris.prezzo != null) aggiornamenti.prezzo = ris.prezzo;
    if (nomeMancante && ris && ris.nome) {
      aggiornamenti.nome = ris.nome;
      if (ris.codice) aggiornamenti.codice = ris.codice;
    }

    if (Object.keys(aggiornamenti).length > 0) {
      const esitoAgg = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
          type: 'AGGIUNGI_CARTA',
          azione: 'aggiornaPrezzo', riga,
          prezzo: aggiornamenti.prezzo,
          nome: aggiornamenti.nome || null, codice: aggiornamenti.codice || null,
        }, (r) => { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r); });
      });
      if (esitoAgg && esitoAgg.ok) {
        const parti = [];
        if (aggiornamenti.prezzo != null) parti.push(`prezzo ${aggiornamenti.prezzo}€`);
        if (aggiornamenti.nome) parti.push(`nome "${aggiornamenti.nome}"`);
        aggiungiLog(`${etichetta} — ${parti.join(' e ')} recuperat${parti.length > 1 ? 'i' : 'o'} al ricontrollo (R${riga})`, 'ok');
      } else {
        aggiungiLog(`${etichetta} — dati trovati ma scrittura fallita: ${esitoAgg?.errore || '?'}`, 'err');
      }
    } else {
      aggiungiLog(`${etichetta} — prezzo ancora non disponibile dopo il ricontrollo`, 'err');
    }
  } catch (e) {
    aggiungiLog(`${etichetta} — errore nel ricontrollo prezzo: ${e.message}`, 'err');
  }
}

// Elabora una singola carta: stessa identica logica di richiesta/backoff/
// scrittura del vecchio ciclo bulk, solo estratta in una funzione a sé che
// riceve un item della coda invece di un indice in un array fisso.
// Restituisce true se la carta è stata completata (riuscita o instradata al
// pannello di correzione — in entrambi i casi "conta" ai fini di "pausa ogni
// N carte"), false se è stata rimessa in cima alla coda senza essere
// processata (stop richiesto durante una pausa rate-limit).
async function _elaboraCarta(item) {
  const { codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk } = item;
  const isSealed = item.tipo === 'sealed';
  const isWishlist = item.destinazione === 'wishlist';

  item.tr.className = 'riga-lettura';
  item.tdStato.innerHTML = '<span class="stato-pill stato-lettura"><span class="spin-mini"></span> lettura…</span>';
  if (item.btnRemove) item.btnRemove.style.visibility = 'hidden';
  const timerCarta = document.getElementById('timerCartaAttiva');
  const timerCountdown = document.getElementById('timerCountdownAttiva');
  const timerRiga = document.getElementById('timerRigaAttiva');
  if (timerRiga) timerRiga.classList.add('visible');
  if (timerCarta) timerCarta.textContent = codice;
  if (timerCountdown) timerCountdown.textContent = '—';
  setStatus(`⏳ Processo: ${codice}…`, 'info');

  const timeoutLettura = await _timeoutLetturaCarta();

  // eslint-disable-next-line no-constant-condition
  while (true) {
    let risposta;
    try {
      if (isSealed) {
        risposta = await _inviaMessaggioConWatchdog({
          type: 'LEGGI_SEALED', urlNome: urlRicercaSealed(codice, lingua), lingua, usaWorkerTab: true,
        }, timeoutLettura);
      } else {
        // FIX (disambiguazione che rimandava a un'altra ricerca ambigua):
        // se questa riga viene da una scelta fatta sul sito tra più
        // opzioni trovate, item.urlDiretto contiene il link ESATTO di
        // quella carta — passandolo qui al posto di una nuova ricerca per
        // nome, _risolviSinglesENomeFetch lo riconosce già come pagina
        // prodotto diretta (contiene "/Singles/") e legge da lì, senza
        // rischiare di ripescare più corrispondenze come prima.
        risposta = await _inviaMessaggioConWatchdog({
          type: 'LEGGI_NOME_CARTA', urlNome: item.urlDiretto || urlRicerca(codice, ''), lingua, condizione,
          oloType: oloType || (reverse ? 'RH' : ''), firstEd: !!firstEd, usaWorkerTab: true,
        }, timeoutLettura);
      }
    } catch (e) {
      aggiungiLog(`${codice} — ${e.message}`, 'err');
      _accodaCorrezioneReale({ codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, opzioni: [], tipo: item.tipo, dbRigaId: item.dbRigaId, destinazione: item.destinazione, prezzoObiettivo: item.prezzoObiettivo });
      contrassegnaEsitoERimuovi(item, 'err', '❌ errore');
      return true;
    }

    if (risposta?.rateLimited) {
      item.rateLimitRetries = (item.rateLimitRetries || 0) + 1;
      aggiungiLog(`${codice} — Error 1015 (rate limited) → pausa 30 min`, 'err');
      setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti…', 'errore');
      item.tdStato.innerHTML = '<span class="stato-pill stato-lettura">☕ pausa rate-limit</span>';
      await _attendiConCountdownCoda(PAUSA_RATE_LIMIT_MS, 'Riprende tra');
      if (_stopRichiesto) {
        // La carta non è stata processata: torna in cima alla coda per il
        // prossimo "▶ Riprendi coda", invece di perdersi.
        item.tr.className = 'riga-coda';
        item.tdStato.innerHTML = '<span class="stato-pill stato-coda">⏳ in coda</span>';
        if (item.btnRemove) item.btnRemove.style.visibility = '';
        _codaInvio.unshift(item);
        aggiornaCodaBadge();
        return false; // rimessa in coda, non completata
      }
      if (item.rateLimitRetries >= 3) {
        aggiungiLog(`${codice} — saltata dopo 3 rate limit consecutivi`, 'err');
        _accodaCorrezioneReale({ codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, opzioni: [], tipo: item.tipo, dbRigaId: item.dbRigaId, destinazione: item.destinazione, prezzoObiettivo: item.prezzoObiettivo });
        contrassegnaEsitoERimuovi(item, 'err', '❌ rate limit');
        return true;
      }
      continue; // ritenta la stessa carta
    }

    const urlTrovato = isSealed ? risposta?.urlProdotto : risposta?.urlSingles;
    if (!urlTrovato) {
      let motivoLog;
      if (isSealed) {
        if (risposta?.disambiguation) motivoLog = 'disambiguazione — correzione manuale';
        else if (risposta === null || risposta === undefined) motivoLog = 'errore di rete / timeout';
        else motivoLog = 'non trovato su Cardmarket';
      } else {
        if (risposta?.varianteNonTrovata) motivoLog = `variante ${oloLabel(reverse, oloType)} non trovata`;
        else if (risposta?.disambiguation) motivoLog = 'disambiguazione — correzione manuale';
        else if (risposta === null || risposta === undefined) motivoLog = 'errore di rete / timeout';
        else motivoLog = 'non trovata su Cardmarket';
      }
      aggiungiLog(`${codice} — ${motivoLog}`, 'err');
      _accodaCorrezioneReale({ codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, opzioni: risposta?.opzioni || [], tipo: item.tipo, dbRigaId: item.dbRigaId, destinazione: item.destinazione, prezzoObiettivo: item.prezzoObiettivo });
      contrassegnaEsitoERimuovi(item, 'err', isSealed ? '❌ non trovato' : '❌ non trovata', risposta?.disambiguation ? risposta.opzioni : null);
      return true;
    }

    // FIX (immagini mancanti/rotte sulle carte NUOVE): questo flusso non ha
    // mai chiamato la conversione dell'immagine — a differenza del
    // controllo prezzi (popup.js), che lo fa da tempo. Scriveva direttamente
    // il link grezzo di Cardmarket (bloccato dall'hotlink protection se
    // aperto da un altro dominio), mostrato solo grazie al proxy di
    // riserva sul sito, mai passato per Supabase Storage come le altre.
    // Stesso schema già usato in popup.js: manda l'URL grezzo a
    // background.js (privilegio di estensione, bypassa CORS), che scarica
    // e carica su Storage, restituendo il link definitivo.
    let immagineConvertita = risposta.immagine || '';
    if (immagineConvertita) {
      try {
        const rispostaImg = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineConvertita }, (r) => resolve(r));
        });
        immagineConvertita = rispostaImg?.immagine || immagineConvertita;
      } catch (_) { /* fallback silenzioso: tiene l'URL grezzo originale */ }
    }

    const codiceFinale = isSealed ? codice : (risposta.codice || codice);
    const rigaDati = isSealed ? {
      [COL.NOME]:       risposta.nome || codice,
      [COL.CODICE]:     '',
      [COL.LOCATION]:   item.location || _leggiLocationCorrente(),
      [COL.QTY]:        qty,
      [COL.LINGUA]:     lingua,
      [COL.CONDIZIONE]: 'NM', // irrilevante per i sealed — nessun concetto di condizione/usura
      [COL.URL]:        risposta.urlProdotto,
      ['I']: risposta.prezzo ?? '',
      [COL.NOTE]: notaBulk || '',
      [COL.IMMAGINE]: immagineConvertita,
    } : {
      [COL.NOME]:       risposta.nome || '',
      [COL.CODICE]:     risposta.codice || codice,
      [COL.LOCATION]:   item.location || _leggiLocationCorrente(),
      [COL.QTY]:        qty,
      [COL.LINGUA]:     lingua,
      [COL.CONDIZIONE]: condizione,
      [COL.URL]:        (() => {
        let u = _costruisciUrlFiltrato(risposta.urlSingles, lingua, condizione);
        return _appendOloParams(u, reverse, oloType, firstEd);
      })(),
      ['I']: risposta.prezzo ?? '',
      [COL.NOTE]: [notaBulk, variantiLabel(reverse, oloType, firstEd, condizione)].filter(Boolean).join(' | '),
      [COL.IMMAGINE]: immagineConvertita,
    };
    if (isWishlist && item.prezzoObiettivo != null) rigaDati[COL.PREZZO_OBIETTIVO] = item.prezzoObiettivo;

    // FIX (bug "coda bloccata per sempre"): questo passo di scrittura NON
    // era protetto da try/catch — a differenza del vecchio ciclo bulk, che
    // avvolgeva l'INTERO corpo (lettura + scrittura) in un solo try/catch.
    // Se chrome.runtime.sendMessage falliva qui (es. service worker
    // riavviato proprio in quel momento), l'eccezione non gestita
    // interrompeva silenziosamente _loopElaborazioneCoda: _bulkAttivo
    // restava bloccato a true per sempre, bottone incastrato su "🛑 Ferma
    // coda", nessun errore mostrato, worker tab mai richiusa. Un fallimento
    // qui viene ora trattato come una carta non trovata: log, pannello di
    // correzione, riga rimossa dalla tabella — invece di rompere la coda.
    let data;
    try {
      data = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          // item.tipo: 'sealed' se questa riga viene dal toggle "📦 Sealed"
          // sul sito (coda_carte.tipo) — passato fino in fondo così finisce
          // scritto sulla colonna 'tipo' della carta, esattamente come fa
          // aggiungi_sealed_popup.js per l'inserimento manuale.
          // item.destinazione: 'wishlist' se la riga viene dalla coda UNICA
          // con destinazione wishlist (vedi coda_unificata.sql) — dice a
          // background.js su quale tabella finale scrivere.
          { type: 'AGGIUNGI_CARTA', rigaDati, tipo: item.tipo || undefined, destinazione: item.destinazione || undefined, dbRigaId: item.dbRigaId || undefined },
          (r) => { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r); }
        );
      });
    } catch (e) {
      aggiungiLog(`${codiceFinale} — ${e.message}`, 'err');
      _accodaCorrezioneReale({ codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, opzioni: [], tipo: item.tipo, dbRigaId: item.dbRigaId, destinazione: item.destinazione, prezzoObiettivo: item.prezzoObiettivo });
      contrassegnaEsitoERimuovi(item, 'err', '❌ errore scrittura');
      return true;
    }

    const oloLog = variantiLabel(reverse, oloType, firstEd, condizione);
    if (!data.ok) {
      aggiungiLog(`${codiceFinale} — errore: ${data.errore || '?'}`, 'err');
      contrassegnaEsitoERimuovi(item, 'err', '❌ scrittura fallita');
      return true;
    }

    aggiungiLog(`R${data.riga} · ${codiceFinale} · ${lingua} · ${condizione}${oloLog ? ' · ' + oloLog : ''}${notaBulk ? ' · 📝 ' + notaBulk : ''}`, 'ok');
    contrassegnaEsitoERimuovi(item, 'ok', `✅ R${data.riga}`);
    _okSessione++;

    const ora = Date.now();
    chrome.storage.local.set({ bulkUltimoUtilizzo: { ts: ora, ok: _okSessione } });
    document.getElementById('ultimaCarta').textContent =
      `✔ ${formattaDataOra(ora)} · ${_okSessione} cart${_okSessione === 1 ? 'a aggiunta' : 'e aggiunte'}`;

    if (rigaDati['I'] === '' || rigaDati['I'] === null || rigaDati['I'] === undefined) {
      const nomeMancante = !rigaDati[COL.NOME];
      await _ricontrollaPrezzoMancante(data.riga, rigaDati[COL.URL], codiceFinale, nomeMancante);
    }
    return true;
  }
}

// ── RILASCIO IMMEDIATO ALLA CHIUSURA ─────────────────────────────────────────
// Le righe "in_corso" tornano disponibili da sole dopo 10 minuti (vedi sopra)
// — ma è una rete di sicurezza per crash/mancanza di corrente, non il
// percorso normale: se chiudi questa tab/estensione volontariamente, le
// carte che questo PC aveva ancora in carico (in coda locale ma non ancora
// completate) devono tornare disponibili SUBITO per un altro PC, non dopo
// 10 minuti di attesa inutile.
//
// A pagina in chiusura (beforeunload/pagehide) non possiamo affidarci ad
// await/promise normali — il browser potrebbe non aspettarle. fetch(...) con
// keepalive:true è pensato apposta per questo caso: la richiesta continua a
// viaggiare anche dopo che la pagina è sparita. Serve però un token di
// sessione già pronto in memoria (niente await qui), tenuto aggiornato da
// onAuthStateChange (il login iniziale e ogni refresh automatico del token).
let _accessTokenCorrente = null;
supabaseClient.auth.onAuthStateChange((_event, session) => {
  _accessTokenCorrente = session?.access_token || null;
});
supabaseClient.auth.getSession().then(({ data }) => {
  _accessTokenCorrente = data?.session?.access_token || null;
});

function _rilasciaClaimAllaChiusura() {
  const ids = _codaInvio.filter((it) => it.dbRigaId).map((it) => it.dbRigaId);
  if (ids.length === 0 || !_accessTokenCorrente) return;
  const filtroIds = ids.map((id) => `"${id}"`).join(',');
  fetch(`${SUPABASE_URL}/rest/v1/coda_carte?id=in.(${filtroIds})`, {
    method: 'PATCH',
    keepalive: true,
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: 'Bearer ' + _accessTokenCorrente,
      'Content-Type': 'application/json',
      Prefer: 'return=minimal',
    },
    body: JSON.stringify({ stato: 'pending', claimed_by: null, claimed_at: null }),
  }).catch(() => {}); // best-effort: se fallisce, restano comunque il fallback dei 10 minuti
}
window.addEventListener('beforeunload', _rilasciaClaimAllaChiusura);
window.addEventListener('pagehide', _rilasciaClaimAllaChiusura);

// ── ORDINI DAL SITO — coda persistente "coda_carte" (Supabase) ──────────────
// A differenza della prima versione (che passava il testo via
// chrome.storage.local, perso se il PC si spegneva), qui il sito scrive
// direttamente una riga per carta nella tabella Supabase 'coda_carte'. Questa
// pagina la "pesca" a lotti, claim-based (stesso pattern già usato per il
// controllo prezzi condiviso in supabase_adapter.js: update con
// .eq('stato','pending') come lock ottimistico), e la versa nella coda
// interna già collaudata (_codaInvio) tramite _confermaRigheInBlocco. Ogni
// riga porta con sé il proprio dbRigaId (vedi sopra), così l'esito finale
// (trovata/errore) viene scritto DIRETTAMENTE sulla riga del database da
// contrassegnaEsitoERimuovi — sopravvive quindi a chiusure impreviste.
//
// Una riga rimasta 'in_corso' per più di 10 minuti (PC spento a metà,
// estensione chiusa senza dare il tempo al rilascio immediato qui sotto di
// partire — crash, mancanza di corrente) viene considerata abbandonata e
// ripescata di nuovo. Ogni riga porta con sé la propria Location (colonna
// 'location' della tabella) che viene scritta carta per carta — vedi
// item.location in _elaboraCarta — non più un unico valore condiviso per
// tutto il lotto.
//
// Lotti piccoli (5 invece di un numero più alto) per bilanciare meglio il
// lavoro tra più PC connessi in contemporanea: ognuno pesca un pezzetto alla
// volta invece che uno solo accaparrarsi tutto il lavoro disponibile in un
// colpo, lasciando gli altri PC a bocca asciutta finché non lo finisce.
const _LOTTO_RECUPERO_DB = 1; // una carta alla volta: con più dispositivi online, si dividono il lavoro una per uno invece che a blocchi
let _recuperoDaDbInCorso = false;

async function _recuperaAltreRigheDaDb() {
  if (_recuperoDaDbInCorso) return;
  _recuperoDaDbInCorso = true;
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return;

    const sogliaStalloIso = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const filtroEleggibili = `stato.eq.pending,and(stato.eq.in_corso,claimed_at.lt.${sogliaStalloIso})`;
    const { data: candidate, error: errLettura } = await supabaseClient
      .from('coda_carte')
      .select('*')
      .or(filtroEleggibili)
      .order('creato_il', { ascending: true })
      .limit(_LOTTO_RECUPERO_DB);
    if (errLettura) { console.error('[coda_carte] errore lettura:', errLettura.message); return; }
    if (!candidate || candidate.length === 0) return;

    const ids = candidate.map((r) => r.id);
    const nomeDisp = await nomeDispositivo();
    // FIX (claim duplicato tra più PC): l'update PRIMA non aveva nessuna
    // condizione sullo stato attuale della riga — solo .in('id', ids). Se
    // due PC leggevano (SELECT) le stesse righe quasi nello stesso istante,
    // entrambi gli update successivi riuscivano: le stesse carte finivano
    // "prese in carico" da entrambi, con doppia ricerca su Cardmarket e
    // rischio di doppie righe in collezione. Ripetere qui lo STESSO filtro
    // di eleggibilità usato nella SELECT trasforma l'update in un vero lock
    // ottimistico: se nel frattempo un altro PC ha già claimato una riga
    // (stato non più 'pending'/in_corso scaduto), questa update la salta —
    // "claimate" conterrà SOLO le righe che questo PC si è aggiudicato
    // davvero, il resto va naturalmente a chi arriva dopo. 'dispositivo'
    // (nome persistente per browser/profilo, vedi nomeDispositivo() in
    // shared.js) registra CHI ha preso in carico ogni riga — utile con più
    // PC online insieme (es. un portatile sempre acceso).
    const { data: claimate, error: errClaim } = await supabaseClient
      .from('coda_carte')
      .update({ stato: 'in_corso', claimed_by: userId, claimed_at: new Date().toISOString(), dispositivo: nomeDisp })
      .in('id', ids)
      .or(filtroEleggibili)
      .select();
    if (errClaim) { console.error('[coda_carte] errore claim:', errClaim.message); return; }
    if (!claimate || claimate.length === 0) return; // già prese da un altro dispositivo
    console.log(`[coda_carte] ${nomeDisp} ha preso in carico ${claimate.length} riga/righe.`);

    const datiRighe = claimate.map((r) => ({
      codice: r.nome,
      lingua: r.lingua || 'IT',
      condizione: r.condizione || 'NM',
      qty: r.qty || 1, // FIX: prima ogni carta veniva sempre scritta con qty=1, anche se il sito ne aveva chieste di più (in quel caso "spacchettava" in N righe separate — vedi index.html)
      reverse: !!r.reverse,
      oloType: r.reverse ? 'RH' : '',
      firstEd: !!r.first_ed,
      notaBulk: r.nota || '',
      dbRigaId: r.id,
      location: r.location || null, // per-riga: vedi item.location in _elaboraCarta
      urlDiretto: r.url_diretto || null, // se presente (scelta da disambiguazione sul sito), salta la ricerca e legge direttamente da qui
      tipo: r.tipo || null, // 'sealed' se aggiunta col toggle omonimo sul sito
      destinazione: r.destinazione || 'collezione', // 'wishlist' o 'collezione' — coda UNICA per entrambe
      prezzoObiettivo: r.prezzo_obiettivo ?? null,
      // FIX (correzione manuale per-utente, sessione 21/08/2026): serve per
      // sapere a che punto è il contatore quando questa riga arriva da una
      // precedente elaborazione fallita (worker autonomo o un altro popup
      // manuale) — vedi soglia in contrassegnaEsitoERimuovi.
      tentativiFalliti: r.tentativi_falliti || 0,
    }));
    await _confermaRigheInBlocco(datiRighe, (d) => d);
  } finally {
    _recuperoDaDbInCorso = false;
  }
}

// Controllo periodico: anche se questa pagina resta aperta a lungo (es. una
// coda enorme che ci mette ore), ogni ~20s controlliamo se sono arrivate
// altre carte da 'coda_carte' — senza aspettare che la coda locale si
// svuoti. _recuperaAltreRigheDaDb è già sicura da richiamare mentre la coda
// è attiva (confermaRigaTabella/avviaElaborazioneCoda sono no-op se il ciclo
// sta già girando, si limitano ad aggiungere righe in fondo).
setInterval(_recuperaAltreRigheDaDb, 20000);

// FIX (un dispositivo perdeva sistematicamente la "gara" per il lavoro in
// coda): setInterval viene RALLENTATO molto da Chrome quando la tab non è
// quella attiva in quel momento (in background) — un dispositivo con la
// tab in secondo piano poteva ritrovarsi a controllare la coda molto meno
// spesso dei 20s previsti, lasciando che l'altro dispositivo (con la tab
// in primo piano) si prendesse tutto il lavoro. chrome.alarms non risente
// di questo rallentamento — stesso motivo per cui è già usato altrove nel
// progetto per il keep-alive. Il minimo consentito è 1 minuto (limite di
// Chrome), quindi resta come backup più lento ma affidabile, non come
// sostituto del controllo veloce sopra.
chrome.alarms.create('recuperaCodaCarte', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'recuperaCodaCarte') _recuperaAltreRigheDaDb();
});

// Riga vuota iniziale, pronta per la prima carta.
nuovaRigaTabella();

function formattaDataOra(ts) {
  if (!ts) return null;
  const d   = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// ── VERIFICA LOGIN CARDMARKET ────────────────────────────────────────────────
// Il controllo "carrello cliccabile" (rigaCarrelloCliccabile in content.js/
// background.js) richiede di essere loggati su Cardmarket nella worker tab
// che legge i prezzi — senza login ogni riga viene scartata e ogni carta va
// in correzione manuale/fallita. Verifica il login vero prima di ogni avvio,
// bloccando per davvero se risulta chiaramente non loggato.
// FIX (tabella streaming): firma "restituisce true/false" — chiamata da
// avviaElaborazioneCoda() nel motore a coda, che deve sapere se può davvero
// iniziare a processare o se il login è fallito (in quel caso lascia le
// righe in coda e mostra "▶ Riprendi coda" invece di "🛑 Ferma coda", vedi
// aggiornaBottoneFerma).
async function _richiediConfermaLogin() {
  setStatus('🔍 Verifico il login su Cardmarket...', 'info');
  let risposta;
  try {
    risposta = await new Promise((resolve, reject) => {
      // FIX (troppe tab in sequenza → Cloudflare): kind:'carte' fa sì che
      // background.js esegua questo controllo nella STESSA worker tab già
      // usata dalla sessione bulk imminente, invece di aprirne una a parte
      // solo per il login — vedi _verificaLoginSuWorkerTab in background.js.
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_SILENZIOSA', kind: 'carte' }, (r) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(r);
      });
    });
  } catch (e) {
    setStatus('⚠️ Impossibile verificare il login (' + e.message + ') — procedo comunque.', 'info');
    return true;
  }

  if (risposta && risposta.loggato === false) {
    setStatus('🔒 Non risulti loggato su Cardmarket — ho aperto una tab per te: accedi e riprova.', 'errore');
    return false; // blocca per davvero
  }
  if (!risposta || risposta.loggato === null) {
    setStatus('⚠️ Non sono riuscito a confermare il login — procedo comunque.', 'info');
  }
  return true;
}



// ── IMPOSTAZIONI BULK ────────────────────────────────────────────────────────
const PAUSA_OGNI_LABELS = ['25', '50', '75', '100', 'Mai'];
// Ricontrollo prezzo mancante: se una carta viene inserita senza prezzo
// (pagina non caricata in tempo, filtri troppo stretti, ecc.) si aspetta
// questo delay e si rilegge SOLO il prezzo dalla stessa pagina già risolta.
const RICONTROLLO_LABELS  = ['Disattivato', '10s', '20s', '30s', '60s'];
const RICONTROLLO_SECONDI = [0, 10, 20, 30, 60];

function toggleSettingsPanel() {
  const panel = document.getElementById('settingsPanel');
  const btn   = document.getElementById('gearBtn');
  const open  = panel.classList.toggle('visible');
  btn.classList.toggle('open', open);
  btn.setAttribute('aria-expanded', String(open));
}

document.getElementById('gearBtn').addEventListener('click', toggleSettingsPanel);

// ── ⚙ INOLTRATO DALL'HUB (app.html) ──────────────────────────────────────────
// Quando questa pagina è dentro l'hub (vedi tab_detect.js/embedded-in-hub),
// il proprio header — e quindi questo stesso gearBtn — è nascosto: l'hub
// mostra un'unica icona ⚙ in cima e, al click, la inoltra qui via postMessage
// così il pannello che si apre resta sempre quello giusto per questa pagina.
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CARDSYNC_TOGGLE_SETTINGS') toggleSettingsPanel();
  // FIX: quando una location viene rinominata/eliminata dal popover 📍
  // dell'hub, questa pagina ricarica la propria datalist — altrimenti
  // resterebbe con l'elenco vecchio finché non si riapre/ricarica.
  if (e.data && e.data.type === 'CARDSYNC_REFRESH_LOCATION') _popolaDatalistLocation();
});

// FIX: sostituito l'unico slider "Delay tra carte" (preset fissi) con due
// slider indipendenti min/max in secondi — stessa modifica di popup.js,
// stessa chiave di storage condivisa (sliderDelayMinSec/sliderDelayMaxSec)
// così il valore resta sincronizzato tra tutte le pagine dell'estensione.
function aggiornaLabelDelayMinMaxBulk() {
  const vMin = document.getElementById('sliderDelayMin').value;
  const vMax = document.getElementById('sliderDelayMax').value;
  document.getElementById('valDelayMin').textContent = vMin + 's';
  document.getElementById('valDelayMax').textContent = vMax + 's';
}

document.getElementById('sliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('sliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelDelayMinMaxBulk();
  chrome.storage.local.set({
    sliderDelayMinSec: vMin,
    sliderDelayMaxSec: parseInt(sliderMax.value),
  });
});

document.getElementById('sliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('sliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelDelayMinMaxBulk();
  chrome.storage.local.set({
    sliderDelayMinSec: parseInt(sliderMin.value),
    sliderDelayMaxSec: vMax,
  });
});

document.getElementById('sliderPausaOgni').addEventListener('input', (e) => {
  const v = parseInt(e.target.value);
  document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[v];
  chrome.storage.local.set({ sliderPausaOgni: v });
});

document.getElementById('sliderRicontrollo').addEventListener('input', (e) => {
  const v = parseInt(e.target.value);
  document.getElementById('valRicontrollo').textContent = RICONTROLLO_LABELS[v];
  chrome.storage.local.set({ sliderRicontrollo: v });
});

// Carica valori salvati al boot (sincronizzati con il popup principale)
chrome.storage.local.get(
  ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderPausaOgni', 'avvisoSonoro', 'sliderRicontrollo'],
  (saved) => {
    // FIX: migrazione dal vecchio indice a preset (solo per chi lo aveva
    // già salvato) — altrimenti, per un'installazione nuova, usa il valore
    // predefinito prudente. Vedi anche _attendiDelay più sopra per lo
    // stesso fallback usato durante una sessione già in corso.
    let vDelayMin = saved.sliderDelayMinSec;
    let vDelayMax = saved.sliderDelayMaxSec;
    if (vDelayMin === undefined || vDelayMax === undefined) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        [vDelayMin, vDelayMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      } else {
        vDelayMin = DEFAULT_DELAY_MIN_SEC;
        vDelayMax = DEFAULT_DELAY_MAX_SEC;
      }
      chrome.storage.local.set({ sliderDelayMinSec: vDelayMin, sliderDelayMaxSec: vDelayMax });
    }
    const vPausa = saved.sliderPausaOgni ?? 1;
    const vRicontrollo = saved.sliderRicontrollo ?? 2;
    document.getElementById('sliderDelayMin').value = vDelayMin;
    document.getElementById('sliderDelayMax').value = vDelayMax;
    document.getElementById('sliderPausaOgni').value = vPausa;
    document.getElementById('sliderRicontrollo').value = vRicontrollo;
    aggiornaLabelDelayMinMaxBulk();
    document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[vPausa];
    document.getElementById('valRicontrollo').textContent = RICONTROLLO_LABELS[vRicontrollo];
    document.getElementById('avvisoSonoro').checked = saved.avvisoSonoro !== false;
  }
);

document.getElementById('avvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

function applicaTema(nome) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nome !== 'purple') document.body.classList.add(`theme-${nome}`);
  document.body.classList.toggle('tema-attivo', nome !== 'purple');
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.selectedTheme) location.reload(); // FIX: refresh vero invece di un cambio 'a caldo' incompleto
  if (changes.cardsyncDarkMode) location.reload();
  if (changes.bulkLocation !== undefined) {
    const el = document.getElementById('inputLocation');
    if (el && document.activeElement !== el) el.value = changes.bulkLocation.newValue || '';
  }
  if (changes.sliderDelayMinSec || changes.sliderDelayMaxSec) {
    if (changes.sliderDelayMinSec) document.getElementById('sliderDelayMin').value = changes.sliderDelayMinSec.newValue ?? 3;
    if (changes.sliderDelayMaxSec) document.getElementById('sliderDelayMax').value = changes.sliderDelayMaxSec.newValue ?? 7;
    aggiornaLabelDelayMinMaxBulk();
  }
  if (changes.sliderPausaOgni) {
    const v = changes.sliderPausaOgni.newValue ?? 1;
    document.getElementById('sliderPausaOgni').value    = v;
    document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[v];
  }
  if (changes.sliderRicontrollo) {
    const v = changes.sliderRicontrollo.newValue ?? 2;
    document.getElementById('sliderRicontrollo').value    = v;
    document.getElementById('valRicontrollo').textContent = RICONTROLLO_LABELS[v];
  }
  if (changes.avvisoSonoro !== undefined) {
    document.getElementById('avvisoSonoro').checked = changes.avvisoSonoro.newValue !== false;
  }
});

// ── EASTER EGG ────────────────────────────────────────────────────────────────
(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('footer-credit');
  if (!footer) return;
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

// ── STATUS ────────────────────────────────────────────────────────────────────
function setStatus(msg, tipo = '') {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = msg ? `visible ${tipo}` : '';
}

// ── LOG ───────────────────────────────────────────────────────────────────────
document.getElementById('logHeader').addEventListener('click', () => {
  document.getElementById('logBody').classList.toggle('visible');
  document.getElementById('logHeader').classList.toggle('open');
});

function aggiungiLog(msg, tipo = 'ok') {
  logCount++;
  logEntries.push({ n: logCount, msg, tipo });
  document.getElementById('logBadge').textContent = logCount;

  const empty = document.querySelector('.log-empty');
  if (empty) empty.remove();

  const entry  = document.createElement('div');
  entry.className = 'log-entry';

  const rigaEl = document.createElement('span');
  rigaEl.className   = 'log-row';
  rigaEl.textContent = `#${logCount}`;

  const msgEl = document.createElement('span');
  msgEl.className   = `log-msg ${tipo}`;
  msgEl.textContent = msg;

  entry.appendChild(rigaEl);
  entry.appendChild(msgEl);

  const body = document.getElementById('logBody');
  body.insertBefore(entry, body.firstChild);
  body.classList.add('visible');
  document.getElementById('logHeader').classList.add('open');
}

document.getElementById('logCopy').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const testo = [...logEntries].reverse().map(e => `#${e.n}\t${e.msg}`).join('\n');
  navigator.clipboard.writeText(testo).then(() => {
    const btn = document.getElementById('logCopy');
    btn.textContent = '✅';
    setTimeout(() => { btn.textContent = '📋'; }, 1500);
  });
});

document.getElementById('logCsv').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const righe = ['#,Messaggio,Tipo'];
  [...logEntries].reverse().forEach(e => {
    const msg  = '"' + (e.msg  || '').replace(/"/g, '""') + '"';
    const tipo = '"' + (e.tipo || '').replace(/"/g, '""') + '"';
    righe.push(`${e.n},${msg},${tipo}`);
  });
  const blob = new Blob([righe.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'cardsync_bulk_' + new Date().toISOString().slice(0, 10) + '.csv';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('logClear').addEventListener('click', (e) => {
  e.stopPropagation();
  logEntries = [];
  logCount   = 0;
  const body = document.getElementById('logBody');
  body.innerHTML = '<div class="log-empty">Nessuna carta aggiunta ancora.</div>';
  document.getElementById('logBadge').textContent = '0';
});

// ── RESET FORM ────────────────────────────────────────────────────────────────
// ── BUG REPORT ────────────────────────────────────────────────────────────────
// FIX: un link mailto: dentro il popup reale dell'estensione spesso non apre
// il client di posta — Chrome tende a chiudere il popup non appena perde il
// focus, il che capita proprio nell'istante in cui il browser tenta di
// passare la mano al gestore mail di sistema. chrome.tabs.create() apre
// sempre una tab vera e stabile.
document.getElementById('bugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});

// ── CHANGELOG ─────────────────────────────────────────────────────────────────
document.getElementById('changelogLink').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

document.getElementById('btnReset').addEventListener('click', () => {
  setStatus('', '');
  // FIX (troppe tab in sequenza → Cloudflare): se una sessione bulk aveva
  // lasciato la worker tab aperta (es. interrotta e poi scartata dal
  // reset), chiudila qui invece di lasciarla in giro indefinitamente.
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'carte' });
  const cardCorr = document.getElementById('cardCorrezione');
  if (cardCorr) { cardCorr.style.display = 'none'; const p = document.getElementById('pannelloCorrezione'); p.innerHTML = ''; p.classList.remove('visible'); }
  _codaCorrezione = [];
  _codaCorrezioneTot = 0;

  // ── Svuota la coda e la tabella (motore a coda) ──
  _stopRichiesto = true;      // il ciclo eventualmente in corso si ferma da solo dopo la carta attuale
  _codaInvio = [];
  _posizioneAssoluta = 0;
  _okSessione = 0;
  fermaAudioKeepAlive();
  chrome.storage.local.remove('bulkSessione');
  const tbodyCarte = document.getElementById('tbodyCarte');
  if (tbodyCarte) tbodyCarte.innerHTML = '';
  _rigaApertaRefs = null;
  nuovaRigaTabella(); // riga vuota pronta per ricominciare
  aggiornaCodaBadge();
  aggiornaBottoneFerma();

  const timerRiga = document.getElementById('timerRigaAttiva');
  if (timerRiga) timerRiga.classList.remove('visible');

  logEntries = [];
  logCount   = 0;
  const logBody = document.getElementById('logBody');
  if (logBody) { logBody.innerHTML = '<div class="log-empty">Nessuna carta aggiunta ancora.</div>'; }
  document.getElementById('logBadge').textContent = '0';
  chrome.storage.local.remove('bulkSessione');
});