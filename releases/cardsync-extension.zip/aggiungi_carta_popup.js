// Pagina "Aggiungi carte" (la coda), dentro app.html (#coda) o aperta da sola.
// Con la scheda dell'app aperta la coda la lavora questa pagina; con l'app chiusa il worker di
// background.js. Le carte degli altri restano anonime: "gruppo", mai il nickname.
// Dalla 5.72 le carte si aggiungono solo dal sito (Inserisci, import CSV): qui niente righe
// scritte a mano, niente incolla in blocco e niente campo location; si vedono e si fermano.

assicuraLoginSupabase();

const COL = {
  NOME:              'B',
  CODICE:            'C',
  LOCATION:          'D',
  QTY:               'E',
  LINGUA:            'F',
  CONDIZIONE:        'G',
  URL:               'H',
  PREZZO_OBIETTIVO:  'J',
  NOTE:              'K',
  IMMAGINE:          'L',
  SIGILLATA_ORIGINALE: 'M',
};

const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];
const DEFAULT_DELAY_MIN_SEC = 10;
const DEFAULT_DELAY_MAX_SEC = 20;

function _timeoutLetturaCarta() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['sliderCfTimeout'], (res) => {
      const minuti = (typeof res.sliderCfTimeout === 'number' && res.sliderCfTimeout >= 1)
        ? res.sliderCfTimeout
        : 3;
      resolve(minuti * 60 * 1000 + 20000);
    });
  });
}

function _erroreConnessioneSW(msg) {
  if (!msg) return false;
  const m = msg.toLowerCase();
  return m.includes('message port closed')
      || m.includes('receiving end does not exist')
      || m.includes('context invalidated')
      || m.includes('could not establish connection');
}

function _inviaMessaggioConRetry(messaggio, timeoutTotaleMs) {
  const scadenza = Date.now() + timeoutTotaleMs;
  return new Promise((resolve, reject) => {
    function tenta() {
      const rimanente = scadenza - Date.now();
      if (rimanente <= 0) { reject(new Error('Timeout')); return; }
      const timeoutId = setTimeout(() => {
        reject(new Error('Timeout'));
      }, rimanente);
      chrome.runtime.sendMessage(messaggio, (r) => {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) {
          if (_erroreConnessioneSW(chrome.runtime.lastError.message) && Date.now() < scadenza) {
            setTimeout(tenta, 1000);
            return;
          }
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(r);
      });
    }
    tenta();
  });
}

function _nuovoRequestId() {
  return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function _pingRichiesta(requestId) {
  return new Promise((resolve) => {
    const timeoutId = setTimeout(() => resolve(null), 5000);
    try {
      chrome.runtime.sendMessage({ type: 'PING_RICHIESTA', requestId }, (r) => {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(r || null);
      });
    } catch (_) {
      clearTimeout(timeoutId);
      resolve(null);
    }
  });
}

function _inviaMessaggioConWatchdog(messaggio, timeoutTotaleMs) {
  const requestId = _nuovoRequestId();
  const messaggioConId = Object.assign({}, messaggio, { requestId });

  let risolta = false;
  let mancatiConsecutivi = 0;
  let heartbeatTimer = null;

  const promiseMessaggio = _inviaMessaggioConRetry(messaggioConId, timeoutTotaleMs)
    .then((r) => ({ orfano: false, risposta: r }))
    .catch((e) => ({ orfano: false, errore: e }))
    .finally(() => { risolta = true; if (heartbeatTimer) clearInterval(heartbeatTimer); });

  const promiseWatchdog = new Promise((resolve) => {
    heartbeatTimer = setInterval(async () => {
      if (risolta) return;
      const esito = await _pingRichiesta(requestId);
      if (risolta) return;
      if (esito && esito.attiva) {
        mancatiConsecutivi = 0;
        return;
      }
      mancatiConsecutivi++;
      if (mancatiConsecutivi >= 3) {
        if (heartbeatTimer) clearInterval(heartbeatTimer);
        resolve({ orfano: true });
      }
    }, 8000);
  });

  return Promise.race([promiseMessaggio, promiseWatchdog]).then((esito) => {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    if (esito.orfano) {
      const err = new Error('service worker riavviato durante l\'attesa — carta saltata');
      err.orfano = true;
      throw err;
    }
    if (esito.errore) throw esito.errore;
    return esito.risposta;
  });
}


// Codici giapponesi e cinesi attaccati: Cardmarket li trova solo staccati ("m6001" → "m6 001",
// "CSV2C001" → "CSV2C 001"). Copia di _staccaCodiceAsiatico in background.js.
function _staccaCodiceAsiaticoPopup(token) {
  const t = String(token || '');
  if (/^(?:PPS|WCD|BOO|BA|MCD|TK)/i.test(t)) return null;
  const m = t.match(/^([A-Za-z]{1,4}\d{1,2}[A-Za-z]{0,2})(\d{3})$/) || t.match(/^(151C)(\d{3})$/i);
  return m ? m[1] + ' ' + m[2] : null;
}

function _testoRicercaCartaPopup(testo) {
  const parti = String(testo || '').trim().split(/\s+/).filter(Boolean);
  const staccato = parti.length ? _staccaCodiceAsiaticoPopup(parti[parti.length - 1]) : null;
  if (staccato) return parti.slice(0, -1).concat(staccato).join(' ');
  for (let i = Math.max(0, parti.length - 3); i < parti.length - 1; i++) {
    // "Mismagius BOO PAL 054", "BOO PAL054": senza l'anno il codice attaccato non basta, resta il testo
    if (/^BOO$/i.test(parti[i])) continue;
    // "Gardevoir WCD23 061", "PPS6 130", "Mismagius BOO23 088": senza la sigla del set il codice attaccato non basta, resta il testo
    if (/^(?:WCD\d{2}|PPS\d{1,2}|BOO\d{2})$/i.test(parti[i]) && i === parti.length - 2 && /^\d+$/.test(parti[parti.length - 1])) continue;
    if (/^(?:BOO\d{0,2}|PPS\d{1,2}|WCD\d{2}|BA\d{2})$/i.test(parti[i]) && /\d/.test(parti[parti.length - 1])) return parti.slice(i).join('').toUpperCase();
  }
  return String(testo || '');
}

function urlRicerca(codice, nome) {
  const q = _testoRicercaCartaPopup(codice || nome || '').trim().replace(/\s+/g, ' ');
  const query = encodeURIComponent(q).replace(/%20/g, '+');
  return `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
}

function urlRicercaSealed(nome, lingua) {
  const query = encodeURIComponent((nome || '').trim().replace(/\s+/g, ' ')).replace(/%20/g, '+');
  let url = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
  const codiceLingua = (lingua || 'IT').toUpperCase().trim();
  const idLingua = LINGUA_MAP_SHARED[codiceLingua];
  if (idLingua) url += `&language=${idLingua}`;
  return url;
}

const _costruisciUrlFiltrato = costruisciUrlFiltrato;

function _appendOloParams(url, reverse, oloType, firstEd) {
  let u = url;
  if (reverse || oloType === 'RH') {
    u = u + (u.includes('?') ? '&' : '?') + 'isReverseHolo=Y';
  }
  if (firstEd) {
    u = u + (u.includes('?') ? '&' : '?') + 'isFirstEd=Y';
  }
  return u;
}

function oloLabel(reverse, oloType) {
  if (reverse || oloType === 'RH') return '✨ RH';
  return '';
}

function firstEdLabel(firstEd) {
  return firstEd ? '🅰️ 1ED' : '';
}

function condizioneLabel(condizione) {
  const c = (condizione || '').toUpperCase().trim();
  if (c.endsWith('+')) return `⬆️ prezzo condizione superiore (${c})`;
  if (c.endsWith('-')) return `⬇️ prezzo condizione anche inferiore (${c})`;
  return '';
}

function variantiLabel(reverse, oloType, firstEd, condizione) {
  return [oloLabel(reverse, oloType), firstEdLabel(firstEd), condizioneLabel(condizione)].filter(Boolean).join(' · ');
}

const URL_SITO_CORREZIONI = 'https://bindexxx.github.io/bindex/';

async function _aggiornaAvvisoCorrezioni() {
  const card = document.getElementById('cardCorrezioni');
  const numero = document.getElementById('numCorrezioni');
  if (!card || !numero) return;
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) { card.style.display = 'none'; return; }
    const { count, error } = await supabaseClient.from('correzioni_manuali_carte')
      .select('id', { count: 'exact', head: true }).eq('owner_id', userId);
    if (error) return;
    const n = count || 0;
    numero.textContent = `${n} cart${n === 1 ? 'a' : 'e'} da sistemare`;
    card.style.display = n > 0 ? '' : 'none';
  } catch (_) {   }
}

document.getElementById('linkCorrezioniSito')?.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: URL_SITO_CORREZIONI });
});
_aggiornaAvvisoCorrezioni();
setInterval(_aggiornaAvvisoCorrezioni, 60000);

let logCount   = 0;
let logEntries = [];


chrome.storage.local.get(['bulkUltimoUtilizzo'], (saved) => {
  if (saved.bulkUltimoUtilizzo) {
    const { ts, ok } = saved.bulkUltimoUtilizzo;
    document.getElementById('ultimaCarta').textContent =
      `🕐 ${formattaDataOra(ts)} · ${ok} cart${ok === 1 ? 'a aggiunta' : 'e aggiunte'}`;
  }

  _recuperaAltreRigheDaDb();
});


let _bulkAttivo = false;

let _cfHitPendente = false;

chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'CLOUDFLARE_HIT_BULK' && message.kind === 'carte') {
    _cfHitPendente = true;
  }
});

let _codaInvio = [];
let _stopRichiesto = false;
let _posizioneAssoluta = 0;
let _numRigaTabella = 0;
let _okSessione = 0;

function aggiornaCodaBadge() {
  const badge = document.getElementById('codaBadge');
  if (badge) badge.textContent = `${_codaInvio.length} in coda`;
}


// Riga di sola lettura per una carta arrivata dal sito (presa dalla coda del DB)
function _rigaCartaDalSito(dati) {
  _numRigaTabella++;
  const tr = document.createElement('tr');
  tr.className = 'riga-coda';
  tr.appendChild(_cella(String(_numRigaTabella), 'num-riga'));
  const tdNome = _cella(null, 'col-nome');
  const nome = document.createElement('span');
  nome.className = 'testo-nome';
  nome.textContent = dati.codice || '(senza nome)';
  tdNome.appendChild(nome);
  if (dati.destinazione === 'wishlist' || dati.tipo === 'sealed') {
    const tag = document.createElement('span');
    tag.className = 'tag-tipo';
    tag.textContent = [dati.tipo === 'sealed' ? 'sealed' : '', dati.destinazione === 'wishlist' ? 'wishlist' : ''].filter(Boolean).join(' · ');
    tdNome.appendChild(tag);
  }
  tr.appendChild(tdNome);
  tr.appendChild(_cella(dati.lingua || 'IT', 'col-lang'));
  tr.appendChild(_cella(dati.tipo === 'sealed' ? '—' : (dati.condizione || 'NM'), 'col-cond'));
  tr.appendChild(_pillVarianti({ reverse: dati.reverse, first_ed: dati.firstEd, sigillata_originale: dati.sigillataOriginale }));
  tr.appendChild(_cella(String(dati.qty || 1), 'col-qty'));
  const tdLocation = _cella(null, 'col-loc');
  const tdDi = _cella(null, 'col-di');
  tr.appendChild(tdLocation);
  tr.appendChild(tdDi);
  tr.appendChild(_cella(dati.notaBulk || '', 'col-note'));
  const tdStato = _cella(null, 'col-stato');
  tdStato.innerHTML = '<span class="stato-pill stato-coda">in coda</span>';
  tr.appendChild(tdStato);
  tr.appendChild(_cella(null, 'col-togli'));
  document.getElementById('tbodyCarte').appendChild(tr);

  const item = { ...dati, tr, tdStato, rateLimitRetries: 0 };
  _scriviLocationEDi({ tr, tdLocation, tdDi }, item);
  _codaInvio.push(item);
  aggiornaCodaBadge();
  avviaElaborazioneCoda();
}

function rimuoviRigaConRitardo(tr, attesaMs) {
  setTimeout(() => {
    tr.classList.add('riga-in-uscita');
    setTimeout(() => {
      tr.classList.add('riga-collassa');
      setTimeout(() => { tr.remove(); _programmaContiFiltri(); }, 360);
    }, 350);
  }, attesaMs);
}

function _soloSeAncoraMia(query) {
  let q = query.eq('stato', 'in_corso');
  if (_userIdCorrente) q = q.eq('claimed_by', _userIdCorrente);
  return q;
}

function contrassegnaEsitoERimuovi(item, tipo, testoPill, opzioni, definitivo) {
  if (tipo !== 'ok') {
    _attivitaAllaHome({ fase: 'fatta', carta: _cartaPerHome(item), esito: { ok: false, testo: String(testoPill || '').replace(/^❌\s*/, '') } });
  }
  item.tr.className = tipo === 'ok' ? 'riga-ok' : 'riga-err';
  item.tdStato.innerHTML = `<span class="stato-pill stato-${tipo}">${testoPill}</span>`;
  if (item.btnRemove) item.btnRemove.style.visibility = 'hidden';
  rimuoviRigaConRitardo(item.tr, tipo === 'ok' ? 900 : 700);

  if (item.dbRigaId) {
    if (tipo === 'ok') {
      registraAiutoGruppo(supabaseClient, item.dbRigaId, item.ownerId, 'coda_carte');
      supabaseClient.from('coda_carte')
        .update({ stato: 'completato', completato_il: new Date().toISOString() })
        .eq('id', item.dbRigaId)
        .then(({ error }) => { if (error) console.error('[coda_carte] impossibile scrivere l\'esito:', error.message); });
    } else {
      const tentativi = (item.tentativiFalliti || 0) + 1;
      const SOGLIA_CORREZIONE_MANUALE = 3;
      const opzioniValide = (Array.isArray(opzioni) && opzioni.length > 0) ? opzioni : null;

      if (definitivo || tentativi >= SOGLIA_CORREZIONE_MANUALE) {
        supabaseClient.rpc('sposta_riga_in_correzione_manuale', {
          p_riga_id: item.dbRigaId,
          p_errore_msg: definitivo ? testoPill : `${testoPill} (dopo ${tentativi} tentativi)`,
          p_opzioni: opzioniValide,
        }).then(({ error }) => {
          if (!error) _aggiornaAvvisoCorrezioni();
          if (error) {
            console.error('[coda_carte] impossibile spostare in correzione manuale:', error.message);
            _soloSeAncoraMia(supabaseClient.from('coda_carte')
              .update({ stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi })
              .eq('id', item.dbRigaId))
              .then(({ error: errFallback }) => { if (errFallback) console.error('[coda_carte] fallback pending fallito:', errFallback.message); });
          }
        });
      } else {
        _soloSeAncoraMia(supabaseClient.from('coda_carte').update({
          stato: 'pending', claimed_by: null, claimed_at: null, tentativi_falliti: tentativi,
          errore_msg: testoPill,
          opzioni_disambiguazione: opzioniValide,
        }).eq('id', item.dbRigaId)).then(({ error }) => {
          if (error) console.error('[coda_carte] impossibile scrivere l\'esito:', error.message);
        });
      }
    }
  }
}


function aggiornaBottoneFerma() {
  const btn = document.getElementById('btnBulkAggiungi');
  if (!btn) return;
  if (_bulkAttivo) {
    btn.style.display = '';
    btn.disabled = false;
    btn.textContent = 'Ferma la coda';
    btn.className = 'btn-ferma';
    btn.onclick = () => {
      _stopRichiesto = true;
      btn.disabled = true;
      btn.textContent = 'Arresto…';
      setStatus('⏳ Finisco la carta attuale e mi fermo…', 'info');
      _attivitaAllaHome({ fase: 'in-arresto' });
    };
  } else if (_codaInvio.length > 0) {
    btn.style.display = '';
    btn.disabled = false;
    btn.textContent = 'Riprendi la coda';
    btn.className = 'btn-primario';
    btn.onclick = () => avviaElaborazioneCoda();
  } else {
    btn.style.display = 'none';
  }
}

const CHIAVE_SEGNALE_CODA_CARTE = 'sessioneCodaAttiva_carte';
let _timerSegnaleCodaCarte = null;

function _segnaleCodaCarteAvvia() {
  const scrivi = () => chrome.storage.local.set({ [CHIAVE_SEGNALE_CODA_CARTE]: { scadenza: Date.now() + 3 * 60 * 1000 } });
  scrivi();
  if (_timerSegnaleCodaCarte) clearInterval(_timerSegnaleCodaCarte);
  _timerSegnaleCodaCarte = setInterval(scrivi, 30000);
}

function _segnaleCodaCarteFerma() {
  if (_timerSegnaleCodaCarte) { clearInterval(_timerSegnaleCodaCarte); _timerSegnaleCodaCarte = null; }
  chrome.storage.local.remove(CHIAVE_SEGNALE_CODA_CARTE);
}

function _chiediPrecedenzaCoda(creatoIlRiga, soloOccupato) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'PRECEDENZA_CODA_CARDMARKET', creatoIlRiga: creatoIlRiga || null, soloOccupato: !!soloOccupato }, (r) => {
        if (chrome.runtime.lastError || !r || !r.ok) { resolve({ attendi: false, motivo: null }); return; }
        resolve({ attendi: !!r.attendi, motivo: r.motivo || null });
      });
    } catch (_) {
      resolve({ attendi: false, motivo: null });
    }
  });
}

let _ultimoMotivoAttesaCoda = null;
function _mostraAttesaCoda(motivo) {
  if (!motivo || motivo === _ultimoMotivoAttesaCoda) return;
  _ultimoMotivoAttesaCoda = motivo;
  const testi = {
    'controllo-prezzi': '⏸ In attesa: su questo PC sta girando un controllo prezzi — la coda riparte appena finisce.',
    'worker': '⏸ In attesa: su questo PC la coda la sta già lavorando l\'estensione in background.',
    'ordine-prima': '⏸ In attesa: c\'è un controllo prezzi chiesto prima di queste carte — parte prima lui.',
  };
  setStatus(testi[motivo] || '⏸ In attesa del proprio turno su Cardmarket…', 'info');
  _attivitaAllaHome({ fase: 'attesa', testo: (testi[motivo] || 'In attesa del proprio turno su Cardmarket.').replace(/^⏸ In attesa: /, '').replace(/^⏸ /, '') });
}

// Uscita da Cardmarket vista da una pagina aperta dall'estensione: la coda si ferma, la carta in
// corso torna in coda senza essere salvata e la coda riparte da sola quando si rientra.
let _fermataPerUscitaCm = false;
function _statoFuoriCmCoda(s) {
  return !!s && s.loggato === false && s.nonConfermato !== true && typeof s.quando === 'number';
}
async function _uscitoDaCmCodaDa(inizioMs) {
  try {
    const { statoLoginCardmarket } = await chrome.storage.local.get('statoLoginCardmarket');
    return _statoFuoriCmCoda(statoLoginCardmarket) && statoLoginCardmarket.quando >= inizioMs;
  } catch (_) {
    return false;
  }
}
function _fermaCodaPerUscitaCm() {
  if (!_bulkAttivo) return;
  _fermataPerUscitaCm = true;
  _stopRichiesto = true;
  setStatus('🔒 Sei uscito da Cardmarket: coda fermata, la carta in corso torna in coda.', 'errore');
}
function _rimettiInCodaPerUscitaCm(item) {
  _fermaCodaPerUscitaCm();
  item.tr.className = 'riga-coda';
  item.tdStato.innerHTML = '<span class="stato-pill stato-coda">⏳ in coda</span>';
  if (item.btnRemove) item.btnRemove.style.visibility = '';
  _codaInvio.unshift(item);
  aggiornaCodaBadge();
  aggiungiLog(`${item.codice} — sei uscito da Cardmarket: non salvata, resta in coda`, 'err');
}
chrome.storage.onChanged.addListener((c) => {
  if (!c.statoLoginCardmarket) return;
  const nuovo = c.statoLoginCardmarket.newValue;
  if (_statoFuoriCmCoda(nuovo)) {
    if (_bulkAttivo && !_fermataPerUscitaCm) _fermaCodaPerUscitaCm();
    return;
  }
  // di nuovo dentro: la coda fermata per l'uscita riparte da sola
  if (nuovo && nuovo.loggato === true && _fermataPerUscitaCm && !_bulkAttivo && _codaInvio.length > 0) {
    avviaElaborazioneCoda();
  }
});

async function avviaElaborazioneCoda() {
  if (_bulkAttivo) return;
  _bulkAttivo = true;
  _stopRichiesto = false;
  _fermataPerUscitaCm = false;
  aggiornaBottoneFerma();
  _segnaleCodaCarteAvvia();

  try {
    if (!(await verificaAccessoValido())) {
      _bulkAttivo = false;
      aggiornaBottoneFerma();
      _attivitaAllaHome({ fase: 'ferma', rimaste: _codaInvio.length });
      return;
    }

    const loginOk = await _accessoCardmarketPronto();
    if (!loginOk) {
      _bulkAttivo = false;
      aggiornaBottoneFerma();
      _attivitaAllaHome({ fase: 'ferma', rimaste: _codaInvio.length });
      return;
    }
    await _loopElaborazioneCoda();
  } finally {
    _segnaleCodaCarteFerma();
    _ultimoMotivoAttesaCoda = null;
  }
}

async function _loopElaborazioneCoda() {
  let carteLavorateQui = 0;
  while (!_stopRichiesto) {
    if (_codaInvio.length === 0) {
      for (let tentativo = 0; tentativo < 3 && _codaInvio.length === 0; tentativo++) {
        if (tentativo > 0) await new Promise(r => setTimeout(r, 400 + Math.floor(Math.random() * 400)));
        await _recuperaAltreRigheDaDb();
      }
      if (_codaInvio.length === 0) break;
    }
    if (carteLavorateQui > 0) {
      await _attendiDelayCoda();
      if (_stopRichiesto) break;
    }
    const item = _codaInvio.shift();
    aggiornaCodaBadge();
    const completata = await _elaboraCarta(item);
    carteLavorateQui++;
    if (completata) _posizioneAssoluta++;
    if (_stopRichiesto) break;
  }

  _bulkAttivo = false;
  _attivitaAllaHome({ fase: 'ferma', rimaste: _codaInvio.length });
  const timerRiga = document.getElementById('timerRigaAttiva');
  if (timerRiga) timerRiga.classList.remove('visible');
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'carte' });
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'sealed' });

  if (_codaInvio.length === 0) {
    setStatus(`✅ Coda completata — ${_okSessione} cart${_okSessione === 1 ? 'a aggiunta' : 'e aggiunte'} in questa sessione.`, 'ok');
  } else if (_fermataPerUscitaCm) {
    setStatus(`🔒 Sei uscito da Cardmarket: coda fermata con ${_codaInvio.length} cart${_codaInvio.length === 1 ? 'a' : 'e'}. Riparte da sola quando rientri.`, 'errore');
  } else if (_stopRichiesto) {
    setStatus(`🛑 Interrotto. ${_codaInvio.length} cart${_codaInvio.length === 1 ? 'a' : 'e'} ancora in coda — "Riprendi la coda" per continuare.`, 'info');
  }
  aggiornaBottoneFerma();
  _stopRichiesto = false;
}

// Un timer unico alla scadenza, non una catena di timer: con la scheda nascosta Chrome fa
// scattare le catene una volta al minuto. Quello di ogni secondo aggiorna solo il numero.
function _attendiConCountdownCoda(ms, etichetta) {
  const fineAttesa = Date.now() + ms;
  const traDueCarte = /^(Prossima|Pausa)/.test(etichetta || '');
  _attivitaAllaHome({
    fase: 'attesa', fino: fineAttesa, durataMs: ms, etichetta: etichetta || 'Parte tra',
    prossima: traDueCarte && _codaInvio[0] ? _cartaPerHome(_codaInvio[0]) : null,
  });
  const timerRiga = document.getElementById('timerRigaAttiva');
  const timerCountdown = document.getElementById('timerCountdownAttiva');
  if (timerRiga) timerRiga.classList.add('visible');
  const mostra = () => {
    const restante = Math.max(0, fineAttesa - Date.now());
    const totSec = Math.ceil(restante / 1000);
    const m = Math.floor(totSec / 60), s = totSec % 60;
    const testo = `${m > 0 ? m + 'm ' : ''}${s}s`;
    if (timerCountdown) timerCountdown.textContent = etichetta ? `${etichetta} ${testo}` : testo;
  };
  return new Promise((resolve) => {
    if (_stopRichiesto || Date.now() >= fineAttesa) { resolve(); return; }
    let finito = false;
    let iv = null;
    let to = null;
    const chiudi = () => {
      if (finito) return;
      finito = true;
      clearInterval(iv);
      clearTimeout(to);
      resolve();
    };
    mostra();
    to = setTimeout(chiudi, Math.max(0, fineAttesa - Date.now()));
    iv = setInterval(() => {
      if (_stopRichiesto || Date.now() >= fineAttesa) { chiudi(); return; }
      mostra();
    }, 1000);
  });
}

function _quandoTurnoCardmarketCoda() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'TURNO_CARDMARKET', fase: 'quando' }, (r) => {
        if (chrome.runtime.lastError || !r || !r.ok || !r.da) { resolve(null); return; }
        resolve(r);
      });
    } catch (_) { resolve(null); }
  });
}

async function _attendiDelayCoda() {
  if (_cfHitPendente) {
    _cfHitPendente = false;
    aggiungiLog('⚠️ Cloudflare rilevato — rallento temporaneamente il ritmo tra le carte', '');
  }
  const turno = await _quandoTurnoCardmarketCoda();
  if (turno) {
    const resta = turno.da - Date.now();
    if (resta > 0) {
      const etichetta = turno.motivo === 'pausa-lunga' ? 'Pausa lunga, prossima tra'
        : (turno.livelloCf > 0 ? 'Prossima tra (rallentato)' : 'Prossima tra');
      await _attendiConCountdownCoda(resta, etichetta);
    }
    return;
  }

  const savedPausa = await new Promise((r) => chrome.storage.local.get(
    ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec'], r));
  {
    let dMinSec = savedPausa.sliderDelayMinSec;
    let dMaxSec = savedPausa.sliderDelayMaxSec;
    if (dMinSec === undefined || dMaxSec === undefined) {
      if (typeof savedPausa.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[savedPausa.sliderDelay]) {
        [dMinSec, dMaxSec] = LEGACY_DELAY_RANGES_SEC[savedPausa.sliderDelay];
      } else {
        dMinSec = DEFAULT_DELAY_MIN_SEC;
        dMaxSec = DEFAULT_DELAY_MAX_SEC;
      }
    }
    const dMin = dMinSec * 1000;
    const dMax = Math.max(dMaxSec, dMinSec) * 1000;
    const MARGINE_RIUSO_TAB_MS = 1200;
    const delayMs = dMin + Math.floor(Math.random() * (dMax - dMin)) + MARGINE_RIUSO_TAB_MS;
    await _attendiConCountdownCoda(delayMs, 'Prossima tra');
  }
}

async function _rileggiPrezzoMancante(url, isSealed, etichetta) {
  if (!url) return null;
  const saved = await new Promise((r) => chrome.storage.local.get(['sliderRicontrollo'], r));
  const idx = saved.sliderRicontrollo ?? 2;
  const secondi = RICONTROLLO_SECONDI[idx] ?? 20;
  if (secondi <= 0 || _stopRichiesto) return null;

  aggiungiLog(`${etichetta} — prezzo non letto, riprovo tra ${secondi}s prima di salvare…`, '');
  await _attendiConCountdownCoda(secondi * 1000, 'Rileggo il prezzo tra');
  if (_stopRichiesto) return null;
  try {
    const timeoutMs = await _timeoutLetturaCarta();
    const ris = await _inviaMessaggioConWatchdog(isSealed
      ? { type: 'LEGGI_SOLO_PREZZO_SEALED', urlProdotto: url, usaWorkerTab: true }
      : { type: 'LEGGI_SOLO_PREZZO', urlConFiltri: url, usaWorkerTab: true }, timeoutMs);
    if (ris && ris.prezzo != null && ris.prezzo !== '') {
      aggiungiLog(`${etichetta} — prezzo ${ris.prezzo}€ letto alla seconda prova`, 'ok');
    } else {
      aggiungiLog(`${etichetta} — prezzo ancora non disponibile`, 'err');
    }
    return ris || null;
  } catch (e) {
    aggiungiLog(`${etichetta} — seconda lettura del prezzo non riuscita: ${e.message}`, 'err');
    return null;
  }
}

async function _elaboraCarta(item) {
  const { codice, condizione, qty, oloType, reverse, firstEd, sigillataOriginale, notaBulk } = item;
  const isSealed = item.tipo === 'sealed';
  // le BOO esistono solo in inglese
  const lingua = isSealed ? item.lingua : linguaPerCartaShared(codice, item.lingua);
  if (!isSealed) item.lingua = lingua;
  const isWishlist = item.destinazione === 'wishlist';

  item.tr.className = 'riga-lettura';
  item.tdStato.innerHTML = '<span class="stato-pill stato-lettura"><span class="spin-mini"></span> lettura…</span>';
  _attivitaAllaHome({ fase: 'lettura', carta: _cartaPerHome(item) });
  if (item.btnRemove) item.btnRemove.style.visibility = 'hidden';
  const timerCarta = document.getElementById('timerCartaAttiva');
  const timerCountdown = document.getElementById('timerCountdownAttiva');
  const timerRiga = document.getElementById('timerRigaAttiva');
  if (timerRiga) timerRiga.classList.add('visible');
  if (timerCarta) timerCarta.textContent = codice;
  if (timerCountdown) timerCountdown.textContent = '—';
  setStatus(`⏳ Processo: ${codice}…`, 'info');

  const timeoutLettura = await _timeoutLetturaCarta();
  const inizioCarta = Date.now();

  while (true) {
    let risposta;
    try {
      if (isSealed) {
        risposta = await _inviaMessaggioConWatchdog({
          type: 'LEGGI_SEALED', urlNome: item.urlDiretto || urlRicercaSealed(codice, lingua), lingua, usaWorkerTab: true,
          integrita: isWishlist ? undefined : (item.integrita || 'sigillato_integro'),
        }, timeoutLettura);
      } else {
        risposta = await _inviaMessaggioConWatchdog({
          type: 'LEGGI_NOME_CARTA', urlNome: item.urlDiretto || urlRicerca(codice, ''), lingua, condizione,
          oloType: oloType || (reverse ? 'RH' : ''), firstEd: !!firstEd, usaWorkerTab: true,
          urlRicercaRiserva: item.urlDiretto ? urlRicerca(codice, '') : null,
        }, timeoutLettura);
      }
    } catch (e) {
      if (_fermataPerUscitaCm || await _uscitoDaCmCodaDa(inizioCarta)) { _rimettiInCodaPerUscitaCm(item); return false; }
      aggiungiLog(`${codice} — ${e.message}`, 'err');
      contrassegnaEsitoERimuovi(item, 'err', '❌ errore');
      return true;
    }

    if (_fermataPerUscitaCm || await _uscitoDaCmCodaDa(inizioCarta)) { _rimettiInCodaPerUscitaCm(item); return false; }

    if (risposta?.rateLimited) {
      item.rateLimitRetries = (item.rateLimitRetries || 0) + 1;
      aggiungiLog(`${codice} — Error 1015 (rate limited) → pausa 30 min`, 'err');
      setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti…', 'errore');
      item.tdStato.innerHTML = '<span class="stato-pill stato-lettura">☕ pausa rate-limit</span>';
      await _attendiConCountdownCoda(PAUSA_RATE_LIMIT_MS, 'Riprende tra');
      if (_stopRichiesto) {
        item.tr.className = 'riga-coda';
        item.tdStato.innerHTML = '<span class="stato-pill stato-coda">⏳ in coda</span>';
        if (item.btnRemove) item.btnRemove.style.visibility = '';
        _codaInvio.unshift(item);
        aggiornaCodaBadge();
        return false;
      }
      if (item.rateLimitRetries >= 3) {
        aggiungiLog(`${codice} — saltata dopo 3 rate limit consecutivi`, 'err');
        contrassegnaEsitoERimuovi(item, 'err', '❌ rate limit');
        return true;
      }
      continue;
    }

    let urlTrovato = isSealed ? risposta?.urlProdotto : risposta?.urlSingles;
    if (!isSealed && urlTrovato) {
      const resto = (urlTrovato.split('/Singles/')[1] || '').split(/[?#]/)[0];
      const nomeLista = /^(?:singole|singles|einzelkarten)(?:\s|$)/i.test((risposta?.nome || '').trim());
      if (resto.split('/').filter(Boolean).length < 2 || nomeLista) {
        aggiungiLog(`${codice} — il link porta alla lista dell'espansione (${urlTrovato}), non alla carta`, 'err');
        risposta = { ...risposta, urlSingles: null, disambiguation: true, opzioni: risposta?.opzioni || [] };
        urlTrovato = null;
      }
    }
    if (!urlTrovato) {
      let motivoLog;
      if (isSealed) {
        if (risposta?.disambiguation) motivoLog = 'disambiguazione — correzione manuale';
        else if (risposta === null || risposta === undefined) motivoLog = 'errore di rete / timeout';
        else motivoLog = 'non trovato su Cardmarket';
      } else {
        if (risposta?.varianteNonTrovata) motivoLog = `variante ${oloLabel(reverse, oloType)} non trovata`;
        else if (risposta?.linkNonValido) motivoLog = risposta?.disambiguation ? 'link Cardmarket non più valido — più versioni trovate cercando per nome' : 'link Cardmarket non più valido e nessun risultato cercando per nome';
        else if (risposta?.disambiguation) motivoLog = 'disambiguazione — correzione manuale';
        else if (risposta === null || risposta === undefined) motivoLog = 'errore di rete / timeout';
        else motivoLog = 'non trovata su Cardmarket';
      }
      aggiungiLog(`${codice} — ${motivoLog}`, 'err');
      const testoEsito = isSealed ? '❌ non trovato'
        : risposta?.linkNonValido ? (risposta?.disambiguation ? '❌ link non più valido: scegli la versione' : '❌ link non più valido')
        : risposta?.disambiguation ? '❌ più versioni: scegli'
        : risposta?.varianteNonTrovata ? `❌ variante ${[(reverse || oloType === 'RH') ? 'Reverse Holo' : '', firstEd ? 'Prima Edizione' : ''].filter(Boolean).join(' + ') || 'richiesta'} non trovata`
        : '❌ non trovata';
      const definitivo = !!(risposta?.disambiguation || risposta?.linkNonValido || risposta?.varianteNonTrovata);
      contrassegnaEsitoERimuovi(item, 'err', testoEsito, risposta?.disambiguation ? risposta.opzioni : null, definitivo);
      return true;
    }

    const urlCarta = isSealed ? risposta.urlProdotto
      : _appendOloParams(_costruisciUrlFiltrato(risposta.urlSingles, lingua, condizione), reverse, oloType, firstEd);
    if (risposta.prezzo == null || risposta.prezzo === '') {
      const riletto = await _rileggiPrezzoMancante(urlCarta, isSealed, isSealed ? codice : (risposta.codice || codice));
      if (riletto) {
        risposta = {
          ...risposta,
          prezzo: riletto.prezzo ?? risposta.prezzo,
          nome: risposta.nome || riletto.nome || risposta.nome,
          codice: risposta.codice || riletto.codice || risposta.codice,
          immagine: risposta.immagine || riletto.immagine || risposta.immagine,
        };
      }
    }

    // carta con la spunta "Sigillata" (dalla 5.76): si legge anche l'offerta sigillata
    let sigillataLetta = null;
    if (!isSealed && sigillataOriginale && !isWishlist) {
      item.tdStato.innerHTML = '<span class="stato-pill stato-lettura">📦 cerco l\'offerta sigillata…</span>';
      try {
        sigillataLetta = await _inviaMessaggioConWatchdog({
          type: 'LEGGI_PREZZO_SIGILLATA', urlSingles: risposta.urlSingles, lingua, condizione,
          oloType: oloType || (reverse ? 'RH' : ''), firstEd: !!firstEd, usaWorkerTab: true,
        }, timeoutLettura);
      } catch (_) { sigillataLetta = null; }
      if (sigillataLetta && sigillataLetta.sigillata && sigillataLetta.prezzo != null) risposta = { ...risposta, prezzo: sigillataLetta.prezzo };
      if (sigillataLetta && sigillataLetta.sigillata === 'trovata') aggiungiLog(`${codice} — sigillata: ${sigillataLetta.prezzo}€ (minimo Cardmarket ${sigillataLetta.minimoCm}€)`, 'ok');
      else if (sigillataLetta && sigillataLetta.sigillata) aggiungiLog(`${codice} — nessuna offerta sigillata, prezzo normale`, '');
    }

    if (_fermataPerUscitaCm || await _uscitoDaCmCodaDa(inizioCarta)) { _rimettiInCodaPerUscitaCm(item); return false; }

    const locationRiga = item.location || '';

    let immagineConvertita = risposta.immagine || '';
    if (immagineConvertita) {
      try {
        const rispostaImg = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineConvertita }, (r) => resolve(r));
        });
        immagineConvertita = rispostaImg?.immagine || immagineConvertita;
      } catch (_) {   }
    }

    const codiceFinale = isSealed ? codice : (risposta.codice || codice);
    const rigaDati = isSealed ? {
      [COL.NOME]:       risposta.nome || codice,
      [COL.CODICE]:     '',
      [COL.LOCATION]:   locationRiga,
      [COL.QTY]:        qty,
      [COL.LINGUA]:     lingua,
      [COL.CONDIZIONE]: 'NM',
      [COL.URL]:        urlCarta,
      ['I']: risposta.prezzo ?? '',
      [COL.NOTE]: notaBulk || '',
      [COL.IMMAGINE]: immagineConvertita,
    } : {
      [COL.NOME]:       risposta.nome || '',
      [COL.CODICE]:     risposta.codice || codice,
      [COL.LOCATION]:   locationRiga,
      [COL.QTY]:        qty,
      [COL.LINGUA]:     lingua,
      [COL.CONDIZIONE]: condizione,
      [COL.URL]:        urlCarta,
      ['I']: risposta.prezzo ?? '',
      [COL.NOTE]: [notaBulk, variantiLabel(reverse, oloType, firstEd, condizione)].filter(Boolean).join(' | '),
      [COL.IMMAGINE]: immagineConvertita,
      [COL.SIGILLATA_ORIGINALE]: !!sigillataOriginale,
    };
    if (isWishlist && item.prezzoObiettivo != null) rigaDati[COL.PREZZO_OBIETTIVO] = item.prezzoObiettivo;

    let data;
    try {
      data = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { type: 'AGGIUNGI_CARTA', rigaDati, tipo: item.tipo || undefined, destinazione: item.destinazione || undefined, dbRigaId: item.dbRigaId || undefined },
          (r) => { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r); }
        );
      });
    } catch (e) {
      aggiungiLog(`${codiceFinale} — ${e.message}`, 'err');
      contrassegnaEsitoERimuovi(item, 'err', '❌ errore scrittura');
      return true;
    }

    const oloLog = variantiLabel(reverse, oloType, firstEd, condizione);
    if (!data.ok) {
      aggiungiLog(`${codiceFinale} — errore: ${data.errore || '?'}`, 'err');
      contrassegnaEsitoERimuovi(item, 'err', '❌ scrittura fallita');
      return true;
    }

    // prodotto sealed (dalla 5.77): minimo di Cardmarket e se il prezzo è dell'integrità giusta
    if (isSealed && !isWishlist && risposta.integrita && data.riga) {
      const esitoInt = await chiamaSupabase('aggiornaIntegritaRigaSealed', {
        riga: data.riga, rigaCodaId: item.dbRigaId || null,
        minimo: risposta.minimoCm ?? null, daIntegrita: risposta.integrita === 'trovata',
      }).catch(() => null);
      if (!esitoInt || !esitoInt.ok) aggiungiLog(`${codiceFinale} — dati dell'integrità non salvati (${esitoInt?.errore || '?'})`, 'err');
      else if (risposta.integrita !== 'trovata') aggiungiLog(`${codiceFinale} — nessuna offerta con questa integrità, prezzo normale`, '');
    }

    if (sigillataLetta && sigillataLetta.sigillata && data.riga) {
      const esitoSig = await chiamaSupabase('aggiornaSigillataRiga', {
        riga: data.riga, rigaCodaId: item.dbRigaId || null,
        minimo: sigillataLetta.minimoCm, daSigillata: sigillataLetta.sigillata === 'trovata',
      }).catch(() => null);
      if (!esitoSig || !esitoSig.ok) aggiungiLog(`${codiceFinale} — dati della carta sigillata non salvati (${esitoSig?.errore || '?'})`, 'err');
    }

    aggiungiLog(`R${data.riga} · ${codiceFinale} · ${lingua} · ${condizione}${oloLog ? ' · ' + oloLog : ''}${notaBulk ? ' · 📝 ' + notaBulk : ''}`, 'ok');
    _attivitaAllaHome({
      fase: 'fatta',
      carta: { ..._cartaPerHome(item), nome: rigaDati[COL.NOME] || codiceFinale, codice: isSealed ? '' : codiceFinale },
      esito: { ok: true, prezzo: rigaDati['I'] === '' ? null : rigaDati['I'] },
    });
    contrassegnaEsitoERimuovi(item, 'ok', 'salvata');
    _okSessione++;

    const ora = Date.now();
    chrome.storage.local.set({ bulkUltimoUtilizzo: { ts: ora, ok: _okSessione } });
    document.getElementById('ultimaCarta').textContent =
      `✔ ${formattaDataOra(ora)} · ${_okSessione} cart${_okSessione === 1 ? 'a aggiunta' : 'e aggiunte'}`;

    if (rigaDati['I'] === '' || rigaDati['I'] === null || rigaDati['I'] === undefined) {
      aggiungiLog(`${codiceFinale} — salvata senza prezzo: lo legge il primo controllo prezzi`, '');
    }
    return true;
  }
}

let _accessTokenCorrente = null;
let _userIdCorrente = null;
supabaseClient.auth.onAuthStateChange((_event, session) => {
  _accessTokenCorrente = session?.access_token || null;
  _userIdCorrente = session?.user?.id || null;
});
supabaseClient.auth.getSession().then(({ data }) => {
  _accessTokenCorrente = data?.session?.access_token || null;
  _userIdCorrente = data?.session?.user?.id || null;
});

function _rilasciaRigheDb(ids) {
  if (!ids || ids.length === 0) return;
  _soloSeAncoraMia(supabaseClient.from('coda_carte')
    .update({ stato: 'pending', claimed_by: null, claimed_at: null })
    .in('id', ids))
    .then(({ error }) => {
      if (error) console.error('[coda_carte] rilascio al reset non riuscito:', error.message);
      else aggiungiLog(`${ids.length} cart${ids.length === 1 ? 'a' : 'e'} del sito rimess${ids.length === 1 ? 'a' : 'e'} in coda per gli altri PC`, '');
    });
}

function _rilasciaClaimAllaChiusura() {
  const ids = _codaInvio.filter((it) => it.dbRigaId).map((it) => it.dbRigaId);
  if (ids.length === 0 || !_accessTokenCorrente) return;
  const filtroIds = ids.map((id) => `"${id}"`).join(',');
  const filtroMie = '&stato=eq.in_corso' + (_userIdCorrente ? `&claimed_by=eq.${_userIdCorrente}` : '');
  fetch(`${SUPABASE_URL}/rest/v1/coda_carte?id=in.(${filtroIds})${filtroMie}`, {
    method: 'PATCH',
    keepalive: true,
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: 'Bearer ' + _accessTokenCorrente,
      'Content-Type': 'application/json',
      Prefer: 'return=minimal',
    },
    body: JSON.stringify({ stato: 'pending', claimed_by: null, claimed_at: null }),
  }).catch(() => {});
}
window.addEventListener('beforeunload', _rilasciaClaimAllaChiusura);
window.addEventListener('pagehide', _rilasciaClaimAllaChiusura);

const _LOTTO_RECUPERO_DB = 1;
let _recuperoDaDbInCorso = false;

async function _recuperaAltreRigheDaDb() {
  if (_recuperoDaDbInCorso) return;
  _recuperoDaDbInCorso = true;
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return;

    const sogliaStalloIso = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const filtroEleggibili = `stato.eq.pending,and(stato.eq.in_corso,claimed_at.lt.${sogliaStalloIso})`;
    let selectQuery = supabaseClient
      .from('coda_carte')
      .select('*')
      .or(filtroEleggibili)
      .order('creato_il', { ascending: true })
      .limit(_LOTTO_RECUPERO_DB);
    const { aiutaGruppo } = await chrome.storage.local.get('aiutaGruppo');
    if (!aiutaGruppo) selectQuery = selectQuery.eq('owner_id', userId);
    const { data: candidate, error: errLettura } = await selectQuery;
    if (errLettura) { console.error('[coda_carte] errore lettura:', errLettura.message); return; }
    if (!candidate || candidate.length === 0) return;

    const precedenza = await _chiediPrecedenzaCoda(candidate[0].creato_il, false);
    if (precedenza.attendi) {
      if (_bulkAttivo) _mostraAttesaCoda(precedenza.motivo);
      return;
    }

    const ids = candidate.map((r) => r.id);
    const nomeDisp = await nomeDispositivo();
    const { data: claimate, error: errClaim } = await supabaseClient
      .from('coda_carte')
      .update({ stato: 'in_corso', claimed_by: userId, claimed_at: new Date().toISOString(), dispositivo: nomeDisp })
      .in('id', ids)
      .or(filtroEleggibili)
      .select();
    if (errClaim) { console.error('[coda_carte] errore claim:', errClaim.message); return; }
    if (!claimate || claimate.length === 0) return;
    console.log(`[coda_carte] ${nomeDisp} ha preso in carico ${claimate.length} riga/righe.`);

    const datiRighe = claimate.map((r) => ({
      codice: r.nome,
      lingua: r.lingua || 'IT',
      condizione: r.condizione || 'NM',
      qty: r.qty || 1,
      reverse: !!r.reverse,
      oloType: r.reverse ? 'RH' : '',
      firstEd: !!r.first_ed,
      sigillataOriginale: !!r.sigillata_originale,
      integrita: r.integrita_packaging || 'sigillato_integro',
      notaBulk: r.nota || '',
      dbRigaId: r.id,
      ownerId: r.owner_id || null,
      location: r.location || null,
      urlDiretto: r.url_diretto || null,
      tipo: r.tipo || null,
      destinazione: r.destinazione || 'collezione',
      prezzoObiettivo: r.prezzo_obiettivo ?? null,
      tentativiFalliti: r.tentativi_falliti || 0,
    }));
    datiRighe.forEach(_rigaCartaDalSito);
  } finally {
    _recuperoDaDbInCorso = false;
  }
}

function _recuperaSeFermo() {
  if (_bulkAttivo || _codaInvio.length > 0) return;
  _recuperaAltreRigheDaDb();
}
setInterval(_recuperaSeFermo, 20000);

chrome.alarms.create('recuperaCodaCarte', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'recuperaCodaCarte') _recuperaSeFermo();
});

function formattaDataOra(ts) {
  if (!ts) return null;
  const d   = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// Senza accesso a Cardmarket: apre la scheda per accedere e aspetta (fino a 20 minuti) che l'accesso
// si veda, poi si riparte da soli. Lo stato arriva dal background in storage (statoLoginCardmarket).
function _attendiAccessoCardmarket(minuti = 20) {
  return new Promise((resolve) => {
    let finito = false;
    const fine = (ok) => {
      if (finito) return;
      finito = true;
      clearTimeout(timer);
      chrome.storage.onChanged.removeListener(suCambio);
      resolve(ok);
    };
    const suCambio = (c) => {
      const nuovo = c.statoLoginCardmarket && c.statoLoginCardmarket.newValue;
      if (nuovo && nuovo.loggato === true) fine(true);
    };
    const timer = setTimeout(() => fine(false), minuti * 60 * 1000);
    chrome.storage.onChanged.addListener(suCambio);
    chrome.runtime.sendMessage({ type: 'CM_ACCESSO_APRI' }, () => { void chrome.runtime.lastError; });
  });
}

async function _accessoCardmarketPronto() {
  setStatus('🔍 Controllo l\'accesso a Cardmarket...', 'info');
  let risposta;
  try {
    risposta = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_SILENZIOSA' }, (r) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(r);
      });
    });
  } catch (e) {
    setStatus('⚠️ Non riesco a controllare l\'accesso a Cardmarket (' + e.message + ') — riprova tra poco.', 'errore');
    return false;
  }
  if (risposta && risposta.loggato === true) return true;
  setStatus(risposta && risposta.cloudflare
    ? '🔒 Cardmarket chiede una verifica: completala nella scheda che ho aperto (e accedi con l\'account secondario se serve). Parto da solo appena hai fatto.'
    : '🔒 Accedi a Cardmarket nella scheda che ho aperto, con l\'account secondario. Parto da solo appena hai fatto.', 'info');
  const ok = await _attendiAccessoCardmarket();
  if (!ok) {
    setStatus('⏹ Non ho visto l\'accesso a Cardmarket in 20 minuti: premi di nuovo Avvia quando sei pronto.', 'errore');
    return false;
  }
  setStatus('🔓 Collegato a Cardmarket: parto.', 'ok');
  return true;
}

// Rileggi un prezzo mancante dopo (secondi, per indice dello slider del menu Impostazioni)
const RICONTROLLO_SECONDI = [0, 10, 20, 30, 60];

window.addEventListener('message', (e) => {
  if (e.source !== window.parent || window.parent === window) return;
  if (e.data && e.data.type === 'CARDSYNC_FERMA' && _bulkAttivo && !_stopRichiesto) {
    const btn = document.getElementById('btnBulkAggiungi');
    if (btn && typeof btn.onclick === 'function') btn.onclick();
  }
  if (e.data && e.data.type === 'CARDSYNC_RIPRENDI' && !_bulkAttivo && _codaInvio.length > 0) avviaElaborazioneCoda();
});

(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('footer-credit');
  if (!footer) return;
  footer.textContent = 'Bindex · estensione v' + chrome.runtime.getManifest().version + ' · © Lunachiara';
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

function setStatus(msg, tipo = '') {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = msg ? `visible ${tipo}` : '';
}

document.getElementById('logHeader').addEventListener('click', () => {
  document.getElementById('logBody').classList.toggle('visible');
  document.getElementById('logHeader').classList.toggle('open');
});

function aggiungiLog(msg, tipo = 'ok') {
  logCount++;
  logEntries.push({ n: logCount, msg, tipo });
  document.getElementById('logBadge').textContent = logCount;

  const empty = document.querySelector('.log-empty');
  if (empty) empty.remove();

  const entry  = document.createElement('div');
  entry.className = 'log-entry';

  const rigaEl = document.createElement('span');
  rigaEl.className   = 'log-row';
  rigaEl.textContent = `#${logCount}`;

  const msgEl = document.createElement('span');
  msgEl.className   = `log-msg ${tipo}`;
  msgEl.textContent = msg;

  entry.appendChild(rigaEl);
  entry.appendChild(msgEl);

  const body = document.getElementById('logBody');
  body.insertBefore(entry, body.firstChild);
  body.classList.add('visible');
  document.getElementById('logHeader').classList.add('open');
}

document.getElementById('logCopy').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const testo = [...logEntries].reverse().map(e => `#${e.n}\t${e.msg}`).join('\n');
  navigator.clipboard.writeText(testo).then(() => {
    const btn = document.getElementById('logCopy');
    btn.textContent = '✅';
    setTimeout(() => { btn.textContent = '📋'; }, 1500);
  });
});

document.getElementById('logCsv').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const righe = ['#,Messaggio,Tipo'];
  [...logEntries].reverse().forEach(e => {
    const msg  = '"' + (e.msg  || '').replace(/"/g, '""') + '"';
    const tipo = '"' + (e.tipo || '').replace(/"/g, '""') + '"';
    righe.push(`${e.n},${msg},${tipo}`);
  });
  const blob = new Blob([righe.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'cardsync_bulk_' + new Date().toISOString().slice(0, 10) + '.csv';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('logClear').addEventListener('click', (e) => {
  e.stopPropagation();
  logEntries = [];
  logCount   = 0;
  const body = document.getElementById('logBody');
  body.innerHTML = '<div class="log-empty">Nessuna carta aggiunta ancora.</div>';
  document.getElementById('logBadge').textContent = '0';
});

document.getElementById('btnReset').addEventListener('click', () => {
  setStatus('', '');
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'carte' });
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'sealed' });
  _stopRichiesto = true;
  _rilasciaRigheDb(_codaInvio.filter((it) => it.dbRigaId).map((it) => it.dbRigaId));
  _codaInvio = [];
  _posizioneAssoluta = 0;
  _okSessione = 0;
  const tbodyCarte = document.getElementById('tbodyCarte');
  if (tbodyCarte) tbodyCarte.innerHTML = '';
  aggiornaCodaBadge();
  aggiornaBottoneFerma();

  const timerRiga = document.getElementById('timerRigaAttiva');
  if (timerRiga) timerRiga.classList.remove('visible');

  logEntries = [];
  logCount   = 0;
  const logBody = document.getElementById('logBody');
  if (logBody) { logBody.innerHTML = '<div class="log-empty">Nessuna carta aggiunta ancora.</div>'; }
  document.getElementById('logBadge').textContent = '0';
});
const _LIMITE_RIGHE_GRUPPO = 200;
const _PAUSA_MAX_RITMO_MS = 5 * 60 * 1000;
let _filtroCoda = 'tutte';
let _letturaGruppoInCorso = false;
let _ultimaLetturaGruppo = 0;
let _contaFatteOggi = 0;

function _mioUserId() {
  try { return _userIdCorrente; } catch (_) { return null; }
}

function _diPerOwner(ownerId) {
  const mio = _mioUserId();
  if (!ownerId || (mio && ownerId === mio)) return { testo: 'tu', classe: 'mia' };
  return { testo: 'gruppo', classe: 'gruppo' };
}

function _scriviLocationEDi(refs, item) {
  if (item.dbRigaId) refs.tr.dataset.dbId = String(item.dbRigaId);
  if (item.ownerId) refs.tr.dataset.ownerId = item.ownerId;
  const di = item.dbRigaId ? _diPerOwner(item.ownerId) : { testo: 'tu', classe: 'mia' };
  refs.tr.dataset.di = di.classe;
  if (refs.tdDi) refs.tdDi.textContent = di.testo;
  if (refs.tdLocation) refs.tdLocation.textContent = item.location || '';
  _programmaContiFiltri();
}

let _timerContiFiltri = null;
function _programmaContiFiltri() {
  if (_timerContiFiltri) return;
  _timerContiFiltri = setTimeout(() => { _timerContiFiltri = null; _aggiornaContiFiltri(); }, 150);
}

function _cartaPerHome(item) {
  const di = item.dbRigaId ? _diPerOwner(item.ownerId) : { testo: 'tu', classe: 'mia' };
  return {
    nome: item.codice || '',
    lingua: item.lingua || '',
    cond: item.tipo === 'sealed' ? '' : (item.condizione || ''),
    di: di.classe === 'mia' ? 'tua' : 'del gruppo',
  };
}

function _attivitaAllaHome(dati) {
  if (window.parent === window) return;
  const origine = location.origin && location.origin !== 'null' ? location.origin : '*';
  try { window.parent.postMessage({ type: 'CARDSYNC_ATTIVITA', chi: 'coda', ...dati }, origine); } catch (_) {   }
}

function _cella(testo, classe) {
  const td = document.createElement('td');
  if (classe) td.className = classe;
  if (testo != null) td.textContent = testo;
  return td;
}

function _pillVarianti(r) {
  const td = _cella(null, 'col-var');
  [[r.reverse, 'RH'], [r.first_ed, '1ª'], [r.sigillata_originale, 'SIG']].forEach(([on, t]) => {
    if (!on) return;
    const s = document.createElement('span');
    s.className = 'pill-var';
    s.textContent = t;
    td.appendChild(s);
  });
  return td;
}

function _rigaGruppo(r, nomeDisp, fatta) {
  const tr = document.createElement('tr');
  const di = _diPerOwner(r.owner_id);
  tr.className = 'riga-gruppo ' + (fatta ? 'riga-ok' : (r.stato === 'in_corso' ? 'riga-lettura' : 'riga-coda'));
  tr.dataset.di = di.classe;
  if (r.owner_id) tr.dataset.ownerId = r.owner_id;
  tr.appendChild(_cella(null, 'num-riga'));
  const tdNome = _cella(null, 'col-nome');
  const nome = document.createElement('span');
  nome.className = 'testo-nome';
  nome.textContent = r.nome || '(senza nome)';
  tdNome.appendChild(nome);
  if (r.destinazione === 'wishlist' || r.tipo === 'sealed') {
    const tag = document.createElement('span');
    tag.className = 'tag-tipo';
    tag.textContent = [r.tipo === 'sealed' ? 'sealed' : '', r.destinazione === 'wishlist' ? 'wishlist' : ''].filter(Boolean).join(' · ');
    tdNome.appendChild(tag);
  }
  tr.appendChild(tdNome);
  tr.appendChild(_cella(r.lingua || 'IT', 'col-lang'));
  tr.appendChild(_cella(r.tipo === 'sealed' ? '—' : (r.condizione || 'NM'), 'col-cond'));
  tr.appendChild(_pillVarianti(r));
  tr.appendChild(_cella(String(r.qty || 1), 'col-qty'));
  tr.appendChild(_cella(r.location || '', 'col-loc'));
  tr.appendChild(_cella(di.testo, 'col-di'));
  tr.appendChild(_cella(r.nota || '', 'col-note'));
  let esito;
  if (fatta) {
    const ora = r.completato_il ? new Date(r.completato_il).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) : '';
    esito = 'fatta ' + ora;
  } else if (r.stato === 'in_corso') {
    esito = r.dispositivo && r.dispositivo === nomeDisp ? 'in lettura qui' : 'su un altro PC';
  } else {
    esito = 'in coda';
  }
  tr.appendChild(_cella(esito, 'col-stato'));
  tr.appendChild(_cella(null, 'col-togli'));
  return tr;
}

function _aggiornaContiFiltri() {
  const righe = [...document.querySelectorAll('#tbodyCarte tr, #tbodyGruppo tr.riga-gruppo')];
  const conta = (sel) => righe.filter(sel).length;
  const scrivi = (id, n) => { const el = document.getElementById(id); if (el) el.textContent = String(n); };
  scrivi('contaTutte', righe.length);
  scrivi('contaMie', conta((tr) => tr.dataset.di === 'mia'));
  scrivi('contaGruppo', conta((tr) => tr.dataset.di === 'gruppo'));
  scrivi('contaFatte', _contaFatteOggi);
  const vuota = document.getElementById('rigaCodaVuota');
  if (!vuota) return;
  const visibili = _filtroCoda === 'fatte' ? _contaFatteOggi
    : _filtroCoda === 'mie' ? conta((tr) => tr.dataset.di === 'mia')
    : _filtroCoda === 'gruppo' ? conta((tr) => tr.dataset.di === 'gruppo')
    : righe.length;
  vuota.hidden = visibili > 0;
  vuota.firstElementChild.textContent = _filtroCoda === 'fatte' ? 'Nessuna carta fatta oggi.'
    : _filtroCoda === 'mie' ? 'Nessuna tua carta in coda.'
    : _filtroCoda === 'gruppo' ? 'Nessuna carta del gruppo in coda.'
    : 'Niente in coda: le carte aggiunte dal sito compaiono qui.';
}

function _applicaFiltroCoda(filtro) {
  _filtroCoda = filtro;
  const tabella = document.querySelector('table.tabella-carte');
  if (tabella) tabella.dataset.filtro = filtro;
  document.querySelectorAll('#filtriCoda [data-filtro]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.filtro === filtro)));
  _aggiornaContiFiltri();
}
document.querySelectorAll('#filtriCoda [data-filtro]').forEach((b) => {
  b.addEventListener('click', () => _applicaFiltroCoda(b.dataset.filtro));
});

function _scriviSottotitoloCoda(nPending, nInCorso, fatteQui) {
  const el = document.getElementById('codaSottotitolo');
  if (!el) return;
  const parti = [`${nPending} in attesa`, `${nInCorso} in corso`];
  const tempi = fatteQui.map((r) => new Date(r.completato_il).getTime()).filter(Number.isFinite).sort((a, b) => a - b);
  const distanze = [];
  for (let i = 1; i < tempi.length; i++) {
    const d = tempi[i] - tempi[i - 1];
    if (d > 0 && d < _PAUSA_MAX_RITMO_MS) distanze.push(d);
  }
  if (distanze.length >= 3) {
    distanze.sort((a, b) => a - b);
    parti.push(`su questo PC una carta ogni ${Math.round(distanze[Math.floor(distanze.length / 2)] / 1000)} s`);
  }
  el.textContent = parti.join(' · ');
}

async function _aggiornaCodaGruppo(forza) {
  if (!forza && (window.innerWidth === 0 || document.visibilityState === 'hidden')) return;
  if (_letturaGruppoInCorso) return;
  _letturaGruppoInCorso = true;
  _ultimaLetturaGruppo = Date.now();
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    if (!sessionData || !sessionData.session) return;
    const nomeDisp = await nomeDispositivo();
    const mezzanotte = new Date(); mezzanotte.setHours(0, 0, 0, 0);
    const colonne = 'id, nome, lingua, condizione, qty, reverse, first_ed, sigillata_originale, nota, location, tipo, destinazione, stato, owner_id, creato_il, dispositivo, completato_il';
    const [attiveQ, contaPQ, contaCQ, fatteQ] = await Promise.all([
      supabaseClient.from('coda_carte').select(colonne).in('stato', ['pending', 'in_corso']).order('creato_il', { ascending: true }).limit(_LIMITE_RIGHE_GRUPPO),
      supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'pending'),
      supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'in_corso'),
      supabaseClient.from('coda_carte').select(colonne, { count: 'exact' }).eq('stato', 'completato').gte('completato_il', mezzanotte.toISOString())
        .order('completato_il', { ascending: false }).limit(_LIMITE_RIGHE_GRUPPO),
    ]);
    const errore = [attiveQ, contaPQ, contaCQ, fatteQ].find((r) => r.error);
    if (errore) { console.error('[coda del gruppo]', errore.error.message); return; }

    const attive = (attiveQ.data || []).filter((r) => r.stato === 'pending' || r.stato === 'in_corso');
    const fatte = (fatteQ.data || []).filter((r) => r.stato === 'completato' && r.completato_il);

    const giaQui = new Set([...document.querySelectorAll('#tbodyCarte tr[data-db-id]')].map((tr) => tr.dataset.dbId));
    const tbodyGruppo = document.getElementById('tbodyGruppo');
    const tbodyFatte = document.getElementById('tbodyFatte');
    if (tbodyGruppo) {
      const frammento = document.createDocumentFragment();
      attive.filter((r) => !giaQui.has(String(r.id))).forEach((r) => frammento.appendChild(_rigaGruppo(r, nomeDisp, false)));
      tbodyGruppo.querySelectorAll('tr.riga-gruppo').forEach((tr) => tr.remove());
      tbodyGruppo.appendChild(frammento);
    }
    if (tbodyFatte) {
      const frammento = document.createDocumentFragment();
      fatte.forEach((r) => frammento.appendChild(_rigaGruppo(r, nomeDisp, true)));
      tbodyFatte.innerHTML = '';
      tbodyFatte.appendChild(frammento);
    }
    _contaFatteOggi = fatteQ.count != null ? fatteQ.count : fatte.length;
    _scriviSottotitoloCoda(contaPQ.count || 0, contaCQ.count || 0, fatte.filter((r) => r.dispositivo === nomeDisp));
    _aggiornaContiFiltri();
  } catch (e) {
    console.error('[coda del gruppo]', e.message);
  } finally {
    _letturaGruppoInCorso = false;
  }
}

setInterval(() => _aggiornaCodaGruppo(false), 15000);
window.addEventListener('resize', () => {
  if (window.innerWidth > 0 && Date.now() - _ultimaLetturaGruppo > 5000) _aggiornaCodaGruppo(false);
});
_applicaFiltroCoda('tutte');
setTimeout(() => _aggiornaCodaGruppo(true), 400);
