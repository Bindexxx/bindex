// ── coda_pendente.js ─────────────────────────────────────────────────────────
// Colonna "Coda pendente" nell'hub (app.html): pannello NATIVO (non un
// iframe di un'altra pagina) che mostra, in sola lettura, la situazione
// attuale delle code condivise — in stile "Gestione attività" di Windows:
// una scheda per ogni funzione (Coda pendente, Controllo prezzi, Aggiungi
// carte e sealed), con barre che mostrano i numeri di ADESSO (non un
// grafico nel tempo — solo lo stato attuale, più semplice e più veloce da
// leggere al volo). Non scrive MAI nulla nel database: solo SELECT.
//
// v5.37 (piano 2026-10-23, B8): le richieste wishlist dal sito arrivano in
// 'coda_carte' con destinazione 'wishlist' (la vecchia 'coda_wishlist' è
// vuota e non la scrive più nessuno) e le lavora la sezione Carte: qui
// compaiono come "di cui wishlist" dentro la coda. Tolta la scheda Wishlist
// (la sezione non esiste più).
//
// Stati possibili di una riga: 'pending' (in attesa che qualcuno la prenda
// in carico), 'in_corso' (un dispositivo la sta processando), 'completato'
// (finita bene — non mostrata qui). Una riga finita male NON resta in
// coda_carte: sposta_riga_in_correzione_manuale la sposta in
// 'correzioni_manuali_carte' (si sistema dal sito). "Errori recenti" legge
// quindi da lì — solo le TUE righe: la tabella le mostra solo al proprietario.

(function () {
  const INTERVALLO_AGGIORNAMENTO_MS = 15000;
  const FINESTRA_ERRORI_RECENTI_MIN = 15;
  const FINESTRA_CLAIM_PREZZI_MIN = 10; // stessa soglia di "abbandonato" usata altrove per i claim
  const LIMITE_LISTA = 200; // righe mostrate nell'elenco; i numeri in alto sono sempre quelli veri
  const LIMITE_CORREZIONI = 50; // tue righe in correzioni_manuali_carte lette a ogni giro

  // Le 3 "schede" (Coda/Prezzi/Carte e sealed) sono card affiancate nella
  // home, sempre visibili insieme (vedi app.html, #codaPendentePrincipaleBody/
  // #codaPendentePrezziBody/#codaPendenteCarteBody). I sealed passano da
  // coda_carte (tipo 'sealed'), le richieste wishlist pure (destinazione
  // 'wishlist'): niente card a parte per loro.
  const elPrincipale = document.getElementById('codaPendentePrincipaleBody');
  const elPrezzi     = document.getElementById('codaPendentePrezziBody');
  const elCarte      = document.getElementById('codaPendenteCarteBody');
  const elDettaglio  = document.getElementById('codaPendenteDettaglioBody'); // sezione "coda-dettaglio", stesso contenuto della card principale
  const elUltimoAgg  = document.getElementById('codaPendenteUltimoAgg');
  if (!elPrincipale || !elPrezzi || !elCarte || !elUltimoAgg) return; // colonna non presente in questa pagina

  let ultimiDati = null; // cache dell'ultima lettura

  function escapeHtml(testo) {
    const div = document.createElement('div');
    div.textContent = testo == null ? '' : String(testo);
    return div.innerHTML;
  }

  function tempoFa(iso) {
    if (!iso) return null;
    const minuti = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
    if (minuti < 1) return 'meno di 1 min fa';
    if (minuti === 1) return '1 min fa';
    if (minuti < 60) return minuti + ' min fa';
    const ore = Math.round(minuti / 60);
    return ore === 1 ? '1 ora fa' : ore + ' ore fa';
  }

  function etichettaTipo(riga) {
    const parti = [];
    parti.push(riga.tipo === 'sealed' ? 'Sealed' : 'Carta');
    if (riga.destinazione === 'wishlist') parti.push('Wishlist');
    if (riga.qty && riga.qty > 1) parti.push('x' + riga.qty);
    return parti.join(' · ');
  }

  function renderRigaAttiva(riga) {
    const badgeClasse = riga.stato === 'in_corso' ? 'in_corso' : 'pending';
    const badgeTesto = riga.stato === 'in_corso' ? 'In corso' : 'In attesa';
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge ${badgeClasse}">${badgeTesto}</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(etichettaTipo(riga))}</span>
      </div>
    `;
  }

  function renderRigaErrore(riga) {
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge errore">Errore</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(riga.errore_msg || 'Errore non specificato')}</span>
      </div>
    `;
  }

  // Righe (in attesa/in corso) di coda_carte: usate sia per i numeri delle barre sia per la lista dettagliata sotto.
  // totali (facoltativo): conteggi veri dal database. La lista è limitata a
  // LIMITE_LISTA righe, quindi contare le righe della lista sbagliava: con
  // 600 carte in coda mostrava "199 in attesa · 1 in corso".
  function riepilogo(righeAttive, righeErrore, totali) {
    const pending = righeAttive.filter((r) => r.stato === 'pending');
    const inCorso = righeAttive.filter((r) => r.stato === 'in_corso');
    const nPending = totali ? totali.pending : pending.length;
    const nInCorso = totali ? totali.inCorso : inCorso.length;
    const dispositivi = Array.from(new Set(inCorso.map((r) => r.dispositivo).filter(Boolean)));
    // righeAttive è già ordinata dal più vecchio al più recente (vedi query) —
    // il primo 'pending' è quindi il più vecchio in attesa.
    const piuVecchia = pending.length > 0 ? pending[0].creato_il : null;
    const nascoste = Math.max(0, nPending + nInCorso - righeAttive.length);
    return { pending, inCorso, nPending, nInCorso, nascoste, dispositivi, piuVecchia, righeAttive, righeErrore };
  }

  function testoAltre(n) {
    return n > 0 ? `<p class="coda-pendente-sotto" style="padding: 0.3rem 0 0.6rem; display:block;">… e altre ${n} righe in coda (qui si vedono le prime ${LIMITE_LISTA}, dalla più vecchia)</p>` : '';
  }

  function barra(label, valore, max) {
    const percento = Math.round((valore / max) * 100);
    return `
      <div class="cpm-bar-row">
        <span class="cpm-bar-label">${escapeHtml(label)}</span>
        <div class="cpm-bar-track"><div class="cpm-bar-fill" style="width:${percento}%"></div></div>
        <span class="cpm-bar-value">${valore}</span>
      </div>
    `;
  }

  // Privacy: dei dispositivi si mostra solo QUANTI sono al lavoro, mai il
  // loro nome (richiesta esplicita, 2026-10-15). Il nome resta nel database
  // solo per coordinare chi ha preso in carico cosa.
  function testoDispositivi(dispositivi) {
    return dispositivi.length > 0 ? String(dispositivi.length) : '—';
  }

  function statRiga(label, valore) {
    return `
      <div class="cpm-stat-row">
        <span class="cpm-stat-label">${escapeHtml(label)}</span>
        <span class="cpm-stat-value">${escapeHtml(valore)}</span>
      </div>
    `;
  }

  function listaOVuoto(righe, renderer, testoVuoto) {
    if (!righe || righe.length === 0) return `<p class="coda-pendente-vuoto">${escapeHtml(testoVuoto)}</p>`;
    return righe.map(renderer).join('');
  }

  // ── SCHEDA "Coda pendente" (coda_carte + prezzi) — HTML, non più
  // scritta direttamente: usata sia per la card principale in home sia per
  // la sezione "coda-dettaglio" (stesso contenuto, due punti di vista). ──
  // soloRiepilogo: per la card della home bastano barre e numeri; gli elenchi
  // stanno nella pagina "Vedi dettagli". Prima la card li conteneva tutti,
  // messi in fila come colonne: con tante carte in coda l'elenco diventava
  // una colonna stretta e altissima e spingeva giù le altre schede.
  function htmlSchedaCoda(dati, soloRiepilogo) {
    const carte = riepilogo(dati.codaCarteAttive, dati.correzioniRecenti, dati.totaliCarte);
    // "di cui wishlist": conteggi veri dal database (come totaliCarte).
    const wl = dati.totaliWishlist || { pending: 0, inCorso: 0 };

    // AGGIUNTA (richiesta esplicita di Claudio, sessione 23/08/2026): il
    // controllo prezzi non ha una coda persistente di "righe da fare" come
    // le carte — solo prenotazioni attive (carteReclamate, da
    // leggi_stato_claim_gruppo) e ordini dal sito (ordiniPrezzi). Niente
    // concetto di "errore" salvato da nessuna parte per il controllo prezzi
    // (i fallimenti restano solo nel log della sessione, lato client, mai
    // scritti su una tabella) — il suo contributo al conteggio errori resta
    // sempre 0, di proposito, non un dato mancante. E leggi_stato_claim_
    // gruppo non restituisce il nome della carta, quindi non può comparire
    // riga per riga nell'elenco sotto come le carte — solo nei numeri
    // aggregati in alto, con una nota se ce n'è in corso.
    const prezziOrdiniPendenti = (dati.ordiniPrezzi || []).filter((o) => o.stato === 'pending').length;
    const prezziInCorso = (dati.carteReclamate || []).length;
    const prezziDispositivi = Array.from(new Set((dati.carteReclamate || []).map((r) => r.dispositivo).filter(Boolean)));

    const inAttesa = carte.nPending + prezziOrdiniPendenti;
    const inCorso  = carte.nInCorso + prezziInCorso;
    const errori   = carte.righeErrore.length;
    const max = Math.max(1, inAttesa, inCorso, errori);
    const dispositivi = Array.from(new Set([...carte.dispositivi, ...prezziDispositivi]));
    const nDaSistemare = dati.correzioniTue.length;
    const testoDaSistemare = nDaSistemare === 0 ? 'nessuna'
      : (nDaSistemare >= LIMITE_CORREZIONI ? LIMITE_CORREZIONI + '+' : String(nDaSistemare)) + ' (dal sito)';

    const riepilogoHtml = `
      <div class="cpm-bars">
        ${barra('In attesa', inAttesa, max)}
        ${barra('In corso', inCorso, max)}
        ${barra(`Errori (${FINESTRA_ERRORI_RECENTI_MIN} min)`, errori, max)}
      </div>
      <div class="cpm-stats">
        ${statRiga('Carte e sealed', carte.nPending + ' in attesa · ' + carte.nInCorso + ' in corso')}
        ${statRiga('di cui wishlist', wl.pending + ' in attesa · ' + wl.inCorso + ' in corso')}
        ${statRiga('Prezzi', prezziOrdiniPendenti + ' ordini in attesa · ' + prezziInCorso + ' carte in controllo')}
        ${statRiga('Dispositivi al lavoro', testoDispositivi(dispositivi))}
        ${statRiga('Più vecchia in attesa', carte.piuVecchia ? tempoFa(carte.piuVecchia) : '—')}
        ${statRiga('Tue carte da sistemare', testoDaSistemare)}
      </div>`;
    if (soloRiepilogo) return riepilogoHtml;

    // Ogni elenco sta in un solo <div>: la griglia di "coda-dettaglio"
    // (app.html) conta 6 figli fissi, una <p> in più la scombinava.
    return `${riepilogoHtml}
      <div class="coda-pendente-sezione-titolo">In attesa / in corso</div>
      <div>${listaOVuoto(dati.codaCarteAttive, renderRigaAttiva, 'Nessuna riga in attesa o in corso — tutto elaborato.')}${testoAltre(carte.nascoste)}
      ${prezziInCorso > 0 ? `<p class="coda-pendente-sotto" style="padding: 0.3rem 0 0.6rem; display:block;">+ ${prezziInCorso} cart${prezziInCorso === 1 ? 'a' : 'e'} in controllo prezzi (non elencate singolarmente qui — vedi la scheda Prezzi a fianco)</p>` : ''}</div>
      <div class="coda-pendente-sezione-titolo">Errori recenti (ultimi ${FINESTRA_ERRORI_RECENTI_MIN} min)</div>
      <div>${listaOVuoto(carte.righeErrore, renderRigaErrore, 'Nessun errore negli ultimi ' + FINESTRA_ERRORI_RECENTI_MIN + ' minuti.')}</div>
    `;
  }

  // ── SCHEDA "Carte e sealed" ─────────────────────────────────────────────
  // soloRiepilogo: come per la card principale, nella home niente elenchi
  // (con una coda lunga la colonna diventava altissima); si vedono da
  // "Vedi dettagli".
  function htmlSchedaSingola(righeAttive, righeErrore, totali, soloRiepilogo) {
    const r = riepilogo(righeAttive, righeErrore, totali);
    const max = Math.max(1, r.nPending, r.nInCorso, r.righeErrore.length);
    return `
      <div class="cpm-bars">
        ${barra('In attesa', r.nPending, max)}
        ${barra('In corso', r.nInCorso, max)}
        ${barra(`Errori (${FINESTRA_ERRORI_RECENTI_MIN} min)`, r.righeErrore.length, max)}
      </div>
      <div class="cpm-stats">
        ${statRiga('Dispositivi al lavoro', testoDispositivi(r.dispositivi))}
        ${statRiga('Più vecchia in attesa', r.piuVecchia ? tempoFa(r.piuVecchia) : '—')}
      </div>${soloRiepilogo ? '' : `
      <div class="coda-pendente-sezione-titolo">In attesa / in corso</div>
      <div>${listaOVuoto(r.righeAttive, renderRigaAttiva, 'Nessuna riga in attesa o in corso — tutto elaborato.')}${testoAltre(r.nascoste)}</div>
      <div class="coda-pendente-sezione-titolo">Errori recenti (ultimi ${FINESTRA_ERRORI_RECENTI_MIN} min)</div>
      <div>${listaOVuoto(r.righeErrore, renderRigaErrore, 'Nessun errore negli ultimi ' + FINESTRA_ERRORI_RECENTI_MIN + ' minuti.')}</div>`}
    `;
  }

  // ── SCHEDA "Controllo prezzi" ─────────────────────────────────────────────
  // Diversa dalle altre: qui non c'è una coda di "righe da fare" persistente,
  // ma sessioni/prenotazioni. Mostriamo quante carte sono prenotate ADESSO
  // (claimed_by valorizzato di recente, vedi popup.js) e se c'è un ordine dal
  // sito in attesa o in corso.
  function htmlSchedaPrezzi(dati) {
    const carteReclamate = dati.carteReclamate || [];
    const ordini = dati.ordiniPrezzi || [];
    const dispositivi = Array.from(new Set(carteReclamate.map((r) => r.dispositivo).filter(Boolean)));
    const ordiniPendenti = ordini.filter((o) => o.stato === 'pending').length;
    const ordineInCorso = ordini.find((o) => o.stato === 'in_corso') || null;
    const max = Math.max(1, carteReclamate.length, ordiniPendenti);

    return `
      <div class="cpm-bars">
        ${barra('Carte prenotate ora', carteReclamate.length, max)}
        ${barra('Ordini in attesa dal sito', ordiniPendenti, max)}
      </div>
      <div class="cpm-stats">
        ${statRiga('Dispositivi al lavoro', testoDispositivi(dispositivi))}
        ${statRiga('Ordine dal sito in corso', ordineInCorso ? ('da ' + tempoFa(ordineInCorso.preso_in_carico_il)) : 'nessuno')}
      </div>
      <p class="coda-pendente-vuoto">Il controllo prezzi non usa una coda persistente come le altre sezioni: questi numeri riflettono solo il lavoro in corso in questo momento, non c'è uno storico da mostrare.</p>
    `;
  }

  // Scrive tutte le card insieme (Coda/Prezzi/Carte e sealed sono sempre
  // visibili una accanto all'altra nella home).
  function renderTutto() {
    if (!ultimiDati) return;
    elPrincipale.innerHTML = htmlSchedaCoda(ultimiDati, true);
    if (elDettaglio) elDettaglio.innerHTML = htmlSchedaCoda(ultimiDati, false);
    elPrezzi.innerHTML = htmlSchedaPrezzi(ultimiDati);
    elCarte.innerHTML = htmlSchedaSingola(ultimiDati.codaCarteAttive, ultimiDati.correzioniRecenti, ultimiDati.totaliCarte, true);
  }

  async function aggiornaDati() {
    try {
      const { data: sessionData } = await supabaseClient.auth.getSession();
      if (!sessionData || !sessionData.session) {
        const msg = '<p class="coda-pendente-vuoto">Accedi per vedere la coda.</p>';
        elPrincipale.innerHTML = msg;
        elPrezzi.innerHTML = msg;
        elCarte.innerHTML = msg;
        if (elDettaglio) elDettaglio.innerHTML = msg;
        return;
      }

      const soglia15 = Date.now() - FINESTRA_ERRORI_RECENTI_MIN * 60 * 1000;

      // RISOLTO (Problema #1): prima leggeva direttamente 'carte' filtrata
      // solo lato client, appoggiandosi alla policy larga "collezione
      // condivisa per controllo prezzi gruppo" — stessa RPC dedicata già
      // collegata in index.html (leggi_stato_claim_gruppo, SECURITY
      // DEFINER), che applica lei stessa la soglia di 10 minuti
      // (FINESTRA_CLAIM_PREZZI_MIN) e restituisce solo le colonne di
      // coordinamento.
      // v5.37: gli errori non stanno più in coda_carte (stato 'errore', 0
      // righe sul DB): una riga finita male va in correzioni_manuali_carte
      // (creato_il = quando ci è finita). Una sola lettura delle TUE righe:
      // le ultime 15 min sono gli "Errori recenti", il totale è "da sistemare".
      const [codaCarteAttiveQ, correzioniQ, carteReclamateQ, ordiniPrezziQ, contaPendingQ, contaInCorsoQ, contaWlPendingQ, contaWlInCorsoQ] = await Promise.all([
        supabaseClient.from('coda_carte').select('nome, tipo, qty, stato, dispositivo, creato_il, destinazione').in('stato', ['pending', 'in_corso']).order('creato_il', { ascending: true }).limit(LIMITE_LISTA),
        supabaseClient.from('correzioni_manuali_carte').select('nome, errore_msg, creato_il').eq('owner_id', sessionData.session.user.id).order('creato_il', { ascending: false }).limit(LIMITE_CORREZIONI),
        supabaseClient.rpc('leggi_stato_claim_gruppo', { p_soglia_minuti: FINESTRA_CLAIM_PREZZI_MIN }),
        supabaseClient.from('ordini').select('id, stato, creato_il, preso_in_carico_il').eq('tipo', 'controlla_prezzi').in('stato', ['pending', 'in_corso']).order('creato_il', { ascending: false }).limit(5),
        // Solo il conteggio (head: true, nessuna riga scaricata).
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'pending'),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'in_corso'),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'pending').eq('destinazione', 'wishlist'),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'in_corso').eq('destinazione', 'wishlist'),
      ]);

      const primoErrore = [codaCarteAttiveQ, correzioniQ, carteReclamateQ, ordiniPrezziQ, contaPendingQ, contaInCorsoQ, contaWlPendingQ, contaWlInCorsoQ].find((r) => r.error);
      if (primoErrore) throw new Error(primoErrore.error.message);

      ultimiDati = {
        codaCarteAttive: codaCarteAttiveQ.data || [],
        correzioniTue: correzioniQ.data || [],
        correzioniRecenti: (correzioniQ.data || []).filter((r) => r.creato_il && new Date(r.creato_il).getTime() >= soglia15),
        carteReclamate: carteReclamateQ.data || [],
        ordiniPrezzi: ordiniPrezziQ.data || [],
        totaliCarte: { pending: contaPendingQ.count || 0, inCorso: contaInCorsoQ.count || 0 },
        totaliWishlist: { pending: contaWlPendingQ.count || 0, inCorso: contaWlInCorsoQ.count || 0 },
      };
      renderTutto();
      elUltimoAgg.textContent = 'Aggiornato alle ' + new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch (e) {
      elUltimoAgg.textContent = 'Aggiornamento fallito — riprovo tra poco.';
      console.error('[coda_pendente] errore:', e.message);
    }
  }

  aggiornaDati();
  setInterval(aggiornaDati, INTERVALLO_AGGIORNAMENTO_MS);
})();
