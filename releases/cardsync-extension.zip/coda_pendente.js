// Numeri del database per l'app (tessere della Home, Coda del gruppo): solo letture.

(function () {
  const INTERVALLO_AGGIORNAMENTO_MS = 15000;
  const INTERVALLO_PREZZI_MS = 60000;
  const FINESTRA_ERRORI_RECENTI_MIN = 15;
  const FINESTRA_CLAIM_PREZZI_MIN = 10;
  const LIMITE_LISTA = 200;
  const LIMITE_CORREZIONI = 50;
  const LIMITE_FATTE_OGGI = 2000;
  const PAUSA_MAX_RITMO_MS = 5 * 60 * 1000;

  const elDettaglio  = document.getElementById('codaPendenteDettaglioBody');
  const elUltimoAgg  = document.getElementById('codaPendenteUltimoAgg');
  if (!elDettaglio || !elUltimoAgg) return;

  const el = (id) => document.getElementById(id);
  let formatoNumero;
  try { formatoNumero = new Intl.NumberFormat('it-IT', { useGrouping: 'always' }); } catch (_) { formatoNumero = new Intl.NumberFormat('it-IT'); }
  const n = (x) => formatoNumero.format(x || 0);

  let ultimiDati = null;
  let ultimaLetturaPrezzi = 0;

  function escapeHtml(testo) {
    const div = document.createElement('div');
    div.textContent = testo == null ? '' : String(testo);
    return div.innerHTML;
  }

  function tempoFa(iso) {
    if (!iso) return null;
    const minuti = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
    if (minuti < 1) return 'meno di 1 min fa';
    if (minuti === 1) return '1 min fa';
    if (minuti < 60) return minuti + ' min fa';
    const ore = Math.round(minuti / 60);
    return ore === 1 ? '1 ora fa' : ore + ' ore fa';
  }

  function quando(iso) {
    if (!iso) return null;
    const d = new Date(iso);
    const ora = d.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
    const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
    const giorno = new Date(d); giorno.setHours(0, 0, 0, 0);
    const diff = Math.round((oggi - giorno) / 86400000);
    if (diff === 0) return 'oggi alle ' + ora;
    if (diff === 1) return 'ieri alle ' + ora;
    return 'il ' + d.toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit' }) + ' alle ' + ora;
  }

  function etichettaTipo(riga) {
    const parti = [];
    parti.push(riga.tipo === 'sealed' ? 'Sealed' : 'Carta');
    if (riga.destinazione === 'wishlist') parti.push('Wishlist');
    if (riga.qty && riga.qty > 1) parti.push('x' + riga.qty);
    return parti.join(' · ');
  }

  function renderRigaAttiva(riga) {
    const badgeClasse = riga.stato === 'in_corso' ? 'in_corso' : 'pending';
    const badgeTesto = riga.stato === 'in_corso' ? 'In corso' : 'In attesa';
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge ${badgeClasse}">${badgeTesto}</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(etichettaTipo(riga))}</span>
      </div>
    `;
  }

  function renderRigaErrore(riga) {
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge errore">Errore</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(riga.errore_msg || 'Errore non specificato')}</span>
      </div>
    `;
  }

  function riepilogo(righeAttive, righeErrore, totali) {
    const pending = righeAttive.filter((r) => r.stato === 'pending');
    const inCorso = righeAttive.filter((r) => r.stato === 'in_corso');
    const nPending = totali ? totali.pending : pending.length;
    const nInCorso = totali ? totali.inCorso : inCorso.length;
    const dispositivi = Array.from(new Set(inCorso.map((r) => r.dispositivo).filter(Boolean)));
    const piuVecchia = pending.length > 0 ? pending[0].creato_il : null;
    const nascoste = Math.max(0, nPending + nInCorso - righeAttive.length);
    return { pending, inCorso, nPending, nInCorso, nascoste, dispositivi, piuVecchia, righeAttive, righeErrore };
  }

  function testoAltre(nAltre) {
    return nAltre > 0 ? `<p class="coda-pendente-sotto" style="padding: 0.3rem 0 0.6rem; display:block;">… e altre ${nAltre} righe in coda (qui si vedono le prime ${LIMITE_LISTA}, dalla più vecchia)</p>` : '';
  }

  function barra(label, valore, max) {
    const percento = Math.round((valore / max) * 100);
    return `
      <div class="cpm-bar-row">
        <span class="cpm-bar-label">${escapeHtml(label)}</span>
        <div class="cpm-bar-track"><div class="cpm-bar-fill" style="width:${percento}%"></div></div>
        <span class="cpm-bar-value">${valore}</span>
      </div>
    `;
  }

  function testoDispositivi(dispositivi) {
    return dispositivi.length > 0 ? String(dispositivi.length) : '—';
  }

  function statRiga(label, valore) {
    return `
      <div class="cpm-stat-row">
        <span class="cpm-stat-label">${escapeHtml(label)}</span>
        <span class="cpm-stat-value">${escapeHtml(valore)}</span>
      </div>
    `;
  }

  function listaOVuoto(righe, renderer, testoVuoto) {
    if (!righe || righe.length === 0) return `<p class="coda-pendente-vuoto">${escapeHtml(testoVuoto)}</p>`;
    return righe.map(renderer).join('');
  }

  function htmlSchedaCoda(dati) {
    const carte = riepilogo(dati.codaCarteAttive, dati.correzioniRecenti, dati.totaliCarte);
    const wl = dati.totaliWishlist || { pending: 0, inCorso: 0 };

    const prezziOrdiniPendenti = (dati.ordiniPrezzi || []).filter((o) => o.stato === 'pending').length;
    const prezziInCorso = (dati.carteReclamate || []).length;
    const prezziDispositivi = Array.from(new Set((dati.carteReclamate || []).map((r) => r.dispositivo).filter(Boolean)));

    const inAttesa = carte.nPending + prezziOrdiniPendenti;
    const inCorso  = carte.nInCorso + prezziInCorso;
    const errori   = carte.righeErrore.length;
    const max = Math.max(1, inAttesa, inCorso, errori);
    const dispositivi = Array.from(new Set([...carte.dispositivi, ...prezziDispositivi]));
    const nDaSistemare = dati.correzioniTue.length;
    const testoDaSistemare = nDaSistemare === 0 ? 'nessuna'
      : (nDaSistemare >= LIMITE_CORREZIONI ? LIMITE_CORREZIONI + '+' : String(nDaSistemare)) + ' (dal sito)';

    return `
      <div class="cpm-bars">
        ${barra('In attesa', inAttesa, max)}
        ${barra('In corso', inCorso, max)}
        ${barra(`Errori (${FINESTRA_ERRORI_RECENTI_MIN} min)`, errori, max)}
      </div>
      <div class="cpm-stats">
        ${statRiga('Carte e sealed', carte.nPending + ' in attesa · ' + carte.nInCorso + ' in corso')}
        ${statRiga('di cui wishlist', wl.pending + ' in attesa · ' + wl.inCorso + ' in corso')}
        ${statRiga('Prezzi', prezziOrdiniPendenti + ' ordini in attesa · ' + prezziInCorso + ' carte in controllo')}
        ${statRiga('Dispositivi al lavoro', testoDispositivi(dispositivi))}
        ${statRiga('Più vecchia in attesa', carte.piuVecchia ? tempoFa(carte.piuVecchia) : '—')}
        ${statRiga('Tue carte da sistemare', testoDaSistemare)}
      </div>
      <div class="coda-pendente-sezione-titolo">In attesa / in corso</div>
      <div>${listaOVuoto(dati.codaCarteAttive, renderRigaAttiva, 'Nessuna riga in attesa o in corso — tutto elaborato.')}${testoAltre(carte.nascoste)}
      ${prezziInCorso > 0 ? `<p class="coda-pendente-sotto" style="padding: 0.3rem 0 0.6rem; display:block;">+ ${prezziInCorso} cart${prezziInCorso === 1 ? 'a' : 'e'} in controllo prezzi (non elencate singolarmente qui)</p>` : ''}</div>
      <div class="coda-pendente-sezione-titolo">Errori recenti (ultimi ${FINESTRA_ERRORI_RECENTI_MIN} min)</div>
      <div>${listaOVuoto(carte.righeErrore, renderRigaErrore, 'Nessun errore negli ultimi ' + FINESTRA_ERRORI_RECENTI_MIN + ' minuti.')}</div>
    `;
  }

  function tipoProblema(msg) {
    const t = String(msg || '').toLowerCase();
    if (t.includes('più versioni') || t.includes('scegli')) return 'più versioni';
    if (t.includes('link')) return 'link non più valido';
    if (t.includes('variante')) return 'variante non trovata';
    if (t.includes('non trovat')) return 'non trovate su Cardmarket';
    return 'errori di lettura';
  }

  function scriviTessere(dati) {
    const carte = dati.totaliCarte || { pending: 0, inCorso: 0 };
    const inAttesa = (carte.pending || 0) + (carte.inCorso || 0);
    const tue = dati.totaliTue || 0;
    el('tileCodaNum').textContent = n(inAttesa);
    el('tileCodaSotto').textContent = inAttesa === 0 ? 'niente in coda adesso'
      : `${n(tue)} tu${tue === 1 ? 'a' : 'e'} · ${n(Math.max(0, inAttesa - tue))} del gruppo${carte.inCorso ? ' · ' + n(carte.inCorso) + ' in corso' : ''}`;
    const navConta = el('navContaCoda');
    if (navConta) {
      navConta.textContent = n(inAttesa);
      navConta.hidden = inAttesa === 0;
    }

    const nFix = dati.correzioniTue.length;
    const testoFix = nFix >= LIMITE_CORREZIONI ? LIMITE_CORREZIONI + '+' : String(nFix);
    el('tileFixNum').textContent = testoFix;
    const badge = el('tileFixBadge');
    badge.textContent = testoFix;
    badge.hidden = nFix === 0;
    if (nFix === 0) {
      el('tileFixSotto').textContent = 'niente da sistemare';
    } else {
      const conte = new Map();
      dati.correzioniTue.forEach((r) => { const t = tipoProblema(r.errore_msg); conte.set(t, (conte.get(t) || 0) + 1); });
      const tipi = [...conte.entries()].sort((a, b) => b[1] - a[1]).map(([t]) => t);
      el('tileFixSotto').textContent = tipi.slice(0, 2).join(' o ') + (tipi.length > 2 ? '…' : '');
    }
  }

  function scriviFatteOggi(righe) {
    const tempi = (righe || []).map((r) => r && r.completato_il ? new Date(r.completato_il).getTime() : NaN)
      .filter((t) => Number.isFinite(t)).sort((a, b) => a - b);
    const elFatte = el('numFatteOggi');
    if (elFatte) elFatte.innerHTML = `<b>${n(tempi.length)}</b> cart${tempi.length === 1 ? 'a fatta' : 'e fatte'} oggi`;
    const distanze = [];
    for (let i = 1; i < tempi.length; i++) {
      const d = tempi[i] - tempi[i - 1];
      if (d > 0 && d < PAUSA_MAX_RITMO_MS) distanze.push(d);
    }
    const elRitmo = el('numRitmo');
    if (!elRitmo) return;
    if (distanze.length < 3) { elRitmo.hidden = true; return; }
    distanze.sort((a, b) => a - b);
    const mediana = distanze[Math.floor(distanze.length / 2)];
    elRitmo.innerHTML = `una ogni <b>${Math.round(mediana / 1000)} s</b>`;
    elRitmo.hidden = false;
  }

  function scriviPrezzi(p) {
    if (!p) return;
    el('tilePrezziNum').textContent = n(p.daControllare);
    el('tilePrezziEtichetta').textContent = 'da controllare';
    el('tilePrezziEtichetta').title = `Tue carte non controllate da almeno ${p.giorni} giorn${p.giorni === 1 ? 'o' : 'i'}`;
    const parti = [`su ${n(p.totale)} tue`];
    parti.push(p.ultimo ? 'ultimo controllo ' + quando(p.ultimo) : 'mai controllate');
    el('tilePrezziSotto').textContent = parti.join(' · ');
  }

  async function leggiPrezzi(userId) {
    const { giorniMinimi } = await chrome.storage.local.get('giorniMinimi');
    const giorni = parseInt(giorniMinimi, 10) > 0 ? parseInt(giorniMinimi, 10) : 3;
    const base = { p_owner_id_richiesto: null, p_solo_proprie: true, p_filtro_location: null, p_giorni_minimi: giorni };
    const [vecchieQ, tutteQ, ultimoQ] = await Promise.all([
      supabaseClient.rpc('conta_carte_da_controllare_gruppo', { ...base, p_solo_vecchie: true }),
      supabaseClient.rpc('conta_carte_da_controllare_gruppo', { ...base, p_solo_vecchie: false }),
      supabaseClient.from('carte').select('ultimo_controllo').eq('owner_id', userId).not('ultimo_controllo', 'is', null)
        .order('ultimo_controllo', { ascending: false }).limit(1),
    ]);
    const errore = [vecchieQ, tutteQ, ultimoQ].find((r) => r.error);
    if (errore) throw new Error(errore.error.message);
    const ultimo = (ultimoQ.data && ultimoQ.data[0] && ultimoQ.data[0].ultimo_controllo) || null;
    return { daControllare: vecchieQ.data || 0, totale: tutteQ.data || 0, ultimo, giorni };
  }

  async function aggiornaDati() {
    try {
      const { data: sessionData } = await supabaseClient.auth.getSession();
      if (!sessionData || !sessionData.session) {
        elDettaglio.innerHTML = '<p class="coda-pendente-vuoto">Accedi per vedere la coda.</p>';
        elUltimoAgg.textContent = 'Accedi per vedere i numeri del gruppo.';
        return;
      }
      const userId = sessionData.session.user.id;
      const soglia15 = Date.now() - FINESTRA_ERRORI_RECENTI_MIN * 60 * 1000;
      const mezzanotte = new Date(); mezzanotte.setHours(0, 0, 0, 0);
      const nomeDisp = await nomeDispositivo();

      const [codaCarteAttiveQ, correzioniQ, carteReclamateQ, ordiniPrezziQ, contaPendingQ, contaInCorsoQ, contaWlPendingQ, contaWlInCorsoQ, contaTueQ, fatteOggiQ] = await Promise.all([
        supabaseClient.from('coda_carte').select('nome, tipo, qty, stato, dispositivo, creato_il, destinazione').in('stato', ['pending', 'in_corso']).order('creato_il', { ascending: true }).limit(LIMITE_LISTA),
        supabaseClient.from('correzioni_manuali_carte').select('nome, errore_msg, creato_il').eq('owner_id', userId).order('creato_il', { ascending: false }).limit(LIMITE_CORREZIONI),
        supabaseClient.rpc('leggi_stato_claim_gruppo', { p_soglia_minuti: FINESTRA_CLAIM_PREZZI_MIN }),
        supabaseClient.from('ordini').select('id, stato, creato_il, preso_in_carico_il').eq('tipo', 'controlla_prezzi').in('stato', ['pending', 'in_corso']).order('creato_il', { ascending: false }).limit(5),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'pending'),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'in_corso'),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'pending').eq('destinazione', 'wishlist'),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).eq('stato', 'in_corso').eq('destinazione', 'wishlist'),
        supabaseClient.from('coda_carte').select('id', { count: 'exact', head: true }).in('stato', ['pending', 'in_corso']).eq('owner_id', userId),
        supabaseClient.from('coda_carte').select('completato_il').eq('stato', 'completato').eq('dispositivo', nomeDisp)
          .gte('completato_il', mezzanotte.toISOString()).order('completato_il', { ascending: true }).limit(LIMITE_FATTE_OGGI),
      ]);

      const primoErrore = [codaCarteAttiveQ, correzioniQ, carteReclamateQ, ordiniPrezziQ, contaPendingQ, contaInCorsoQ, contaWlPendingQ, contaWlInCorsoQ, contaTueQ, fatteOggiQ].find((r) => r.error);
      if (primoErrore) throw new Error(primoErrore.error.message);

      ultimiDati = {
        codaCarteAttive: codaCarteAttiveQ.data || [],
        correzioniTue: correzioniQ.data || [],
        correzioniRecenti: (correzioniQ.data || []).filter((r) => r.creato_il && new Date(r.creato_il).getTime() >= soglia15),
        carteReclamate: carteReclamateQ.data || [],
        ordiniPrezzi: ordiniPrezziQ.data || [],
        totaliCarte: { pending: contaPendingQ.count || 0, inCorso: contaInCorsoQ.count || 0 },
        totaliWishlist: { pending: contaWlPendingQ.count || 0, inCorso: contaWlInCorsoQ.count || 0 },
        totaliTue: contaTueQ.count || 0,
      };
      elDettaglio.innerHTML = htmlSchedaCoda(ultimiDati);
      scriviTessere(ultimiDati);
      scriviFatteOggi(fatteOggiQ.data);

      if (Date.now() - ultimaLetturaPrezzi >= INTERVALLO_PREZZI_MS) {
        ultimaLetturaPrezzi = Date.now();
        try {
          scriviPrezzi(await leggiPrezzi(userId));
        } catch (e) {
          ultimaLetturaPrezzi = 0;
          console.error('[coda_pendente] prezzi:', e.message);
        }
      }
      elUltimoAgg.textContent = 'Numeri del gruppo aggiornati alle ' + new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch (e) {
      elUltimoAgg.textContent = 'Aggiornamento dei numeri non riuscito — riprovo tra poco.';
      console.error('[coda_pendente] errore:', e.message);
    }
  }

  chrome.storage.onChanged.addListener((cambi) => {
    if (cambi.giorniMinimi) { ultimaLetturaPrezzi = 0; aggiornaDati(); }
  });

  aggiornaDati();
  setInterval(aggiornaDati, INTERVALLO_AGGIORNAMENTO_MS);
})();
