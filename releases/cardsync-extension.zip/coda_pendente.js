// ── coda_pendente.js ─────────────────────────────────────────────────────────
// Colonna "Coda pendente" nell'hub (app.html): pannello NATIVO (non un
// iframe di un'altra pagina) che mostra, in sola lettura, la situazione
// attuale delle code condivise — in stile "Gestione attività" di Windows:
// una scheda per ogni funzione (Coda pendente, Controllo prezzi, Aggiungi
// carte, Wishlist), con barre che mostrano i numeri di ADESSO (non un
// grafico nel tempo — solo lo stato attuale, più semplice e più veloce da
// leggere al volo). Non scrive MAI nulla nel database: solo SELECT.
//
// FIX (bug mai notato prima): la vecchia versione leggeva SOLO 'coda_carte'
// e cercava di riconoscere le righe wishlist da un campo 'destinazione' —
// ma la wishlist vive davvero in una tabella A PARTE ('coda_wishlist', vedi
// aggiungi_wishlist_popup.js), quindi le righe wishlist non comparivano mai
// qui. Ora si leggono entrambe le tabelle.
//
// Stati possibili di una riga: 'pending' (in attesa che qualcuno la prenda
// in carico), 'in_corso' (un dispositivo la sta processando), 'completato'
// (finita bene — non mostrata qui), 'errore' (finita male — mostrata tra
// gli "Errori recenti" per un po', poi sparisce da sola da questa vista).

(function () {
  const INTERVALLO_AGGIORNAMENTO_MS = 15000;
  const FINESTRA_ERRORI_RECENTI_MIN = 15;
  const FINESTRA_CLAIM_PREZZI_MIN = 10; // stessa soglia di "abbandonato" usata altrove per i claim

  // AGGIUNTA v4.18 — le 4 "schede" (Coda/Prezzi/Carte/Wishlist) non sono
  // più un tab-switcher con un solo pannello condiviso: sono 4 card
  // affiancate nella home, sempre visibili insieme (vedi app.html,
  // #codaPendentePrincipaleBody/#codaPendentePrezziBody/#codaPendenteCarteBody/
  // #codaPendenteWishlistBody). "Sealed" non ha una card dinamica qui: non
  // esiste ancora una coda condivisa per il sealed (nessuna tabella
  // coda_sealed), quindi la sua card in app.html è markup statico fisso.
  const elPrincipale = document.getElementById('codaPendentePrincipaleBody');
  const elPrezzi     = document.getElementById('codaPendentePrezziBody');
  const elCarte      = document.getElementById('codaPendenteCarteBody');
  const elWishlist   = document.getElementById('codaPendenteWishlistBody');
  const elDettaglio  = document.getElementById('codaPendenteDettaglioBody'); // sezione "coda-dettaglio", stesso contenuto della card principale
  const elUltimoAgg  = document.getElementById('codaPendenteUltimoAgg');
  if (!elPrincipale || !elPrezzi || !elCarte || !elWishlist || !elUltimoAgg) return; // colonna non presente in questa pagina

  let ultimiDati = null; // cache dell'ultima lettura

  function escapeHtml(testo) {
    const div = document.createElement('div');
    div.textContent = testo == null ? '' : String(testo);
    return div.innerHTML;
  }

  function tempoFa(iso) {
    if (!iso) return null;
    const minuti = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
    if (minuti < 1) return 'meno di 1 min fa';
    if (minuti === 1) return '1 min fa';
    if (minuti < 60) return minuti + ' min fa';
    const ore = Math.round(minuti / 60);
    return ore === 1 ? '1 ora fa' : ore + ' ore fa';
  }

  function etichettaTipo(riga, fonte) {
    const parti = [];
    parti.push(fonte === 'wishlist' ? 'Wishlist' : (riga.tipo === 'sealed' ? 'Sealed' : 'Carta'));
    if (riga.qty && riga.qty > 1) parti.push('x' + riga.qty);
    return parti.join(' · ');
  }

  function renderRigaAttiva(riga, fonte) {
    const badgeClasse = riga.stato === 'in_corso' ? 'in_corso' : 'pending';
    const badgeTesto = riga.stato === 'in_corso' ? 'In corso' : 'In attesa';
    const chi = riga.stato === 'in_corso' && riga.dispositivo ? ` · preso in carico da ${escapeHtml(riga.dispositivo)}` : '';
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge ${badgeClasse}">${badgeTesto}</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(etichettaTipo(riga, fonte))}${chi}</span>
      </div>
    `;
  }

  function renderRigaErrore(riga) {
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge errore">Errore</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(riga.errore_msg || 'Errore non specificato')}</span>
      </div>
    `;
  }

  // Righe (in attesa/in corso), stessa forma per 'carte' e 'wishlist': usate
  // sia per i numeri delle barre sia per la lista dettagliata sotto.
  function riepilogo(righeAttive, righeErrore) {
    const pending = righeAttive.filter((r) => r.stato === 'pending');
    const inCorso = righeAttive.filter((r) => r.stato === 'in_corso');
    const dispositivi = Array.from(new Set(inCorso.map((r) => r.dispositivo).filter(Boolean)));
    // righeAttive è già ordinata dal più vecchio al più recente (vedi query) —
    // il primo 'pending' è quindi il più vecchio in attesa.
    const piuVecchia = pending.length > 0 ? pending[0].creato_il : null;
    return { pending, inCorso, dispositivi, piuVecchia, righeAttive, righeErrore };
  }

  function barra(label, valore, max) {
    const percento = Math.round((valore / max) * 100);
    return `
      <div class="cpm-bar-row">
        <span class="cpm-bar-label">${escapeHtml(label)}</span>
        <div class="cpm-bar-track"><div class="cpm-bar-fill" style="width:${percento}%"></div></div>
        <span class="cpm-bar-value">${valore}</span>
      </div>
    `;
  }

  function statRiga(label, valore) {
    return `
      <div class="cpm-stat-row">
        <span class="cpm-stat-label">${escapeHtml(label)}</span>
        <span class="cpm-stat-value">${escapeHtml(valore)}</span>
      </div>
    `;
  }

  function listaOVuoto(righe, renderer, testoVuoto) {
    if (!righe || righe.length === 0) return `<p class="coda-pendente-vuoto">${escapeHtml(testoVuoto)}</p>`;
    return righe.map(renderer).join('');
  }

  // ── SCHEDA "Coda pendente" (combinata: carte + wishlist) — HTML, non più
  // scritta direttamente: usata sia per la card principale in home sia per
  // la sezione "coda-dettaglio" (stesso contenuto, due punti di vista). ──
  function htmlSchedaCoda(dati) {
    const carte = riepilogo(dati.codaCarteAttive, dati.codaCarteErrori);
    const wishlist = riepilogo(dati.codaWishlistAttive, dati.codaWishlistErrori);

    // AGGIUNTA (richiesta esplicita di Claudio, sessione 23/08/2026): il
    // controllo prezzi non ha una coda persistente di "righe da fare" come
    // carte/wishlist — solo prenotazioni attive (carteReclamate, da
    // leggi_stato_claim_gruppo) e ordini dal sito (ordiniPrezzi). Niente
    // concetto di "errore" salvato da nessuna parte per il controllo prezzi
    // (i fallimenti restano solo nel log della sessione, lato client, mai
    // scritti su una tabella) — il suo contributo al conteggio errori resta
    // sempre 0, di proposito, non un dato mancante. E leggi_stato_claim_
    // gruppo non restituisce il nome della carta, quindi non può comparire
    // riga per riga nell'elenco sotto come carte/wishlist — solo nei numeri
    // aggregati in alto, con una nota se ce n'è in corso.
    const prezziOrdiniPendenti = (dati.ordiniPrezzi || []).filter((o) => o.stato === 'pending').length;
    const prezziInCorso = (dati.carteReclamate || []).length;
    const prezziDispositivi = Array.from(new Set((dati.carteReclamate || []).map((r) => r.dispositivo).filter(Boolean)));

    const inAttesa = carte.pending.length + wishlist.pending.length + prezziOrdiniPendenti;
    const inCorso  = carte.inCorso.length + wishlist.inCorso.length + prezziInCorso;
    const errori   = carte.righeErrore.length + wishlist.righeErrore.length;
    const max = Math.max(1, inAttesa, inCorso, errori);
    const dispositivi = Array.from(new Set([...carte.dispositivi, ...wishlist.dispositivi, ...prezziDispositivi]));
    const vecchie = [carte.piuVecchia, wishlist.piuVecchia].filter(Boolean).sort();
    const righeAttiveTaggate = [
      ...dati.codaCarteAttive.map((r) => ({ r, fonte: 'carte' })),
      ...dati.codaWishlistAttive.map((r) => ({ r, fonte: 'wishlist' })),
    ];
    const righeErroreTotali = [...dati.codaCarteErrori, ...dati.codaWishlistErrori];

    return `
      <div class="cpm-bars">
        ${barra('In attesa', inAttesa, max)}
        ${barra('In corso', inCorso, max)}
        ${barra(`Errori (${FINESTRA_ERRORI_RECENTI_MIN} min)`, errori, max)}
      </div>
      <div class="cpm-stats">
        ${statRiga('Carte', carte.pending.length + ' in attesa · ' + carte.inCorso.length + ' in corso')}
        ${statRiga('Wishlist', wishlist.pending.length + ' in attesa · ' + wishlist.inCorso.length + ' in corso')}
        ${statRiga('Prezzi', prezziOrdiniPendenti + ' ordini in attesa · ' + prezziInCorso + ' carte in controllo')}
        ${statRiga('Dispositivi al lavoro', dispositivi.length > 0 ? dispositivi.join(', ') : '—')}
        ${statRiga('Più vecchia in attesa', vecchie.length > 0 ? tempoFa(vecchie[0]) : '—')}
      </div>
      <div class="coda-pendente-sezione-titolo">In attesa / in corso</div>
      <div>${listaOVuoto(righeAttiveTaggate, (x) => renderRigaAttiva(x.r, x.fonte), 'Nessuna riga in attesa o in corso — tutto elaborato.')}</div>
      ${prezziInCorso > 0 ? `<p class="coda-pendente-sotto" style="padding: 0.3rem 0 0.6rem; display:block;">+ ${prezziInCorso} cart${prezziInCorso === 1 ? 'a' : 'e'} in controllo prezzi (non elencate singolarmente qui — vedi la scheda Prezzi a fianco)</p>` : ''}
      <div class="coda-pendente-sezione-titolo">Errori recenti (ultimi ${FINESTRA_ERRORI_RECENTI_MIN} min)</div>
      <div>${listaOVuoto(righeErroreTotali, renderRigaErrore, 'Nessun errore negli ultimi ' + FINESTRA_ERRORI_RECENTI_MIN + ' minuti.')}</div>
    `;
  }

  // ── SCHEDA "Aggiungi carte" o "Wishlist" (una sola fonte) ────────────────
  function htmlSchedaSingola(righeAttive, righeErrore, fonte) {
    const r = riepilogo(righeAttive, righeErrore);
    const max = Math.max(1, r.pending.length, r.inCorso.length, r.righeErrore.length);
    return `
      <div class="cpm-bars">
        ${barra('In attesa', r.pending.length, max)}
        ${barra('In corso', r.inCorso.length, max)}
        ${barra(`Errori (${FINESTRA_ERRORI_RECENTI_MIN} min)`, r.righeErrore.length, max)}
      </div>
      <div class="cpm-stats">
        ${statRiga('Dispositivi al lavoro', r.dispositivi.length > 0 ? r.dispositivi.join(', ') : '—')}
        ${statRiga('Più vecchia in attesa', r.piuVecchia ? tempoFa(r.piuVecchia) : '—')}
      </div>
      <div class="coda-pendente-sezione-titolo">In attesa / in corso</div>
      <div>${listaOVuoto(r.righeAttive, (riga) => renderRigaAttiva(riga, fonte), 'Nessuna riga in attesa o in corso — tutto elaborato.')}</div>
      <div class="coda-pendente-sezione-titolo">Errori recenti (ultimi ${FINESTRA_ERRORI_RECENTI_MIN} min)</div>
      <div>${listaOVuoto(r.righeErrore, renderRigaErrore, 'Nessun errore negli ultimi ' + FINESTRA_ERRORI_RECENTI_MIN + ' minuti.')}</div>
    `;
  }

  // ── SCHEDA "Controllo prezzi" ─────────────────────────────────────────────
  // Diversa dalle altre: qui non c'è una coda di "righe da fare" persistente,
  // ma sessioni/prenotazioni. Mostriamo quante carte sono prenotate ADESSO
  // (claimed_by valorizzato di recente, vedi popup.js) e se c'è un ordine dal
  // sito in attesa o in corso.
  function htmlSchedaPrezzi(dati) {
    const carteReclamate = dati.carteReclamate || [];
    const ordini = dati.ordiniPrezzi || [];
    const dispositivi = Array.from(new Set(carteReclamate.map((r) => r.dispositivo).filter(Boolean)));
    const ordiniPendenti = ordini.filter((o) => o.stato === 'pending').length;
    const ordineInCorso = ordini.find((o) => o.stato === 'in_corso') || null;
    const max = Math.max(1, carteReclamate.length, ordiniPendenti);

    return `
      <div class="cpm-bars">
        ${barra('Carte prenotate ora', carteReclamate.length, max)}
        ${barra('Ordini in attesa dal sito', ordiniPendenti, max)}
      </div>
      <div class="cpm-stats">
        ${statRiga('Dispositivi al lavoro', dispositivi.length > 0 ? dispositivi.join(', ') : '—')}
        ${statRiga('Ordine dal sito in corso', ordineInCorso ? ('da ' + tempoFa(ordineInCorso.preso_in_carico_il)) : 'nessuno')}
      </div>
      <p class="coda-pendente-vuoto">Il controllo prezzi non usa una coda persistente come le altre sezioni: questi numeri riflettono solo il lavoro in corso in questo momento, non c'è uno storico da mostrare.</p>
    `;
  }

  // AGGIUNTA v4.18 — scrive tutte le card insieme (Coda/Prezzi/Carte/
  // Wishlist sono sempre visibili una accanto all'altra nella home, niente
  // più scheda unica da cambiare a click).
  function renderTutto() {
    if (!ultimiDati) return;
    const htmlCoda = htmlSchedaCoda(ultimiDati);
    elPrincipale.innerHTML = htmlCoda;
    if (elDettaglio) elDettaglio.innerHTML = htmlCoda;
    elPrezzi.innerHTML = htmlSchedaPrezzi(ultimiDati);
    elCarte.innerHTML = htmlSchedaSingola(ultimiDati.codaCarteAttive, ultimiDati.codaCarteErrori, 'carte');
    elWishlist.innerHTML = htmlSchedaSingola(ultimiDati.codaWishlistAttive, ultimiDati.codaWishlistErrori, 'wishlist');
  }

  async function aggiornaDati() {
    try {
      const { data: sessionData } = await supabaseClient.auth.getSession();
      if (!sessionData || !sessionData.session) {
        const msg = '<p class="coda-pendente-vuoto">Accedi per vedere la coda.</p>';
        elPrincipale.innerHTML = msg;
        elPrezzi.innerHTML = msg;
        elCarte.innerHTML = msg;
        elWishlist.innerHTML = msg;
        if (elDettaglio) elDettaglio.innerHTML = msg;
        return;
      }

      const soglia15 = new Date(Date.now() - FINESTRA_ERRORI_RECENTI_MIN * 60 * 1000).toISOString();

      // RISOLTO (Problema #1): prima leggeva direttamente 'carte' filtrata
      // solo lato client, appoggiandosi alla policy larga "collezione
      // condivisa per controllo prezzi gruppo" — stessa RPC dedicata già
      // collegata in index.html (leggi_stato_claim_gruppo, SECURITY
      // DEFINER), che applica lei stessa la soglia di 10 minuti
      // (FINESTRA_CLAIM_PREZZI_MIN) e restituisce solo le colonne di
      // coordinamento.
      // v5.17: tolte le due letture di 'coda_wishlist' fatte a ogni giro —
      // la tabella è vuota (0 righe, verificato sul DB 2026-10-15), il sito
      // non ci scrive più (le richieste wishlist passano da coda_carte) e
      // nell'estensione nessuno la lavora. Le due liste restano vuote qui
      // sotto, così la parte che disegna la pagina non cambia.
      const codaWishlistAttiveQ = { data: [], error: null };
      const codaWishlistErroriQ = { data: [], error: null };
      const [codaCarteAttiveQ, codaCarteErroriQ, carteReclamateQ, ordiniPrezziQ] = await Promise.all([
        supabaseClient.from('coda_carte').select('nome, tipo, qty, stato, dispositivo, creato_il').in('stato', ['pending', 'in_corso']).order('creato_il', { ascending: true }).limit(200),
        supabaseClient.from('coda_carte').select('nome, errore_msg, completato_il').eq('stato', 'errore').gte('completato_il', soglia15).order('completato_il', { ascending: false }).limit(50),
        supabaseClient.rpc('leggi_stato_claim_gruppo', { p_soglia_minuti: FINESTRA_CLAIM_PREZZI_MIN }),
        supabaseClient.from('ordini').select('id, stato, creato_il, preso_in_carico_il').eq('tipo', 'controlla_prezzi').in('stato', ['pending', 'in_corso']).order('creato_il', { ascending: false }).limit(5),
      ]);

      const primoErrore = [codaCarteAttiveQ, codaCarteErroriQ, codaWishlistAttiveQ, codaWishlistErroriQ, carteReclamateQ, ordiniPrezziQ].find((r) => r.error);
      if (primoErrore) throw new Error(primoErrore.error.message);

      ultimiDati = {
        codaCarteAttive: codaCarteAttiveQ.data || [],
        codaCarteErrori: codaCarteErroriQ.data || [],
        codaWishlistAttive: codaWishlistAttiveQ.data || [],
        codaWishlistErrori: codaWishlistErroriQ.data || [],
        carteReclamate: carteReclamateQ.data || [],
        ordiniPrezzi: ordiniPrezziQ.data || [],
      };
      renderTutto();
      elUltimoAgg.textContent = 'Aggiornato alle ' + new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch (e) {
      elUltimoAgg.textContent = 'Aggiornamento fallito — riprovo tra poco.';
      console.error('[coda_pendente] errore:', e.message);
    }
  }

  aggiornaDati();
  setInterval(aggiornaDati, INTERVALLO_AGGIORNAMENTO_MS);
})();
