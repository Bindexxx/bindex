# Changelog — CardSync Pro

Tutte le modifiche rilevanti al progetto sono elencate qui, dalla più recente alla meno recente.

## v5.35 — 2026-10-23

### 🤝 I contributi al gruppo tornano a contare
Dalla 5.31, con la scheda dell'app aperta, la coda "Aggiungi carte" la
lavora solo la pagina dell'app (il worker in background si ferma). Il
contributo però veniva registrato solo dal worker: dal 16/10 le carte
lavorate per gli altri non venivano più contate.
- **`aggiungi_carta_popup.js`**: la riga presa dalla coda porta con sé il
  proprietario; quando la carta è scritta davvero si registra il contributo,
  come fa il worker in background. Le proprie carte continuano a non
  contare.
- Le carte lavorate prima di questa versione non vengono recuperate: il
  conteggio riparte da qui.

## v5.34 — 2026-10-16

### 🔄 Aggiornamenti che entrano davvero in funzione
Dopo `aggiorna_cardsync.bat` su un PC girava ancora il motore della 5.30
con le pagine della 5.33: i file erano stati sostituiti con Chrome ancora
acceso, e il service worker vecchio restava in memoria finché non si
premeva ↻ in `chrome://extensions`.
- **`background.js`**: ogni minuto (alarm `controlla-aggiornamento-file`)
  confronta la versione di `manifest.json` sul disco con quella in uso; se
  sono diverse l'estensione si ricarica da sola (al massimo una volta ogni
  10 minuti per la stessa versione).
- **`aggiorna_cardsync.bat`**: installa solo dopo aver verificato che Chrome
  sia chiuso del tutto; se non si chiude chiede di chiuderlo a mano (anche
  dall'icona vicino all'orologio) e ricontrolla.

## v5.33 — 2026-10-16

### 🔁 "Riapri l'app se viene chiusa" ora funziona
Nella 5.32 l'app non si riapriva: la riapertura scattava solo per le schede
che si erano "registrate" all'avvio, e quel passaggio non funzionava.
- **`background.js`**: con l'interruttore acceso si controlla dopo ogni
  scheda chiusa, una volta al minuto (alarm `riapri-app`) e all'avvio di
  Chrome; se non c'è nessuna scheda dell'app se ne apre una in secondo
  piano. Sempre niente se si sta chiudendo Chrome. Tolto
  `REGISTRA_SCHEDA_APP`.
- **`app.js`**: tolta la registrazione della scheda.

## v5.32 — 2026-10-16

### 🔁 Nuovo interruttore "Riapri l'app se viene chiusa"
Nella home dell'app, sotto "Lavora anche a estensione chiusa". Vale per
questo PC, di base spento.
- Acceso: se chiudi l'ultima scheda dell'app, dopo pochi secondi se ne
  riapre una in secondo piano (su "Coda pendente"). All'avvio di Chrome si
  apre se il ripristino delle schede non l'ha già riaperta.
- Non riapre niente se stai chiudendo Chrome (ultima finestra).
- Per chiuderla davvero: spegni l'interruttore, poi chiudi la scheda.
- **`background.js`**: `_riapriAppSeChiusa`, ascolto di `tabs.onRemoved` e
  `runtime.onStartup`, messaggio `REGISTRA_SCHEDA_APP`.
- **`app.js` / `app.html`**: interruttore (`riapriAppSeChiusa`) e
  registrazione della scheda.

## v5.31 — 2026-10-16

### 🛑 Controllo finale: nessuna carta salvata con il link della lista dell'espansione
Con la 5.30 una carta è passata lo stesso (**"Singole Forze Scatenate"**,
URL `.../Singles/Unleashed`): i controlli erano solo dentro i singoli
percorsi di lettura.
- **`background.js`**: `_leggiNomeDaCardmarket` ora controlla il risultato
  finale di qualunque percorso (fetch, scheda, verifica candidato, retry):
  URL senza la carta o nome "Singole …" → disambiguazione (correzione
  manuale), con avviso nella console. Il nome riletto nella fase prezzo non
  viene preso se è il titolo di una lista.
- **`aggiungi_carta_popup.js`**: stessa verifica subito prima di scrivere la
  carta, con riga nel log ("il link porta alla lista dell'espansione").

### 👥 Coda "Aggiungi carte": una sola parte alla volta
Sullo stesso PC la coda la lavoravano in due insieme: la pagina Aggiungi
carte e il worker in background (una carta al minuto). Il segnale che doveva
fermare il worker con la pagina al lavoro non veniva più scritto.
- **Scheda dell'app aperta**: lavora solo la pagina Aggiungi carte.
- **Scheda chiusa**: lavora il worker in background, solo con "Lavora anche
  a estensione chiusa" acceso. Spento = coda ferma.
- **`background.js`**: nuova `_workerCodaCartePuoLavorare`, usata dal worker
  prima di prendere una carta e di nuovo prima di iniziarla. Gli ordini di
  prezzi seguono la regola di prima (`_lavoroPermessoSuQuestoPc`).

## v5.30 — 2026-10-16

### 🚫 Link che finiscono sulla lista dell'espansione = errore, non una carta
Alcune carte venivano salvate con un nome tipo **"Singole HeartGold e
SoulSilver"**: il link `/Singles/` portava (o veniva reindirizzato) alla
lista delle singole dell'espansione invece che alla pagina della carta, e
l'estensione leggeva il titolo della lista come se fosse il nome.
- **`background.js`**: nuova `_ePaginaListaSingles` — una pagina è "lista"
  se l'URL ha meno di 2 segmenti dopo `/Singles/` oppure se il titolo inizia
  con "Singole"/"Singles"/"Einzelkarten". In quel caso la carta va in
  **disambiguazione** (errore → correzione manuale) con le opzioni trovate
  nella pagina, ristrette alla carta cercata quando possibile. Controllo
  applicato a lettura via fetch, lettura via scheda (dopo i redirect) e
  verifica dei candidati.

## v5.29 — 2026-10-16

### 🔌 "Lavora anche a estensione chiusa": scheda aperta = lavora, scheda chiusa = fermo
Regola semplice, come richiesto: con l'interruttore spento l'estensione
lavora solo se una scheda dell'app è aperta, chiunque l'abbia aperta. Con la
scheda aperta lavora come sempre: coda, ordini, controlli automatici e, con
"Aiuta il gruppo" attivo, anche le carte degli altri. Chiusa la scheda, si
ferma tutto.
- Tolta la distinzione "aperta da te / aperta da sola" della 5.27–5.28 e la
  chiusura automatica delle schede aperte da sola (`background.js`,
  `popup.js`, `aggiungi_wishlist_popup.js`, `aggiungi_carta_popup.js`, messaggio
  `LAVORO_AUTOMATICO_PERMESSO` e segnale `sessioneCodaAttiva_carte` rimossi).
- Resta la pausa tra una carta e l'altra in Aggiungi carte (5.28).

### 🧵 Un solo lavoro su Cardmarket alla volta per PC
Controllo prezzi (carte, sealed, wishlist) e coda "Aggiungi carte" (pagina
dell'app e worker in background) giravano insieme, ognuno con la sua scheda
Cardmarket: due lavori in parallelo e fino a tre schede aperte. Ora su ogni
PC ne gira uno alla volta e **chi arriva prima finisce**.
- **`background.js`**: con la coda al lavoro gli ordini di prezzi restano in
  attesa; mentre un ordine di prezzi sta partendo (verifica login, apertura
  app) non se ne prende un secondo e la coda non parte (`prezziInPartenza`).
  Il worker in background non prende carte se gira un controllo prezzi, se la
  pagina dell'app sta già lavorando la coda o se c'è un ordine di prezzi
  arrivato prima della carta (`workerAutonomoAttivo` mentre lavora). Nuovo
  messaggio `PRECEDENZA_CODA_CARDMARKET` per le pagine.
- **`aggiungi_carta_popup.js`**: segnale `sessioneCodaAttiva_carte` mentre la
  coda lavora; non prende carte dal database durante un controllo prezzi o se
  un ordine di prezzi è arrivato prima; le carte inserite a mano aspettano la
  fine del controllo in corso, con il motivo a schermo.
- **`popup.js`, `aggiungi_wishlist_popup.js`**: un controllo prezzi avviato
  con la coda al lavoro aspetta che finisca; "mi unisco" e controllo in
  inattività non partono.
- **Schede**: passando da carte a sealed (o viceversa) si chiude la scheda
  Cardmarket dell'altro tipo, invece di restare aperta e ferma.
- Un ordine che questo PC non può prendere (login Cardmarket non confermato,
  versione vecchia, interruttore spento ad app chiusa) o più vecchio di 2 ore
  non ferma la coda.
- Nota: il lavoro "a estensione chiusa" visto il 2026-10-16 veniva da una
  seconda copia dell'estensione rimasta alla 5.20 in un altro profilo Chrome
  (l'interruttore esiste solo dalla 5.25): va aggiornata o rimossa a mano.

## v5.28 — 2026-10-16

### 🐢 Aggiungi carte: pausa tra una carta e l'altra, sempre
L'attesa scelta con gli slider partiva solo se nella coda locale c'era già
la carta successiva. Le carte inserite dal sito arrivano dal database una
alla volta, quindi dopo ogni carta la coda locale era vuota e la successiva
partiva subito, senza "Prossima tra" (dalla 5.26 aspettava solo il turno
Cardmarket in background, senza conto alla rovescia).
- **`aggiungi_carta_popup.js`**: l'attesa (con il conto alla rovescia) c'è
  sempre tra due carte dello stesso ciclo, da qualunque parte arrivi la
  successiva, e solo quando una successiva c'è davvero. Il turno in
  background si sovrappone, non si somma.

### 🔌 "Lavora anche a estensione chiusa" spento: conta solo la scheda aperta da te
Nella 5.27 si escludevano solo le schede aperte da sole da un ordine. Una
scheda dell'app ripristinata da Chrome al riavvio (il `.bat` riavvia Chrome)
o rimasta da prima dell'aggiornamento contava ancora come "app aperta" e il
PC continuava a lavorare e ad aprire schede.
- **`background.js`**: ora si elencano le schede aperte o richiamate da te in
  questa sessione di Chrome (icona, "Apri l'app", "Apri sempre l'app" del
  sito). Tutte le altre schede dell'app contano come aperte da sole: non
  lavorano da sole e, a lavoro finito, si chiudono. Non si chiude mai la
  scheda che stai guardando; per usarla, richiamala dall'icona.

## v5.27 — 2026-10-16

### 📦 Versione nuova per i fix della 5.26
I fix "attesa tra le carte", "turno Cardmarket unico" e "interruttore
rispettato dagli ordini" erano usciti dentro la 5.26 senza cambiare numero:
c'erano quattro pacchetti diversi tutti chiamati 5.26 e non si poteva capire
quale fosse installato (un PC aggiornato ai primi minuti era rimasto senza i
fix). Questa versione li contiene tutti; dalla 5.27 ogni rilascio ha il suo
numero.

### 🔌 "Lavora anche a estensione chiusa" spento: conta solo l'app aperta da te
Prima "app aperta" voleva dire qualunque scheda dell'app, anche quella aperta
da sola in secondo piano da un ordine di prezzi dal sito, che poi restava
aperta: da lì in avanti il PC lavorava come con l'interruttore acceso.
- **`background.js`**: le schede dell'app aperte da sole da un ordine sono
  elencate (`chrome.storage.session`) e non contano come "app aperta". Una
  scheda conta come tua quando la apri o la richiami tu: icona
  dell'estensione, "Apri l'app" o "Apri sempre l'app" del sito (che quindi
  vince sull'interruttore).
- **`background.js`**: con l'interruttore spento la scheda aperta da sola si
  chiude da sola a lavoro finito (nessun controllo prezzi o wishlist in
  corso, coda "Aggiungi carte" ferma, nessun ordine in partenza, per due giri
  di fila). Un nuovo ordine usa la scheda aperta da te, se c'è.
- **`popup.js`, `aggiungi_wishlist_popup.js`, `aggiungi_carta_popup.js`**:
  con l'interruttore spento, controllo in inattività, "mi unisco al
  controllo in corso" e la coda "Aggiungi carte" presa dal database partono
  solo nella scheda aperta da te (messaggio `LAVORO_AUTOMATICO_PERMESSO`).
  Gli ordini dal sito già presi partono sempre.
- **`aggiungi_carta_popup.js`**: segnale `sessioneCodaAttiva_carte` mentre la
  coda lavora, così la scheda non si chiude a metà carta.

## v5.26 — 2026-10-15

### 👥 Avviso se sito ed estensione usano account diversi
Sito ed estensione hanno login separati (dalla 5.17): cambiando account sul
sito, l'estensione restava sul vecchio e lavorava coda e ordini a suo nome
senza che si vedesse.
- **`background.js`**: nuovo messaggio `CARDSYNC_GET_UTENTE`, il sito chiede
  chi è loggato nell'estensione (risposta: id e nome utente, nessun token).
- **Sito**: se l'utente è diverso compare una barra fissa con "Apri l'app";
  basta premere "Esci" nell'estensione e rientrare con lo stesso utente del
  sito. La barra sparisce da sola tornando sulla scheda.

### 🐢 Controllo prezzi: rispetta sempre l'attesa tra una carta e l'altra
L'attesa scelta con gli slider (minimo/massimo) stava solo in fondo al ciclo
e veniva saltata in due casi: l'ultima carta di ogni lotto (i lotti sono da
3, quindi una carta su tre partiva subito dopo la precedente) e ogni carta
scartata dopo aver già aperto Cardmarket (Cloudflare non risolto, carta non
trovata nella pagina, URL di ricerca non risolto).
- **`popup.js`**: nuovo `creaRitmoCardmarket`. Ogni richiesta a Cardmarket
  fissa l'orario minimo della successiva e prima di ogni richiesta si aspetta
  quell'orario, su qualunque percorso e anche tra un lotto e l'altro. Vale
  per carte e sealed.
- La micro-pausa ogni 10 carte ora si somma all'attesa scelta (prima la
  sostituiva con 6–16 s, accorciandola con slider più alti) e conta sul
  totale della sessione: con lotti da 3 non scattava mai.

### ⏱️ Un solo turno Cardmarket per tutta l'estensione
Ogni flusso rispettava solo la propria attesa. Girando insieme (per esempio il
worker autonomo, che con l'app aperta continua ad aiutare, durante un
controllo prezzi) le richieste a Cardmarket si sommavano e il ritmo reale
superava quello scelto con gli slider.
- **`background.js`**: turno unico (`_prenotaTurnoCardmarket` /
  `_chiudiTurnoCardmarket`, orario salvato in `chrome.storage.local`). Tra
  due carte qualsiasi, da qualunque flusso, passa sempre un'attesa casuale
  tra "Delay minimo" e "Delay massimo" (+1,2 s), contata dalla fine della
  carta precedente. Lo usano aggiungi carte/sealed, wishlist, ricontrollo
  prezzo mancante, controllo prezzi sealed e il worker autonomo.
- **`popup.js`**: il controllo prezzi prende lo stesso turno (messaggio
  `TURNO_CARDMARKET`) prima di ogni pagina, con il conto alla rovescia.
- **Pausa lunga ogni N carte** (slider "Pausa lunga ogni N carte"): ora è
  nel turno comune e conta le carte di tutti i flussi insieme; dopo l'N-esima
  si aggiungono 60 s all'attesa casuale. Prima ogni flusso contava per conto
  suo, il worker autonomo non la faceva mai, e in aggiungi carte/wishlist la
  pausa lunga (30 s) prendeva il posto dell'attesa casuale invece di
  sommarsi: con slider sopra i 30 s la accorciava. Ora l'attesa casuale c'è
  sempre, tra ogni carta.

### 🔌 "Lavora anche a estensione chiusa" spento: rispettato anche dagli ordini
Nella 5.25 l'interruttore fermava solo il worker della coda carte. Gli ordini
di controllo prezzi dal sito venivano presi lo stesso: l'estensione apriva
Cardmarket per verificare il login e poi l'app in una scheda nascosta.
- **`background.js`**: con l'interruttore spento e l'app chiusa, gli ordini
  di prezzi restano in attesa per un altro PC (o finché non apri l'app qui).
  Il motivo compare nella console del service worker.

## v5.25 — 2026-10-15

### ⚙️ Interruttore "Lavora anche a estensione chiusa"
Con Chrome aperto e il login fatto, il worker in background lavora la coda
carte da solo (una carta al minuto) anche con l'app chiusa, e per leggere i
prezzi apre schede Cardmarket in secondo piano. Ora si può spegnere, per
dispositivo, dal sito: Impostazioni → preferenze estensione, accanto ad
"Aiuta il gruppo".
- **`background.js`**: nuova preferenza `lavoraAChiuso` (chrome.storage.local,
  assente = acceso, come prima) con i messaggi
  `CARDSYNC_GET_LAVORA_A_CHIUSO` / `CARDSYNC_SET_LAVORA_A_CHIUSO`. Spenta: il
  worker autonomo non prende carte se non c'è una scheda dell'app aperta.
  Con l'app aperta non cambia niente.
- **`app.html` / `app.js`**: lo stesso interruttore è in cima alla home
  (Coda pendente), sempre in vista; si tiene allineato con quello del sito.
- **`coda_pendente.js`**: anche le colonne "Carte e sealed" e "Wishlist"
  della home mostrano solo barre e numeri: con una coda lunga l'elenco le
  rendeva altissime. Gli elenchi restano in "Vedi dettagli".

### 🐢 Aggiungi carte: niente più carte accumulate "in corso"
- **`aggiungi_carta_popup.js`**: i controlli periodici della coda (ogni 20 s
  e ogni minuto) prendono una carta solo se la pagina è ferma. Prima la
  prendevano anche mentre il ciclo stava lavorando: con le pause anti-bot si
  completa circa una carta al minuto, quindi le carte prese si accumulavano
  (12 "in corso" durante l'importazione CSV del 2026-10-15), dopo 10 minuti
  risultavano abbandonate e un altro lavoratore (anche il worker in
  background dello stesso PC) le cercava di nuovo su Cardmarket: richieste
  doppie e più rischio di blocchi. Con il ciclo attivo la carta successiva
  la prende il ciclo stesso, appena ha finito la precedente.
- Database: da sql/117 la coda salva il dispositivo che lavora la riga
  ("Dispositivi al lavoro" conta davvero). Nessun'altra modifica.

## v5.24 — 2026-10-15

### 📥 Coda pendente: home in ordine e numeri veri
- **`coda_pendente.js`**: la card "Coda pendente" della home mostra solo barre
  e numeri; gli elenchi (in attesa/in corso, errori) restano in "Vedi
  dettagli". Prima finivano tutti nella card, messi in fila come colonne: con
  tante carte in coda (es. un'importazione CSV) l'elenco diventava una
  colonna stretta e altissima, la card occupava tutto lo schermo e spingeva
  giù Prezzi, Carte e Wishlist.
- **`coda_pendente.js`**: "In attesa" e "In corso" sono contati dal database.
  Prima si contavano le righe dell'elenco, che ne legge al massimo 200: con
  628 carte in coda mostrava "199 in attesa · 1 in corso". L'elenco resta
  limitato a 200 righe, con "… e altre N righe" sotto.
- **`coda_pendente.js`**: nella pagina di dettaglio la nota sulle carte in
  controllo prezzi non scombina più la griglia a due colonne.
- **`coda_pendente.js`** (privacy): "Dispositivi al lavoro" mostra solo
  quanti sono, non più il loro nome; tolto anche "preso in carico da …"
  sulle righe in corso. Il nome resta nel database solo per coordinare il
  lavoro.
- Nessuna modifica al database richiesta da questa versione.

## v5.23 — 2026-10-15

### ▶️ Il controllo prezzi chiesto dal sito parte da solo
Un ordine di prezzi dal sito restava "in attesa" finché sull'estensione non
si premeva Avvia. Causa: prima di prendere un ordine di prezzi l'estensione
verifica il login Cardmarket in una scheda nascosta e ricorda l'esito; un
esito "non confermato" (pagina lenta, verifica Cloudflare, scheda chiusa)
veniva ricordato come "non loggato" e per 30 minuti il PC non prendeva più
ordini di prezzi, senza dirlo da nessuna parte. Avvia rifaceva la verifica e
sbloccava tutto.

- **`background.js`**: "non confermato" non blocca più per 30 minuti. Si
  riprova dopo 2 minuti, poi 4, 8, 16, al massimo 30 se continua a non
  confermarsi. "Non loggato" certo resta 30 minuti, "loggato" 10 minuti, come
  prima. Senza login confermato i giri automatici continuano a non partire.
- **`content.js`**: ogni pagina Cardmarket che mostra l'account (anche aperta
  a mano) segna "loggato": dopo un login fatto a mano l'ordine parte al giro
  successivo (20 s).
- **`background.js`**: quando il PC non prende ordini di prezzi scrive il
  motivo nella console del service worker (già in corso un controllo, login
  non confermato, estensione non aggiornata), al massimo ogni 2 minuti.

### 💤 Controllo in inattività: ordini vecchi ignorati
- **`popup.js`**: il controllo in inattività cede il passo solo agli ordini
  di prezzi creati nelle ultime 2 ore. Gli ordini in attesa non scadono: uno
  che nessun PC poteva prendere fermava il controllo in inattività di tutto il
  gruppo finché chi l'aveva creato non lo annullava.
- Nessuna modifica al database (versione minima portata a 5.22 il
  2026-10-15).

## v5.22 — 2026-10-15

### 🛑 Annullare un controllo prezzi dal sito lo ferma davvero
Dal sito si può annullare un proprio ordine (sql/115), ma l'estensione andava
avanti lo stesso. Due cause, viste nei log del 2026-10-15: gli ordini annullati
non erano mai stati presi da nessun PC, perché stava girando il controllo
automatico "in inattività", che non è legato a nessun ordine e intanto teneva
il PC "occupato"; e, quando un ordine era in corso, la sessione non rileggeva
mai il suo stato.

- **`popup.js`**: mentre gira la sessione di un ordine (carte, sealed, "mi
  unisco al controllo in corso"), lo stato dell'ordine si rilegge ogni 5 s.
  Se è 'annullato' la sessione si ferma come col bottone "Ferma": finisce la
  carta attuale, rilascia le prenotazioni, chiude la scheda e scrive
  "Controllo annullato dal sito". L'esito sull'ordine resta 'annullato'.
- **`aggiungi_wishlist_popup.js`**: stessa cosa per l'aggiornamento prezzi
  della wishlist (ordine dal sito e "aggiorno anche la mia").
- **`popup.js`**: il controllo in inattività non parte se c'è un ordine di
  prezzi in attesa e, se sta girando, si mette in pausa entro 20 s quando ne
  arriva uno. Così l'ordine chiesto dal sito parte subito invece di aspettare
  la fine del giro automatico.
- Nessuna modifica al database.

## v5.21 — 2026-10-15

### 🩺 Controllo prezzi: esito sempre giusto, ordini non sprecati
Verifica completa del collegamento sito ↔ estensione ↔ database (dopo sql/111
e sql/112). Correzioni:

- **`background.js`**: un'estensione non aggiornata non prende più in carico
  gli ordini di prezzi (carte, sealed, wishlist). Prima li prendeva e la
  sessione si fermava subito su "Estensione non aggiornata", con l'ordine
  chiuso in errore (successo il 2026-10-15 dopo l'uscita della 5.20). Ora
  restano in attesa per un PC aggiornato, come quando il login Cardmarket non
  è confermato.
- **`popup.js`**: quando il prezzo viene trovato, la diagnosi di un giro
  precedente ("Prezzo non trovato...", in `carte.esito_controllo`) viene
  tolta. Prima il database la toglieva solo se il prezzo cambiava: con prezzo
  uguale o variazione sotto soglia restava per sempre.
- **`popup.js`**: la scrittura della diagnosi viene attesa prima del rilascio
  delle carte a fine lotto, come "segna controllata". Da sql/111 il database
  scrive solo su carte ancora prenotate: sull'ultima carta di un lotto di un
  altro utente la diagnosi poteva andare persa.
- **`popup.js`**: gli errori di una carta (prezzo non trovato, link mancante,
  carta non nella pagina) li vede solo il proprietario, sul sito in Controlla
  prezzi, come le "Carte con problemi" di Aggiungi carte. Chi controlla per
  il gruppo vede solo "Controllata (carta di un altro utente)".
- Nessuna modifica obbligatoria al database (sql/113 azzera anche la data
  dell'esito; eseguito il 2026-10-15).

## v5.20 — 2026-10-15

### 🔒 Location degli ordini di controllo prezzi: mai più visibili agli altri
Le location scelte sul sito per un controllo prezzi finivano in
`ordini.parametri`, che tutto il gruppo può leggere; e il PC che eseguiva
l'ordine di un altro le riceveva per nome (le mostrava anche a schermo, "Lettura
dati dal foglio (location: …)"). Ora il sito salva le location in una tabella
privata (`ordini_parametri_privati`, sql/108) che legge solo chi ha creato
l'ordine, e il filtro lo applica il database.

- **`popup.js`**: l'ordine dal sito (avvio automatico e "mi unisco") passa il
  proprio id fino al database; per gli ordini non si scrivono più nomi di
  location a schermo (al massimo quante sono, per gli ordini del sito vecchio).
- **`supabase_adapter.js`**: conteggio e prenotazione delle carte mandano
  `p_ordine_id` solo quando c'è un ordine — il controllo manuale e quello in
  inattività restano identici.
- Gli ordini creati dal sito vecchio (location ancora nei parametri) continuano
  a funzionare come prima.
- Richiede sql/108 sul database (eseguito prima di pubblicare questa versione).

## v5.19 — 2026-10-15

### 🔑 Login con il solo nome nell'ambiente di test
Nell'ambiente di test tutti gli account sono `nome@test.local`: scrivendo solo
il nome, l'estensione lo completava con `@cardsyncpro.local` e il login veniva
rifiutato ("Nome utente o password errati"). Ora il nome da solo si completa
con `@test.local`; l'email intera funziona come prima.

- **`auth_ui.js`**: completamento del nome con `@test.local` (temporaneo, solo
  per l'ambiente di test — in produzione si torna a `@cardsyncpro.local`).
- Stesso cambio sul sito (pagina principale, admin, pagine pubbliche).

## v5.18 — 2026-10-15

### 🔒 Giri automatici solo con il login Cardmarket confermato
Senza login su Cardmarket i carrelli non sono cliccabili e ogni carta risulta
"Esaurita". I giri che partono da soli (ordini di controllo prezzi dal sito,
controllo in inattività, "mi unisco al controllo in corso") non lo
verificavano: segnavano comunque ogni carta come controllata (ferma per
giorni), scrivevano "Prezzo non trovato per lingua e/o condizione" nella sua
nota e contavano l'aiuto al gruppo.

- **Ordini dal sito** (controllo prezzi carte, sealed e wishlist): il PC
  verifica il login **prima** di prendere l'ordine. Se non è loggato non lo
  prende: l'ordine resta in attesa per un PC del gruppo che è loggato. Gli
  ordini "aggiungi carte" e "aggiungi wishlist" (che non usano Cardmarket)
  vengono presi come prima.
- **Controllo in inattività** e **"mi unisco"** (carte e wishlist): se il login
  non è confermato il giro si salta in silenzio, senza messaggi a schermo.
- La verifica apre una scheda Cardmarket **in background**, la chiude sempre e
  non la porta mai in primo piano. Se il login non si riesce a confermare
  (Cloudflare, pagina lenta) conta come non loggato.
- L'esito viene ricordato: "non loggato" → nessun nuovo tentativo per 30
  minuti (niente schede ogni 20 secondi); "loggato" → valido 10 minuti. Ogni
  controllo con esito certo (bottone "Controlla connessione", avvio manuale,
  apertura dell'app dal sito, login completato) aggiorna l'esito ricordato:
  chi accede a Cardmarket dall'app sblocca subito i giri automatici.
- Il controllo degli ordini e l'avvio in inattività non possono più partire
  due volte in parallelo mentre aspettano la verifica.
- Corretto anche: durante un controllo in inattività, il giro successivo del
  timer (ogni 60s) spegneva la sorveglianza che mette in pausa il controllo
  quando arriva lavoro vero in coda. Ora resta accesa per tutta la sessione.
- File: **`background.js`**, **`popup.js`**, **`aggiungi_wishlist_popup.js`**.

## v5.17 — 2026-10-14

### 📦 Controllo prezzi sealed: ora il prezzo viene salvato davvero
Il controllo prezzi dei prodotti sealed (ordine "controlla prezzi sealed" dal
sito) leggeva il prezzo da Cardmarket, lo mostrava nel log ("Salito",
"Sceso"...) ma **non lo scriveva mai** nel database: la condizione che
decideva se il prezzo era valido guardava un numero come se fosse un oggetto,
quindi risultava sempre falsa.

- **`popup.js`** (`eseguiSessioneSealed`): la validità del prezzo si controlla
  sull'oggetto restituito dalla lettura, e alla scrittura si passa quel
  prezzo (prima veniva passato un valore vuoto).
- Se il database rifiuta la scrittura, ora compare un avviso nel log invece
  di passare inosservato.
- Nessun cambiamento al controllo prezzi delle carte.

### 🧹 Tolta la sezione "Sealed" dell'hub (era rotta)
La sezione Sealed caricava una pagina (`aggiungi_sealed_popup.html`) che non
esiste più: aprendola si vedeva solo un errore. Il riquadro in home mostrava
numeri fissi a zero e diceva che il sealed non ha una coda condivisa, ma non è
così: i sealed messi in coda dal sito passano già dalla coda delle carte e li
lavora la sezione Carte.

- **`app.html`**: tolte la colonna Sealed e il suo riquadro in home; il
  riquadro "Carte" ora si chiama **"Carte e sealed"**.
- **`app.js`**: "sealed" tolta dall'elenco delle sezioni — un vecchio link
  `#sealed` apre la home invece di una pagina vuota.
- **`manifest.json`**: tolto il riferimento alla pagina inesistente.
- **`aggiungi_sealed_popup.js`** eliminato: non era caricato da nessuna pagina
  e scriveva ancora i sealed nel vecchio modo.
- **`popup.html` / `popup.js`**: tolto il bottone "📦 Sealed" del riquadro
  Novità, che portava alla stessa sezione rotta (i bottoni restanti si
  dispongono su 4 colonne invece di 5).
- Tolti dal codice i commenti che citavano ancora il file eliminato.

### 🤝 "Aiuta il gruppo" ora vale anche per l'app aperta
Con l'app dell'estensione aperta, la sezione Carte prendeva dalla coda le
carte di **tutti**, anche con "Aiuta il gruppo" spento: bastava aprire l'app
(anche quando la apre il sito da solo) per lavorare la coda dell'intero
gruppo senza averlo scelto. Il worker in background invece rispettava già
l'interruttore.

- **`aggiungi_carta_popup.js`**: la lettura della coda segue ora la stessa
  regola del worker — interruttore **spento** → solo le tue carte;
  **acceso** → anche quelle degli altri.

### 💤 Controllo prezzi "in inattività": basta giri infiniti su Cardmarket
Con "Aiuta il gruppo" acceso e l'app aperta, quando non c'era altro lavoro
l'estensione avviava da sola un controllo prezzi su **tutte** le carte del
gruppo; finito il giro, un minuto dopo ne ripartiva un altro — Cardmarket
interrogato di continuo, con il rischio di blocchi.

- **`popup.js`**: in inattività controlla solo le carte **non controllate da
  almeno 7 giorni**. Se sono tutte aggiornate non parte affatto e non mostra
  nulla; se nel frattempo un altro dispositivo ha preso le ultime carte, si
  ferma senza segnalare errori.
- I controlli prezzi avviati dal sito o con "▶ Avvia" funzionano come prima.

### 🔒 Controllo versione lato database: ora funziona davvero
Prima di ogni lettura/scrittura l'estensione chiede anche al database se la
sua versione è ancora ammessa. La risposta "non aggiornata" però non veniva
mai vista: la libreria Supabase restituisce l'errore invece di lanciarlo, e
il codice lo cercava nel posto sbagliato — il controllo non scattava mai.

- **`supabase_adapter.js`**: l'errore `ESTENSIONE_NON_AGGIORNATA` viene letto
  dalla risposta della chiamata; se la versione è sotto quella minima,
  l'estensione si ferma con "Estensione non aggiornata".
- La versione minima si imposta sul database (`sql/103` nel repo del sito):
  va alzata solo **dopo** aver pubblicato ogni nuova versione.
- Se il controllo non riesce (rete, database), resta permissivo come prima.

### 🧾 Niente più carte aggiunte due volte dalla coda
Quando la ricerca di una carta in coda falliva, la riga veniva rimessa "in
attesa" senza guardare in che stato fosse. Se nel frattempo era stata
completata (da un altro dispositivo o dalla correzione manuale), tornava in
coda e la carta finiva in collezione **una seconda volta**.

- **`aggiungi_carta_popup.js`** e **`background.js`** (worker autonomo): una
  riga viene rimessa in attesa solo se è ancora "in corso" e presa in carico
  da te — mai se è già completata o se l'ha presa qualcun altro. Vale per
  l'errore normale, per il ripiego quando lo spostamento in "Carte con
  problemi" non riesce, per la pausa da rate limit e per il rilascio alla
  chiusura della pagina.

### ⏳ Niente più ordini "in corso" per sempre
Se arrivava un ordine di controllo prezzi dal sito mentre l'estensione stava
già controllando i prezzi, l'estensione ricaricava la pagina dell'app per
avviare il nuovo ordine: la sessione in corso si interrompeva a metà e il suo
ordine restava "in corso" per sempre (sul database ce n'erano 6, fermi da
fine agosto).

- **`popup.js`** e **`aggiungi_wishlist_popup.js`**: mentre un controllo
  prezzi (carte, sealed o wishlist) sta girando, l'estensione lo segnala con
  un avviso che si rinnova da solo e scade dopo 3 minuti se la pagina si
  chiude.
- **`background.js`**: finché quell'avviso è attivo non prende nuovi ordini di
  controllo prezzi — restano in attesa e partono appena la sessione finisce.
  Gli ordini "aggiungi carte/wishlist" continuano a passare come prima.
- Se un ordine arriva comunque mentre una sessione gira, torna "in attesa"
  invece di restare "in corso" (wishlist: prima veniva segnato "completato"
  con 0 carte senza aver fatto nulla).
- **`background.js`**: i **tuoi** ordini rimasti "in corso" da più di 6 ore
  (pagina chiusa, PC spento...) vengono chiusi da soli come "errore" con una
  spiegazione; il controllo gira al massimo ogni 10 minuti e mai mentre una
  sessione sta girando.
- **`aggiungi_wishlist_popup.js`**: se l'aggiornamento prezzi wishlist va in
  errore a metà non resta più bloccato fino al riavvio della pagina.
- I 6 ordini vecchi sono stati chiusi con `sql/104` (repo del sito).

### 🚪 "Esci" chiude solo questo dispositivo
Uscire dall'estensione (bottone "🚪 Esci", oppure la chiusura con "Mantieni
acceso" spento) scollegava l'account **ovunque**: sito e tutti gli altri
dispositivi. Ora vale la stessa regola del sito: esci solo da qui.

- **`auth_ui.js`** e **`background.js`**: l'uscita chiude solo la sessione di
  questo dispositivo.
- Se avevi aperto l'app dal sito, l'estensione usa la stessa sessione del sito
  su questo PC: uscendo dall'estensione esci anche dal sito **su questo PC**,
  non sugli altri.
- Un account sospeso o disattivato invece viene ancora scollegato da tutti i
  dispositivi.

### ⚠️ Salvataggi falliti: ora te ne accorgi
Quando il database rifiutava una scrittura, l'estensione non se ne accorgeva:
il log diceva "Salito/Sceso" ma il prezzo non era salvato, e "Rimuovi" nella
wishlist faceva sparire la carta anche se restava nel database.

- **`popup.js`** (controllo prezzi carte): se il salvataggio del prezzo o
  dell'URL viene rifiutato compare nel log "⚠️ … non scritto — riprova più
  tardi"; la sessione prosegue con le altre carte.
- **`aggiungi_wishlist_popup.js`**: "🗑️ Rimuovi" lascia la carta in lista e
  mostra l'errore se il database non la cancella; nell'aggiornamento prezzi
  wishlist un prezzo non salvato non viene contato né cambiato a schermo.

### 📋 Wishlist: i messaggi non spariscono più dopo 20 secondi
La wishlist si ricarica da sola ogni 20 secondi e ogni volta scriveva
"📋 Wishlist caricata", cancellando errori, avanzamento ("🔄 Aggiorno prezzo
3/10") ed esiti ("✅ Prezzi aggiornati").

- **`aggiungi_wishlist_popup.js`**: il ricaricamento automatico aggiorna la
  lista ma cambia il messaggio solo se a schermo c'è già "Wishlist caricata"
  (o niente); un errore di lettura momentaneo non compare più a schermo ogni
  20 secondi. Mentre l'aggiornamento prezzi wishlist gira, il ricaricamento
  automatico salta il giro.
- Apertura della pagina, dopo un'aggiunta e prima di un ordine dal sito: come
  prima.

### 🛡️ Script di aggiornamento più sicuro (repo del sito)
`releases/aggiorna_cardsync.bat` svuotava la cartella scelta prima di sapere
se il file scaricato fosse buono, e senza guardare cosa c'era dentro:
scegliendo per sbaglio la cartella sbagliata nel selettore la si cancellava
tutta, e uno zip rovinato lasciava l'estensione vuota.

- Svuota la cartella solo se è nuova, vuota o contiene già CardSync Pro;
  altrimenti si ferma senza toccare nulla.
- Scarica, estrae in una cartella temporanea e controlla che sia davvero
  CardSync Pro **prima** di chiudere Chrome: se qualcosa non va, Chrome resta
  aperto e l'estensione intatta.
- Tolto `--load-extension` (Chrome lo ignora dalla versione 137); Chrome
  riparte riaprendo il sito.
- Sul sito il testo delle istruzioni ora descrive quello che lo script fa
  davvero.

### 🔑 L'estensione ha un suo login
Aprendo l'app dal sito, l'estensione usava **la stessa sessione** del sito.
Supabase però cambia la chiave di rinnovo a ogni rinnovo e chiude l'intera
sessione se qualcuno ne usa una troppo vecchia: l'estensione la rinnova ogni
ora, la scheda del sito chiusa resta indietro, e riaprendo il sito dopo
qualche ora la sessione veniva chiusa a entrambi.

- **`background.js`**: l'estensione non usa più la sessione del sito (anche se
  un sito vecchio la manda ancora). La prima volta su ogni dispositivo chiede
  il login nella scheda dell'app; con "Mantieni acceso" resta collegata.
- **`app.js`**: il popup "Verifica login Cardmarket" compare solo **dopo** il
  login dell'estensione, non sopra.
- Sul sito (`ui/extension.ui.js`) "Apri l'app" non manda più i token.
- Se l'estensione era già entrata con la sessione del sito, continua a usarla
  finché resta valida; quando scade chiede il login una volta.

### 🙈 Controllo prezzi di gruppo: niente più location e note degli altri
Le funzioni del database che assegnano le carte da controllare restituivano
le righe **intere** anche delle carte degli altri (location, note; per il
sealed prezzo d'acquisto e data). Si fidavano dell'utente indicato
dall'estensione e non avevano un limite al numero di carte.

- **Database** (`sql/105` nel repo del sito): per le carte e i prodotti degli
  altri arrivano solo i dati che servono al controllo prezzi; l'utente è
  quello davvero collegato; al massimo 10 carte per volta.
- **Filtro location**: vale solo per le tue carte (o per quelle di chi ha
  chiesto il controllo dal sito). Prima, scegliendo una location, finivano
  nel giro anche le carte degli altri con una location dallo stesso nome.
- Nessun cambiamento visibile nell'estensione: quei dati non venivano usati.

### 📍 Coda condivisa: le location restano di chi le ha scelte
Chiunque fosse collegato poteva leggere la location delle carte in coda di
tutti; e quando aiutavi il gruppo, se la richiesta di un altro non aveva una
location, nella sua carta finiva **la location del tuo dispositivo**.

- **Database** (`sql/106` nel repo del sito): nella coda vedi la location solo
  delle tue richieste; completando la carta di un altro, la location la
  prende il database dalla sua richiesta (se non ce l'aveva, la carta resta
  senza e la imposta lui). Le tue carte funzionano come prima.
- Vale anche per chi ha ancora la 5.16: la regola è sul database.

### 🖱️ Cardmarket non scorre più da solo mentre navighi
Su ogni pagina di Cardmarket, anche aperta da te, l'estensione faceva
scorrere la pagina a caso qualche volta prima di riportarla in cima.

- **`content.js`**: lo scorrimento (e il movimento del mouse simulato) avviene
  solo nelle schede che non stai guardando — quelle che l'estensione apre in
  background per il controllo prezzi, che funzionano come prima.

### 🛡️ Riconoscimento di Cloudflare più preciso (lettura veloce delle pagine)
Quando cercava nome e link di una carta senza aprire una scheda,
l'estensione considerava "Cloudflare" qualunque pagina contenesse parole
come "un attimo", "por favor" o "verifique" in un punto qualsiasi, oppure un
widget anti-bot dentro una pagina normale: in quei casi apriva una scheda per
niente. Al contrario, una pagina di blocco con un titolo in una lingua non
prevista poteva sfuggire.

- **`background.js`**: usa prima il segnale ufficiale di Cloudflare
  (l'intestazione `cf-mitigated: challenge` della risposta); poi cerca quelle
  frasi solo nel titolo della pagina, più alcuni elementi che esistono solo
  nelle pagine di blocco e non dipendono dalla lingua.
- Anche la seconda pagina letta (quella della carta o del prodotto) viene
  controllata: una pagina di blocco non viene mai scambiata per la carta.

### 📈 "✓ Comprata" ora compare in "Variazione valore"
Segnando una carta della wishlist come comprata dall'estensione, la carta
entrava in collezione ma non veniva registrata tra i movimenti: sul sito,
"Variazione valore" non la vedeva.

- **`supabase_adapter.js`**: registra il movimento "aggiunta" (quantità,
  prezzo, valore), come fa il sito. Se la registrazione non riesce, la carta
  viene comunque spostata in collezione.

### 🧽 Errori dei controlli prezzi più puliti (e senza location)
Quando un controllo prezzi chiesto dal sito andava in errore, il messaggio
salvato nell'ordine (che tutto il gruppo vede sul sito) conteneva dettagli
tecnici di prova: righe di codice e, se non c'erano carte da controllare, i
nomi delle location scelte.

- **`popup.js`**: nell'ordine e a schermo resta solo il messaggio
  ("Nessuna carta da controllare con i filtri scelti.", "Errore: …"); i
  dettagli tecnici restano solo nel log dell'estensione e nella console di
  chi la usa, con le location indicate solo come numero.

### 🧹 Pulizie: schede rimaste aperte, letture inutili, riquadro "Novità"
- **Scheda di Cardmarket dei sealed**: a fine coda (hub) e a fine controllo
  prezzi sealed restava aperta. Ora si chiude come quella delle carte
  (`aggiungi_carta_popup.js`, `popup.js`).
- **`background.js`**: la chiusura di una scheda di lavoro aspetta che finisca
  la lettura eventualmente in corso su quella scheda, invece di chiuderla a
  metà.
- **`coda_pendente.js`**: tolte due letture fatte ogni 15 secondi di una
  vecchia coda della wishlist ormai vuota e non più usata.
- **`popup.html` / `popup.js`**: tolto il riquadro "Novità?" (Carte, Wishlist,
  Scambi, Vendite): nell'app era già nascosto e la pagina non si apre più
  da sola.

### 🔎 Controllo prezzi: la verifica "è la carta giusta?" ora verifica davvero
Prima di scrivere un prezzo, l'estensione controlla che la pagina aperta sia
quella della carta. Il controllo era troppo largo: "CEC 1" passava su una
pagina "CEC 10", e una carta con il numero a una cifra ("CG 9") passava su
qualunque pagina con quella cifra nel codice.

- **`popup.js`**: ora conta lo stesso numero finale (026 = 26, ma 1 ≠ 10) e
  una sigla compatibile (spazi, punti e trattini ignorati). Se la pagina non
  è quella giusta la carta viene saltata, senza scrivere un prezzo sbagliato.

### 🔐 Login su Cardmarket: niente più sessioni "alla cieca" né attese infinite
Il login su Cardmarket è indispensabile: senza, i carrelli non sono
cliccabili e ogni carta risulta "Esaurita". Il controllo fatto prima di ogni
sessione però, se non riusciva a confermarlo (pagina lenta, Cloudflare),
partiva lo stesso ("procedo comunque"); e in alcuni casi restava in attesa
per sempre, bloccando la sessione su "Verifico il login…".

- **`background.js`**: il controllo finisce sempre (al massimo 45 secondi,
  subito se chiudi la scheda, e parte anche se la pagina era già caricata).
  L'attesa del login dopo l'apertura dall'app si ferma dopo 20 minuti.
- **`popup.js`, `aggiungi_carta_popup.js`, `aggiungi_wishlist_popup.js`**: se
  il login non è confermato la sessione **non parte** — la scheda di
  Cardmarket viene portata in primo piano e compare "Non riesco a confermare
  il login su Cardmarket — controlla la scheda aperta e riprova".
- All'apertura dell'app dal sito, se il login non è confermato la scheda di
  Cardmarket resta aperta in primo piano invece di chiudersi da sola.

### ✏️ Piccole correzioni
- **`auth_ui.js`**: il bottone "🚪 Esci" mostra il nome utente, non più
  l'email intera.
- **`aggiungi_carta_popup.js`, `aggiungi_wishlist_popup.js`**: nel pannello di
  correzione il codice della carta viene mostrato sempre come testo semplice
  (un codice scritto con dentro dell'HTML non può più alterare il pannello).

Nota: le versioni 5.14–5.16 non hanno una voce in questo file.

## v5.13 — 2026-09-06

### 🔍 Diagnosi: perché il fetch statico fallisce sempre (solo log)
Nella sessione precedente la fase 1 del controllo prezzi (il fetch dell'HTML
senza aprire tab) è fallita su **tre carte su tre**, sempre con lo stesso
sintomo: `htmlRicevuto:false, lunghezza:0, fetchFailed:true`. Ogni carta
ripiegava sul fallback via tab, cioè pagava il percorso lento dopo aver già
speso un tentativo inutile.

Il motivo per cui non si riusciva a capire la causa è che `_fetchHtml()`
restituiva lo **stesso identico `null`** in due casi molto diversi — risposta
con status non-2xx e eccezione di rete — e lo status HTTP veniva scartato
senza mai essere letto. Da `fetchFailed:true` non si può distinguere un blocco
di Cloudflare (403/503) da un rate limit (429) da un problema di connessione.

- **`background.js`**: `_fetchHtml()` ora registra, quando la risposta non è
  ok, lo `status`, lo `statusText` e gli header che Cloudflare usa per marcare
  le proprie risposte (`cf-mitigated`, `cf-ray`, `server`), più `retry-after`
  per riconoscere un rate limit. Il ramo eccezione logga nome e messaggio
  dell'errore invece di ingoiarlo in silenzio.
- **Nessun cambio di comportamento**: il valore di ritorno resta `null` in
  entrambi i rami, esattamente come prima. Questa versione serve solo a
  raccogliere i dati necessari per decidere la correzione.

Osservazione emersa leggendo il codice, **non ancora corretta**: i controlli
`isPaginaRateLimit()` e `isCF()` girano sul *corpo* della risposta ma stanno
dopo il `if (!html)`. Se Cardmarket serve la challenge o l'Error 1015 con uno
status non-2xx, quel corpo non viene mai letto e quei controlli non vengono
mai valutati — quindi si aprirebbe una tab anche durante un rate limit, cioè
esattamente ciò che il codice dichiara di voler evitare. I log di questa
versione diranno se sta succedendo davvero.

## v5.12 — 2026-09-06

### 🤝 Contributi al gruppo — secondo percorso (controllo prezzi condiviso)
Fino alla 5.11 veniva contato un solo tipo di aiuto: le righe di coda lavorate
dal worker autonomo. Il controllo prezzi eseguito per conto di qualcun altro
("🤝 Aiuta anche il gruppo") non lasciava traccia, pur essendo la metà del
lavoro che il gruppo si scambia.

Il motivo per cui era rimasto indietro: dentro `eseguiSessione()` non si sapeva
di CHI fosse la carta appena controllata. La RPC
`reclama_carte_per_controllo_prezzi` restituisce la riga intera
(`RETURNS SETOF carte` con `returning c.*`), quindi il proprietario arrivava
già fino all'adapter — veniva soltanto scartato dalla mappatura dei campi.

- **`supabase_adapter.js`**: `_supabaseToRigaLeggi()` porta ora anche `ownerId`.
  Nessun dato sensibile in più di quelli già presenti: chi esegue il controllo
  condiviso sta già leggendo le carte di quella persona.
- **`popup.js`**: aggancio di `registraAiutoGruppo()` nell'unico punto di
  SUCCESSO del ciclo, subito dopo `_segnaControllataAsync`. Gli altri otto
  punti in cui la carta viene segnata come controllata sono tutti rami di
  fallimento (URL mancante, rate limit, Cloudflare non risolto, carta non
  trovata nel DOM): esistono per il fix del loop infinito, non perché un
  lavoro sia stato portato a termine.
- Contata la carta CONTROLLATA, non la carta con prezzo CAMBIATO: una carta
  col prezzo invariato è stata comunque aperta, letta e confrontata. Legare il
  contatore alla scrittura del prezzo avrebbe sottostimato di molto chi
  controlla le carte altrui in un gruppo dove i prezzi si muovono poco.
- Le righe proprie continua a scartarle la RPC lato database, non il client.

## v5.11 — 2026-09-05

### 🐛 Il worker autonomo falliva a ogni giro senza dirlo
`shared.js` viene caricato in due ambienti diversi: le pagine dei popup (dove
`window` esiste) e il service worker di background via `importScripts` (dove
in MV3 `window` NON esiste). `nomeDispositivo()` leggeva
`window._nomeDispositivoCache` senza guardia, quindi nel worker lanciava un
`ReferenceError`.

Il punto in cui faceva male: `_lavoroAutonomo()` chiama `nomeDispositivo()`
PRIMA di claimare la riga, dentro un `try/catch` che inghiottiva l'errore. Il
worker autonomo falliva quindi a ogni giro, sempre nello stesso punto, senza
mai prendere in carico niente e senza che l'errore fosse visibile altrove che
in console — "Aiuta il gruppo" non stava lavorando le righe altrui.

- **`shared.js`**: `globalThis` al posto di `window` in `nomeDispositivo()`,
  che funziona in entrambi gli ambienti. Il resto del file usava già
  `typeof window !== 'undefined'` per lo stesso motivo; lì la guardia mancava.

### 🤝 Contributi al gruppo
Il lavoro fatto per gli altri non lasciava traccia: le righe di coda vengono
cancellate al completamento. Ora ogni carta risolta per conto di qualcun altro
viene registrata in `activity_log`.

- **`shared.js`**: nuovo helper `registraAiutoGruppo()`, fire-and-forget — un
  errore nel contatore non deve mai far fallire il lavoro vero, che a quel
  punto è già stato completato.
- **`background.js`**: aggancio in `_risolviRigaCodaCarteAutonoma()` DOPO la
  scrittura andata a buon fine, non al momento del claim: contare al claim
  avrebbe gonfiato il numero con i tentativi falliti e con le righe
  abbandonate a metà da un dispositivo spento.
- Chi decide cosa conta è la RPC lato database, non il client: le righe di cui
  sei già proprietario vengono scartate da sola (il worker autonomo risolve
  sempre le proprie carte a prescindere dal flag, quindi contarle misurerebbe
  l'uso dell'app, non l'aiuto) e l'autore viene preso da `auth.uid()`.

## v4.13 — 2026-08-16

### 🔐 Popup di verifica login Cardmarket: ora davvero a schermo intero
Il popup introdotto in v4.12 era già bloccante (bottone "Ho capito" prima di
aprire Cardmarket) ma il riquadro restava piccolo (360px) al centro dello
schermo — testo poco leggibile su schermi grandi.

- **`app.js`**: l'overlay ora copre l'intera viewport (niente riquadro
  bianco centrato), sfondo pieno, titolo e testo molto più grandi (font
  quasi triplicato), bottone "Ho capito" più grande. La logica di blocco
  (nessuna apertura di Cardmarket prima del click) resta invariata.

### 📋 "Coda pendente" davvero come pagina di default
Nonostante fosse già impostata come default dalla v4.10, l'hub si apriva
quasi sempre su "Controllo prezzi".

- **`background.js`**: `_apriOFocalizzaTabApp()` forzava sempre l'hash
  `#prezzi` alla creazione di una nuova tab, sovrascrivendo qualunque altra
  logica — ora apre esplicitamente su `#coda`.
- **`app.js`**: `attivaSezione()` non ricade più sull'ultima sezione vista
  (salvata in localStorage) come default — su richiesta esplicita, "Coda
  pendente" è ora sempre la prima cosa mostrata ad ogni apertura, a
  prescindere da cosa si guardava l'ultima volta.

### 📱 Rimosso messaggio di disinstallazione fuorviante su dispositivi non Windows
Su Android (dove l'estensione non è comunque installabile) compariva
comunque il bottone "Voglio disinstallarla comunque".

- **`index.html`**: il bottone (`#btnDisinstallaComunque`) ora si nasconde
  quando il sito ha già rilevato che il dispositivo non è Windows.

## v4.12 — 2026-08-16

### 🔐 Popup di verifica login Cardmarket ora bloccante
Il popup "sto per aprire Cardmarket" (introdotto in v4.10) era un toast che
spariva da solo dopo 4 secondi — non sempre in tempo per leggerlo, e il
controllo login partiva subito in automatico, in parallelo.

- **`app.js`**: il toast è ora un popup modale (overlay a schermo intero)
  con testo aggiornato — specifica di fare login con un **account
  secondario**, non quello personale usato ogni giorno — e un bottone
  **"Ho capito"**. Il controllo Cardmarket parte solo al click.
- **`background.js`**: `CARDSYNC_OPEN_APP` non avvia più subito il
  controllo login — salva la tab del sito da rifocalizzare e aspetta il
  nuovo messaggio interno `CARDSYNC_LOGIN_CHECK_ACK` (mandato da `app.js`
  al click su "Ho capito") prima di partire.
- **`background.js`**: quando l'utente risulta già loggato, la tab
  Cardmarket non si chiude più istantaneamente (poteva sembrare un crash) —
  ora aspetta ~2 secondi prima di chiuderla.

## v4.11 — 2026-08-16

### 📐 Layout più compatto dentro l'hub (Controllo prezzi/Carte/Sealed/Wishlist)
Le pagine embeddate nell'hub (`app.html`) usavano ancora il layout a colonne
affiancate pensato per una tab a tutta pagina, sprecando spazio orizzontale
in una scheda più stretta.

- **`popup.html`** (Controllo prezzi): la colonna "Legenda/Filtro/Connessione"
  era comunque già vuota dentro l'hub (ogni sua card nascosta) ma occupava
  un terzo dello spazio — ora è nascosta del tutto.
- **`popup.html`, `aggiungi_carta_popup.html`, `aggiungi_sealed_popup.html`,
  `aggiungi_wishlist_popup.html`**: le colonne rimanenti, prima affiancate,
  sono ora impilate in una sola colonna compatta quando la pagina è dentro
  l'hub. Il layout a colonne affiancate resta invariato per chi apre queste
  pagine come tab intera a sé stante (bottone "⤢ Apri in una tab").

## v4.10 — 2026-08-16

### 🔐 Controllo login Cardmarket automatico all'apertura app dal sito
Ad ogni apertura dell'hub innescata dal sito (bottone "Apri l'app" o "Apri
sempre l'app"), l'estensione ora verifica automaticamente anche la sessione
Cardmarket, invece di scoprirlo solo al primo avvio di una sessione bulk.

- **`background.js`**: `CARDSYNC_OPEN_APP` ora apre anche una tab Cardmarket
  dedicata per il controllo login. Se risulti già loggato la tab si chiude
  subito senza disturbare; se non lo sei resta in primo piano finché non
  completi il login. In entrambi i casi il focus torna alla fine sulla tab
  del SITO (non su quella dell'hub appena aperta, che resta comunque pronta
  in background per quando vorrai usarla).
- **`app.html`/`app.js`**: appena l'hub si apre (o torna in primo piano),
  mostra un avviso non bloccante che spiega cosa sta per succedere ("sto
  per aprire Cardmarket per il login").

### 📋 Coda pendente come tab di default
`app.html` si apre ora sulla tab "Coda pendente" al primo utilizzo, invece
che su "Controllo prezzi" (resta comunque valido: se avevi già usato l'hub,
riparte dall'ultima sezione guardata).

### 🖥️ Rilevamento dispositivo non-Windows (sito)
Il wizard di installazione/aggiornamento (`index.html`) è basato su un
comando PowerShell, quindi funziona solo su Windows. Su qualunque altro
sistema operativo ora viene saltato del tutto: un messaggio dedicato spiega
che al momento su quel dispositivo non è possibile installare l'estensione,
e si passa direttamente al login (si può comunque usare il sito, con i
calcoli affidati al PC di Bill).

## v4.9 — 2026-08-16

### 🧹 Estensione — zero click: tolti controlli manuali non più necessari
Obiettivo di questa versione: l'estensione non deve mai richiedere un click
da parte dell'utente — resta aperta solo per fare i calcoli (controllo
prezzi, aggiunte in coda dal sito). Ogni azione manuale residua è stata
tolta o spostata sul sito.

- **Barra doppia nella barra delle tab (`app.html`)**: ogni sezione aveva
  due righe che ripetevano il nome (la tab in alto + una seconda riga
  "intestazione colonna" identica sotto). Tolta la seconda riga;
  l'ingranaggio ⚙ impostazioni (Controllo prezzi/Carte/Sealed) è stato
  spostato dentro la tab stessa, accanto al nome — stesso comportamento di
  prima, un solo click.
- **"Controlla connessione" (`app.html`)**: tolto il bottone dal menu
  account dell'hub. Di conseguenza il chip account (in alto a destra) non è
  più cliccabile: resta come semplice etichetta che mostra chi è loggato
  in quel momento (avatar + nome), senza aprire più nulla.
- **"🤝 Aiuta anche il gruppo" (`app.html`)**: tolto del tutto l'interruttore
  (prima era una fascia sempre visibile sopra le tab). La scelta resta
  disponibile dal sito quando si mette in coda un controllo prezzi
  ("Tutto il gruppo" / "Solo mie") e arriva già dentro l'ordine
  (`ordine.parametri.aiutaGruppo`) — l'estensione la applica in automatico,
  senza bisogno di alcun interruttore visibile qui.
- **"Filtro Location" e "Legenda colonna Variazione" (`popup.html`)**:
  nascosti quando l'estensione è aperta nell'hub — stesso pattern (solo CSS)
  già usato per "Connessione"/"Comportamento", nessuna modifica alla logica
  JS. Il filtro location resta impostabile dal sito e trasmesso qui via
  ordine, la legenda era solo consultazione.
- **Testo informativo ℹ️ nella pagina "Carte" (`aggiungi_carta_popup.html`)**:
  tolto il paragrafo sotto la tabella (spiegava come funziona la coda in
  arrivo dal sito — non necessario da leggere ogni volta).
- **Campo Location nella pagina "Sealed" (`aggiungi_sealed_popup.html`)**:
  tolto. I prodotti sealed aggiunti da estensione avranno Location = "?"
  (fallback già previsto dal codice esistente, invariato).
- **"Wishlist attuale" nella pagina "Wishlist" (`aggiungi_wishlist_popup.html`)**:
  nascosta (solo via CSS) perché già visibile sul sito — il caricamento e
  l'aggiornamento prezzi in background restano attivi invariati, perché
  alimentano anche il controllo "carta già in wishlist" usato quando se ne
  aggiunge una nuova.

File modificati: `app.html`, `app.js`, `popup.html`,
`aggiungi_carta_popup.html`, `aggiungi_sealed_popup.html`,
`aggiungi_wishlist_popup.html`.

## v4.8 — 2026-08-16

### 🧹 Estensione — pulizia doppioni nella tendina account e nel bottone bug
- Tolto dalla tendina account dell'hub (`app.html`) il "guscio" del futuro
  sistema profili, mai attivo ("Profilo (prossimamente)" e "Salva come
  profilo… (presto)"): restava disabilitato e senza alcuna funzione. Rimane
  solo "🔌 Controlla connessione", che è l'unica voce realmente funzionante.
- Nascosto (solo via CSS, quando la pagina è dentro l'hub) il toggle "Aiuta
  anche il gruppo" duplicato dentro il popup "Controllo prezzi"
  (`popup.html`): l'hub ha già il proprio toggle equivalente, sempre visibile
  sopra le tab. Stesso identico pattern già usato in questo file per
  "Connessione" e "Comportamento" — nessuna modifica alla logica JS che
  legge/scrive il valore, resta identica e continua a funzionare anche
  quando `popup.html` viene aperto da solo (fuori dall'hub).
- Unificato il testo del bottone "Segnala un bug" in tutti e 5 i file che lo
  mostrano (era già lo stesso link, solo testo/tooltip disallineati): ora è
  ovunque "🐛 Segnala un caterpie".

### 🎛️ Estensione — tendina "Comportamento" dell'hub più sicura
- Aggiunto un avviso ("Modifica a tuo rischio e pericolo…") e un tasto
  "↺ Ripristina predefiniti" nella tendina Comportamento dell'hub
  (`app.html`), che prima non aveva né l'uno né l'altro (il popup
  "Controllo prezzi" li aveva già, l'hub no).

File modificati: `popup.html`, `app.html`, `app.js`,
`aggiungi_carta_popup.html`, `aggiungi_sealed_popup.html`,
`aggiungi_wishlist_popup.html`.

Nota: verificato che l'estensione non crea più preferiti automatici
all'installazione (già rimosso in una sessione precedente, nessun codice
residuo trovato) — nessuna modifica necessaria su questo punto.

## v4.7 — 2026-08-16

### 🧹 Estensione — legende rimosse del tutto, non solo nascoste
- Le legende (codici lingua/condizione, formato riga, prezzo obiettivo) non
  sono più solo nascoste via CSS nell'estensione (come in v4.6): il blocco
  è stato tolto dal markup nelle pagine "Aggiungi carta", "Aggiungi
  sealed" e "Aggiungi wishlist". Restano invariate nel sito (dentro l'hub
  `app.html`).
- Layout delle tre pagine passato da 3 a 2 colonne quando aperte in una
  tab intera, un po' più compatto.

### 🧹 Estensione — tolti testo/etichette superflue dai popup
- Rimossi etichetta e testo informativo del campo Location nei popup
  "Aggiungi carta" e "Aggiungi sealed" (il campo resta, con solo il
  placeholder come guida).
- Nel popup Wishlist rimossi titolo, testo esplicativo, campo Location e i
  pulsanti "↺ Carica" e "🔄 Aggiorna prezzi": caricamento e aggiornamento
  prezzi erano già completamente automatici (avvio all'apertura, refresh
  ogni 20s, autorun quando il sito o il gruppo lo richiedono) — i pulsanti
  manuali erano ridondanti.
- File modificati: `aggiungi_carta_popup.html`, `aggiungi_sealed_popup.html`,
  `aggiungi_wishlist_popup.html`, `aggiungi_wishlist_popup.js`.

## v4.6 — 2026-08-16

### ✨ Sito — schede in alto al posto delle colonne affiancate
- Il sito (`app.html`) ora mostra una sezione alla volta (Controllo prezzi /
  Carte / Sealed / Wishlist / Coda pendente) tramite schede cliccabili in
  cima, con lo stesso stile "Gestione attività" già usato per la Coda
  pendente — al posto delle vecchie colonne affiancate con scroll
  orizzontale.
- **Nessun cambiamento ai controlli automatici**: tutte le sezioni restano
  caricate insieme all'apertura, anche quelle non mostrate al momento — la
  coda carte in attesa e l'autorun del controllo prezzi condiviso
  continuano a girare in background esattamente come prima, cambiare
  scheda nasconde/mostra solo la vista.
- L'ultima scheda guardata viene ricordata: riaprendo il sito si riparte da
  lì (o da "Controllo prezzi" la prima volta).
- Su schermi stretti le schede vanno a capo automaticamente invece di
  impilare tutte le sezioni una sopra l'altra come prima.
- File modificati: `app.html`, `app.js`.

### 🧹 Estensione — tolte le legende dai popup Carte/Sealed/Wishlist
- Le legende (codici lingua/condizione, formato riga, prezzo obiettivo)
  non compaiono più quando le pagine "Aggiungi carte/sealed/wishlist" sono
  aperte dall'estensione.
- **Restano invariate nel sito** (dentro l'hub `app.html`), dove erano
  comunque già utili come colonna di riferimento.
- File modificati: `aggiungi_carta_popup.html`, `aggiungi_sealed_popup.html`,
  `aggiungi_wishlist_popup.html` (solo CSS, nessuna riga di legenda
  cancellata dal sito).

## v4.5 — 2026-08-16

### 🔧 Interno — avviso.mp3 incorporato nel codice
- Il suono di allerta Cloudflare non è più un file audio separato
  (`avviso.mp3`): il contenuto è ora incorporato come testo (Base64)
  dentro il nuovo file `avviso_audio.js`.
- Nessun cambiamento per chi usa l'estensione: il suono è identico a
  prima, cambia solo come viene distribuito dentro il pacchetto.
- File modificati: `manifest.json`, `offscreen.html`, `offscreen.js`,
  `background.js`. Nuovo file: `avviso_audio.js`. File rimosso:
  `avviso.mp3` (non va più incluso nello zip).

## v4.4 — 2026-08-16

### ✨ Nuovo — colonna "Coda pendente" in stile cruscotto
- Riscritta come "Gestione attività di Windows": quattro schede (Coda
  pendente, Controllo prezzi, Aggiungi carte, Wishlist) con barre che
  mostrano i numeri di ADESSO (in attesa, in corso, errori recenti) invece
  di due liste fisse.
- **"Coda pendente" è la scheda mostrata di default all'apertura** — combina
  carte + wishlist, con anche il dettaglio riga per riga sotto le barre
  (stessa lista di prima, solo riorganizzata).
- **Fix**: la vecchia versione leggeva solo `coda_carte` e non mostrava mai
  le righe della wishlist, perché la wishlist vive davvero in una tabella a
  parte (`coda_wishlist`) — un dettaglio mai notato prima. Ora entrambe le
  code vengono lette.
- La scheda "Controllo prezzi" mostra quante carte sono prenotate in questo
  momento e se c'è un ordine dal sito in attesa o in corso — non essendo una
  coda persistente come le altre, non ha uno storico da mostrare.
- Aggiunto anche il tag del dispositivo alle prenotazioni della coda
  wishlist (mancava, a differenza di `coda_carte`) — serve a popolare
  "Dispositivi al lavoro" nella scheda Wishlist del cruscotto.
- **Richiede un piccolo intervento manuale su Supabase** — vedi le
  istruzioni di pubblicazione.

## v4.3 — 2026-08-16

### 🐛 Fix — controllo prezzi che non si fermava mai (rifaceva le stesse carte all'infinito)
- **Causa trovata**: la sessione di controllo prezzi si fermava confrontando
  quante carte aveva già processato con un conteggio iniziale
  (`totaleStimato`) calcolato una sola volta all'avvio. Se quel conteggio
  falliva per qualunque motivo, l'errore spariva silenziosamente e il
  conteggio diventava `0` — un valore che disattivava del tutto il
  controllo di stop, facendo continuare la sessione all'infinito.
- Inoltre la scrittura che segna una carta come "controllata ora"
  (`segnaControllata`) veniva lanciata senza aspettarla: tra un lotto di
  carte e il successivo poteva capitare che quella scrittura non fosse
  ancora arrivata al database, facendo ripescare le stesse carte appena
  controllate — molto più visibile su code piccole (es. 7 carte).
- Due carte "difficili" (Cloudflare non risolto in tempo, carta non
  trovata nella pagina) non venivano MAI segnate come controllate, quindi
  restavano sempre in cima alla fila ad ogni nuovo lotto.
- **Fix in `popup.js`**:
  - un errore nel conteggio iniziale ora interrompe subito la sessione con
    un messaggio chiaro, invece di proseguire con un conteggio azzerato
    silenziosamente;
  - le scritture "controllata ora" vengono aspettate tutte insieme una
    volta per lotto (non una per carta, per non rallentare la sessione)
    prima di richiedere il lotto successivo;
  - aggiunto un limite di sicurezza assoluto sul numero di lotti richiesti,
    indipendente dal conteggio iniziale: qualunque cosa succeda al
    conteggio, la sessione ora si ferma comunque;
  - le carte che incontrano Cloudflare non risolto o non vengono trovate
    nella pagina vengono ora sempre segnate come controllate, come già
    succedeva per le carte senza URL salvato.

### 🐛 Fix — prenotazioni del controllo prezzi confuse tra più PC con lo stesso account
- Le carte prenotate durante un controllo prezzi condiviso erano taggate
  solo con l'account (`claimed_by`), non con il singolo dispositivo: due PC
  online insieme con lo stesso login potevano "confondere" le rispettive
  prenotazioni, e quando uno dei due finiva la sua sessione liberava anche
  le carte che l'altro stava ancora controllando.
- Ora ogni prenotazione porta anche il nome del dispositivo (stesso
  sistema già usato per la coda di inserimento carte), e il rilascio a
  fine sessione libera solo le prenotazioni di questo dispositivo.
- **Richiede un piccolo intervento manuale su Supabase** — vedi le
  istruzioni di pubblicazione.

### 🧹 Rimosso — pulsanti non più utili
- Tolto il pulsante "🧪 Prova" (dry run) dal controllo prezzi.
- Tolto il popover "📍 Gestisci location" dall'header dell'hub (creava/
  rinominava/eliminava location manualmente) e il pulsante "↺ Aggiorna
  elenco" nel filtro Location del controllo prezzi: le location si creano
  già da sole quando se ne scrive una nuova aggiungendo una carta, e ora
  la tendina del filtro nel controllo prezzi si aggiorna automaticamente
  ogni volta che una nuova location viene registrata da qualunque sezione
  (prima si aggiornava solo con quel pulsante manuale).

## v4.2 — 2026-08-15

### 🐛 Fix — immagini che restavano sempre l'URL grezzo di Cardmarket
- **Causa trovata**: per un sottoinsieme di immagini più vecchie del
  catalogo Cardmarket, il loro server risponde con un header
  Content-Type spazzatura (la stringa letterale
  "multerS3.AUTO_CONTENT_TYPE", un residuo interno del loro sistema)
  invece di un vero tipo MIME come "image/jpeg". Supabase Storage
  rifiutava l'upload con "Invalid Content-Type header", e il codice
  faceva fallback silenzioso all'URL Cardmarket grezzo — che
  Cardmarket blocca in hotlinking da altri domini, quindi l'immagine
  non si vedeva mai né sul sito né altrove, nemmeno dopo ripetuti
  controlli prezzi.
- **Fix in `_immagineAUrlDati()` (background.js)**: se l'header
  Content-Type ricevuto da Cardmarket non è un vero tipo immagine
  (non inizia per "image/"), viene ignorato e il tipo corretto viene
  dedotto dall'estensione del file nell'URL (.jpg/.png/.webp), con
  image/jpeg come default di sicurezza.
- Le carte già presenti con URL Cardmarket grezzo si aggiornano da
  sole ai prossimi controlli prezzi, nessun intervento manuale
  richiesto.
- Corretto anche lato sito: `sealed.html`, `wishlist.html` e
  `scambio.html` ora instradano gli URL Cardmarket grezzi storici
  attraverso lo stesso proxy images.weserv.nl già usato da
  `index.html`, invece di provare a caricarli direttamente (bloccati
  dall'hotlinking di Cardmarket).

## v4.0 — 2026-08-15

### 🔴 Ristrutturazione grossa — estetica e collegamento sito↔estensione
- **Estensione: un'unica pagina a colonne** invece di tab da aprire una alla volta — Controllo prezzi, Carte, Sealed, Wishlist e la nuova colonna **Coda pendente** sono ora tutte visibili insieme, affiancate (una sopra l'altra su schermi stretti). Nessuna modifica alla logica di calcolo/elaborazione sottostante.
- **Nuova colonna "Coda pendente"**: mostra in tempo reale (sola lettura) le righe in attesa/in corso e gli errori recenti della coda condivisa — utile per verificare che un inserimento fatto dal sito sia stato preso in carico, senza dover indovinare.
- **Tolta "Anteprima"**: pagina di debug non più necessaria ora che l'inserimento vero avviene dal sito.
- **Tema e tema scuro non si scelgono più nell'estensione**: arrivano automaticamente dal sito quando si apre l'app (nessun selettore proprio da tenere sincronizzato a mano).
- **Login condiviso**: aprendo l'app dal sito, l'estensione riceve la stessa sessione già attiva — non chiede più un secondo login separato.
- **Via il preferito automatico**: al suo posto, due controlli in alto sul sito — "Apri l'app" (apre/porta in primo piano la tab dell'estensione) e uno switch "Apri sempre l'app all'apertura del sito da questo dispositivo" (preferenza locale, per dispositivo).
- **Pannello "Incolla lista" tolto da Carte**: l'inserimento vero avviene dal sito tramite la coda condivisa; la tabella "riga per riga" resta (è anche la vista live di ciò che l'estensione sta elaborando in automatico), utilizzabile a mano per casi eccezionali.
- Rimossi permesso `bookmarks` e tutta la logica del preferito automatico dal manifest/`background.js`.
- File morti rimossi dal pacchetto: `anteprima_popup.js/html`, `dark-mode.css/js`, `notify_update.js`, `errore.mp3`, `sidebar.html`, e i 4 file `.gs` residui dall'epoca Google Sheets (ormai sostituiti da Supabase).
- **Pulizia completa residui Google Sheets/Apps Script**: rimossi ovunque i parametri `webAppUrl`/`sheetName` (mai più letti da nessuna parte dopo la migrazione a Supabase, ma ancora passati in giro in `background.js` e nelle 3 pagine "aggiungi"), il campo "Nome scheda Wishlist", le funzioni di diagnostica per errori Apps Script in `shared.js`. Riscritto `ISTRUZIONI.md` per riflettere l'architettura reale (sito + Supabase). Rimosso `PATCH_ISTRUZIONI.md` (patch di una sessione passata, già applicate).

## v3.29 — 2026-08-15

### 🔴 Fix critici
- **Login mai richiesto dopo "Non installarla"**: chi sceglieva di non installare l'estensione (o non poteva, es. dispositivo non Windows) restava bloccato per sempre — il controllo login non partiva mai dopo quella scelta. Ora prosegue correttamente al login.
- **Script `.bat` che si chiudeva subito senza fare nulla**: causato dai caratteri decorativi speciali aggiunti nella versione precedente (encoding non affidabile per un file scaricato ed eseguito). Rimossi tutti i caratteri non-ASCII dal file.

### Novità
- **Popup di controllo versione ridisegnato, dentro l'estensione**: ora mostra sempre un riscontro visivo — un piccolo avviso "Bill ti ringrazia" (si chiude da solo dopo 3 secondi, o con la X) se sei aggiornato, oppure un messaggio bloccante con link diretto al sito se non lo sei. Prima, quando tutto andava bene, non si vedeva nulla — impossibile sapere con certezza se il controllo fosse mai girato.
- **Script `.bat` più snello**: se il sito conferma che è un aggiornamento (non una prima installazione) e c'è una cartella già ricordata, la usa direttamente senza aprire nessuna finestra.
- Tolta la chiusura automatica del terminale — resta aperto con un messaggio chiaro ("ora puoi chiuderlo") finché non lo chiudi tu stesso.

## v3.28 — 2026-08-15

### Fix
- **Toggle "Tema scuro"** ora forza lo stesso refresh vero già applicato ai temi colore — mancava, causava lo stesso tipo di applicazione incompleta.
- Aggiunti log diagnostici temporanei nel controllo versione obbligatorio (console del service worker) per capire con certezza se/come sta funzionando.

### Novità
- Testo del toggle: "Tema scuro" → "Rendi il tema scelto più scuro" (più chiaro su cosa fa davvero).
- **Script `.bat` più curato**: intestazione e conclusione con cornice, colore a tema. Chiusura automatica dopo 5 secondi quando non c'è altro da fare; quando invece serve il passo manuale "Carica estensione non pacchettizzata", il messaggio ora è molto più visibile (colore acceso, cornice dedicata) e la finestra resta aperta finché non la chiudi tu stesso, invece di sparire dopo pochi secondi.
- Il comando copiato dal sito ora chiude anche la finestra di PowerShell da sola a fine esecuzione (non solo lo script).

## v3.27 — 2026-08-15

### Fix
- **Temi diversi da "Psychic Energy" (default) mal funzionanti**: causa trovata — il tema di base funziona sempre bene perché sono le regole CSS "di partenza" del file, mentre gli altri 14 temi si basano su override che non coprono tutti gli elementi (stesso problema già risolto per "Dark Type"). Estesa la stessa rete di sicurezza a **tutti** i temi, non solo al tema scuro.
- **Cambio tema "a caldo" incompleto**: ora ogni cambio tema (click su un bottone, o sincronizzato da un'altra scheda) forza un refresh vero della pagina invece di applicare solo alcune classi CSS — garantisce che tutto si ridisegni coerente col tema scelto.

## v3.26 — 2026-08-15

### Fix
- **Header non scuro col "Tema scuro" attivo**: ogni tema aveva un gradiente header sempre chiaro/pastello, mai toccato dal tema scuro (per non "rubare" il colore caratteristico). Corretto con uno scurimento automatico basato sul colore del tema stesso (tecnica `color-mix`), niente più header chiaro su sfondo scuro.

### Novità
- **"Aiuta il gruppo" e "Tema scuro" sempre visibili**: spostati in una fascia fissa sotto l'header principale, visibile su ogni tab (non più nascosti dentro un pannello impostazioni da aprire).
- Link `chrome://extensions` nelle istruzioni di disinstallazione ora copiabile con un click (un sito non può aprirlo direttamente — restrizione di sicurezza di Chrome).
- Lo script di aggiornamento ora riceve dal sito un parametro esplicito (aggiornamento/installazione) invece di doverlo indovinare da solo — elimina il messaggio "Carica estensione non pacchettizzata" quando non serve davvero.

## v3.25 — 2026-08-15

### 🔴 Ristrutturazione temi
- **"Dark Type" non è più un tema a sé** — è diventato un modificatore indipendente ("Tema scuro"), applicabile sopra a QUALUNQUE degli altri 15 temi esistenti (nessuno eliminato). Sfondo scuro neutro condiviso, colore caratteristico del tema attivo sempre mantenuto — es. tema verde + tema scuro = accenti verdi su sfondo scuro neutro, non più grigio scolorito.
- Risolve anche il conflitto di ieri (tema scuro che sbiadiva temi già scuri come "Dark Type"/Psychic Energy).

### Novità
- Wizard di aggiornamento **dentro l'estensione** semplificato: invece di duplicare le istruzioni (con un risultato visivamente peggiore di quelle sul sito), ora rimanda con un bottone al sito, che gestisce da solo l'intero percorso.
- Istruzioni di installazione: bivio più netto tra "prima installazione" e "aggiornamento" — chi ha già una versione (seppur vecchia) non vede più il passo "Carica estensione non pacchettizzata".
- Testi con la battuta "PC di Bill" al posto delle precedenti.
- Rimosso il bottone "Aggiorna estensione" dall'header del sito (ridondante col controllo automatico).

## v3.24 — 2026-08-15

### 🔴 Fix critico
- **Il nuovo "tema scuro" di 3.23 andava in conflitto col tema "Dark Type" preesistente** — l'inversione cromatica introdotta ieri scoloriva quel tema (già scuro di suo) rendendolo grigio chiaro invece di lasciarlo intatto. Rimossa del tutto quella tecnica: il toggle "Tema scuro" ora riusa direttamente il tema "Dark Type" già esistente, invece di introdurre un sistema parallelo.
- **Tema "Dark Type" completato**: aggiunta una rete di sicurezza CSS in tutte le pagine (popup, Carte, Prezzi, Wishlist, Sealed, Anteprima) per gli sfondi rimasti bianchi per colori fissi mai aggiornati dal tema — dovrebbe risolvere il "mezza pagina bianca" visto ieri.

### Novità
- **Bivio nelle istruzioni di aggiornamento** (sito): dato che il sito sa già se ha rilevato una versione vecchia o nessuna estensione, mostra solo le istruzioni rilevanti al caso specifico — chi sta solo aggiornando non vede più il passo "Carica estensione non pacchettizzata" (che Chrome già conosce), mostrato solo a chi la installa per la prima volta.
- Avviso "Chrome si riavvierà" spostato in cima alle istruzioni, con l'aggiunta di NON premere "Ripristina" se Chrome lo chiede al riavvio.
- Battuta "Tienimi acceso" aggiornata: via l'uovo, dentro il "PC di Bill" 💻 (sia sul sito che nell'estensione).

## v3.23 — 2026-08-15

### Novità
- **Vero tema scuro nell'estensione** (prima non esisteva affatto — quello che si vedeva "a metà" era probabilmente lo scurimento automatico e parziale di Chrome). Nuovo interruttore "🌙 Tema scuro" nelle Impostazioni, sincronizzato su tutte le pagine (popup, Carte, Prezzi, Wishlist, Sealed, Anteprima).
- **"Tienimi acceso"** anche nell'estensione (stesso concetto già presente sul sito) — se disattivato, esce automaticamente quando l'estensione si sospende.
- All'avvio di Chrome, ora si apre automaticamente anche il sito (non solo la tab Prezzi dell'estensione).

## v3.22 — 2026-08-15

### Fix
- **"Doppio contenitore" (login/logout duplicati)**: le tab Carte/Prezzi/Wishlist sono iframe separate, ognuna con la propria copia dello script di login — ognuna mostrava il proprio form/bottone, sovrapposti. Ora solo la finestra principale li mostra; le iframe aspettano semplicemente che la sessione diventi disponibile.
- **Testo illeggibile in tema scuro** (es. il disclaimer "Chrome si riavvierà"): mancava la variante scura dello sfondo di avviso (`--danger-bg`), restava sempre chiaro anche di notte con testo quasi bianco sopra.
- **Popup del sito non centrato**: aggiunta una protezione via JavaScript che sposta sempre il popup direttamente sotto `<body>` prima di mostrarlo, eliminando qualunque possibile interferenza dal resto della pagina.

### Novità
- **Controllo versione anche lato database** (non solo lato client): una nuova funzione SQL (`verifica_versione_minima`) rifiuta esplicitamente le operazioni se la versione dichiarata non è quella minima richiesta — la decisione finale non dipende più solo dal fidarsi del client.
- Aspetto dei popup arricchito con un effetto radiale e un piccolo dettaglio decorativo, per avvicinarsi di più all'estetica "carta collezionabile" senza usare personaggi protetti da copyright.

## v3.21 — 2026-08-15

### Novità
- **Controllo versione prima di ogni operazione sul database**: l'estensione verifica di essere aggiornata prima di leggere/scrivere qualunque dato — protegge il database condiviso da eventuali danni causati da una versione vecchia rimasta in giro su qualche PC. Controllo in cache per 3 minuti (non rallenta il lavoro normale), permissivo se il controllo stesso fallisce (es. offline).
- **Popup unificato**: il wizard di aggiornamento (Win+X, comando da copiare, ecc.) ora vive dentro lo stesso popup del controllo versione, invece di un modale separato — risolve alla radice il problema di centratura che il secondo modale continuava ad avere.

## v3.20 — 2026-08-15

### 🔴 Fix critico
- **L'estensione si disinstallava da sola al riavvio di Chrome** — causata dal tentativo (introdotto in 3.19) di riscrivere le preferenze di Chrome per evitare il prompt "Ripristina le pagine?". Chrome rileva le modifiche esterne alle proprie preferenze come possibile manomissione e può resettare varie impostazioni per sicurezza, incluse le estensioni caricate manualmente. Rimosso del tutto — resta il prompt di ripristino occasionale, decisamente meno grave.
- **Promemoria "Carica estensione non pacchettizzata" non sempre mostrato**: prima veniva deciso in base alla sola presenza dei file sul disco (che restano anche se Chrome non ha mai caricato quella cartella) — ora si basa su una conferma vera da parte di Chrome stesso, mostrando il promemoria ogni volta che non è certo al 100%.

### Novità
- Apertura automatica della tab Prezzi ad ogni avvio di Chrome (stesso posto del preferito).
- Popup di controllo versione e wizard di aggiornamento: cornice più marcata, testo più grande, larghezza aumentata.
- Le istruzioni "Carica estensione non pacchettizzata" ora sono scritte anche nel wizard sul sito, non solo nell'output dello script.
- **Doppio controllo anti-furbetti**: chiudere il wizard di aggiornamento senza aver davvero completato l'installazione ora fa ripartire una verifica reale — se l'estensione ancora non risulta aggiornata, ricompare l'avviso (in tono scherzoso).

## v3.19 — 2026-08-15

### Fix
- **Preferito automatico**: prima si affidava solo a `onInstalled`/`onStartup` (non abbastanza affidabili per un'estensione non pacchettizzata, specialmente dopo una chiusura forzata di Chrome) — ora viene richiesto anche ad ogni apertura riuscita di una pagina dell'estensione, molto più affidabile. Evita comunque sempre i duplicati.

### Novità
- **Controllo versione anche sul sito**: ad ogni apertura, il sito chiede direttamente all'estensione (se installata) che versione hai, e mostra un popup a tutta pagina — "complimenti, sei aggiornato" se tutto ok, altrimenti tre scelte: aggiorna ora, non mi serve su questo PC (va bene, non è obbligatorio su ogni dispositivo), oppure disinstalla. Richiede il nuovo permesso `externally_connectable` (solo il sito può comunicare con l'estensione, nessun altro dominio).
- Wizard di aggiornamento sul sito: aggiornata l'istruzione per aprire PowerShell — Win+X poi **I** invece di cliccare, più veloce.

## v3.17 — 2026-08-14

### Novità
- **Preferito automatico**: l'estensione si crea da sola un segnalibro "🃏 CardSync Pro" nella barra dei Preferiti (punta direttamente alla tab Prezzi), sfruttando l'ID ora fisso introdotto in 3.16 — non serve più che ciascuno se lo crei a mano. Un solo passo resta manuale e non automatizzabile: se la barra dei Preferiti è nascosta, va mostrata una volta con **Ctrl+Shift+B** (nessuna API di estensione può farlo al posto dell'utente).

## v3.16 — 2026-08-14

### Novità
- **ID estensione fisso**: prima Chrome assegnava un ID diverso ad ogni installazione (dipendeva dal percorso della cartella) — ora è sempre lo stesso per tutti, così un link diretto tipo `chrome-extension://ID_FISSO/app.html#prezzi` funziona identico su ogni PC, senza doverselo ricavare da soli.
- **⚠️ Effetto collaterale una tantum di questo aggiornamento**: cambiando ID, Chrome tratta l'estensione come "diversa" ai fini delle preferenze salvate SOLO SUL DISPOSITIVO (es. "Aiuta anche il gruppo", nome dispositivo, ultimo utilizzo) — si resettano ai valori di default una volta sola con questo aggiornamento. **La collezione/wishlist/carte non sono minimamente toccate** (vivono sul server, non nell'estensione).
- **Chiusura Chrome più "gentile"** durante l'aggiornamento: prima una chiusura forzata faceva comparire il fastidioso prompt "Ripristina le pagine?" al riavvio (Chrome la scambiava per un crash) — ora prova prima una chiusura pulita, forzando solo come ripiego se necessario.
- Lo script `.bat` non si blocca più alla primissima installazione se la cartella scelta non ha ancora l'estensione dentro — la installa lì direttamente, con un avviso finale su come completare il collegamento a Chrome (va fatto "Carica estensione non pacchettizzata" una volta sola, richiesto da Chrome per ragioni di sicurezza — impossibile da automatizzare oltre).

## v3.15 — 2026-08-14

### Novità
- **Aggiornamento obbligatorio**: l'estensione controlla da sola, prima ancora del login, se è disponibile una versione più recente — se sì, blocca l'accesso con un wizard a schermo intero (impossibile da chiudere) che guida passo passo all'aggiornamento. Fallisce in modo permissivo se offline (non blocca chi non ha connessione).
- **Script di aggiornamento (`aggiorna_cardsync.bat`)** riscritto: ora prova prima a rilevare da solo la cartella dell'estensione leggendo le impostazioni di Chrome (dove sono elencate le estensioni "non pacchettizzate" con il loro percorso reale), chiedendo all'utente solo come ultima risorsa. Corretto anche un bug per cui la cartella scelta non veniva ricordata correttamente tra un utilizzo e l'altro.
- Wizard di aggiornamento sul sito (pannello "Aggiorna estensione" nell'header) semplificato: rimossa l'opzione "a mano", tutto passa dal comando PowerShell copiabile.

## v3.4 – v3.14 — 2026-08-13/14

Riassunto (voci individuali non registrate singolarmente al momento):
- Conversione immagini via Supabase Storage estesa a tutti i flussi (wishlist, sealed, non solo carte) — prima solo il controllo prezzi la applicava.
- Contenuto tipo file ripulito prima dell'upload su Storage (evitava errori "Invalid Content-Type header").
- Corretto un crash del controllo prezzi su carte senza URL salvato.
- Corretto un loop infinito del controllo prezzi su collezioni piccole (la sessione non si fermava mai da sola).
- Riscritta la prenotazione delle carte durante il controllo prezzi in modo **atomico** lato database (funzione `reclama_carte_per_controllo_prezzi`, FOR UPDATE SKIP LOCKED) — eliminata una race condition per cui due dispositivi potevano finire per controllare le stesse carte.
- Corretti due bug per cui gli aggiornamenti di prezzo/data-controllo venivano silenziosamente ignorati quando un dispositivo processava le carte di un altro membro del gruppo.
- Unione automatica a un controllo prezzi già in corso nel gruppo (carte e wishlist), e avvio automatico "aiuta se non hai altro da fare" con pausa se arriva lavoro vero — entrambi dietro l'interruttore "Aiuta anche il gruppo" (mai attivo di default).

## v3.3 — 2026-08-13

### Fix
- **🔴 Carte di un altro finite nel database sbagliato** — quando l'estensione elabora una carta per conto di qualcun altro (coda condivisa dal sito), ora scrive sempre sul proprietario reale della richiesta, non su chi è loggato sul dispositivo che la esegue. Stessa correzione applicata separatamente anche al controllo prezzi ("solo le mie" filtrava sulle carte di chi esegue, non di chi ha creato la richiesta).
- **🔴 Lavoro non diviso tra dispositivi online** — sia l'aggiunta carte che il controllo prezzi finivano per essere elaborati quasi interamente da un solo dispositivo, anche con più PC online contemporaneamente. Ridotti i lotti reclamati per volta (1 carta per l'aggiunta, 3 per il controllo prezzi, con richiesta automatica del successivo), aggiunto un controllo di riserva basato su `chrome.alarms` per i dispositivi con la tab in background (rallentata da Chrome).
- **Regola di sicurezza mancante** per la lettura della collezione altrui durante il controllo prezzi condiviso — esistevano regole solo per Sealed e Scambio, non per il resto della collezione.
- **Permesso mancante** per eliminare righe dalla coda (bloccava la rimozione delle "Carte con problemi").
- **Crash "Cannot read properties of null"** durante il controllo prezzi — una carta senza URL salvato bloccava l'intera sessione invece di essere saltata.
- **Filtro location vuoto interpretato come "nessuna corrispondenza"** invece di "tutte le location" durante il controllo prezzi dal sito.
- Vincolo `NOT NULL` sulla colonna `tipo` che rifiutava le carte non-sealed.
- Content-Type non valido durante l'upload di alcune immagini su Storage (residui dall'era Google Apps Script).
- Nomi carta forzati in maiuscolo — ora restano con la capitalizzazione naturale.
- Scroll casuale anti-rilevamento: ora torna sempre in cima alla pagina alla fine.

### Novità
- **Immagini spostate su Supabase Storage** (prima base64 dentro il database) — alleggerisce il database, con deduplica automatica via hash del contenuto.
- **Sezione "Carte con problemi"** sul sito: vedi/correggi/riprova le carte che l'estensione non è riuscita a trovare, incluse le disambiguazioni (ora risolte via link diretto invece di una nuova ricerca per nome, che poteva restare ambigua).
- **Vista mobile compatta** per Visualizzazione/Scambio/Wishlist/Sealed/Inserimento — niente più scorrimento orizzontale su telefono.
- **Ricerca globale** sul sito (cerca su tutta la collezione, non solo la tab attiva).
- **Notifiche letto/non letto** per match trovati e avvisi prezzo wishlist.
- **Privacy match**: due interruttori per nascondere i propri Scambio/Wishlist dal matching automatico col gruppo.
- **Login semplificato**: solo nome utente, niente più email da scrivere per intero.
- **Icona profilo** al posto dell'email in header, con menu nome/email/logout.
- **Pulizia automatica dello storico prezzi** oltre i 30 giorni (gira da sola ogni notte).
- **Ambito controllo prezzi** ("solo le mie" / "tutto il gruppo") ora scelto esplicitamente sul sito al momento della richiesta, invece di dipendere da un'impostazione locale del dispositivo che la esegue.

## v3.2 — 2026-08-08

### Fix
- **🔒 Credenziali Telegram esposte in `notify_update.js`** — il token del
  bot e il chat/thread ID usati per le notifiche di aggiornamento erano
  scritti in chiaro come valore di default nel file (attivo per chiunque
  eseguisse lo script senza impostare le variabili d'ambiente), invece di
  essere richiesti solo tramite `TELEGRAM_BOT_TOKEN`/`TELEGRAM_CHAT_ID`/
  `TELEGRAM_THREAD_ID`. Chiunque avesse accesso al file poteva usare quel
  token per mandare messaggi nel canale/gruppo configurato. Rimossi i
  default "veri": le variabili vanno ora sempre impostate via ambiente.
  Corretto anche il controllo di avvio in `main()`, che confrontava contro
  dei placeholder mai effettivamente usati come default (quindi non
  scattava mai) — ora verifica semplicemente che le variabili non siano
  vuote. **Se il token era già stato distribuito/versionato, va comunque
  rigenerato da BotFather (`/revoke`): sostituire il file da solo non lo
  invalida.**
- **Pulizia codice morto** — rimossa `_fermaKeepAlive()` in `background.js`
  (mai chiamata da nessun punto del file) e `CONDIZIONI_MAP` in `popup.js`
  (mai referenziata), individuate con un controllo incrociato su tutte le
  dichiarazioni di funzione/costante del progetto.

## v3.1 — 2026-08-01

### Novità
- **➕ Aggiungi carte: tabella a righe invece della sola textarea** — la
  pagina "Carte" ha ora un tab "🧾 Riga per riga": scrivi il codice o
  nome+numero, Invio conferma la riga (Lingua/Condizione — incluse tutte le
  varianti `+`/`-` — RH/1ED/Qty/Note come controlli diretti, non più token
  da ricordare) e se ne apre subito una nuova, senza aspettare. Le carte
  vengono processate una alla volta con lo stesso ritmo anti-blocco di
  sempre; quelle riuscite spariscono dalla tabella dopo un breve ✅ (restano
  nel log), quelle non trovate/ambigue vanno dritte nel pannello di
  correzione manuale esistente. Il vecchio campo bulk resta disponibile in
  un secondo tab "📝 Incolla lista" (stessa sintassi di sempre), ora anche
  con caricamento diretto di un file `.txt` (bottone o trascinamento).
- **Ripresa sessione interrotta rivista** — salva la coda non ancora
  completata (non più il testo grezzo) e la ripopola nella tabella al click
  su "Riprendi".

### Fix
- **Coda che poteva bloccarsi per sempre** — lo step di scrittura sul
  foglio non era protetto da un controllo errori: un fallimento isolato
  (es. service worker riavviato in quel momento) avrebbe interrotto
  silenziosamente l'intera coda, senza messaggio d'errore né modo di
  ripartire se non ricaricando la pagina. Ora un fallimento lì viene
  trattato come una carta non trovata (log + pannello di correzione).
- **Conteggio "pausa ogni N carte" leggermente sfalsato dopo uno stop
  durante un rate-limit** — fermandosi proprio mentre una carta era in
  pausa per Error 1015, veniva comunque contata come completata pur
  tornando in coda per la ripresa. Il contatore ora avanza solo per le
  carte davvero concluse.

## v3.0 — 2026-07-26

### Novità
- **Hub unico in una tab** (`app.html`) — Controllo prezzi, Carte, Sealed,
  Wishlist e Anteprima vivono ora come iframe in un'unica tab con una
  tab-bar interna, invece di aprire fino a 5 tab separate del browser.
  Header comune (profilo/⚙/📜/🎨/🎛️), footer unico e cambio sezione senza
  ricaricare pagina. Le singole pagine restano invariate internamente e
  restano apribili anche da sole.
- **📍 Gestisci location** — nuovo popover nell'header dell'hub per
  aggiungere, rinominare ed eliminare le location della scheda dedicata
  "LOCATION" (quella collegata alla tendina Location dell'Inventario), con
  propagazione automatica alle righe dell'Inventario che le usano
  (rinomina le aggiorna, elimina le riporta a "?"). Richiede
  `apps_script_location_snippet.gs` (nuove azioni `elencaLocationTab`/
  `aggiungiLocationTab`/`rinominaLocationTab`/`eliminaLocationTab`).
- **🎛️ Comportamento e 👤 Profilo centralizzati nell'hub** — Ritardo
  min/max, Timeout Cloudflare, Pausa ogni N carte e Avviso sonoro, prima
  duplicati in ogni pagina bulk, vivono ora in un unico popover
  raggiungibile da qualunque sezione; stesso discorso per la scelta del
  profilo condiviso, non più legata alla sola pagina "Controllo prezzi".

### Fix
- **Worker tab non riusata nei fallback Cloudflare** — i percorsi di
  fallback per carte e sealed (`_risolviNomeEPrezzoUnicaTab`,
  `_risolviProdottoSealedTab`) aprivano sempre una tab nuova invece di
  riusare quella `about:blank` già pronta per la sessione, vanificando in
  parte l'ottimizzazione "una sola tab per sessione". Ora il tabId passato
  viene sempre riusato via `tabIdEsterno`, propagato attraverso tutta la
  catena di risoluzione.
- **Sessioni lunghe (▶ Avvia / bulk Carte-Sealed-Wishlist / 🔄 Aggiorna
  prezzi) si bloccavano se la tab restava per ore fuori dal primo piano**
  (finestra minimizzata, coperta da altre finestre, lasciata aperta durante
  la notte…) — riprendevano da sole solo tornando a mettere la tab in
  focus. Causa: il "background tab timer throttling" di Chrome, che
  rallenta drasticamente `setTimeout`/`setInterval` in una tab non
  visibile/non attiva dopo pochi minuti — e tutta l'attesa tra una carta e
  l'altra si basa su questi timer. Fix: ogni sessione lunga avvia ora un
  audio in loop a volume quasi impercettibile (nuovo
  `avviaAudioKeepAlive()`/`fermaAudioKeepAlive()` in `shared.js`, nessun
  file esterno), che esclude la tab dal throttling per tutta la propria
  durata — fermato automaticamente alla fine (successo, stop manuale o
  errore).

## v2.23 — 2026-07-19

### Novità
- **👁️ Anteprima foglio** — nuova pagina (icona 👁️ nell'header, accanto a
  📜/⚙) che mostra il Google Sheet configurato in una tabella scorrevole:
  ricerca testuale su tutte le colonne, filtro Location, link Cardmarket
  cliccabili, modifica inline della Location (salva subito nel foglio),
  simbolo € accanto ai prezzi.
- **👤 Cambio profilo da Carte/Sealed/Wishlist** — le tre pagine bulk hanno
  ora la stessa tendina "Profilo" del popup principale nel pannello ⚙️
  Impostazioni, senza dover tornare al popup principale per cambiarlo.

### Fix
- **👁️ Anteprima foglio: righe mancanti, disallineate o mostrate a partire
  dalla riga sbagliata** — tre cause distinte, tutte corrette:
  1. La tabella partiva dalla riga 1, mostrando anche le eventuali righe di
     intestazione — ora parte sempre da una riga fissa (4).
  2. La riga di partenza veniva letta da `rigaInizio` in storage, che però
     è il puntatore di *ripresa* del controllo prezzi (sovrascritto a ogni
     riga elaborata) — l'anteprima ora usa una soglia fissa, indipendente.
  3. La causa più insidiosa: la lettura passava dall'export CSV pubblico di
     Google (`gviz/tq`), che **esclude del tutto le righe nascoste
     manualmente** dal risultato (limite di Google, nessun parametro URL
     per aggirarlo) — ogni riga dopo una riga nascosta scalava di
     posizione, facendo sparire/disallineare esattamente le righe vicino
     all'inizio. Risolto alla radice: la lettura ora passa dalla Web App
     (nuova azione `leggiAnteprima` in `webapp_scrivi_prezzi.gs`, da
     ridistribuire), che legge con `SpreadsheetApp`/`getDisplayValues()` e
     include sempre tutte le righe reali, comprese quelle nascoste.
     Richiede quindi l'URL Web App configurato anche solo per visualizzare
     l'anteprima (prima serviva solo per modificare la Location).
- **👁️ Anteprima foglio: la seconda modifica alla Location non veniva
  salvata** — il click sulla cella catturava il valore da modificare solo
  al primo caricamento della tabella; dopo un salvataggio riuscito la cella
  non veniva ridisegnata, quindi ogni click successivo continuava a
  proporre il valore ORIGINARIO invece di quello appena salvato — se il
  nuovo valore desiderato coincideva per caso con quello originario (es.
  alternando tra due location), veniva scambiato per "nessun cambiamento" e
  scartato in silenzio. Ora il valore attuale viene riletto a ogni click,
  non più congelato al primo render.

## v2.22 — 2026-07-18

### Novità
- **🗂️ Wishlist** — nuovo terzo flusso, accanto a "➕ Carte" e "📦 Sealed":
  una pagina dedicata per registrare le carte che vuoi comprare (non che
  possiedi già), su una scheda separata dello stesso Google Sheet
  dell'Inventario. Stessa sintassi bulk delle carte (codice/nome, lingua,
  condizione, RH, 1ED, formato con virgola per nomi tipo "Mew EX"), con in
  più un **prezzo obiettivo** opzionale: aggiungi `@PREZZO` in qualunque
  punto della riga (es. `MEW008 @15`) per segnare la soglia sotto cui
  conviene comprare — le carte scese sotto quella soglia vengono
  evidenziate in verde nel pannello "📋 Wishlist attuale".
- **🔄 Aggiorna prezzi** (Wishlist) — ricontrolla in sequenza il prezzo di
  tutte le carte già in wishlist, riusando la stessa infrastruttura di
  lettura prezzo già collaudata nel controllo prezzi principale — nessuna
  modifica al service worker.
- **✓ Comprata** (Wishlist) — sposta con un click la carta dalla Wishlist
  all'Inventario (stessa configurazione Web App/Sheet ID già impostata nel
  popup principale), svuotando la riga di origine. **🗑️ Rimuovi** elimina
  la riga senza spostarla, per le carte che non interessano più.
- Richiede due nuove azioni lato Apps Script (`leggiWishlist`,
  `svuotaRiga`) — vedi `apps_script_wishlist_snippet.gs` e Parte 10 di
  `ISTRUZIONI.md` per il setup.

## v2.21 — 2026-07-17

### Modifiche
- **Badge "profilo attivo" nell'header sostituito con testo semplice** — la
  pill colorata introdotta in v2.20 ("👤 NOME" con sfondo proprio) è stata
  sostituita da una riga di testo sobria, coerente con lo stile del
  sottotitolo già presente nell'header: **"Connesso come: NOME"**, solo il
  nome in grassetto, nessuno sfondo/bordo. Stessa logica di aggiornamento
  (boot + `chrome.storage.onChanged`, sincronizzato tra tutte le pagine),
  solo l'aspetto visivo è cambiato.

## v2.20 — 2026-07-17

### Novità
- **Badge "profilo attivo" sempre visibile nell'header** — finora l'unico
  punto in cui si vedeva quale profilo condiviso fosse in uso era il
  modale mostrato prima di avviare una sessione (v2.19), quindi bisognava
  aprire un popup o passare da un avvio per accorgersene. Ora un piccolo
  badge ("👤 NOME") compare sempre sotto il titolo, in tutte e tre le
  pagine (popup principale, "Aggiungi carte", "Aggiungi sealed") — sparisce
  da solo se nessun profilo è selezionato. Si aggiorna in tempo reale anche
  quando il profilo cambia da un'ALTRA pagina dell'estensione (es. lo si
  cambia dal popup principale mentre una pagina bulk è già aperta), tramite
  `chrome.storage.onChanged`, coerente con la stessa logica già usata per
  far ripresentare il promemoria di conferma (v2.19). Sfondo bianco
  semi-trasparente indipendente dal colore dell'header, così resta
  leggibile anche nel tema Pokéball (dove l'header è tinta unita identica
  al colore accent).

## v2.19 — 2026-07-17

### Novità
- **Conferma del profilo attivo prima di controlli/aggiunte** — con più
  persone che condividono la stessa estensione (profilo condiviso, v2.16),
  mancava un modo per accorgersi di avviare una sessione col profilo di
  un'ALTRA persona ancora selezionato nella tendina. Il modale "🚀 Recluta
  il Team Rocket!" (già mostrato prima di ▶ Avvia / 📋 Aggiungi tutte / 📦
  Aggiungi al foglio) ora mostra anche un riquadro con il **nome del
  profilo attivo** ("👤 Profilo attivo: NOME — sei tu?"), o un avviso se
  nessun profilo è selezionato. A differenza della sola conferma login
  (mostrata una volta per apertura pagina), questo promemoria si
  **ripresenta ogni volta che il profilo attivo cambia** rispetto
  all'ultima conferma data — anche a metà sessione, es. se il profilo
  viene cambiato dalla tendina nel popup principale mentre una pagina bulk
  è già aperta altrove.

## v2.18 — 2026-07-17

### Fix
- **L'ultimo profilo scelto non restava selezionato riaprendo il popup** —
  la tendina "Profilo" si ripopolava sempre da capo su "— scegli un profilo
  —", anche se i dati di quel profilo (URL Web App/ID Sheet/Nome scheda)
  erano già in storage e già in uso. Ora, all'apertura del popup, la tendina
  mostra subito l'ultimo profilo caricato — senza rifare la chiamata al
  registro, solo per mostrare visivamente quale profilo è attivo — così non
  serve più sceglierlo di nuovo a ogni apertura.

## v2.17 — 2026-07-17

### Modifiche
- **Riquadri "👤 Profilo condiviso" e "⚡ Connessione Google" uniti in uno
  solo** — dopo l'introduzione del profilo condiviso (v2.16), avere due
  riquadri separati sempre entrambi in vista era più confusione visiva del
  necessario, specie ora che l'uso quotidiano richiede solo scegliere un
  nome da una tendina. Il nuovo riquadro unico **"⚡ Connessione"**, aperto,
  mostra subito la tendina "Profilo" — un solo campo — e nasconde i dettagli
  tecnici (URL Web App, ID Sheet, Nome scheda, "🔌 Controlla connessione",
  "💾 Salva come profilo…", URL registro) dietro un secondo toggle nidificato
  **"⚙️ Configura manualmente"**, da aprire solo la prima volta che si crea
  un profilo o per un controllo puntuale.

## v2.16 — 2026-07-16

### Novità
- **Profilo condiviso** — nuovo riquadro "👤 Profilo condiviso" nel popup
  principale (accanto a "⚡ Connessione Google") pensato per chi usa la
  stessa estensione su più PC/account (es. con un amico): un secondo Google
  Sheet, separato dall'inventario, funge da "registro profili" con una riga
  per persona (URL Web App, ID Sheet, Nome scheda, colonne). Basta
  configurare una volta l'URL del registro su ogni PC, poi scegliere il
  profilo dalla tendina e cliccare "📥 Carica" per compilare in automatico
  tutta la connessione — niente più copia/incolla manuale di 4-5 campi ogni
  volta che cambia la persona che usa l'estensione. Il bottone "💾 Salva
  connessione attuale…" scrive la configurazione corrente nel registro con
  il nome scelto. La tendina profili si aggiorna da sola all'apertura del
  riquadro e sceglierne uno lo carica subito — nessun bottone "Carica" o
  "Aggiorna elenco" separato da capire. L'URL del registro condiviso è
  precompilato di default nel codice (stesso registro per tutti): non serve
  incollarlo su ogni PC, resta comunque un campo modificabile. Nuovo script
  `webapp_registro_profili.gs` da incollare nel secondo Sheet (setup
  descritto in `ISTRUZIONI.md`, Parte 4bis) — il foglio dell'inventario e
  il suo `webapp_scrivi_prezzi.gs` restano invariati.

## v2.15 — 2026-07-15

### Novità
- **Nota libera nel bulk "Aggiungi carte"** — nel formato con virgola (già
  usato per nomi tipo "Mew EX"), qualunque parola dopo la virgola che non è
  un modificatore noto (lingua/condizione/RH/1ED) veniva prima scartata
  silenziosamente. Ora viene scritta nella colonna Note: `FST007, NM error`
  → codice FST007, condizione NM, nota "ERROR". Utile in particolare per le
  carte più vecchie il cui link Cardmarket non contiene il codice (vedi fix
  v2.14) e per cui una nota manuale aiuta a ricordare perché quella riga
  richiede attenzione. La nota si combina con quelle automatiche
  (RH/1ED/condizione +/-) sia nell'inserimento diretto sia nel pannello di
  correzione manuale, e sopravvive alla lista "carte fallite" da ricopiare
  per riprovare. Il formato storico (senza virgola) resta invariato: non
  supporta note libere, perché non c'è modo affidabile di distinguere una
  parola in più del nome da una nota senza un separatore esplicito.

## v2.14 — 2026-07-15

### Fix
- **Carte vecchie segnate come "non trovata"** (es. `FST095` → Tynamo,
  Fusion Strike) — alcune espansioni datate non includono affatto il
  codice set+numero nello slug dell'URL Cardmarket (es.
  `.../Singles/Fusion-Strike/Tynamo`, senza "FST095" da nessuna parte).
  La verifica anti-carta-sbagliata (introdotta per il bug "MEW 8 → apriva
  Wartortle") si basava solo sullo slug e scartava sempre questi link,
  anche quando erano l'unico risultato restituito da Cardmarket e quindi
  quasi certamente corretti. Ora, quando la ricerca produce un solo
  risultato il cui slug non conferma né smentisce la query, l'estensione
  **apre/legge davvero la pagina candidata** e verifica il codice
  effettivo dall'h1 (fonte molto più affidabile dello slug) prima di
  accettarla — nessun costo aggiuntivo, quella pagina andava comunque
  fetchata per leggere nome/prezzo. Corretto sia nel percorso normale
  (fetch statico) sia nel fallback via tab (usato quando Cloudflare blocca
  il fetch statico), mantenendo invariata la protezione contro i falsi
  positivi: se il codice reale non combacia, la carta va comunque in
  correzione manuale invece di essere accettata alla cieca.

## v2.13 — 2026-07-14

### Documentazione
- **`ISTRUZIONI.md` riscritto** — era rimasto fermo alla versione "base" del
  progetto (popup singolo, nessuna colonna Location/Variazione, nessun
  accenno a bulk carte/sealed, temi, controllo login, changelog viewer).
  Ora riflette lo stato reale del prodotto: setup Sheet/Web App, guida
  completa ai due flussi bulk (sintassi righe, formato con virgola per nomi
  tipo "Mew EX", quantità sealed), login su Cardmarket, filtro Location,
  temi, struttura file aggiornata.

### Novità
- **Scrollbar a tema estesa a tutta l'estensione** — dopo l'introduzione
  nella pagina Changelog (v2.12), lo stesso stile (colori presi dalle
  variabili del tema attivo invece della scrollbar di sistema) è stato
  applicato anche a: il log sessione (`.log-body`) nel popup principale e
  in entrambe le pagine bulk; il dettaglio "🔺 Carte salite"/"🔻 Carte scese"
  nel popup principale; il pannello di correzione manuale in modalità-tab
  nelle pagine bulk carte/sealed; l'elenco delle varianti candidate nel
  pannello di correzione carte (nuova classe riusabile `.themed-scroll` per
  gli elementi creati dinamicamente via JS).

### Pulizia codice morto
- Rimossi in `background.js` due handler di messaggi mai invocati da nessun
  punto del progetto: `FETCH_IMMAGINE` (superato dall'estrazione immagine
  inline già usata altrove) e `LEGGI_NOME_SEALED` (duplicato incompleto di
  `LEGGI_SEALED` — mancava il collegamento al watchdog anti-blocco
  `requestId`/`_touchRichiesta`: se mai richiamato per errore avrebbe
  silenziosamente disattivato quella protezione).
- Rimosse due funzioni intere mai chiamate in `background.js`:
  `_risolviSinglesENome()` e `_leggiNomeDaSingles()` — entrambe aprivano una
  propria tab bypassando il riuso della worker tab, superate rispettivamente
  da `_risolviNomeEPrezzoUnicaTab()` (risoluzione+prezzo in un'unica tab) e
  dalla lettura nome integrata nelle funzioni di risoluzione esistenti.
- Rimossa `verificaCartaNellUrl()` (e la sua unica dipendenza `slugify()`)
  in `popup.js` — il vecchio approccio "indovina dallo slug dell'URL",
  superato da `verificaCartaNelDom()` che verifica sul DOM reale della
  pagina.
- Rimosse `oloTypeFromUrl()`/`firstEdFromUrl()` in `aggiungi_carta_popup.js`
  — residuo del controllo duplicati rimosso in una versione precedente dal
  flusso bulk per velocizzare le sessioni.
- Rimossa `_accodaCorrezione()` in `aggiungi_carta_popup.js` — mai chiamata:
  l'unico punto che accoda carte da correggere lo fa apposta in blocco
  (non una alla volta) per mostrare subito il totale corretto nel pannello.

## v2.12 — 2026-07-13

### Novità
- **Scrollbar a tema nella pagina Changelog** — lo scrolling introdotto in
  v2.11 usava la scrollbar di sistema (grigia), stonando soprattutto con i
  temi scuri (Dark Type, Team Rocket) e col tema Pokéball. Ora la scrollbar
  usa i colori del tema attivo (`--accent-dim`/`--surface`), cambiando
  automaticamente insieme al tema — nessuna regola aggiuntiva da mantenere
  per i temi "normali"; Wise Glasses e Pokéball hanno un piccolo tocco
  dedicato per restare coerenti col loro stile a bordi netti.

## v2.11 — 2026-07-13

### Novità
- **Scrolling nella pagina Changelog** — prima l'unico modo per leggere un
  changelog lungo era scorrere l'intera pagina del browser, portando via
  dalla vista anche l'header e il footer. Ora la pagina occupa esattamente
  il viewport: header e footer restano sempre visibili, e solo il testo del
  changelog scorre nel proprio riquadro — stesso pattern di scroll già usato
  altrove nell'estensione (es. il log delle sessioni bulk).

## v2.10 — 2026-07-13

### Fix
- **Race condition sulla worker tab riusata dal link 🔗 "Apri ricerca
  Cardmarket"** — il fix di v2.9 faceva riusare la worker tab a quel
  bottone, ma senza passare dalla coda `_accodaSuWorkerTab` già introdotta
  apposta per serializzare ogni uso della worker tab tra flussi diversi
  (bulk automatico, ricontrollo prezzo mancante, correzioni manuali). Un
  click su 🔗 mentre un'altra di queste operazioni era ancora in corso sulla
  stessa worker tab poteva navigarla a metà di quella lettura, facendo
  leggere all'altro task la pagina sbagliata — lo stesso tipo di bug che la
  coda era nata per prevenire. Ora anche questo ramo si accoda, come tutti
  gli altri usi di `usaWorkerTab`.
- **Micro-leak di memoria in `_righeGiaConfermate`** — il tracker anti-duplicato
  per carte volutamente identiche era un `Set` mai svuotato per tutta la vita
  del service worker: su bulk molto lunghi o tante sessioni ravvicinate
  cresceva senza limiti. Convertito in una `Map` riga→timestamp con pulizia
  periodica (voci più vecchie di 60 minuti, ben oltre una sessione bulk
  plausibile) agganciata allo stesso alarm `sw-keepalive` già usato per
  `_pulisciRichiesteVecchie` — nessun cambiamento di comportamento per i
  chiamanti, stessa logica di prima.

## v2.9 — 2026-07-13

### Fix
- **Il link 🔗 "Apri ricerca Cardmarket" nel pannello di correzione manuale
  apriva sempre una tab nuova** — su una sessione bulk con più carte/prodotti
  da correggere a mano, ognuna accumulava la propria tab in aggiunta a quella
  già usata per la lettura automatica: lo stesso pattern di navigazione
  "meccanico" già identificato altrove come segnale per l'anti-bot di
  Cloudflare. Ora riusa la worker tab già aperta per la sessione bulk
  (stesso comportamento per l'utente, una tab in meno da gestire). Corretto
  sia nel pannello carte sia in quello sealed.

## v2.8 — 2026-07-13

### Modifiche
- **Il modale "Team Rocket" ora verifica per davvero il login** — prima si
  fidava solo del click su "Sì, Boss Giovanni!". Ora, subito dopo la
  conferma, esegue un controllo reale e silenzioso su Cardmarket (stesso
  segnale DOM verificato del bottone "🔌 Controlla connessione":
  `account-dropdown` presente = loggato, `login-signup` presente = non
  loggato). Il controllo è silenzioso — nessuna tab visibile se sei già
  loggato — e porta la tab in primo piano SOLO se risulti non loggato, così
  puoi accedere subito invece di scoprirlo a sessione già iniziata. Se non
  sei loggato, l'avvio viene bloccato per davvero, non solo scoraggiato dal
  promemoria. Vale per ▶ Avvia, 📋 Aggiungi tutte, 📦 Aggiungi al foglio e la
  ripresa di una sessione interrotta.
- Il modale resta comunque utile come promemoria proattivo (mostrato una
  volta per apertura del popup) — ora ha anche un riscontro oggettivo dietro.

---

## v2.7 — 2026-07-13

### Novità
- **Bottone "🔌 Controlla connessione"** nel popup principale (dentro il
  riquadro "⚡ Connessione Google"): un solo click verifica prima di lanciare
  una sessione lunga.
- **Web App + foglio raggiungibili** — controllo automatico e affidabile,
  riusa l'azione `elencaLocation` già esistente e già testata, nessuna nuova
  chiamata inventata verso Apps Script.
- **Login su Cardmarket** — controllo affidabile basato su un segnale
  verificato dal DOM reale (2026-07): `<a id="account-dropdown">` presente
  nell'header = loggato, `<div id="login-signup">` presente = non loggato
  (i due elementi sono mutuamente esclusivi, sempre uno dei due presente).
  La tab resta comunque attiva dopo il controllo, così si può accedere
  subito se il risultato è "non loggato".

---

## v2.6 — 2026-07-13

### Refactor
- **Eliminata la triplice duplicazione del filtro righe offerta** — la logica
  che legge il DOM (mappa lingua→aria-label, rank condizione, marker Reverse
  Holo/Prima Edizione, controllo "carrello cliccabile") viveva copiata quasi
  identica in `content.js` e in due punti diversi di `background.js`
  (necessario perché `chrome.scripting.executeScript` non può referenziare
  funzioni esterne dell'estensione). Ora vive in un'unica fonte di verità in
  `shared.js` (`rigaSoddisfaFiltriShared`), iniettato dichiarativamente su
  ogni pagina Cardmarket insieme a `content.js` — Chrome condivide lo stesso
  "mondo isolato" tra script dichiarativi e injection imperative della stessa
  estensione sulla stessa tab, quindi `background.js` può richiamare la
  funzione condivisa invece di riscriverla. Aggiunto un fallback fail-open
  (nessun filtro, mai un blocco totale) nell'improbabile caso in cui
  `shared.js` non fosse ancora pronto, per non ripetere l'incidente "tutte le
  carte Esaurita" di una versione precedente.
- Un bug futuro in questa logica richiederà ora **un solo fix**, non tre
  sincronizzati a mano.

---

## v2.5 — 2026-07-13

### Novità
- **Changelog visibile nel popup** — nuova icona 📜 nell'header (popup
  principale + pagine bulk carte/sealed) che apre `changelog.html` in una
  tab: legge e mostra `CHANGELOG.md` formattato, con lo stesso tema
  scelto dall'utente. Basta continuare ad aggiornare questo file per
  vederlo comparire lì senza toccare altro.

### Modifiche
- **Bottone "Segnala un bug" spostato dall'header al footer** — prima
  aveva lo stesso peso visivo di 📜/⚙ nell'header pur essendo un'azione
  usata raramente. Ora è un link testuale piccolo e attenuato (opacità
  0.45, sale a 0.9 al passaggio del mouse) subito sotto la riga di
  copyright in fondo alla pagina — sempre raggiungibile in un click, ma
  senza competere visivamente con i controlli usati più spesso.

---

## v2.4 — 2026-07-13

### Fix
- **"Tutte le carte risultano Esaurita"** — il controllo "carrello cliccabile"
  (`rigaCarrelloCliccabile`, introdotto per scartare offerte non acquistabili)
  era un'**allowlist troppo rigida**: richiedeva una corrispondenza esatta
  `<button data-id-amount>` per accettare una riga. Bastava un piccolo
  scostamento (tab non ancora autenticata su Cardmarket al momento della
  lettura, markup leggermente diverso) per far scartare *ogni* riga di *ogni*
  carta, risultando sistematicamente in "Esaurita". Ora la funzione esclude
  solo il pattern esplicito "non cliccabile" osservato nel DOM reale
  (`<a class="btn-grey" role="button">` senza `data-id-amount`) — fail-safe
  invece di allowlist rigida. Corretto in `content.js` e nelle due copie
  inline in `background.js`.

### Novità
- **Promemoria login prima di avviare** — un modale bloccante ("🚀 Recluta il
  Team Rocket! ... hai ricordato di loggarti con l'account secondario?")
  compare ora prima di ▶ Avvia (popup principale), 📋 Aggiungi tutte (carte) e
  📦 Aggiungi al foglio (sealed), oltre che prima di riprendere una sessione
  interrotta. Va confermato cliccando "😈 Sì, Boss Giovanni!" prima che il
  flusso parta davvero — il controllo carrello richiede infatti di essere
  loggati su Cardmarket, altrimenti si ripresenta il bug sopra. La conferma
  vale solo per l'apertura corrente del popup/tab: si richiede di nuovo ogni
  volta che viene riaperto. Il "🧪 Prova" (dry run) non è gate-ato, visto che
  non apre tab reali.
- **Nuovo tema "Team Rocket"** — tema scuro nero/rosso aggiunto al selettore
  aspetto del popup principale, disponibile anche nelle pagine bulk
  carte/sealed (sincronizzato via `chrome.storage`).

### Modifiche
- Riordinato il selettore temi: **Dark Type** ora compare subito dopo
  **Grass Type** (prima era in fondo, dopo Wise Glasses).

---

## v2.3 e precedenti
Cronologia non tracciata in questo file — vedi i commenti `FIX:` inline nel
codice sorgente (content.js, background.js, popup.js, aggiungi_carta_popup.js,
aggiungi_sealed_popup.js), che documentano ogni correzione con il motivo del
bug originale.