// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
assicuraLoginSupabase();

// ── COSTANTI ──────────────────────────────────────────────────────────────────
// Elenco di eventuali campi testo da persistere automaticamente in storage
// (meccanismo generico, riusabile in futuro) — al momento nessuno, dato che
// webAppUrl/sheetId/sheetName sono stati rimossi con la migrazione a Supabase.
const CAMPI = [];
const LISTA_TEMI = ['purple', 'green', 'blue', 'contrast', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];

const DEFAULTS = {
  sliderDelayMinSec: 10,
  sliderDelayMaxSec: 20,
  sliderCfTimeout:   3,
  sliderSoglia:      0,
  sliderMaxNd:       5,
  sliderPausaOgni:   2,   // default: pausa ogni 50 carte
  soloVariazioni:    false,
  avvisoSonoro:      true,
  selectedTheme:     'purple',
};

// Limiti dei due slider Delay minimo/massimo (in secondi)
const DELAY_SEC_MIN = 1;
const DELAY_SEC_MAX = 60;

const PAUSA_OGNI_LABELS  = ['25', '50', '75', '100', 'Mai'];
const PAUSA_OGNI_VALUES  = [25, 50, 75, 100, Infinity];
const CF_LABELS     = ['1 min','2 min','3 min','4 min','5 min','6 min','7 min','8 min','9 min','10 min'];
const SOGLIA_LABELS = ['0,01 €','0,05 €','0,10 €','0,20 €','0,50 €','1,00 €','2,00 €'];
const SOGLIA_VALUES = [0.01, 0.05, 0.10, 0.20, 0.50, 1.00, 2.00];
// FIX: il singolo slider "Ritardo tra carte" (preset fissi tipo "5–10s")
// è stato sostituito da due slider indipendenti — minimo e massimo, in
// secondi — per lasciare scegliere un range personalizzato invece che uno
// tra 8 preset predefiniti. Questa tabella resta solo per MIGRARE il
// vecchio valore salvato (indice 0–7) di chi aggiorna l'estensione da una
// versione precedente — vedi caricamento dati salvati più sotto.
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];

// Rallentamento adattivo Cloudflare: prima si spostava l'indice dentro
// DELAY_RANGES verso un preset più lento; con un range continuo si aggiunge
// invece un margine fisso per gradino, fino a un tetto massimo di gradini.
const CF_ESCALATION_STEP_SEC = 3;
const CF_ESCALATION_MAX_LEVEL = 5;

// ── STATO GLOBALE ─────────────────────────────────────────────────────────────
let isRunning     = false;
let stopRequested = false;
let cUp = 0, cDown = 0, cSteady = 0, cErrori = 0;
let logEntries = [];
// FIX (bug "cliccare su saliti/scesi non fa vedere niente"): il pannello
// #trendDetailPanel esisteva già nell'HTML (con pillole "🔺 saliti" /
// "🔻 scesi" cliccabili e title "Clicca per vedere l'elenco...") ma non era
// mai collegato a nulla — nessun listener di click, e soprattutto nessuna
// traccia di QUALI carte fossero salite/scese (si contava solo cUp/cDown,
// mai il dettaglio riga/nome/variazione). Questi due array raccolgono
// quel dettaglio durante la sessione, usati da mostraTrendDetail() più sotto.
let trendSalitiEntries = [];
let trendScesiEntries  = [];

// ── TEMI ──────────────────────────────────────────────────────────────────────
function applicaTema(nomeTema) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nomeTema !== 'purple') document.body.classList.add(`theme-${nomeTema}`);
  // Marcatore generico (indipendente da QUALE tema è attivo) — usato dalla
  // "rete di sicurezza" nel CSS per correggere gli elementi con colori
  // fissi dimenticati, invece di dover scrivere una rete diversa per
  // ciascuno dei 15 temi.
  document.body.classList.toggle('tema-attivo', nomeTema !== 'purple');
  LISTA_TEMI.forEach(t => {
    const btn = document.getElementById(`theme-${t}`);
    if (btn) btn.classList.toggle('active', t === nomeTema);
  });
}

LISTA_TEMI.forEach(tema => {
  const btn = document.getElementById(`theme-${tema}`);
  if (btn) {
    btn.addEventListener('click', () => {
      // FIX: un cambio tema "a caldo" (senza ricaricare) lasciava alcuni
      // elementi con lo stile vecchio — un refresh vero e proprio
      // garantisce che tutto si ridisegni da capo, coerente col tema
      // scelto. Salva prima di ricaricare, per non perdere la scelta.
      chrome.storage.local.set({ selectedTheme: tema }, () => location.reload());
    });
  }
});

// ── GEAR BUTTON ───────────────────────────────────────────────────────────────
const gearBtn       = document.getElementById('gearBtn');
const settingsPanel = document.getElementById('settingsPanel');

function toggleSettingsPanel() {
  const aperto = settingsPanel.classList.toggle('visible');
  gearBtn.classList.toggle('open', aperto);
  gearBtn.setAttribute('aria-expanded', String(aperto));
}

gearBtn.addEventListener('click', toggleSettingsPanel);

// ── ⚙ INOLTRATO DALL'HUB (app.html) ──────────────────────────────────────────
// Quando questa pagina è dentro l'hub (vedi tab_detect.js/embedded-in-hub),
// il proprio header — e quindi questo stesso gearBtn — è nascosto: l'hub
// mostra un'unica icona ⚙ in cima e, al click, la inoltra qui via postMessage
// così il pannello che si apre resta sempre quello giusto per questa pagina.
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CARDSYNC_TOGGLE_SETTINGS') toggleSettingsPanel();
  // FIX (togliere il pulsante manuale "Aggiorna elenco"): quando una
  // location nuova viene registrata da un'altra sezione (Carte/Sealed/
  // Wishlist, es. da un inserimento arrivato dal sito), l'hub (app.js)
  // avvisa TUTTE le sezioni con campo Location — questa pagina inclusa —
  // così la tendina del filtro qui sotto si aggiorna da sola, senza che
  // nessuno debba mai venire ad aprire l'estensione e cliccare un bottone.
  if (e.data && e.data.type === 'CARDSYNC_REFRESH_LOCATION') popolaTendinaLocation();
});

// ── CONNESSIONE COLLASSABILE ──────────────────────────────────────────────────
const connToggle = document.getElementById('connToggle');
const connBody   = document.getElementById('connBody');

connToggle.addEventListener('click', () => {
  const aperto = connBody.classList.toggle('visible');
  connToggle.classList.toggle('open', aperto);
  connToggle.setAttribute('aria-expanded', String(aperto));
});

// ── LEGENDA COLONNA VARIAZIONE (collassabile) ────────────────────────────────
// Stesso pattern di connToggle/connBody sopra. Aperta di default quando la
// pagina occupa una tab intera (comportamento identico a prima); chiusa di
// default quando è dentro l'hub (vedi tab_detect.js/embedded-in-hub) — lì lo
// spazio della colonna è più prezioso e questo contenuto è puramente di
// consultazione, non serve sempre in vista.
const legendaToggle = document.getElementById('legendaToggle');
const legendaBody   = document.getElementById('legendaBody');

legendaToggle.addEventListener('click', () => {
  const aperto = legendaBody.classList.toggle('visible');
  legendaToggle.classList.toggle('open', aperto);
  legendaToggle.setAttribute('aria-expanded', String(aperto));
});

if (!document.body.classList.contains('embedded-in-hub')) {
  legendaBody.classList.add('visible');
  legendaToggle.classList.add('open');
  legendaToggle.setAttribute('aria-expanded', 'true');
}

// ── SLIDER (generici a valore singolo) ──────────────────────────────────────
// Tabella unica: aggiunge listener, espone la fn di aggiornamento label,
// e viene riusata da reset e caricamento storage — nessuna ripetizione.
// sliderDelayMin/sliderDelayMax NON sono qui: hanno una logica dedicata
// subito sotto, perché devono restare vincolati tra loro (min ≤ max).
const SLIDERS = [
  { id: 'sliderCfTimeout', labelId: 'valCfTimeout', fn: v => CF_LABELS[v - 1]          ?? CF_LABELS[2]        }, // slider 1–10, array 0-indexed
  { id: 'sliderSoglia',    labelId: 'valSoglia',    fn: v => SOGLIA_LABELS[v]           ?? SOGLIA_LABELS[0]    },
  { id: 'sliderMaxNd',     labelId: 'valMaxNd',     fn: v => String(v)                                         },
  { id: 'sliderPausaOgni', labelId: 'valPausaOgni', fn: v => PAUSA_OGNI_LABELS[v]      ?? PAUSA_OGNI_LABELS[1] },
];

function aggiornaLabelSlider({ labelId, fn }, val) {
  document.getElementById(labelId).textContent = fn(val);
}

SLIDERS.forEach(slider => {
  document.getElementById(slider.id).addEventListener('input', (e) => {
    const v = parseInt(e.target.value);
    aggiornaLabelSlider(slider, v);
    chrome.storage.local.set({ [slider.id]: v });
  });
});

// Scorciatoie mantenute per compatibilità con le chiamate esistenti nel resto del file
function aggiornaLabelCfTimeout(val) { aggiornaLabelSlider(SLIDERS[0], val); }
function aggiornaLabelSoglia(val)    { aggiornaLabelSlider(SLIDERS[1], val); }
function aggiornaLabelMaxNd(val)     { aggiornaLabelSlider(SLIDERS[2], val); }
function aggiornaLabelPausaOgni(val) { aggiornaLabelSlider(SLIDERS[3], val); }

// ── SLIDER DELAY MIN/MAX (vincolati tra loro) ────────────────────────────────
// Due slider indipendenti al posto dell'unico preset "5–10s" ecc.: min ≤ max
// sempre garantito — se l'utente trascina il minimo sopra il massimo (o
// viceversa), l'altro slider viene spinto a seguire invece di lasciare uno
// stato incoerente (min > max) che romperebbe il calcolo del ritardo.
function aggiornaLabelDelayMinMax() {
  const vMin = document.getElementById('sliderDelayMin').value;
  const vMax = document.getElementById('sliderDelayMax').value;
  document.getElementById('valDelayMin').textContent = vMin + 's';
  document.getElementById('valDelayMax').textContent = vMax + 's';
}

document.getElementById('sliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('sliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelDelayMinMax();
  chrome.storage.local.set({
    sliderDelayMinSec: vMin,
    sliderDelayMaxSec: parseInt(sliderMax.value),
  });
});

document.getElementById('sliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('sliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelDelayMinMax();
  chrome.storage.local.set({
    sliderDelayMinSec: parseInt(sliderMin.value),
    sliderDelayMaxSec: vMax,
  });
});



// ── RESET PREDEFINITI ─────────────────────────────────────────────────────────
document.getElementById('btnResetDefaults').addEventListener('click', () => {
  document.getElementById('sliderDelayMin').value   = DEFAULTS.sliderDelayMinSec;
  document.getElementById('sliderDelayMax').value   = DEFAULTS.sliderDelayMaxSec;
  document.getElementById('sliderCfTimeout').value  = DEFAULTS.sliderCfTimeout;
  document.getElementById('sliderSoglia').value     = DEFAULTS.sliderSoglia;
  document.getElementById('sliderMaxNd').value      = DEFAULTS.sliderMaxNd;
  document.getElementById('sliderPausaOgni').value  = DEFAULTS.sliderPausaOgni;
  document.getElementById('soloVariazioni').checked = DEFAULTS.soloVariazioni;
  document.getElementById('avvisoSonoro').checked   = DEFAULTS.avvisoSonoro;
  aggiornaLabelDelayMinMax();
  aggiornaLabelCfTimeout(DEFAULTS.sliderCfTimeout);
  aggiornaLabelSoglia(DEFAULTS.sliderSoglia);
  aggiornaLabelMaxNd(DEFAULTS.sliderMaxNd);
  aggiornaLabelPausaOgni(DEFAULTS.sliderPausaOgni);
  applicaTema(DEFAULTS.selectedTheme);
  chrome.storage.local.set({
    sliderDelayMinSec: DEFAULTS.sliderDelayMinSec,
    sliderDelayMaxSec: DEFAULTS.sliderDelayMaxSec,
    sliderCfTimeout: DEFAULTS.sliderCfTimeout,
    sliderSoglia:    DEFAULTS.sliderSoglia,
    sliderMaxNd:     DEFAULTS.sliderMaxNd,
    sliderPausaOgni: DEFAULTS.sliderPausaOgni,
    soloVariazioni:  DEFAULTS.soloVariazioni,
    avvisoSonoro:    DEFAULTS.avvisoSonoro,
    selectedTheme:   DEFAULTS.selectedTheme,
  });
  setStatus('✅ Impostazioni ripristinate ai valori predefiniti.', 'ok');
});


// ── TOGGLE PERSISTENTI ────────────────────────────────────────────────────────
document.getElementById('soloVariazioni').addEventListener('change', (e) => {
  chrome.storage.local.set({ soloVariazioni: e.target.checked });
});
document.getElementById('soloVecchie').addEventListener('change', (e) => {
  chrome.storage.local.set({ soloVecchie: e.target.checked });
  document.getElementById('wrapGiorniMinimi').style.display = e.target.checked ? '' : 'none';
});
document.getElementById('giorniMinimi').addEventListener('input', (e) => {
  chrome.storage.local.set({ giorniMinimi: e.target.value });
});
document.getElementById('aiutaGruppo').addEventListener('change', (e) => {
  chrome.storage.local.set({ aiutaGruppo: e.target.checked });
});
document.getElementById('temaScuroEstensione').addEventListener('change', (e) => {
  // Il tema scuro ora è un modificatore indipendente (classe "modo-scuro"),
  // non più un tema a sé — si combina con qualunque tema colore attivo
  // invece di sostituirlo, quindi non serve più "ricordarsi" il tema di
  // prima per poterci tornare. Stesso refresh forzato degli altri cambi
  // tema, per lo stesso motivo (applicazione "a caldo" incompleta).
  chrome.storage.local.set({ cardsyncDarkMode: e.target.checked }, () => location.reload());
});
document.getElementById('mantieniAccessoEstensione').addEventListener('change', (e) => {
  chrome.storage.local.set({ cardsyncMantieniAccessoEstensione: e.target.checked });
});
document.getElementById('avvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

// ── CAMPI TESTO PERSISTENTI ───────────────────────────────────────────────────
CAMPI.forEach(id => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('input', () => chrome.storage.local.set({ [id]: el.value }));
});

// ── CARICAMENTO DATI SALVATI ──────────────────────────────────────────────────
chrome.storage.local.get(
  [...CAMPI, 'selectedTheme', 'soloVariazioni', 'soloVecchie', 'giorniMinimi', 'aiutaGruppo', 'avvisoSonoro',
   'sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec',
   'sliderCfTimeout', 'sliderSoglia', 'sliderMaxNd', 'sliderPausaOgni', 'ultimoUtilizzo',
   'filtroLocationSelezionata', 'cardsyncMantieniAccessoEstensione', 'cardsyncDarkMode'],
  (saved) => {
    CAMPI.forEach(id => {
      const el = document.getElementById(id);
      if (el && saved[id] !== undefined) el.value = saved[id];
    });

    document.getElementById('soloVariazioni').checked = saved.soloVariazioni ?? DEFAULTS.soloVariazioni;
    document.getElementById('soloVecchie').checked    = saved.soloVecchie    ?? false;
    document.getElementById('giorniMinimi').value     = saved.giorniMinimi  ?? 3;
    document.getElementById('wrapGiorniMinimi').style.display = document.getElementById('soloVecchie').checked ? '' : 'none';
    // FIX (Fase 8 — consenso esplicito): questo toggle parte SEMPRE spento
    // di default (?? false, mai ?? true) — nessuno deve ritrovarsi ad
    // "aiutare il gruppo" senza averlo attivato lui stesso almeno una volta.
    document.getElementById('aiutaGruppo').checked    = saved.aiutaGruppo   ?? false;
    document.getElementById('avvisoSonoro').checked   = saved.avvisoSonoro   ?? DEFAULTS.avvisoSonoro;
    document.getElementById('temaScuroEstensione').checked = saved.cardsyncDarkMode === true;
    document.body.classList.toggle('modo-scuro', saved.cardsyncDarkMode === true);
    document.getElementById('mantieniAccessoEstensione').checked = saved.cardsyncMantieniAccessoEstensione ?? true;

    // FIX: migrazione dal vecchio slider unico a preset (indice 0–7,
    // salvato come "sliderDelay") ai due nuovi slider min/max in secondi.
    // Se l'utente ha già i nuovi valori salvati li usiamo direttamente;
    // altrimenti, se esiste ancora il vecchio indice, lo convertiamo una
    // sola volta nel range equivalente così chi aggiorna l'estensione non
    // si ritrova il ritardo azzerato o diverso da quello che aveva scelto.
    let vDelayMin = saved.sliderDelayMinSec;
    let vDelayMax = saved.sliderDelayMaxSec;
    if (vDelayMin === undefined || vDelayMax === undefined) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        [vDelayMin, vDelayMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      } else {
        vDelayMin = DEFAULTS.sliderDelayMinSec;
        vDelayMax = DEFAULTS.sliderDelayMaxSec;
      }
      chrome.storage.local.set({ sliderDelayMinSec: vDelayMin, sliderDelayMaxSec: vDelayMax });
    }

    const vCf    = saved.sliderCfTimeout ?? DEFAULTS.sliderCfTimeout;
    const vSogl  = saved.sliderSoglia    ?? DEFAULTS.sliderSoglia;
    const vMaxNd     = saved.sliderMaxNd     ?? DEFAULTS.sliderMaxNd;
    const vPausaOgni = saved.sliderPausaOgni ?? DEFAULTS.sliderPausaOgni;

    document.getElementById('sliderDelayMin').value  = vDelayMin;
    document.getElementById('sliderDelayMax').value  = vDelayMax;
    document.getElementById('sliderCfTimeout').value = vCf;
    document.getElementById('sliderSoglia').value    = vSogl;
    document.getElementById('sliderMaxNd').value      = vMaxNd;
    document.getElementById('sliderPausaOgni').value  = vPausaOgni;
    aggiornaLabelDelayMinMax();
    aggiornaLabelCfTimeout(vCf);
    aggiornaLabelSoglia(vSogl);
    aggiornaLabelMaxNd(vMaxNd);
    aggiornaLabelPausaOgni(vPausaOgni);

    applicaTema(saved.selectedTheme || DEFAULTS.selectedTheme);

    const elUU = document.getElementById('ultimoUtilizzo');
    if (elUU) {
      elUU.textContent = saved.ultimoUtilizzo
        ? '🕐 Ultimo utilizzo: ' + formattaDataOra(saved.ultimoUtilizzo)
        : '🕐 Ultimo utilizzo: mai';
    }

    // ── FILTRO LOCATION ──────────────────────────────────────────────────
    // Popola subito la tendina con i valori già presenti nel foglio (se la
    // connessione è già configurata) e ripristina l'ultima location scelta.
    popolaTendinaLocation().then(() => {
      const selectLoc = document.getElementById('filtroLocation');
      if (selectLoc && saved.filtroLocationSelezionata) {
        selectLoc.value = saved.filtroLocationSelezionata;
      }
      // FASE 2 (ordini dal sito): a questo punto tutti i campi (location
      // inclusa) hanno il valore giusto — è il momento sicuro per un
      // eventuale avvio automatico richiesto da background.js.
      // Fase 1.2 (2026-09-12): l'autorun sealed è indipendente da quello
      // carte (chiave di storage separata, vedi _avviaAutorunSealedSeRichiesto)
      // — incatenato con .then(), non in parallelo: _avviaAutorunSeRichiesto
      // aspetta il completamento dell'INTERA sessione carte (se c'era un
      // ordine pendente) prima di risolversi, quindi l'autorun sealed parte
      // solo a carte finite, mai in sovrapposizione sulla stessa tab/sessione.
      // Se invece non c'era nessun ordine carte pendente, questa catena è
      // istantanea e l'autorun sealed parte subito.
      _avviaAutorunSeRichiesto().then(() => _avviaAutorunSealedSeRichiesto()).then(() => _avviaAutorunWishlistSeRichiesto()).then(async () => {
        // FIX (consenso esplicito): l'unione automatica e il lavoro in
        // inattività NON devono partire per chi non ha attivato "Aiuta
        // anche il gruppo" — un dispositivo con poca RAM/risorse non deve
        // ritrovarsi ad aiutare nessuno senza averlo scelto. Gli ordini
        // specifici per QUESTO dispositivo (_avviaAutorunSeRichiesto,
        // gestito sopra) restano invece sempre validi: è comunque una
        // richiesta esplicita, non un'iniziativa autonoma.
        const { aiutaGruppo } = await chrome.storage.local.get('aiutaGruppo');
        if (!aiutaGruppo) return;

        // Se questo dispositivo non aveva un proprio ordine specifico da
        // eseguire, controlla comunque se qualcun altro del gruppo ha già
        // un controllo prezzi in corso in questo momento — in tal caso si
        // unisce da sola, contribuendo al lavoro condiviso (stessi lotti
        // piccoli, si dividono automaticamente senza sovrapporsi).
        if (!isRunning) {
          _unisciteControlloPrezziInCorsoSeCe().then(() => {
            // Ancora nessun lavoro? Prova ad avviarsi da sola per
            // sfruttare il tempo morto (vedi funzione più sotto).
            if (!isRunning) _avviaControlloPrezziSeInattivo();
          });
        }
      });
    });
  }
);

// Se un controllo prezzi è già "in_corso" (avviato da qualcun altro nel
// gruppo, tramite sito o manualmente), questo dispositivo si unisce da
// solo appena apre l'estensione — non serve premere nulla. Un ordine è
// considerato ancora attivo solo se preso in carico negli ultimi 15
// minuti (oltre, si presume abbandonato/bloccato: non ci si unisce a
// qualcosa che probabilmente non sta più procedendo davvero).
async function _unisciteControlloPrezziInCorsoSeCe() {
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    if (!sessionData?.session?.user?.id) return; // non loggato, niente da fare

    // v5.37: anche gli ordini wishlist (ora lavorati da tutto il gruppo) e
    // ordini in corso da meno di 6 ore (B7, anticipato dalla Fase 4): prima
    // 15 minuti dall'INIZIO dell'ordine, quindi a un controllo lungo nessuno
    // si univa più. Unirsi tardi non costa nulla: se il lavoro è finito, il
    // database non dà più righe da controllare.
    const sogliaIso = new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
    const { data: inCorso } = await supabaseClient
      .from('ordini')
      .select('id, tipo, parametri, creato_da')
      .in('tipo', ['controlla_prezzi', 'controlla_prezzi_wishlist'])
      .eq('stato', 'in_corso')
      .gt('preso_in_carico_il', sogliaIso)
      .order('preso_in_carico_il', { ascending: false })
      .limit(1);

    if (!inCorso || inCorso.length === 0) return; // nessuna sessione attiva da nessuna parte
    if (isRunning) return; // questo dispositivo ha già iniziato nel frattempo
    if (await _codaCardmarketOccupataQui()) return; // v5.29: la coda di questo PC ha la precedenza

    // v5.18 (punto 25): giro automatico — senza login Cardmarket confermato
    // si salta in silenzio (vedi _loginCardmarketAutomaticoOk più sotto).
    if (!(await _loginCardmarketAutomaticoOk())) return;
    if (isRunning) return; // partita un'altra sessione durante la verifica

    const ordine = inCorso[0];
    const locations = ordine.parametri?.locations;
    const aiutaGruppoOrdine = ordine.parametri?.aiutaGruppo;

    setStatus(ordine.tipo === 'controlla_prezzi_wishlist'
      ? '🤝 Controllo prezzi wishlist in corso nel gruppo — mi unisco per aiutare...'
      : '🤝 Controllo prezzi già in corso nel gruppo — mi unisco per aiutare...', 'info');
    const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordine.id); // v5.22
    try {
      if (ordine.tipo === 'controlla_prezzi_wishlist') {
        await eseguiSessione(false, { dominio: 'wishlist', ordineId: ordine.id, aiutaGruppo: true });
        return;
      }
      await eseguiSessione(false, {
        filtroLocation: Array.isArray(locations) ? locations : [],
        ...(aiutaGruppoOrdine !== undefined ? { aiutaGruppo: aiutaGruppoOrdine } : {}),
        ...(ordine.creato_da ? { ownerIdRichiesto: ordine.creato_da } : {}),
        ordineId: ordine.id, // v5.20 (punto 26): location lette dal database, vedi eseguiSessione
      });
    } finally {
      if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
    }
  } catch (e) {
    console.error('[unisciti controllo prezzi] errore:', e.message);
  }
}

// ── CONTROLLO PREZZI AUTOMATICO IN INATTIVITÀ ────────────────────────────────
// Se questo dispositivo non ha nessun altro lavoro da fare (coda_carte
// vuota — niente carte/sealed/wishlist in attesa di essere aggiunte, per
// nessuno del gruppo) e nessuno ha già un controllo prezzi in corso, ne
// avvia uno da solo per AIUTARE TUTTI (non solo le proprie carte) — tanto
// vale sfruttare il tempo morto. Se nel frattempo arriva lavoro "vero"
// (qualcuno mette in coda una carta da cercare), si mette in pausa da solo
// per lasciargli la priorità — vedi _sorveglianzaPausaControlloPrezziAuto
// più sotto.
//
// FIX v5.17 (giro infinito su Cardmarket): prima questo controllo prendeva
// TUTTE le carte del gruppo, senza il filtro "solo più vecchie" — finito un
// giro completo (oltre mille carte) il timer da 60s ne faceva ripartire
// subito un altro, interrogando Cardmarket senza sosta. Ora controlla solo le
// carte non controllate da almeno GIORNI_MINIMI_INATTIVITA giorni (scelta di
// Claudio, 2026-10-14: 7) e, se non ce n'è nessuna, non parte affatto e non
// mostra nulla.
const GIORNI_MINIMI_INATTIVITA = 7;
let _sessioneAutoInattivita = false;

// ── SEGNALE "OCCUPATO" PER IL SERVICE WORKER (v5.17) ─────────────────────────
// FIX (ordini rimasti "in corso" per sempre): quando arriva un ordine di
// controllo prezzi dal sito, background.js ricarica la pagina dell'app per
// avviarlo — se qui stava già girando un controllo prezzi, il ricaricamento
// lo uccideva a metà e il suo ordine restava "in corso" per sempre. Finché
// una sessione gira, questa pagina tiene in chrome.storage.local un segnale
// con scadenza (rinnovato ogni 30s, scade da solo dopo 3 minuti se la pagina
// muore): background.js non prende nuovi ordini di prezzi finché è attivo.
// Chiave separata per pagina (la wishlist ha la sua), così la fine di una
// sessione qui non cancella il segnale di un'altra pagina ancora al lavoro.
// ── UN SOLO LAVORO SU CARDMARKET ALLA VOLTA PER PC (v5.29) ───────────────────
// Mentre su questo PC la coda "Aggiungi carte" lavora (pagina dell'app o
// worker in background, segnali con scadenza scritti da
// aggiungi_carta_popup.js e background.js), un controllo prezzi avviato qui
// aspetta che finisca, e i giri automatici ("mi unisco", inattività) non
// partono. Chi arriva prima finisce (vedi _precedenzaCodaCardmarket in
// background.js). Duplicato apposta nelle pagine (regola d'oro #1).
async function _codaCardmarketOccupataQui() {
  try {
    const v = await chrome.storage.local.get(['sessioneCodaAttiva_carte', 'workerAutonomoAttivo']);
    const vivo = (x) => !!x && typeof x.scadenza === 'number' && x.scadenza > Date.now();
    return vivo(v.sessioneCodaAttiva_carte) || vivo(v.workerAutonomoAttivo);
  } catch (_) {
    return false;
  }
}

async function _attendiCodaCardmarketLibera() {
  let avvisato = false;
  while (!stopRequested && (await _codaCardmarketOccupataQui())) {
    if (!avvisato) {
      setStatus('⏳ In attesa: su questo PC la coda "Aggiungi carte" sta lavorando — il controllo prezzi parte appena finisce.', 'info');
      avvisato = true;
    }
    await new Promise((r) => setTimeout(r, 5000));
  }
}

const CHIAVE_SEGNALE_OCCUPATO = 'sessionePrezziAttiva_prezzi';
let _timerSegnaleOccupato = null;

function _segnaleOccupatoAvvia() {
  const scrivi = () => chrome.storage.local.set({ [CHIAVE_SEGNALE_OCCUPATO]: { scadenza: Date.now() + 3 * 60 * 1000 } });
  scrivi();
  // v5.29: la sessione è partita, il segnale "ordine in partenza" scritto da
  // background.js non serve più (questo lo sostituisce).
  chrome.storage.local.remove('prezziInPartenza');
  if (_timerSegnaleOccupato) clearInterval(_timerSegnaleOccupato);
  _timerSegnaleOccupato = setInterval(scrivi, 30000);
}

function _segnaleOccupatoFerma() {
  if (_timerSegnaleOccupato) { clearInterval(_timerSegnaleOccupato); _timerSegnaleOccupato = null; }
  chrome.storage.local.remove(CHIAVE_SEGNALE_OCCUPATO);
}

// Rimette un ordine 'in_corso' in attesa (solo se è ancora 'in_corso'):
// usato quando questa pagina riceve un ordine ma è già occupata, invece di
// lasciarlo "in corso" per sempre senza che nessuno lo esegua.
async function _rimettiOrdineInAttesa(ordineId) {
  try {
    const { error } = await supabaseClient.from('ordini')
      .update({ stato: 'pending', preso_in_carico_da: null, preso_in_carico_il: null })
      .eq('id', ordineId)
      .eq('stato', 'in_corso');
    if (error) console.error('[ordini] impossibile rimettere in attesa:', error.message);
  } catch (e) {
    console.error('[ordini] impossibile rimettere in attesa:', e.message);
  }
}

// ── ORDINE ANNULLATO DAL SITO (v5.22) ────────────────────────────────────────
// Dal sito chi ha creato un ordine può annullarlo (sql/115). Prima la sessione
// non lo sapeva: un controllo carte con location private si fermava solo al
// lotto successivo (il database non dava più carte), sealed e ordini vecchi
// andavano avanti fino alla fine. Ora, finché la sessione di un ordine gira,
// lo stato dell'ordine si rilegge ogni 5 s: se è 'annullato' la sessione si
// ferma come col bottone "Ferma" (finisce la carta attuale, rilascia le
// prenotazioni, chiude la scheda). Restituisce la funzione che spegne la
// sorveglianza e dice se l'ordine è stato annullato.
let _ordineAnnullatoDalSito = false;

function _sorvegliaAnnullamentoOrdine(ordineId) {
  _ordineAnnullatoDalSito = false;
  if (!ordineId) return () => false;
  const timer = setInterval(async () => {
    if (!isRunning || stopRequested) return;
    try {
      const { data } = await supabaseClient.from('ordini').select('stato').eq('id', ordineId).maybeSingle();
      if (data && data.stato === 'annullato') {
        _ordineAnnullatoDalSito = true;
        stopRequested = true;
        setStatus('🛑 Controllo annullato dal sito — finisco la carta attuale e mi fermo...', 'info');
      }
    } catch (_) { /* rete ballerina: si riprova al giro dopo */ }
  }, 5000);
  return () => { clearInterval(timer); return _ordineAnnullatoDalSito; };
}

function _segnalaAnnullamentoOrdine() {
  setStatus('🛑 Controllo annullato dal sito.', 'ok');
  aggiungiLog(null, 'Controllo annullato dal sito.', '');
}

// v5.22: ordini di prezzi in attesa (di chiunque). Il controllo in inattività
// non parte e, se sta girando, si mette in pausa: finché gira, questo PC è
// "occupato" e background.js non prende ordini di prezzi — l'ordine chiesto
// dal sito restava in attesa dietro al giro automatico, e annullarlo non
// fermava nulla (il giro automatico non è legato a nessun ordine).
// v5.23: solo ordini creati nelle ultime 2 ore. Gli ordini in attesa non
// scadono mai: uno che nessun PC può prendere (nessuno loggato su
// Cardmarket, PC non aggiornati) fermava per sempre il controllo in
// inattività su TUTTI i PC del gruppo, finché chi l'aveva creato non lo
// annullava dal sito.
const _ORE_ORDINI_PREZZI_IN_ATTESA = 2;
async function _contaOrdiniPrezziInAttesa() {
  const soglia = new Date(Date.now() - _ORE_ORDINI_PREZZI_IN_ATTESA * 60 * 60 * 1000).toISOString();
  const { count } = await supabaseClient
    .from('ordini')
    .select('id', { count: 'exact', head: true })
    .eq('stato', 'pending')
    .in('tipo', ['controlla_prezzi', 'controlla_prezzi_sealed', 'controlla_prezzi_wishlist'])
    .gt('creato_il', soglia);
  return count || 0;
}

async function _contaCodaCartePendenti() {
  const { count } = await supabaseClient
    .from('coda_carte')
    .select('id', { count: 'exact', head: true })
    .eq('stato', 'pending');
  return count || 0;
}

// ── LOGIN CARDMARKET PER I GIRI AUTOMATICI (v5.18, punto 25) ─────────────────
// Controllo in inattività e "mi unisco al controllo in corso" partono senza
// nessuno davanti al PC: senza login Cardmarket ogni carta risulterebbe
// "Esaurita" e verrebbe comunque segnata come controllata (ferma per giorni),
// con "Prezzo non trovato..." scritto nella nota. Qui NON si usa
// _richiediConfermaLogin (porta la scheda in primo piano e scrive l'errore a
// schermo): background.js verifica in una scheda in background chiusa
// sempre, e ricorda l'esito (non loggato → niente nuovi tentativi per 30
// minuti). Se non è confermato, il giro si salta in silenzio.
function _loginCardmarketAutomaticoOk() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_AUTOMATICA' }, (r) => {
        if (chrome.runtime.lastError) { resolve(false); return; }
        resolve(!!r && r.loggato === true);
      });
    } catch (_) {
      resolve(false);
    }
  });
}

// v5.18: un solo avvio alla volta — la verifica del login può durare fino a
// ~45s e il timer da 60s non deve far partire due sessioni in parallelo.
// Sta FUORI dal try: un giro saltato non deve toccare _sessioneAutoInattivita
// della sessione ancora in corso (prima il blocco finally la azzerava a ogni
// giro del timer, spegnendo la sorveglianza "arrivato altro lavoro").
let _avvioInattivitaInCorso = false;

async function _avviaControlloPrezziSeInattivo() {
  if (_avvioInattivitaInCorso) return;
  _avvioInattivitaInCorso = true;
  try {
    // FIX (consenso esplicito): controllo di sicurezza anche qui, non solo
    // al primo avvio — questa funzione viene richiamata anche dal timer
    // periodico più sotto, che potrebbe scattare dopo che l'utente ha
    // acceso/spento "Aiuta anche il gruppo" nel frattempo.
    const { aiutaGruppo } = await chrome.storage.local.get('aiutaGruppo');
    if (!aiutaGruppo) return;
    if (isRunning) return; // già in corso qualcosa (manuale, ordine, o unione automatica)
    if (await _codaCardmarketOccupataQui()) return; // v5.29: un lavoro su Cardmarket alla volta
    const { data: sessionData } = await supabaseClient.auth.getSession();
    if (!sessionData?.session?.user?.id) return;

    if ((await _contaCodaCartePendenti()) > 0) return; // c'è altro lavoro, priorità a quello
    if ((await _contaOrdiniPrezziInAttesa()) > 0) return; // v5.22: prima gli ordini dal sito

    // Ricontrolla che non sia già partito nel frattempo un controllo prezzi
    // da qualcun altro (in tal caso ci si è già uniti sopra, in
    // _unisciteControlloPrezziInCorsoSeCe) — evita di avviarne un secondo
    // in parallelo inutilmente.
    const sogliaIso = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { data: giaInCorso } = await supabaseClient
      .from('ordini')
      .select('id')
      .eq('tipo', 'controlla_prezzi')
      .eq('stato', 'in_corso')
      .gt('preso_in_carico_il', sogliaIso)
      .limit(1);
    if (giaInCorso && giaInCorso.length > 0) return;

    // Solo un conteggio (nessuna prenotazione): se tutte le carte del gruppo
    // sono state controllate negli ultimi GIORNI_MINIMI_INATTIVITA giorni non
    // c'è niente da fare — si esce in silenzio, senza aprire tab né scrivere
    // messaggi di stato.
    const daControllare = await contaEleggibiliControlloPrezzi([], true, GIORNI_MINIMI_INATTIVITA, true, null);
    if (daControllare === 0) return;
    // v5.18 (punto 25): solo ora, quando c'è davvero qualcosa da controllare,
    // si verifica il login Cardmarket — se non è confermato si salta in
    // silenzio (vedi _loginCardmarketAutomaticoOk).
    if (!(await _loginCardmarketAutomaticoOk())) return;
    if (isRunning) return; // partita un'altra sessione durante le letture sopra

    setStatus(`💤 Nessun altro lavoro in coda — controllo i prezzi del gruppo non aggiornati da ${GIORNI_MINIMI_INATTIVITA} giorni...`, 'info');
    _sessioneAutoInattivita = true;
    await eseguiSessione(false, {
      filtroLocation: [],
      aiutaGruppo: true,
      soloVecchie: true,
      giorniMinimi: GIORNI_MINIMI_INATTIVITA,
      silenziosoSeVuoto: true,
    });
  } catch (e) {
    console.error('[controllo prezzi automatico] errore:', e.message);
  } finally {
    _sessioneAutoInattivita = false;
    _avvioInattivitaInCorso = false;
  }
}

// Sorveglianza: mentre una sessione avviata per inattività è in corso,
// controlla periodicamente se è arrivato lavoro "vero" (coda_carte non più
// vuota) — in tal caso interrompe la sessione con garbo (stopRequested,
// stesso meccanismo del bottone "Ferma"), lasciando che l'altra tab/pagina
// (già in ascolto continuo su coda_carte) lo prenda in carico subito.
setInterval(async () => {
  if (!_sessioneAutoInattivita || !isRunning || stopRequested) return;
  try {
    if ((await _contaCodaCartePendenti()) > 0) {
      console.log('[controllo prezzi automatico] arrivato altro lavoro — mi metto in pausa.');
      stopRequested = true;
    } else if ((await _contaOrdiniPrezziInAttesa()) > 0) {
      // v5.22: un ordine di prezzi dal sito ha la precedenza sul giro automatico.
      console.log('[controllo prezzi automatico] ordine di prezzi in attesa — mi metto in pausa per lasciarlo partire.');
      stopRequested = true;
    }
  } catch (_) { /* silenzioso: un errore qui non deve interrompere nulla */ }
}, 20000);

// Controlla periodicamente (non solo all'avvio) se questo dispositivo è
// diventato inattivo nel frattempo — es. ha appena finito la sua coda
// personale e potrebbe aiutare col controllo prezzi.
setInterval(_avviaControlloPrezziSeInattivo, 60000);

// ── ORDINI DAL SITO (autorun) ────────────────────────────────────────────────
// background.js, quando prende in carico un ordine 'controlla_prezzi', salva
// {id, tipo, parametri} in chrome.storage.local sotto 'ordinePendenteAutorun'
// e apre questa pagina (dentro l'iframe di app.html#prezzi). Qui controlliamo
// quel flag e, se presente, avviamo la stessa identica sessione che partirebbe
// cliccando manualmente "▶ Avvia" — con i parametri di default/salvati già
// popolati nei campi sopra, TRANNE la location: se l'ordine porta un elenco
// di location (checkbox spuntate su Pages, parametri.locations), quello
// sostituisce la tendina manuale — poi scriviamo l'esito sulla riga dell'ordine.
async function _avviaAutorunSeRichiesto() {
  const { ordinePendenteAutorun } = await chrome.storage.local.get('ordinePendenteAutorun');
  if (!ordinePendenteAutorun || ordinePendenteAutorun.tipo !== 'controlla_prezzi') return;

  // Consuma subito il flag — PRIMA di avviare — così un ricaricamento di
  // questa pagina (es. l'utente cambia sezione e torna indietro) non fa
  // ripartire la sessione una seconda volta sullo stesso ordine.
  await chrome.storage.local.remove('ordinePendenteAutorun');
  if (isRunning) {
    // Una sessione è già in corso, non sovrapporre — v5.17: l'ordine torna in
    // attesa (prima restava "in corso" per sempre).
    await _rimettiOrdineInAttesa(ordinePendenteAutorun.id);
    return;
  }

  const ordineId = ordinePendenteAutorun.id;
  const locations = ordinePendenteAutorun.parametri?.locations;
  const aiutaGruppoOrdine = ordinePendenteAutorun.parametri?.aiutaGruppo;
  const creatoDa = ordinePendenteAutorun.creatoDa;
  await assicuraLoginSupabase(); // per sicurezza, anche se qui la sessione dovrebbe già esserci

  setStatus('🤖 Ordine ricevuto dal sito — avvio controllo prezzi...', 'info');
  // FIX (controllo prezzi non trovava nulla nonostante le carte esistessero):
  // quando l'ordine porta "nessuna location selezionata" (locations: []),
  // il filtro veniva OMESSO dall'oggetto overrides invece che passato
  // esplicitamente vuoto — questo faceva ricadere sul valore del campo
  // location MANUALE dentro l'estensione (pensato per l'uso diretto, non
  // per gli ordini dal sito), che poteva contenere un valore vecchio non
  // pertinente all'account giusto. Ora filtroLocation viene sempre incluso
  // esplicitamente per gli ordini dal sito, mai lasciato "indovinare".
  const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordineId); // v5.22
  try {
    await eseguiSessione(false, {
      filtroLocation: Array.isArray(locations) ? locations : [],
      ...(aiutaGruppoOrdine !== undefined ? { aiutaGruppo: aiutaGruppoOrdine } : {}),
      ...(creatoDa ? { ownerIdRichiesto: creatoDa } : {}),
      // v5.20 (punto 26): con l'id dell'ordine il database usa le location
      // salvate nella tabella privata (ordini creati dal sito nuovo: in
      // parametri non ci sono più). Ordini del sito vecchio: valgono ancora le
      // location qui sopra.
      ordineId,
    });
  } finally {
    if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
  }
  // v5.22: annullato dal sito — l'esito resta 'annullato' (il trigger di
  // sql/115 lo terrebbe fermo comunque), non si scrive nulla.
  if (_ordineAnnullatoDalSito) return;

  // eseguiSessione gestisce già i propri errori internamente (li mostra in
  // #status e non li rilancia) — leggiamo qui l'esito dalla classe CSS che
  // setStatus() applica, per capire se scrivere 'completato' o 'errore'.
  const statusEl  = document.getElementById('status');
  const fuErrore  = statusEl.className.includes('errore');

  try {
    if (fuErrore) {
      await supabaseClient.from('ordini').update({
        stato: 'errore',
        errore_msg: statusEl.textContent || 'Errore sconosciuto durante la sessione automatica.',
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'completato',
        risultato: { salite: cUp, scese: cDown, invariate: cSteady },
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    }
  } catch (e) {
    console.error('[ordini] impossibile scrivere l\'esito sull\'ordine:', e);
  }
}

// v5.37 (Fase 2): ordine 'controlla_prezzi_wishlist' — stessa sessione delle
// carte con dominio 'wishlist' (prima lo eseguiva la sezione Wishlist dell'app,
// che controllava la wishlist di chi eseguiva, non di chi l'aveva chiesto).
// background.js salva il flag 'ordinePendenteAutorunWishlist' e apre la
// sezione Prezzi; il proprietario della wishlist lo legge il database
// dall'ordine.
async function _avviaAutorunWishlistSeRichiesto() {
  const { ordinePendenteAutorunWishlist } = await chrome.storage.local.get('ordinePendenteAutorunWishlist');
  if (!ordinePendenteAutorunWishlist) return;
  await chrome.storage.local.remove('ordinePendenteAutorunWishlist');
  if (isRunning) {
    await _rimettiOrdineInAttesa(ordinePendenteAutorunWishlist.id);
    return;
  }
  const ordineId = ordinePendenteAutorunWishlist.id;
  await assicuraLoginSupabase();
  setStatus('🤖 Ordine ricevuto dal sito — avvio controllo prezzi wishlist...', 'info');
  const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordineId);
  try {
    await eseguiSessione(false, { dominio: 'wishlist', ordineId, aiutaGruppo: true });
  } finally {
    if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
  }
  if (_ordineAnnullatoDalSito) return;
  // Stessa lettura dell'esito di _avviaAutorunSeRichiesto (classe di #status):
  // si sistema per tutti gli ordini nella Fase 4 del piano (B13).
  const statusEl = document.getElementById('status');
  const fuErrore = statusEl.className.includes('errore');
  try {
    if (fuErrore) {
      await supabaseClient.from('ordini').update({
        stato: 'errore',
        errore_msg: statusEl.textContent || 'Errore sconosciuto durante la sessione automatica.',
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'completato',
        risultato: { salite: cUp, scese: cDown, invariate: cSteady },
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    }
  } catch (e) {
    console.error('[ordini] impossibile scrivere l\'esito sull\'ordine wishlist:', e);
  }
}

// ── STATUS ────────────────────────────────────────────────────────────────────
function setStatus(msg, tipo = '') {
  const el = document.getElementById('status');
  el.textContent = msg;
  // Ricostruisce className da zero per evitare classi residue
  el.className = msg ? (tipo ? `${tipo} visible` : 'visible') : '';
}

// ── PROGRESS BAR ──────────────────────────────────────────────────────────────
function setProgress(pct) {
  document.getElementById('progressBar').style.display = 'block';
  document.getElementById('progressFill').style.width  = Math.min(100, Math.max(0, pct)) + '%';
}

function nascondiProgress() {
  document.getElementById('progressBar').style.display = 'none';
  document.getElementById('progressFill').style.width  = '0%';
}

// ── LOG SESSIONE ──────────────────────────────────────────────────────────────
const logPanel   = document.getElementById('logPanel');
const logHeader  = document.getElementById('logHeader');
const logBody    = document.getElementById('logBody');
const logBadge   = document.getElementById('logBadge');
const logEmpty   = document.getElementById('logEmpty');

logHeader.addEventListener('click', () => {
  const aperto = logBody.classList.toggle('visible');
  logHeader.classList.toggle('open', aperto);
});

document.getElementById('logCopy').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const testo = logEntries.map(e => `${_etichettaRiga(e.riga)}\t${e.msg}`).join('\n');
  navigator.clipboard.writeText(testo).then(() => {
    const btn = document.getElementById('logCopy');
    btn.textContent = '✅';
    setTimeout(() => btn.textContent = '📋', 1500);
  });
});

document.getElementById('logCsv').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const righe = ['Riga,Messaggio,Tipo'];
  logEntries.forEach(e => {
    const riga = '"' + _etichettaRiga(e.riga).replace(/"/g, '""') + '"';
    const msg  = '"' + (e.msg  || '').replace(/"/g, '""') + '"';
    const tipo = '"' + (e.tipo || '').replace(/"/g, '""') + '"';
    righe.push(`${riga},${msg},${tipo}`);
  });
  const blob = new Blob([righe.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'cardsync_log_' + new Date().toISOString().slice(0,10) + '.csv';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('logClear').addEventListener('click', (e) => {
  e.stopPropagation();
  logEntries = [];
  logBody.innerHTML = '';
  logBody.appendChild(logEmpty);
  logEmpty.style.display = '';
  logBadge.textContent = '0';
});

// FIX (migrazione Supabase): "riga" nei log era un numero corto (es. 42) ai
// tempi di Google Sheets — ora è l'ID lungo della carta su Supabase (una
// stringa tipo "935a3ff6-..."), poco leggibile nei log. Questa mappa
// ricorda, per ogni ID incontrato durante la sessione, il nome o codice
// della carta corrispondente (popolata nel ciclo di eseguiSessione), così i
// log possono mostrare qualcosa di leggibile invece dell'ID grezzo.
const _etichetteRiga = {};

function _etichettaRiga(riga) {
  if (riga == null) return '—';
  return _etichetteRiga[riga] || ('ID ' + String(riga).slice(0, 8));
}

function aggiungiLog(riga, msg, tipo = '') {
  logEntries.push({ riga, msg, tipo });
  logEmpty.style.display = 'none';

  const entry  = document.createElement('div');
  entry.className = 'log-entry';

  const rigaEl = document.createElement('span');
  rigaEl.className   = 'log-row';
  rigaEl.textContent = _etichettaRiga(riga);

  const msgEl = document.createElement('span');
  msgEl.className   = 'log-msg' + (tipo ? ` ${tipo}` : '');
  msgEl.textContent = msg;

  entry.appendChild(rigaEl);
  entry.appendChild(msgEl);
  logBody.appendChild(entry);
  logBody.scrollTop = logBody.scrollHeight;

  logBadge.textContent = logEntries.length;
  logPanel.classList.add('visible');
}

// ── DETTAGLIO SALITI/SCESI ────────────────────────────────────────────────────
// FIX (bug "cliccare su saliti/scesi non fa vedere niente"): le pillole
// #countUp/#countDown avevano già il cursore a pointer e il tooltip "Clicca
// per vedere l'elenco delle carte salite/scese" nell'HTML, e il pannello
// #trendDetailPanel esisteva già pronto — ma nessuno script leggeva un click
// su quelle pillole, né veniva mai salvato il dettaglio di QUALI carte
// fossero salite o scese (solo il conteggio cUp/cDown). Questa funzione
// riempie e mostra il pannello con l'elenco raccolto in
// trendSalitiEntries/trendScesiEntries (popolati in eseguiSessione più sotto).
function mostraTrendDetail(tipo) {
  const panel = document.getElementById('trendDetailPanel');
  const title = document.getElementById('trendDetailTitle');
  const body  = document.getElementById('trendDetailBody');
  if (!panel || !title || !body) return;

  const lista = tipo === 'up' ? trendSalitiEntries : trendScesiEntries;
  title.textContent = tipo === 'up' ? '🔺 Carte salite' : '🔻 Carte scese';
  body.innerHTML = '';

  if (lista.length === 0) {
    const vuoto = document.createElement('div');
    vuoto.className = 'log-empty';
    vuoto.textContent = tipo === 'up'
      ? 'Nessuna carta salita in questa sessione.'
      : 'Nessuna carta scesa in questa sessione.';
    body.appendChild(vuoto);
  } else {
    lista.forEach(e => {
      const item = document.createElement('div');
      item.className = 'trend-detail-item';

      const rigaEl = document.createElement('span');
      rigaEl.className = 'trend-detail-riga';
      rigaEl.textContent = e.riga != null ? `R${e.riga}` : '—';

      const nomeEl = document.createElement('span');
      nomeEl.className = 'trend-detail-nome';
      nomeEl.textContent = e.nome || '—';
      nomeEl.title = e.nome || '';

      const varEl = document.createElement('span');
      varEl.className = `trend-detail-var ${tipo}`;
      varEl.textContent = e.testo || '';

      item.appendChild(rigaEl);
      item.appendChild(nomeEl);
      item.appendChild(varEl);
      body.appendChild(item);
    });
  }

  panel.style.display = 'flex';
}

const _trendPillUp   = document.querySelector('.trend-pill.up');
const _trendPillDown = document.querySelector('.trend-pill.down');
if (_trendPillUp)   _trendPillUp.addEventListener('click', () => mostraTrendDetail('up'));
if (_trendPillDown) _trendPillDown.addEventListener('click', () => mostraTrendDetail('down'));

const _trendDetailClose = document.getElementById('trendDetailClose');
if (_trendDetailClose) {
  _trendDetailClose.addEventListener('click', () => {
    const panel = document.getElementById('trendDetailPanel');
    if (panel) panel.style.display = 'none';
  });
}

// ── UTILITIES PREZZI ──────────────────────────────────────────────────────────
function pulisciPrezzo(prezzoStr) {
  if (prezzoStr === null || prezzoStr === undefined || prezzoStr === '') return 0;
  if (typeof prezzoStr === 'number') return isNaN(prezzoStr) ? 0 : prezzoStr;

  let clean = prezzoStr.toString().trim().replace(/[^0-9,.]/g, '');

  if (clean.includes(',') && clean.includes('.')) {
    // entrambi: determina quale è il separatore decimale
    if (clean.lastIndexOf(',') > clean.lastIndexOf('.')) {
      // formato europeo: 1.500,00
      clean = clean.replace(/\./g, '').replace(',', '.');
    } else {
      // formato anglosassone: 1,500.00
      clean = clean.replace(/,/g, '');
    }
  } else if (clean.includes(',')) {
    const decimale = clean.split(',')[1];
    // virgola decimale solo se ha 1-2 cifre dopo
    clean = (decimale && decimale.length <= 2)
      ? clean.replace(',', '.')
      : clean.replace(',', '');
  }

  const num = parseFloat(clean);
  return isNaN(num) ? 0 : num;
}

function calcolaVariazione(pV, pN) {
  if (pV <= 0 || pN <= 0) return '➖';
  const diff = pN - pV;
  if (Math.abs(diff) < 0.005) return '➖';
  const pct     = ((diff / pV) * 100).toFixed(1);
  const segno   = diff > 0 ? '+' : '';
  const diffStr = segno + diff.toFixed(2).replace('.', ',') + '€';
  const pctStr  = segno + pct + '%';
  return `${diff > 0 ? '🔺' : '🔻'} ${diffStr} (${pctStr})`;
}

function formattaDataOra(ts) {
  if (!ts) return null;
  const d = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// ── COSTRUZIONE URL FILTRATO ──────────────────────────────────────────────────
// v5.39 (Fase 3.5, B10): tolte LINGUA_MAP, COND_MAP e CONDIZIONI_MAP (questa
// mai usata). Lingue e condizioni stanno in UNA mappa, in shared.js
// (LINGUA_MAP_SHARED, COND_NUM_MAP_SHARED, con tutti gli alias).

// v5.36 (link vecchi): ricerca su Cardmarket per nome + codice della carta,
// testo codificato come nelle altre pagine (un "&" non taglia la ricerca).
function _urlRicercaControlloPrezzi(testo) {
  const q = encodeURIComponent(String(testo || '').trim().replace(/\s+/g, ' ')).replace(/%20/g, '+');
  return `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${q}`;
}

// Riporta sul link nuovo i filtri Reverse Holo / Prima Edizione del vecchio.
function _riapplicaVarianti(urlNuovo, urlVecchio) {
  try {
    const vecchio = new URL(urlVecchio);
    const nuovo = new URL(urlNuovo);
    ['isReverseHolo', 'isFirstEd'].forEach(k => { if (vecchio.searchParams.get(k) === 'Y') nuovo.searchParams.set(k, 'Y'); });
    return nuovo.toString();
  } catch (_) {
    return urlNuovo;
  }
}

function costruisciUrlFiltrato(urlBase, lingua, condizioneRaw) {
  // Delega a shared.js — stessa logica, unica fonte di verità.
  return costruisciUrlFiltrato_shared(urlBase, lingua, condizioneRaw);
}

// v5.39 (Fase 3.5, B10): l'URL è "giusto" se ha gli stessi filtri lingua e
// condizione che gli darebbe costruisciUrlFiltrato — una sola regola, la
// stessa che lo costruisce. Prima il controllo usava una mappa lingue diversa
// da quella usata per costruirlo: per "CIN", "?" o una lingua vuota l'URL
// risultava sempre sbagliato e veniva riscritto (uguale) a ogni controllo.
function urlHaTuttiParametri(url, lingua, condizione) {
  let attuale, atteso;
  try {
    attuale = new URL(url);
    atteso = new URL(costruisciUrlFiltrato(url, lingua, condizione));
  } catch (_) {
    return true; // URL non valido: niente da riscrivere qui
  }
  const lang = (u) => u.searchParams.get('language') || u.searchParams.get('idLanguage') || '';
  return lang(attuale) === lang(atteso)
    && !attuale.searchParams.has('idLanguage')
    && (attuale.searchParams.get('minCondition') || '') === (atteso.searchParams.get('minCondition') || '');
}

// FIX (pulizia codice morto): rimosse slugify() e verificaCartaNellUrl() —
// mai chiamate da nessun punto del file. Erano il vecchio approccio "indovina
// dallo slug dell'URL salvato nel foglio" per verificare che il prezzo letto
// appartenesse davvero alla carta attesa; superato da verificaCartaNelDom()
// qui sotto, che confronta nome/codice letti DAL DOM REALE della pagina
// (più affidabile: non richiede indovinare la corrispondenza tra slug URL e
// nome/codice del foglio, spesso divergenti per carte con codice speciale).

// ── CONFRONTO CODICI (v5.17, M2) ──────────────────────────────────────────────
// Spazi, punti e trattini ignorati ("CSV9.5C 006" = "CSV95C006",
// "PPS8 MEG-121" = "PPS8MEG121"). Coincidono se:
// - sono uguali, oppure
// - hanno lo STESSO numero finale, confrontato come numero (026 = 26, ma
//   1 ≠ 10), e la parte prima del numero di uno contiene quella dell'altro
//   ("SVP" ⊂ "SVPEN", "BRS" ⊂ "PPS3BRS"), oppure
// - il codice atteso non ha numeri (es. "MFB") ed è contenuto in quello
//   della pagina, come faceva la regola precedente.
function _normCodiceCarta(s) {
  return String(s || '').toUpperCase().replace(/[\s.\-]+/g, '');
}
function _codiciCoincidono(atteso, pagina) {
  const a = _normCodiceCarta(atteso);
  const p = _normCodiceCarta(pagina);
  if (!a || !p) return false;
  if (a === p) return true;
  const ma = a.match(/^(.*?)(\d+)$/);
  const mp = p.match(/^(.*?)(\d+)$/);
  if (ma && mp) {
    if (parseInt(ma[2], 10) !== parseInt(mp[2], 10)) return false;
    return ma[1].includes(mp[1]) || mp[1].includes(ma[1]);
  }
  if (!/\d/.test(a)) return p.includes(a);
  return false;
}

// ── VERIFICA CARTA NEL DOM (usa nome/codice letti dalla pagina reale) ─────────
function verificaCartaNelDom(nomePagina, codicePagina, codiceAtteso, nomeAtteso) {
  // Se la content script non ha restituito dati DOM, lascia passare (sicuro)
  if (!nomePagina && !codicePagina) return true;

  const nomePaginaUp    = nomePagina.toUpperCase();
  const codicePaginaUp  = codicePagina.toUpperCase();

  if (codiceAtteso) {
    // FIX v5.17 (M2): prima bastava che il codice atteso fosse CONTENUTO in
    // quello della pagina ("CEC 1" passava su "CEC 10") o che la pagina
    // contenesse le sue CIFRE ("CG 9" passava su qualunque codice con un 9)
    // — sulle carte col numero a una cifra la verifica non verificava quasi
    // nulla. Ora: stesso numero finale (come numero) e sigla compatibile,
    // vedi _codiciCoincidono. Provata sui 971 codici+URL del DB (2026-10-15).
    if (_codiciCoincidono(codiceAtteso, codicePaginaUp)) return true;
    // Fallback: verifica nel nome della pagina
    if (nomeAtteso) {
      const nomeNorm = nomeAtteso.toUpperCase().replace(/\s+/g, '');
      if (nomePaginaUp.replace(/\s+/g, '').includes(nomeNorm)) return true;
    }
    return false;
  }

  if (nomeAtteso) {
    const nomeNorm = nomeAtteso.toUpperCase().replace(/\s+/g, '');
    return nomePaginaUp.replace(/\s+/g, '').includes(nomeNorm);
  }

  return true;
}


// FIX (controllo prezzi non diviso tra dispositivi online, stesso bug già
// risolto per l'aggiunta carte): lotti piccoli invece di reclamare tutto
// in un colpo solo — chi parte per primo non si prende più l'intera coda,
// lasciando gli altri dispositivi a bocca asciutta.
const LOTTO_CONTROLLO_PREZZI = 3;

// Conteggio veloce (senza reclamare nulla) — usato per la stima "X carte da
// controllare" mostrata a schermo E come base del limite di sicurezza che
// ferma la sessione (vedi MAX_LOTTI_SICUREZZA in eseguiSessione).
//
// FIX (loop infinito — "non si ferma mai"): prima, se questa chiamata
// falliva per qualunque motivo (timeout, errore di rete, ecc.), l'errore
// spariva silenziosamente e la funzione restituiva 0 — un valore che più
// avanti disattivava del tutto il controllo che ferma la sessione dopo un
// giro completo (quel controllo si attivava solo con totaleStimato > 0).
// Con 0 "finto" al posto di un numero vero, la sessione poteva continuare a
// richiedere lotti all'infinito, anche su una coda piccola. Ora un errore
// qui interrompe subito la sessione con un messaggio chiaro, invece di
// proseguire con un conteggio silenziosamente sbagliato.
// v5.20 (punto 26): ordineId = ordine dal sito in esecuzione (null per il
// controllo manuale e per l'inattività) — il database ne legge proprietario e
// location dalla tabella privata (sql/108), il client non le vede.
// v5.37: azioneLeggi = 'leggiWishlistGruppo' per il controllo prezzi della
// wishlist (stessa sessione, altre funzioni sul database).
async function contaEleggibiliControlloPrezzi(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, ordineId = null, azioneLeggi = 'leggi') {
  const data = await chiamaSupabase(azioneLeggi, { filtroLocation, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, ordineId, soloConta: true });
  if (!data.ok) throw new Error(data.errore || 'Errore nel conteggio iniziale delle carte da controllare.');
  return data.totale || 0;
}

async function leggiDatiSheet(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, lottoSize, nomeDisp, ordineId = null, azioneLeggi = 'leggi') {
  const data = await chiamaSupabase(azioneLeggi, { filtroLocation, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, ordineId, lottoSize, nomeDispositivo: nomeDisp });
  if (!data.ok) throw new Error(data.errore || 'Errore nel caricamento dei dati.');

  return data.carte.map(c => ({
    rigaSheet:    c.rigaSheet,
    // Se l'URL nel foglio è già /Singles/, aggiungi i parametri filtro.
    // Se è /Search? o altro, lascialo invariato: verrà saltato o segnalato.
    // FIX (crash "Cannot read properties of null (reading 'includes')"):
    // una carta con URL vuoto (null) nel database — es. inserita in un modo
    // che non l'ha salvato — mandava in crash l'intero controllo prezzi.
    // Ora quella carta viene semplicemente saltata/segnalata più avanti,
    // senza bloccare tutte le altre.
    url:          (c.urlBase && c.urlBase.includes('/Singles/'))
                    ? costruisciUrlFiltrato(c.urlBase, c.lingua, c.condizione)
                    : c.urlBase,
    urlOriginale: c.urlBase,
    lingua:       c.lingua,
    condizione:   c.condizione,
    codice:       c.codice || '',
    nome:         c.nome   || '',
    location:     c.location || '',
    prezzoVecchio: c.prezzoPrecedente ?? c.prezzoCorrente ?? c.prezzo ?? '',
    immagine:     c.immagine || '',
    // v5.37 (trovato preparando la Fase 2): ownerId arrivava dall'adapter
    // (_supabaseToRigaLeggi) ma questa mappatura lo perdeva — nel ciclo era
    // sempre undefined: i contributi del controllo prezzi non venivano mai
    // registrati (0 nel DB) e gli errori sulle carte degli altri venivano
    // mostrati come propri.
    ownerId:      c.ownerId || null,
  }));
}

// FIX (filtro Location): legge dal foglio i valori distinti già presenti in
// colonna Location per popolare la tendina "Controlla solo", invece di
// costringere l'utente a scriverli a mano da qualche parte. Chiamata al
// click su "↺ Aggiorna elenco" e una volta all'avvio se la connessione è
// già configurata.
async function popolaTendinaLocation() {
  const select = document.getElementById('filtroLocation');
  if (!select) return;
  // Nota: non serve più controllare webAppUrl/sheetName qui — le location
  // si leggono da Supabase, non dal vecchio foglio Google.

  const valoreAttuale = select.value;
  try {
    const data = await chiamaSupabase('elencaLocation', {});
    if (!data.ok) return;
    select.innerHTML = '<option value="">Tutte le location</option>';
    (data.location || []).forEach(loc => {
      const opt = document.createElement('option');
      opt.value = loc;
      opt.textContent = loc;
      select.appendChild(opt);
    });
    // Ripristina la selezione precedente se il valore esiste ancora tra le opzioni
    if (valoreAttuale && Array.from(select.options).some(o => o.value === valoreAttuale)) {
      select.value = valoreAttuale;
    }
  } catch (_) {
    // Silenzioso: la tendina resta con le opzioni già caricate/precedenti.
  }
}

// FIX: il bottone manuale "↺ Aggiorna elenco" è stato tolto — la tendina si
// aggiorna da sola (vedi listener 'CARDSYNC_REFRESH_LOCATION' più sopra, e
// il caricamento iniziale in DOMContentLoaded più sotto).

document.getElementById('filtroLocation')?.addEventListener('change', (e) => {
  chrome.storage.local.set({ filtroLocationSelezionata: e.target.value });
});

// ── CONTROLLA CONNESSIONE ─────────────────────────────────────────────────────
// Un solo click verifica due cose PRIMA di lanciare una sessione lunga:
//   1. Web App + foglio raggiungibili — riusa l'azione 'elencaLocation'
//      (già esistente, già testata da popolaTendinaLocation) invece di
//      inventare una nuova chiamata al Web App.
//   2. Login su Cardmarket — controllo affidabile basato su un segnale
//      verificato dal DOM reale (vedi _controllaLoginCardmarket in
//      background.js): <a id="account-dropdown"> presente = loggato,
//      <div id="login-signup"> presente = non loggato. La tab resta comunque
//      attiva dopo il controllo, così si può accedere subito se serve.
document.getElementById('btnControllaConnessione')?.addEventListener('click', async () => {
  const btn = document.getElementById('btnControllaConnessione');

  btn.disabled = true;
  btn.textContent = '⏳ Controllo Supabase...';
  setStatus('⏳ Controllo la connessione a Supabase...', 'info');

  try {
    const data = await chiamaSupabase('elencaLocation', {});
    if (!data.ok) {
      setStatus('❌ ' + (data.errore || 'Risposta inattesa da Supabase.'), 'errore');
      btn.disabled = false;
      btn.textContent = '🔌 Controlla connessione';
      return;
    }
  } catch (e) {
    setStatus('❌ ' + e.message, 'errore');
    btn.disabled = false;
    btn.textContent = '🔌 Controlla connessione';
    return;
  }

  // Web App e foglio ok — controlla il login su Cardmarket (verificato dal
  // DOM reale, vedi _controllaLoginCardmarket in background.js).
  btn.textContent = '🔎 Controllo login Cardmarket...';
  chrome.runtime.sendMessage({ type: 'APRI_TAB_CONTROLLO_LOGIN' }, (risposta) => {
    let msgLogin, tipoLogin;
    if (risposta && risposta.loggato === true) {
      msgLogin = '🔓 Sei loggato su Cardmarket.';
      tipoLogin = 'ok';
    } else if (risposta && risposta.loggato === false) {
      msgLogin = '🔒 Non risulti loggato su Cardmarket — accedi nella tab appena aperta prima di avviare.';
      tipoLogin = 'errore';
    } else {
      msgLogin = '❓ Non sono riuscito a determinare lo stato di login — controlla tu nella tab appena aperta.';
      tipoLogin = 'info';
    }
    setStatus('✅ Web App e foglio raggiungibili. ' + msgLogin, tipoLogin);
    btn.disabled = false;
    btn.textContent = '🔌 Controlla connessione';
  });
});

// ── SISTEMA PROFILI — GUSCIO VUOTO ──────────────────────────────────────────
// Il vecchio sistema (registro profili su Google Apps Script, salvava
// webAppUrl/sheetId/sheetName) è stato rimosso con la migrazione a Supabase.
// La tendina e il pulsante restano nell'interfaccia come punto di aggancio
// per un futuro sistema profili basato su Supabase — per ora sono inerti.
document.getElementById('selectProfilo')?.addEventListener('change', () => {
  setStatus('ℹ️ Il sistema profili è in aggiornamento — non ancora disponibile.', 'info');
});

document.getElementById('btnSalvaProfilo')?.addEventListener('click', () => {
  setStatus('ℹ️ Il sistema profili è in aggiornamento — non ancora disponibile.', 'info');
});

// v5.37: tolte scriviDati/scriviUrl (non più chiamate): eseguiSessione scrive
// prezzo e link con _scriviPrezzoDominio/_scriviUrlDominio, che usano le
// azioni delle carte o della wishlist a seconda del dominio.

// ── TIMER / COUNTDOWN INTERROMPIBILE ─────────────────────────────────────────
function formattaTempo(secondi) {
  const m = Math.floor(secondi / 60);
  const s = Math.floor(secondi % 60);
  return `${m}m ${s}s`;
}

// ── RITMO TRA UNA RICHIESTA CARDMARKET E LA SUCCESSIVA (v5.26) ──────────────
// FIX ("controlla le carte troppo veloce"): l'attesa scelta con gli slider
// stava solo in fondo al ciclo, quindi la saltavano (1) l'ultima carta di
// ogni lotto — i lotti sono da 3, quindi una carta su tre partiva subito
// dopo la precedente — e (2) ogni carta scartata con "continue" dopo aver
// già aperto Cardmarket (Cloudflare, carta non nella pagina, URL /Search non
// risolto...). Ora ogni richiesta a Cardmarket fissa l'orario minimo della
// successiva, e prima di ogni richiesta si aspetta quell'orario: vale per
// qualunque percorso del ciclo e anche tra un lotto e l'altro.
// In più, prima di ogni richiesta si prende il turno Cardmarket COMUNE a
// tutta l'estensione (TURNO_CARDMARKET in background.js): così anche gli
// altri flussi che girano insieme (aggiungi carte, wishlist, worker
// autonomo) non accorciano l'attesa tra una carta e l'altra.
function _turnoCardmarket(fase) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'TURNO_CARDMARKET', fase }, (r) => {
        if (chrome.runtime.lastError || !r || !r.ok) { resolve(null); return; }
        resolve(r);
      });
    } catch (_) { resolve(null); }
  });
}

function creaRitmoCardmarket(delayMinSec, delayMaxSec, margineFissoMs, livelloCf) {
  let prossimaDa = 0;
  return {
    fissa() {
      const dMin = delayMinSec * 1000;
      const dMax = delayMaxSec * 1000;
      const margineCfMs = livelloCf() * CF_ESCALATION_STEP_SEC * 1000;
      prossimaDa = Date.now() + dMin + Math.floor(Math.random() * (dMax - dMin)) + margineFissoMs + margineCfMs;
      _turnoCardmarket('chiudi');
    },
    allunga(ms) { prossimaDa = Math.max(prossimaDa, Date.now()) + ms; },
    async attendi() {
      const resta = prossimaDa - Date.now();
      if (resta > 0) await attendiConCountdown(resta);
      if (stopRequested) return;
      const turno = await _turnoCardmarket('prenota');
      // Se il background non risponde, resta valida l'attesa locale sopra.
      if (turno && turno.da && turno.da > Date.now()) {
        if (turno.motivo === 'pausa-lunga') setStatus('☕ Pausa lunga (slider "Pausa lunga ogni N carte")...', 'info');
        await attendiConCountdown(turno.da - Date.now());
      }
    },
  };
}

// FIX: il countdown controlla stopRequested ogni secondo e risolve subito se richiesto
// v5.39: l'attesa si misura sull'orologio (fine = adesso + ms), non contando
// i "tick". Chrome, con la scheda dell'app in secondo piano, può far
// scattare i timer ripetuti anche una volta al minuto: contando i tick, 15 s
// di attesa potevano diventare 15 minuti (rallentamento visto il 24/10).
// Un timer unico alla scadenza chiude l'attesa in orario; quello ogni
// secondo aggiorna solo il numero mostrato e il tasto Stop.
function attendiConCountdown(ms) {
  return new Promise(resolve => {
    const fine = Date.now() + Math.max(0, ms);
    const el = document.getElementById('tempoAttesa');
    let finito = false;
    let iv = null;
    let to = null;
    const chiudi = (testo) => {
      if (finito) return;
      finito = true;
      clearInterval(iv);
      clearTimeout(to);
      if (el && testo != null) el.textContent = testo;
      resolve();
    };
    const mostra = () => { if (el) el.textContent = Math.max(0, Math.ceil((fine - Date.now()) / 1000)) + 's'; };
    mostra();
    to = setTimeout(() => chiudi('0s'), Math.max(0, fine - Date.now()));
    iv = setInterval(() => {
      // Se arriva stop, esci immediatamente senza aspettare la fine del timer
      if (stopRequested) { chiudi('—'); return; }
      if (Date.now() >= fine) { chiudi('0s'); return; }
      mostra();
    }, 1000);
  });
}

// ── APERTURA TAB E ATTESA PREZZO ──────────────────────────────────────────────
// FIX (troppe tab in sequenza → Cloudflare): questo era l'unico flusso
// dell'estensione rimasto senza il pattern "worker tab" già usato dai bulk
// "Aggiungi carta"/"Aggiungi sealed" — ogni singola carta della sessione
// principale (▶ Avvia) apriva e chiudeva una tab NUOVA, un ciclo
// apri→leggi→chiudi ripetuto per ogni riga del foglio: lo stesso pattern di
// navigazione "meccanico" già identificato come segnale forte per l'anti-bot
// di Cloudflare nei flussi bulk. Ora si riusa UNA sola tab per l'intera
// sessione (chrome.tabs.update invece di tabs.create/tabs.remove a ogni
// carta), esattamente come background.js fa già per le altre due pagine.
let _tabControlloPrezziId = null;

// Apre la tab la prima volta (tabs.create) e la riusa per le chiamate
// successive (tabs.update) — se nel frattempo la tab non esiste più (es.
// chiusa manualmente dall'utente, o rimossa dal watchdog Cloudflare di
// background.js dopo un timeout), ne apre una nuova al volo e aggiorna
// _tabControlloPrezziId di conseguenza.
function _apriOAggiornaTabControllo(url, callback) {
  if (_tabControlloPrezziId != null) {
    chrome.tabs.update(_tabControlloPrezziId, { url }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        chrome.tabs.create({ url, active: false }, (nuovaTab) => {
          _tabControlloPrezziId = nuovaTab.id;
          callback(nuovaTab);
        });
      } else {
        callback(tab);
      }
    });
  } else {
    chrome.tabs.create({ url, active: false }, (tab) => {
      _tabControlloPrezziId = tab.id;
      callback(tab);
    });
  }
}

// Chiude la tab riusata a fine sessione (successo, stop, o errore) — non va
// tenuta aperta indefinitamente una volta finita la lettura. Se una nuova
// sessione parte in seguito, _apriOAggiornaTabControllo ne aprirà una nuova
// al bisogno.
function _chiudiTabControlloPrezzi() {
  if (_tabControlloPrezziId != null) {
    const idDaChiudere = _tabControlloPrezziId;
    _tabControlloPrezziId = null;
    chrome.tabs.remove(idDaChiudere, () => { void chrome.runtime.lastError; });
  }
}

// FIX: il listener accetta CLOUDFLARE_TIMEOUT anche senza sender.tab
// (il background lo manda con sendMessage, non da una content script)
function apriTabEAspettaPrezzo(url, cfTimeoutMinuti) {
  return new Promise((resolve) => {
    _apriOAggiornaTabControllo(url, (tab) => {
      const tabId = tab.id;
      let normalTimeoutId;
      let stopCheckId;
      let cloudflareRilevato = false;
      let risolto = false;

      function concludi(valore) {
        if (risolto) return;
        risolto = true;
        clearTimeout(normalTimeoutId);
        clearInterval(stopCheckId);
        chrome.runtime.onMessage.removeListener(listener);
        resolve(valore);
      }

      // Controlla stopRequested ogni 300ms: se arriva stop, chiude la tab e risolve subito
      stopCheckId = setInterval(() => {
        if (stopRequested) {
          // FIX: se Cloudflare era già stato rilevato, il background ha una
          // voce attiva nel watchdog per questa tab — senza avvisarlo,
          // resterebbe lì fino alla sua scadenza naturale (anche minuti dopo
          // che l'utente ha già fermato tutto), tentando poi di chiudere una
          // tab già rimossa. Innocuo ma inutile: puliamo subito.
          chrome.runtime.sendMessage({ type: 'FERMA_AVVISO_CLOUDFLARE' });
          // Fine sessione: qui, a differenza degli altri esiti, la tab
          // riusata va chiusa davvero (nessuna carta successiva la riuserà).
          _chiudiTabControlloPrezzi();
          concludi('Stop');
        }
      }, 300);

      function fermaAvviso() {
        chrome.runtime.sendMessage({ type: 'FERMA_AVVISO_CLOUDFLARE' });
      }

      const listener = (message, sender) => {
        // Messaggi dalla content script della nostra tab
        if (sender.tab && sender.tab.id === tabId) {
          if (message.type === 'PREZZO_TROVATO') {
            fermaAvviso();
            // FIX: non si chiude più la tab qui — resta aperta e pronta per
            // essere riusata dalla carta successiva (vedi
            // _apriOAggiornaTabControllo). Si chiude solo a fine sessione.
            concludi({ prezzo: message.prezzo, nomePagina: message.nomePagina || '', codicePagina: message.codicePagina || '', immagine: message.immagine || null, cloudflareEncountered: cloudflareRilevato });
          } else if (message.type === 'RATE_LIMIT_DETECTED') {
            // Error 1015: nessun challenge da risolvere, solo da aspettare.
            // Segnaliamo al loop principale di mettere in pausa — la tab
            // resta aperta, verrà riusata (o navigata di nuovo) al retry.
            concludi('RateLimit');
          } else if (message.type === 'CLOUDFLARE_DETECTED' && !cloudflareRilevato) {
            cloudflareRilevato = true;
            clearTimeout(normalTimeoutId);
            setStatus('⚠️ CLOUDFLARE RILEVATO! Risolvi il blocco nella tab aperta...', 'errore');
            chrome.runtime.sendMessage({
              type: 'AVVIA_AVVISO_CLOUDFLARE',
              tabId,
              avvisoSonoro:   document.getElementById('avvisoSonoro').checked,
              timeoutMinuti:  cfTimeoutMinuti,
            });
          }
        }

        // CLOUDFLARE_TIMEOUT arriva dal background (sender senza .tab).
        // La tab è già stata rimossa dal background: non richiamare tabs.remove
        // per evitare una doppia rimozione che genera lastError silente.
        if (message.type === 'CLOUDFLARE_TIMEOUT' && message.tabId === tabId) {
          // FIX: la tab riusata non esiste più (rimossa dal watchdog di
          // background.js) — se coincide con quella che stavamo tenendo
          // pronta per il riuso, dimentichiamola subito così la carta
          // successiva ne apre una nuova invece di tentare un update() su
          // un tabId ormai morto (fallirebbe comunque in modo innocuo grazie
          // al fallback in _apriOAggiornaTabControllo, ma evitiamo il giro a vuoto).
          if (_tabControlloPrezziId === tabId) _tabControlloPrezziId = null;
          concludi('Cloudflare');
        }
      };

      chrome.runtime.onMessage.addListener(listener);

      // Timeout normale (18s) per pagine senza Cloudflare
      normalTimeoutId = setTimeout(() => {
        // FIX: non si chiude più la tab qui — resta aperta e pronta per
        // essere riusata dalla carta successiva, stesso discorso di
        // PREZZO_TROVATO/RATE_LIMIT_DETECTED più sopra.
        concludi('Timeout');
      }, 18000);
    });
  });
}

// ── UI: TREND ────────────────────────────────────────────────────────────────
function aggiornaTrend() {
  document.getElementById('countUp').textContent     = cUp;
  document.getElementById('countDown').textContent   = cDown;
  document.getElementById('countSteady').textContent = cSteady;
  document.getElementById('trendContainer').classList.add('visible');
}

// ── UI: RESET POST-SESSIONE ───────────────────────────────────────────────────
function resetUiPostSessione() {
  isRunning     = false;
  stopRequested = false;
  const btnAvvia  = document.getElementById('btnAvvia');
  btnAvvia.disabled    = false;
  btnAvvia.textContent = '▶ Avvia';
  document.getElementById('timerContainer').classList.remove('visible');
  document.getElementById('tempoAttesa').textContent = '—';
}

// ── SESSIONE PRINCIPALE ───────────────────────────────────────────────────────
// v5.21: gli errori di una carta (prezzo non trovato, link mancante, carta
// non nella pagina) li vede solo il proprietario — sul sito, in Controlla
// prezzi — come le "Carte con problemi" di Aggiungi carte. Chi controlla per
// il gruppo vede solo che la carta di un altro è stata controllata.
let _mioUserIdSessionePrezzi = null;
async function _aggiornaMioUserIdSessionePrezzi() {
  try {
    const { data } = await supabaseClient.auth.getSession();
    _mioUserIdSessionePrezzi = data?.session?.user?.id || null;
  } catch (_) { _mioUserIdSessionePrezzi = null; }
}
function _cartaDiUnAltro(ownerId) {
  return !!(ownerId && _mioUserIdSessionePrezzi && ownerId !== _mioUserIdSessionePrezzi);
}
function _logErroreCarta(rigaSheet, ownerId, msg, tipo = 'errore') {
  if (_cartaDiUnAltro(ownerId)) aggiungiLog(rigaSheet, 'Controllata (carta di un altro utente)', '');
  else aggiungiLog(rigaSheet, msg, tipo);
}

async function eseguiSessione(isDry, overrides = {}) {
  await _aggiornaMioUserIdSessionePrezzi();
  // v5.37 (Fase 2, decisione Q3): la stessa sessione controlla anche la
  // wishlist del gruppo. Cambiano solo le funzioni del database (sql/118) e
  // si saltano le parti che hanno senso solo per la collezione: filtro
  // location e diagnosi in esito_controllo (la wishlist non ha quel campo, e
  // le sue note sono del proprietario).
  const dominio = overrides.dominio === 'wishlist' ? 'wishlist' : 'carte';
  const AZ = dominio === 'wishlist'
    ? { leggi: 'leggiWishlistGruppo', segna: 'segnaControllataWishlistGruppo', nota: null, url: 'aggiornaUrlRigaWishlistGruppo', prezzo: 'aggiornaPrezzoRigaWishlistGruppo', rilascia: 'rilasciaClaimWishlist', tipoAiuto: 'controllo_prezzi_wishlist' }
    : { leggi: 'leggi', segna: 'segnaControllata', nota: 'aggiornaNotaRiga', url: 'aggiornaUrlRiga', prezzo: 'aggiornaPrezzoRiga', rilascia: 'rilasciaClaim', tipoAiuto: 'controllo_prezzi' };
  const _scriviUrlDominio = (riga, u) => chiamaSupabase(AZ.url, { riga, url: u });
  const _scriviPrezzoDominio = (riga, prezzo, immagine) => chiamaSupabase(AZ.prezzo, { riga, prezzo, immagine: immagine || undefined });
  const _scriviEsitoDominio = (riga, nota) => (AZ.nota ? chiamaSupabase(AZ.nota, { riga, nota }) : Promise.resolve({ ok: true }));
  // Leggi tutti i parametri al momento dell'avvio
  // FASE ordini "controlla_prezzi" con location dal sito: se l'ordine porta
  // un elenco di location (checkbox spuntate su Pages), overrides.filtroLocation
  // lo sostituisce al valore della tendina manuale — vedi _avviaAutorunSeRichiesto.
  const filtroLocation = dominio === 'wishlist' ? [] : (overrides.filtroLocation !== undefined
    ? overrides.filtroLocation
    : (document.getElementById('filtroLocation')?.value.trim() || ''));
  const soloVariazioni = document.getElementById('soloVariazioni').checked;
  // v5.17: soloVecchie/giorniMinimi possono arrivare dal chiamante (controllo
  // in inattività, che li impone a "più vecchie di 7 giorni") — altrimenti si
  // usano i campi dell'interfaccia, come prima.
  const soloVecchie    = overrides.soloVecchie !== undefined
    ? overrides.soloVecchie
    : document.getElementById('soloVecchie').checked;
  const giorniMinimi   = overrides.giorniMinimi !== undefined
    ? overrides.giorniMinimi
    : (parseInt(document.getElementById('giorniMinimi').value) || 3);
  // FIX: prima "aiuta il gruppo" dipendeva SEMPRE dalla casella locale di
  // QUESTO dispositivo, anche per ordini arrivati dal sito — chi creava la
  // richiesta non aveva alcun controllo su questo, un dispositivo con la
  // casella spuntata controllava le carte di tutti a sua insaputa. Stesso
  // pattern già usato sopra per filtroLocation: se l'ordine porta un
  // valore esplicito, quello vince sulla casella locale.
  const aiutaGruppo    = overrides.aiutaGruppo !== undefined
    ? overrides.aiutaGruppo
    : document.getElementById('aiutaGruppo').checked;
  // FIX (controllo prezzi eseguito da un dispositivo diverso da chi l'ha
  // richiesto): "solo le mie" deve riferirsi a chi ha CREATO la richiesta
  // dal sito, non a chi la sta eseguendo — vedi ownerIdRichiesto passato
  // giù fino a chiamaSupabase('leggi', ...).
  const ownerIdRichiesto = overrides.ownerIdRichiesto || null;
  // v5.20 (punto 26): id dell'ordine dal sito in esecuzione (autorun o "mi
  // unisco"). Con questo il database prende proprietario e location
  // dell'ordine dalla sua tabella privata: i nomi delle location di chi l'ha
  // chiesto non arrivano mai qui.
  const ordineId = overrides.ordineId || null;
  const delayMinSec    = parseInt(document.getElementById('sliderDelayMin').value) || DEFAULTS.sliderDelayMinSec;
  const delayMaxSec    = Math.max(parseInt(document.getElementById('sliderDelayMax').value) || DEFAULTS.sliderDelayMaxSec, delayMinSec);
  const cfMinuti       = parseInt(document.getElementById('sliderCfTimeout').value);
  const sogliaIdx      = parseInt(document.getElementById('sliderSoglia').value);
  const sogliaEuro     = SOGLIA_VALUES[sogliaIdx] ?? 0.01;
  const maxNd          = parseInt(document.getElementById('sliderMaxNd').value);

  // Nota: non richiediamo più webAppUrl/sheetId/sheetName qui — la
  // collezione si legge/scrive su Supabase, non sul vecchio foglio Google.
  // Serve però essere loggati su Supabase.
  {
    const { data: _sessCheck } = await supabaseClient.auth.getSession();
    if (!_sessCheck.session) {
      setStatus('⚠️ Non sei loggato su Supabase — ricarica l\'estensione per rifare il login.', 'errore');
      fermaAudioKeepAlive(); // era già stato avviato dal click handler
      return;
    }
  }

  // Reset stato
  cUp = 0; cDown = 0; cSteady = 0; cErrori = 0;
  // FIX (dettaglio saliti/scesi): azzera anche il dettaglio a ogni nuova
  // sessione — altrimenti una carta salita in una sessione precedente
  // resterebbe visibile aprendo il pannello in quella successiva.
  trendSalitiEntries = [];
  trendScesiEntries  = [];
  const _trendDetailPanel = document.getElementById('trendDetailPanel');
  if (_trendDetailPanel) _trendDetailPanel.style.display = 'none';
  let ndConsecutivi = 0;
  let cfConsecutivi = 0;
  let rateLimitRetryCorrente = 0; // tentativi di retry sulla riga corrente dopo Error 1015
  // ── BACKOFF ADATTIVO CLOUDFLARE ────────────────────────────────────────
  // Stesso meccanismo introdotto nei popup bulk (aggiungi carte/sealed):
  // ogni volta che una carta incontra Cloudflare (risolto in tempo o no,
  // vedi cloudflareEncountered più sotto) il livello sale di un gradino,
  // allungando temporaneamente il delay tra una carta e la successiva; ogni
  // carta che procede senza incontrare Cloudflare lo abbassa di un gradino,
  // così il ritmo torna da solo verso quello scelto dall'utente.
  let cfEscalationLevel = 0;
  // Margine fisso 1200 ms (ex MARGINE_RIUSO_TAB_MS): prima ogni carta
  // apriva/chiudeva una tab nuova e quel ciclo aggiungeva un ritardo
  // "nascosto"; riusando una sola tab (apriTabEAspettaPrezzo) è sparito e a
  // parità di slider partivano più richieste al minuto (Error 1015). Il
  // margine riporta il ritmo reale vicino a quello di prima. L'escalation
  // Cloudflare aggiunge CF_ESCALATION_STEP_SEC per gradino.
  const ritmo = creaRitmoCardmarket(delayMinSec, delayMaxSec, 1200, () => cfEscalationLevel);
  // FIX (loop infinito / carte ripetute): le scritture di "segnaControllata"
  // (che aggiornano ultimo_controllo) venivano lanciate senza aspettarle
  // ("fire and forget") — il ciclo passava subito alla carta successiva, e
  // a fine lotto poteva richiedere il lotto successivo PRIMA che quelle
  // scritture fossero arrivate davvero al database. Su una coda piccola
  // (poche carte) questa corsa poteva far ripescare le stesse carte appena
  // controllate. Ora ogni scrittura va in questo elenco e, subito prima di
  // chiedere il lotto successivo, si aspetta che siano TUTTE arrivate — un
  // solo punto di attesa ogni pochi secondi (una volta per lotto, non una
  // volta per carta), quindi non rallenta la sessione carta per carta.
  let chiamateSegnaControllataPendenti = [];
  function _segnaControllataAsync(rigaSheet) {
    chiamateSegnaControllataPendenti.push(
      chiamaSupabase(AZ.segna, { riga: rigaSheet }).catch((e) => {
        console.error('[segnaControllata] errore:', e?.message || e);
      })
    );
  }
  aggiornaTrend();
  nascondiProgress();

  isRunning     = true;
  stopRequested = false;

  const ora = Date.now();
  chrome.storage.local.set({ ultimoUtilizzo: ora });
  const elUU = document.getElementById('ultimoUtilizzo');
  if (elUU) elUU.textContent = '🕐 Ultimo utilizzo: ' + formattaDataOra(ora);

  const btnAvvia  = document.getElementById('btnAvvia');
  btnAvvia.textContent = '🛑 Ferma lettura';

  // Nome persistente di questo PC/estensione (vedi shared.js) — usato per
  // taggare le carte prenotate durante QUESTA sessione, così le prenotazioni
  // di due PC diversi (anche con lo stesso account) non si confondono più.
  // Vedi supabase_adapter.js, case 'leggi' e 'rilasciaClaim'.
  const nomeDisp = await nomeDispositivo();

  try {
    await _attendiCodaCardmarketLibera(); // v5.29: un lavoro su Cardmarket alla volta
    _segnaleOccupatoAvvia(); // v5.17: vedi commento su CHIAVE_SEGNALE_OCCUPATO
    // v5.20 (punto 26): per un ordine dal sito i nomi delle location non si
    // scrivono a schermo (sono di chi ha chiesto il controllo, non di chi lo
    // esegue) — al massimo quante sono, per gli ordini creati dal sito vecchio.
    const filtroLocationLabel = ordineId
      ? (Array.isArray(filtroLocation) && filtroLocation.length ? `${filtroLocation.length} location` : '')
      : (Array.isArray(filtroLocation) ? filtroLocation.join(', ') : filtroLocation);
    setStatus(filtroLocationLabel ? `📡 Lettura dati dal foglio (location: ${filtroLocationLabel})...` : '📡 Lettura dati dal foglio...', 'info');

    // Stima del totale (solo per la barra di avanzamento — non reclama
    // nulla, altri dispositivi possono nel frattempo iniziare a lavorarci
    // anche loro, quindi questo numero può risultare via via ottimistico
    // se ci stanno lavorando in più: normale, non un bug).
    const totaleStimato = await contaEleggibiliControlloPrezzi(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, ordineId, AZ.leggi);

    let carte = await leggiDatiSheet(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI, nomeDisp, ordineId, AZ.leggi);

    // FIX (loop infinito — rete di sicurezza indipendente dal conteggio):
    // il conteggio sopra (totaleStimato) resta la base normale per fermarsi
    // dopo "un giro completo", ma non deve essere l'UNICA rete di
    // sicurezza — se per un qualunque motivo risultasse più basso del
    // reale (es. carte diventate eleggibili proprio mentre la sessione
    // gira), la sessione si fermerebbe troppo presto, il che va bene; se
    // invece il problema fosse nella direzione opposta (un conteggio che
    // non riflette più la realtà, o una carta che torna eleggibile senza
    // che il suo "controllata ora" sia stato scritto in tempo — vedi fix
    // su segnaControllata più sotto), questo limite assoluto sul NUMERO DI
    // LOTTI richiesti impedisce comunque un loop senza fine: con lotti da
    // LOTTO_CONTROLLO_PREZZI carte, dopo questo tanti lotti la sessione si
    // ferma SEMPRE, qualunque cosa dica il conteggio iniziale.
    const MAX_LOTTI_SICUREZZA = Math.ceil((totaleStimato || carte.length) / LOTTO_CONTROLLO_PREZZI) + 5;
    let numeroLottiElaborati = 1;

    if (carte.length === 0 && overrides.silenziosoSeVuoto) {
      // v5.17: controllo in inattività e nel frattempo un altro dispositivo
      // ha preso le ultime carte da controllare — niente da fare, non è un
      // errore. Il blocco finally più sotto rimette comunque tutto a posto.
      setStatus('💤 Prezzi del gruppo già aggiornati — niente da controllare per ora.', 'info');
      return;
    }

    if (carte.length === 0) {
      // FIX v5.17 (C8): prima qui c'era un "DEBUG temporaneo" che metteva nel
      // messaggio i nomi delle location e gli id — e il messaggio finisce in
      // ordini.errore_msg, che TUTTO il gruppo può leggere (regola di lettura
      // "true" su ordini, verificata sul DB 2026-10-15), mostrato dal sito.
      // Ora il messaggio è generico; i dettagli restano solo su questo
      // dispositivo (console + log locale dell'estensione).
      // Location come numero, non come nomi: se l'ordine è di un altro, chi
      // lo esegue non deve trovarsele scritte nel log.
      const nLocation = Array.isArray(filtroLocation) ? filtroLocation.length : (filtroLocation ? 1 : 0);
      const dettagliFiltri = `location filtrate=${nLocation}, aiutaGruppo=${aiutaGruppo}, ownerIdRichiesto=${ownerIdRichiesto}, soloVecchie=${soloVecchie}`;
      console.warn('[controllo prezzi] nessuna carta da controllare:', dettagliFiltri);
      aggiungiLog(null, `Nessuna carta da controllare (${dettagliFiltri})`, 'errore');
      throw new Error('Nessuna carta da controllare con i filtri scelti.');
    }

    document.getElementById('timerContainer').classList.add('visible');
    const elTotale = document.getElementById('tempoTotale');
    const elAttesa = document.getElementById('tempoAttesa');

    // Offset cumulativo attraverso TUTTI i lotti precedenti (non solo
    // quello corrente) — usato per la barra di avanzamento, che altrimenti
    // ripartirebbe da "1" ad ogni nuovo lotto richiesto. Calcolato come
    // somma, non incrementato punto per punto nel ciclo (troppo lungo e
    // pieno di "continue" per rischiare di dimenticarne uno).
    let offsetLottiPrecedenti = 0;

    while (carte.length > 0) {
    for (let step = 0; step < carte.length; step++) {
      if (stopRequested) break;

      // ownerId (2026-09-06): proprietario della carta, serve ai contributi
      // al gruppo piu' sotto. Aggiunto a _supabaseToRigaLeggi() in
      // supabase_adapter.js — prima non arrivava fin qui.
      const { rigaSheet, url, prezzoVecchio, urlOriginale, lingua, condizione, codice, nome, ownerId } = carte[step];
      _etichetteRiga[rigaSheet] = nome || codice || null;
      const stepGlobale = offsetLottiPrecedenti + step;

      // FIX (crash "Cannot read properties of null (reading 'includes')"):
      // una carta senza URL salvato (es. inserita in un modo che non l'ha
      // registrato) mandava in crash l'intero controllo prezzi al primo
      // .includes() chiamato su null, più avanti in questo stesso ciclo —
      // bloccando anche tutte le carte successive. Meglio saltarla subito
      // con un messaggio chiaro.
      if (!urlOriginale) {
        _logErroreCarta(rigaSheet, ownerId, `${_etichettaRiga(rigaSheet)}: nessun URL salvato, saltata`, 'err');
        cErrori++;
        // FIX (loop infinito): saltare la carta qui NON la segnava mai come
        // "controllata" — restava per sempre in cima alla fila (ultimo_controllo
        // ancora null) e veniva ripescata ad ogni nuovo lotto, all'infinito,
        // anche se inutile da controllare (non ha nemmeno un link). La segna
        // controllata comunque, così passa alle successive.
        _segnaControllataAsync(rigaSheet);
        continue;
      }

      // Stima tempo rimanente — sul totale stimato complessivo, non solo
      // sul lotto corrente (che è piccolo apposta, vedi LOTTO_CONTROLLO_PREZZI).
      const mediaMs      = ((delayMinSec + delayMaxSec) / 2) * 1000 + 1200;
      const restanti     = Math.max(totaleStimato - stepGlobale, carte.length - step);
      const stimaSec     = restanti * ((18000 + mediaMs) / 1000);
      if (elTotale) elTotale.textContent = formattaTempo(stimaSec);

      setStatus(`⏳ ${isDry ? '[DRY] ' : ''}Carta ${stepGlobale + 1}/${totaleStimato || carte.length} — ${_etichettaRiga(rigaSheet)}`, 'info');
      setProgress(totaleStimato > 0 ? Math.round((stepGlobale / totaleStimato) * 100) : 0);

      // ── DRY RUN: simula senza aprire tab ────────────────────────────────
      if (isDry) {
        const pV = pulisciPrezzo(prezzoVecchio);
        const pN = parseFloat((Math.random() * 10 + 0.5).toFixed(2));
        const varTesto = calcolaVariazione(pV, pN);
        aggiungiLog(rigaSheet, `[DRY] → ${pN}€ ${varTesto}`, 'dry');
        if (pN > pV && pV > 0)      { cUp++;     }
        else if (pN < pV && pV > 0) { cDown++;   }
        else                         { cSteady++; }
        aggiornaTrend();
        if (elAttesa) elAttesa.textContent = '—';
        if (stopRequested) break;
        // Piccola pausa simulata tra le carte in dry run
        await attendiConCountdown(300);
        continue;
      }

      // ── APERTURA TAB ────────────────────────────────────────────────────
      // ── RISOLUZIONE URL /Search? ─────────────────────
      // Se l'URL in H e' una pagina /Search?, il loop non sa leggere
      // prezzi da li'. Chiediamo al background di risolvere il /Singles/
      // reale, lo salviamo in H e usiamo quello per aprire la tab.
      let urlDaAprire = url;
      if (urlOriginale.includes('/Products/Search')) {
        await ritmo.attendi();
        if (stopRequested) break;
        setStatus(`⏳ ${_etichettaRiga(rigaSheet)}: risolvo URL ricerca → Singles...`, 'info');
        try {
          const risolto = await Promise.race([
            new Promise((resolve, reject) => {
              chrome.runtime.sendMessage({
                type:      'LEGGI_NOME_CARTA',
                turnoGiaPreso: true, // v5.26: preso da ritmo.attendi()
                urlNome:   urlOriginale,
                lingua,
                condizione,
              }, (r) => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve(r);
              });
            }),
            new Promise((_, reject) =>
              setTimeout(() => reject(new Error('Timeout risoluzione URL (30s)')), 30000)
            ),
          ]).finally(() => ritmo.fissa());
          if (risolto && risolto.rateLimited) {
            rateLimitRetryCorrente++;
            aggiungiLog(rigaSheet, 'Error 1015 (rate limited) durante risoluzione URL → pausa 30 min', 'errore');
            setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti...', 'errore');
            await attendiConCountdown(PAUSA_RATE_LIMIT_MS);
            if (stopRequested) break;
            if (rateLimitRetryCorrente >= 3) {
              aggiungiLog(rigaSheet, 'Saltata dopo 3 rate limit consecutivi', 'errore');
              rateLimitRetryCorrente = 0;
              avanzaRiga(rigaSheet);
              // FIX (loop infinito): stesso principio già applicato al caso
              // "nessun URL salvato" — se non segniamo questa carta come
              // controllata, resta in cima alla fila e viene ripescata subito
              // di nuovo al lotto successivo. Riproverà comunque al prossimo
              // controllo prezzi.
              _segnaControllataAsync(rigaSheet);
              continue;
            }
            step--;
            continue;
          }
          if (risolto && risolto.urlSingles) {
            const urlSinglesConFiltri = costruisciUrlFiltrato(risolto.urlSingles, lingua, condizione);
            aggiungiLog(rigaSheet, `URL /Search risolto: ${risolto.urlSingles}`, 'info');
            // v5.17: chiamaSupabase non lancia eccezioni, restituisce ok:false —
            // senza questo controllo un salvataggio rifiutato passava muto.
            const esitoUrlRisolto = await _scriviUrlDominio(rigaSheet, urlSinglesConFiltri);
            if (!esitoUrlRisolto || !esitoUrlRisolto.ok) {
              aggiungiLog(rigaSheet, `⚠️ URL non salvato (${esitoUrlRisolto?.errore || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
            }
            urlDaAprire = urlSinglesConFiltri;
            carte[step].urlOriginale = urlSinglesConFiltri;
          } else {
            aggiungiLog(rigaSheet, 'URL /Search: Singles non trovato, saltata', 'errore');
            avanzaRiga(rigaSheet);
            _segnaControllataAsync(rigaSheet); // FIX (loop infinito): vedi commento sopra
            continue;
          }
        } catch (e) {
          aggiungiLog(rigaSheet, 'Errore risoluzione URL: ' + e.message, 'errore');
          avanzaRiga(rigaSheet);
          _segnaControllataAsync(rigaSheet); // FIX (loop infinito): vedi commento sopra
          continue;
        }
      }

      // ── APERTURA TAB ────────────────────────────────────────────────
      await ritmo.attendi();
      if (stopRequested) break;
      const risultato   = await apriTabEAspettaPrezzo(urlDaAprire, cfMinuti);
      ritmo.fissa();
      const nuovoPrezzo  = (risultato && typeof risultato === 'object') ? risultato.prezzo : risultato;
      const nomePagina   = (risultato && typeof risultato === 'object') ? risultato.nomePagina  : '';
      const codicePagina = (risultato && typeof risultato === 'object') ? risultato.codicePagina : '';
      const immagineTab  = (risultato && typeof risultato === 'object') ? risultato.immagine : null;
      // Vero sia se il challenge non è stato risolto in tempo (nuovoPrezzo
      // === 'Cloudflare') sia se è stato risolto MA la pagina lo ha comunque
      // incontrato lungo il percorso (flag propagato da apriTabEAspettaPrezzo).
      const cloudflareEncountered = nuovoPrezzo === 'Cloudflare'
        || (risultato && typeof risultato === 'object' && !!risultato.cloudflareEncountered);

      // ── STOP IMMEDIATO ──────────────────────────────────────────────────
      if (nuovoPrezzo === 'Stop' || stopRequested) break;

      // ── ERROR 1015 (RATE LIMIT) ──────────────────────────────────────────
      // Nessun challenge da risolvere: serve solo aspettare. Pausa fissa di
      // 30 minuti, poi si ritenta la STESSA riga (non si avanza). Limite di
      // sicurezza per evitare loop infiniti se il rate limit persiste.
      if (nuovoPrezzo === 'RateLimit') {
        rateLimitRetryCorrente++;
        aggiungiLog(rigaSheet, `Error 1015 (rate limited) → pausa 30 min`, 'errore');
        setStatus(`🚫 Error 1015: troppi richieste. Pausa di 30 minuti...`, 'errore');
        await attendiConCountdown(PAUSA_RATE_LIMIT_MS);
        if (stopRequested) break;
        if (rateLimitRetryCorrente >= 3) {
          aggiungiLog(rigaSheet, `Saltata dopo 3 rate limit consecutivi`, 'errore');
          rateLimitRetryCorrente = 0;
          avanzaRiga(rigaSheet);
          _segnaControllataAsync(rigaSheet); // FIX (loop infinito): vedi commento più sopra
          continue;
        }
        step--; // ritenta la stessa carta al prossimo giro del for
        continue;
      }
      rateLimitRetryCorrente = 0; // reset se la riga è andata a buon fine

      // ── BACKOFF ADATTIVO CLOUDFLARE ──────────────────────────────────────
      // Aggiorna il livello di escalation prima di calcolare il delay finale
      // di questa iterazione — vedi commento esteso su cfEscalationLevel più
      // sopra. Il ramo Cloudflare qui sotto gestisce anche il proprio log,
      // quindi qui aggiorniamo solo il contatore silenziosamente.
      if (cloudflareEncountered) {
        cfEscalationLevel = Math.min(cfEscalationLevel + 1, CF_ESCALATION_MAX_LEVEL);
      } else if (cfEscalationLevel > 0) {
        cfEscalationLevel--;
      }

      // ── CLOUDFLARE ──────────────────────────────────────────────────────
      if (nuovoPrezzo === 'Cloudflare') {
        cfConsecutivi++;
        aggiungiLog(rigaSheet, 'Saltata (Cloudflare non risolto)', 'errore');
        setStatus(`⏭️ ${_etichettaRiga(rigaSheet)}: saltata (Cloudflare).`, 'errore');
        avanzaRiga(rigaSheet);
        // FIX (loop infinito): mancava qui — questa carta non veniva MAI
        // segnata come controllata quando Cloudflare non si risolveva in
        // tempo, quindi restava sempre in cima alla fila e veniva ripescata
        // ad ogni lotto successivo. Stesso principio già applicato al caso
        // "nessun URL salvato": riproverà comunque al prossimo controllo
        // prezzi, ma non blocca questa sessione all'infinito.
        _segnaControllataAsync(rigaSheet);
        // Pausa lunga dopo 2 Cloudflare di fila: molto probabile ban temporaneo
        if (cfConsecutivi >= 2) {
          cfConsecutivi = 0;
          setStatus('🚫 2 Cloudflare consecutivi → pausa anti-ban 2 min...', 'errore');
          aggiungiLog(null, '2 Cloudflare consecutivi → pausa 2 min', 'errore');
          await attendiConCountdown(120000);
          if (stopRequested) break;
        }
        continue;
      }
      cfConsecutivi = 0; // reset se la carta è andata a buon fine
      if (cloudflareEncountered) {
        aggiungiLog(rigaSheet, '⚠️ Cloudflare incontrato ma risolto — rallento temporaneamente il ritmo', '');
      }

      // ── v5.36: LINK VECCHIO (porta alla lista dell'espansione) ───────────
      // content.js manda 'LinkNonValido' quando Cardmarket rimanda alla lista
      // dell'espansione (es. Magikarp-HS72, oggi Magikarp-V1-HS72). Prima la
      // carta veniva saltata come "non trovata nella pagina" ma segnata
      // controllata, e il prezzo non si aggiornava più. Ora si cerca il link
      // giusto per nome e codice (stesse regole della coda), lo si salva e si
      // rilegge la stessa carta, una volta sola. Se resta ambiguo, la diagnosi
      // "Link Cardmarket non più valido: da correggere" finisce in
      // esito_controllo (mai nelle note della carta).
      if (nuovoPrezzo === 'LinkNonValido') {
        let urlRiparato = null;
        const testoRicerca = [nome, codice].filter(Boolean).join(' ').trim();
        if (!carte[step]._linkRiparato && testoRicerca) {
          carte[step]._linkRiparato = true;
          aggiungiLog(rigaSheet, 'Link Cardmarket non più valido → cerco la carta per nome', '');
          await ritmo.attendi();
          if (stopRequested) break;
          try {
            const r = await Promise.race([
              new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({
                  type: 'LEGGI_NOME_CARTA',
                  turnoGiaPreso: true, // preso da ritmo.attendi() qui sopra
                  urlNome: _urlRicercaControlloPrezzi(testoRicerca),
                  lingua,
                  condizione,
                }, (x) => {
                  if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                  else resolve(x);
                });
              }),
              new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout ricerca link (60s)')), 60000)),
            ]).finally(() => ritmo.fissa());
            if (r && r.urlSingles) urlRiparato = _riapplicaVarianti(costruisciUrlFiltrato(r.urlSingles, lingua, condizione), urlOriginale);
          } catch (e) {
            aggiungiLog(rigaSheet, 'Errore nella ricerca del link: ' + e.message, 'errore');
          }
        }
        if (urlRiparato) {
          const esitoUrl = await _scriviUrlDominio(rigaSheet, urlRiparato);
          if (!esitoUrl || !esitoUrl.ok) aggiungiLog(rigaSheet, `⚠️ Link nuovo non salvato (${esitoUrl?.errore || 'errore sconosciuto'})`, 'errore');
          else aggiungiLog(rigaSheet, `Link aggiornato: ${urlRiparato}`, 'info');
          carte[step].url = urlRiparato;
          carte[step].urlOriginale = urlRiparato;
          step--; // rilegge la stessa carta con il link nuovo
          continue;
        }
        _logErroreCarta(rigaSheet, ownerId, 'Link Cardmarket non più valido: da correggere');
        if (!_cartaDiUnAltro(ownerId)) setStatus(`⚠️ ${_etichettaRiga(rigaSheet)}: link Cardmarket non più valido, da correggere.`, 'errore');
        chiamateSegnaControllataPendenti.push(
          _scriviEsitoDominio(rigaSheet, 'Link Cardmarket non più valido: da correggere').catch(() => {})
        );
        avanzaRiga(rigaSheet);
        // Segnata controllata comunque: altrimenti tornerebbe in cima a ogni
        // lotto (stesso motivo degli altri "FIX (loop infinito)"). La
        // diagnosi qui sopra resta visibile sul sito.
        _segnaControllataAsync(rigaSheet);
        continue;
      }

      // ── VERIFICA CARTA ──────────────────────────────────────────────────
      // ── VERIFICA CARTA (sul DOM reale, non sull'URL) ───────────────────
      if (!verificaCartaNelDom(nomePagina, codicePagina, codice, nome)) {
        const checker = codice || nome;
        _logErroreCarta(rigaSheet, ownerId, `"${checker}" non trovato nella pagina`);
        if (!_cartaDiUnAltro(ownerId)) setStatus(`⚠️ ${_etichettaRiga(rigaSheet)}: "${checker}" non nella pagina, saltata.`, 'errore');
        avanzaRiga(rigaSheet);
        _segnaControllataAsync(rigaSheet); // FIX (loop infinito): vedi commenti più sopra
        continue;
      }

      // ── CONFRONTO PREZZI ────────────────────────────────────────────────
      const pV          = pulisciPrezzo(prezzoVecchio);
      const pN          = pulisciPrezzo(nuovoPrezzo);
      const diffAss     = Math.abs(pN - pV);
      const varTesto    = calcolaVariazione(pV, pN);
      const prezzoValido = typeof nuovoPrezzo === 'number' ||
        (typeof nuovoPrezzo === 'string' &&
          !['N/D','Timeout','Esaurita','Cloudflare'].includes(nuovoPrezzo));

      if (pV > 0 && pN > 0) {
        if (diffAss < 0.005) {
          cSteady++;
          setStatus(`➖ ${_etichettaRiga(rigaSheet)}: stabile (${pN}€)`, 'info');
          aggiungiLog(rigaSheet, `Stabile a ${pN}€`, 'ok');
        } else if (pN > pV) {
          cUp++;
          // FIX (dettaglio saliti/scesi): registra riga/nome/variazione per
          // il pannello "🔺 Carte salite" apribile cliccando la pillola.
          trendSalitiEntries.push({
            riga: rigaSheet,
            nome: codice || nome || '',
            testo: `${pV}€ → ${pN}€ ${varTesto}`,
          });
          setStatus(`🔺 ${_etichettaRiga(rigaSheet)}: salito ${pV}€ → ${pN}€`, 'ok');
          aggiungiLog(rigaSheet, `Salito: ${pV}€ → ${pN}€ ${varTesto}`, 'up');
        } else {
          cDown++;
          // FIX (dettaglio saliti/scesi): stesso discorso per "🔻 Carte scese".
          trendScesiEntries.push({
            riga: rigaSheet,
            nome: codice || nome || '',
            testo: `${pV}€ → ${pN}€ ${varTesto}`,
          });
          setStatus(`🔻 ${_etichettaRiga(rigaSheet)}: sceso ${pV}€ → ${pN}€`, 'errore');
          aggiungiLog(rigaSheet, `Sceso: ${pV}€ → ${pN}€ ${varTesto}`, 'down');
        }
        ndConsecutivi = 0;
      } else {
        cSteady++;
        if (['N/D','Timeout','Esaurita'].includes(nuovoPrezzo)) {
          ndConsecutivi++;
          _logErroreCarta(rigaSheet, ownerId, String(nuovoPrezzo));
          // FIX: prima la cella prezzo restava semplicemente vuota, senza
          // nessuna traccia del motivo — scrive nella colonna Variazione un
          // messaggio esplicativo così è chiaro perché manca il prezzo.
          // 'Esaurita' viene da content.js quando la pagina HA offerte ma
          // nessuna soddisfa i filtri lingua/condizione richiesti; 'N/D' e
          // 'Timeout' indicano invece un problema di caricamento/lettura,
          // non di filtri. Sovrascritto automaticamente al prossimo giro
          // in cui il prezzo viene trovato (scriviDati scrive lì sopra).
          const _motivoMancante = {
            'Esaurita': 'Prezzo non trovato per lingua e/o condizione',
            'N/D':      'Prezzo non trovato (pagina non caricata correttamente)',
            'Timeout':  'Timeout: pagina troppo lenta a rispondere',
          }[nuovoPrezzo];
          if (_motivoMancante) {
            // FIX (migrazione Supabase): non esiste più una "colonna
            // Variazione" — questa nota diagnostica va scritta nel campo
            // note della carta, con una funzione dedicata che NON tocca
            // l'URL (a differenza del vecchio riuso di scriviUrl).
            // v5.21: attesa prima del rilascio di fine lotto (come
            // segnaControllata): da sql/111 il DB scrive solo su carte
            // ancora prenotate da chi chiama.
            chiamateSegnaControllataPendenti.push(
              _scriviEsitoDominio(rigaSheet, _motivoMancante).catch(() => {})
            );
          }
        } else {
          ndConsecutivi = 0;
          if (prezzoValido) aggiungiLog(rigaSheet, `Nuovo: ${pN}€`, 'ok');
        }
      }
      // FIX v5.21: prezzo trovato → la diagnosi di un giro precedente
      // ("Prezzo non trovato...", in carte.esito_controllo da sql/111) non
      // vale più. La funzione sul DB la toglie da sola solo se il prezzo
      // CAMBIA: con prezzo uguale, o variazione sotto soglia, restava lì per
      // sempre. Nota null = nessun esito.
      if (prezzoValido) {
        chiamateSegnaControllataPendenti.push(
          _scriviEsitoDominio(rigaSheet, null).catch(() => {})
        );
      }
      aggiornaTrend();

      // Segna la carta come "controllata ora" a prescindere da cosa succede
      // dopo (scrittura prezzo saltata per soloVariazioni, prezzo N/D, ecc.)
      // — è quello che tiene aggiornato l'ordinamento "più vecchie prima" in
      // 'leggi', permettendo alla sessione successiva di riprendere da sola
      // da dove questa si è fermata, rispettando anche il filtro location.
      _segnaControllataAsync(rigaSheet);

      // ── CONTRIBUTI AL GRUPPO (migration 37) ────────────────────────────
      // SECONDO PERCORSO DELL'AIUTO, dopo quello del worker autonomo in
      // background.js. Questo e' l'UNICO punto di SUCCESSO del ciclo: gli
      // altri otto _segnaControllataAsync sono tutti su rami di fallimento
      // (URL mancante, rate limit, Cloudflare non risolto, carta non
      // trovata nel DOM) e sono li' per il fix del loop infinito, non
      // perche' un lavoro sia stato portato a termine.
      //
      // PERCHE' QUI E NON DOPO scriviDati(): una carta col prezzo invariato
      // non produce nessuna scrittura di prezzo, ma e' stata comunque
      // aperta, letta e confrontata — e' lavoro fatto. Agganciarlo alla
      // scrittura conterebbe solo le carte il cui prezzo e' cambiato,
      // sottostimando di molto chi controlla le carte altrui.
      // Rientra qui anche il caso "prezzo N/D": la pagina e' stata aperta e
      // la carta verificata nel DOM, il prezzo semplicemente non c'era.
      //
      // Le righe PROPRIE le scarta la RPC lato database (p_owner_riga =
      // auth.uid() -> RETURN), non questo codice: chi decide cosa conta e'
      // il database, come per il worker autonomo.
      // Fire-and-forget, come in background.js: un errore nel contatore non
      // deve mai fermare il controllo prezzi, che a questo punto ha gia'
      // fatto il suo lavoro.
      registraAiutoGruppo(supabaseClient, rigaSheet, ownerId, AZ.tipoAiuto);

      // ── PAUSA ANTI-BOT PER N/D CONSECUTIVI ─────────────────────────────
      if (ndConsecutivi >= maxNd) {
        ndConsecutivi = 0;
        setStatus(`⚠️ ${maxNd} N/D di fila! Pausa anti-bot 30s...`, 'errore');
        aggiungiLog(null, `${maxNd} N/D consecutivi → pausa 30s`, 'errore');
        await attendiConCountdown(30000);
        if (stopRequested) break;
      }

      // ── SCRITTURA URL FILTRATO ───────────────────────────────────────────
      if (urlOriginale && !urlHaTuttiParametri(urlOriginale, lingua, condizione)) {
        // Log esplicito: mostra i parametri prima e dopo la riscrittura
        const _pVecchi   = new URLSearchParams(urlOriginale.includes('?') ? urlOriginale.split('?')[1] : '');
        const _langPre   = _pVecchi.get('language') || _pVecchi.get('idLanguage') || 'assente';
        const _condPre   = _pVecchi.get('minCondition') || 'assente';
        const _pNuovi    = new URLSearchParams(url.includes('?') ? url.split('?')[1] : '');
        const _langPost  = _pNuovi.get('language') || 'assente';
        const _condPost  = _pNuovi.get('minCondition') || 'assente';
        aggiungiLog(rigaSheet, `URL riscritto: lang ${_langPre}->${_langPost}, cond ${_condPre}->${_condPost} (foglio: "${lingua}"→id:${LINGUA_MAP_SHARED[(lingua||'').toUpperCase().trim()]||'?'}/${condizione})`, 'info');
        try {
          const esitoUrl = await _scriviUrlDominio(rigaSheet, url);
          // v5.17: anche il rifiuto del database (ok:false, senza eccezione).
          if (!esitoUrl || !esitoUrl.ok) {
            aggiungiLog(rigaSheet, `⚠️ URL non riscritto (${esitoUrl?.errore || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
          }
        } catch (eScrittura) {
          // FIX: non interrompere l'intera sessione per un "Failed to fetch"
          // isolato su una riga — logga e prosegui con le altre carte.
          aggiungiLog(rigaSheet, `⚠️ URL non riscritto (${eScrittura.message}) — riprova più tardi`, 'errore');
        }
      }

      // ── SCRITTURA PREZZO ─────────────────────────────────────────────────
      // soloVariazioni + soglia: scrivi solo se la variazione supera la soglia,
      // oppure se è un prezzo nuovo (riga prima vuota)
      const prezzoVariato = pV > 0 && pN > 0 && diffAss >= sogliaEuro;
      const prezzoNuovo   = pV === 0 && prezzoValido;

      if (!soloVariazioni || prezzoVariato || prezzoNuovo) {
        if (prezzoValido) {
          try {
            // FIX (immagine mai visibile): immagineTab è ancora un URL
            // esterno grezzo — Cardmarket lo blocca se richiesto da un altro
            // dominio (referer sbagliato). Chiediamo a background.js di
            // scaricarlo lui (privilegio di estensione, ignora il CORS sui
            // domini dichiarati in host_permissions) e convertirlo in un
            // dato incorporato prima di salvarlo.
            let immagineDaSalvare = immagineTab;
            if (immagineTab && !immagineTab.startsWith('data:')) {
              try {
                const rispostaImg = await new Promise((res, rej) => {
                  chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineTab }, (r) => {
                    if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message)); else res(r);
                  });
                });
                immagineDaSalvare = rispostaImg?.immagine || immagineTab;
              } catch (_) {
                // fallback silenzioso: salva comunque l'URL grezzo
              }
            }
            const esitoPrezzo = await _scriviPrezzoDominio(rigaSheet, nuovoPrezzo, immagineDaSalvare);
            // v5.17: anche il rifiuto del database (ok:false, senza eccezione) —
            // prima il log diceva "Salito/Sceso" ma il prezzo non era salvato.
            if (!esitoPrezzo || !esitoPrezzo.ok) {
              aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${esitoPrezzo?.errore || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
            }
          } catch (eScrittura) {
            // FIX: come sopra — un "Failed to fetch" isolato non deve
            // bloccare tutte le carte rimanenti della sessione.
            aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${eScrittura.message}) — riprova più tardi`, 'errore');
          }
        }
      } else {
        setStatus(`⏭️ ${_etichettaRiga(rigaSheet)}: Δ < ${sogliaEuro}€, saltata.`, 'info');
        aggiungiLog(rigaSheet, `Saltata (Δ < ${sogliaEuro}€)`, '');
        // FIX (immagine mai visibile su carte con prezzo stabile): prima,
        // se "Solo Variazioni" era attivo e il prezzo non cambiava
        // abbastanza, la scrittura veniva saltata DEL TUTTO — immagine
        // compresa, dato che vivevano nello stesso blocco condizionale. Ma
        // se abbiamo comunque appena letto un'immagine dalla pagina, non
        // c'è motivo di scartarla solo perché il prezzo non è variato: la
        // salviamo comunque, riscrivendo lo stesso prezzo già presente.
        if (immagineTab && !immagineTab.startsWith('data:')) {
          try {
            const rispostaImg = await new Promise((res, rej) => {
              chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineTab }, (r) => {
                if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message)); else res(r);
              });
            });
            const immagineConvertita = rispostaImg?.immagine || null;
            if (immagineConvertita) await _scriviPrezzoDominio(rigaSheet, pV, immagineConvertita);
          } catch (_) {
            // fallback silenzioso: nessuna immagine salvata questo giro, riproverà al prossimo controllo prezzi
          }
        }
      }

      // ── IMMAGINE: non più salvata nel foglio ─────────────────────────────
      // FIX: le immagini non vengono più scritte in colonna M (coerente col
      // resto dell'estensione — vedi background.js/aggiungi_carta_popup.js).
      // Prima questo blocco continuava a scrivere immagineTab in M a ogni
      // ricontrollo prezzo, anche dopo aver disattivato il salvataggio
      // immagini altrove.

      // ── AVANZA RIGA ─────────────────────────────────────────────────────
      avanzaRiga(rigaSheet);
      if (stopRequested) break;
      if (step + 1 >= carte.length) break;

      // ── DELAY ANTI-BOT ──────────────────────────────────────────────────
      // Pausa lunga ogni N carte (configurabile) per evitare Error 1015 —
      // FIX: deve contare sul totale cumulativo (stepGlobale), non sull'indice
      // locale al lotto corrente (ora piccolo apposta, vedi LOTTO_CONTROLLO_PREZZI)
      // altrimenti con lotti da 3 questa pausa non scatterebbe mai più.
      // Pausa lunga ogni N carte: ora la fa il turno Cardmarket comune
      // (background.js), contando le carte di TUTTI i flussi insieme —
      // ritmo.attendi() la aspetta e la mostra.
      // Attesa scelta con gli slider, contata da adesso (fine lavoro su
      // questa carta), con l'escalation Cloudflare già aggiornata. Vedi
      // creaRitmoCardmarket: la stessa attesa ora protegge anche i
      // "continue" e il passaggio tra un lotto e l'altro.
      ritmo.fissa();
      // Micro-pausa extra ogni 10 carte (indipendente dallo slider). Si
      // AGGIUNGE all'attesa scelta: prima la sostituiva, quindi con uno
      // slider sopra i 16 s accorciava l'attesa invece di allungarla. Conta
      // sul totale (stepGlobale): con lotti da 3, step+1 non arrivava mai a 10.
      if ((stepGlobale + 1) % 10 === 0) {
        ritmo.allunga(6000 + Math.floor(Math.random() * 10000));
        setStatus('☕ Pausa anti-bot...', 'info');
      }
      // v5.38: qui c'era un secondo "await ritmo.attendi()". Ogni attendi()
      // prende un turno nel background (_prenotaTurnoCardmarket), che conta
      // una carta e prenota un'attesa intera per la successiva: la carta
      // dopo, prima di aprire la pagina, aspettava una SECONDA volta. Ritmo
      // reale circa la metà degli slider e pausa lunga ogni N/2 carte (bug
      // dalla 5.26). Un solo turno per ogni richiesta a Cardmarket: l'attesa
      // fissata qui sopra (con la micro-pausa) la fa l'attendi() prima della
      // pagina successiva, su qualunque percorso e anche tra due lotti.
    }

    // FIX (loop infinito / carte ripetute): prima di chiedere il lotto
    // successivo, aspettiamo che TUTTE le scritture "segnaControllata" di
    // questo lotto siano davvero arrivate al database — vedi
    // _segnaControllataAsync più sopra. Un solo punto di attesa ogni
    // LOTTO_CONTROLLO_PREZZI carte (non una per carta): il costo in tempo è
    // trascurabile (una manciata di scritture piccole, già quasi certamente
    // concluse nel tempo impiegato ad aprire/leggere le pagine Cardmarket),
    // ma chiude la corsa che poteva far ripescare le stesse carte appena
    // controllate nel lotto successivo.
    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
      chiamateSegnaControllataPendenti = [];
    }

    // FIX (richiesta esplicita di Claudio, sessione 23/08/2026): prima il
    // rilascio delle carte prenotate (claimed_by/claimed_at) avveniva SOLO
    // a fine dell'intera sessione (vedi il blocco finally più sotto) — con
    // sessioni lunghe su tante carte, i lotti già processati restavano
    // "prenotati" per tutta la durata della sessione, anche se il loro
    // controllo prezzo era già scritto da un pezzo. Ora si rilascia SUBITO
    // il lotto appena finito, prima di chiederne uno nuovo: la dashboard
    // "Carte prenotate ora" mostra quindi sempre solo il lotto realmente in
    // lavorazione (fino a LOTTO_CONTROLLO_PREZZI), non la somma di tutti i
    // lotti già passati in questa sessione. Il rilascio finale nel blocco
    // finally resta com'era, come ultima rete di sicurezza (copre anche il
    // caso di stop/errore a metà di un lotto, dove queste righe potrebbero
    // non essere ancora state raggiunte).
    await chiamaSupabase(AZ.rilascia, { nomeDispositivo: nomeDisp }).catch(() => {});

    // Lotto esaurito — se non è stato richiesto lo stop, ne richiede subito
    // un altro (lasciando comunque, tra un lotto e l'altro, la finestra
    // naturale in cui un altro dispositivo online può reclamare la sua
    // parte, dato che i lotti sono piccoli apposta).
    //
    // FIX (loop infinito su collezioni piccole): con lotti piccoli
    // richiesti in continuazione, una carta appena controllata torna
    // comunque "ri-eleggibile" col tempo (niente la esclude per sempre) —
    // su una collezione piccola il giro ricomincia da capo indefinitamente
    // invece di fermarsi, perché prima (con un lotto unico enorme) la
    // sessione si fermava naturalmente finito quell'unico array. Ora si
    // ferma esplicitamente una volta processate tante carte quante ne
    // stimava il conteggio iniziale — un "giro completo", coerente col
    // comportamento di prima.
    //
    // FIX (loop infinito — non fidarsi solo di totaleStimato): rimosso il
    // controllo "totaleStimato > 0" che prima doveva essere vero perché la
    // sessione si fermasse — se il conteggio iniziale fosse per qualunque
    // motivo 0 o sbagliato, quel controllo disattivava del tutto la
    // condizione di stop. Ora, in aggiunta, numeroLottiElaborati fa da rete
    // di sicurezza assoluta e indipendente (vedi MAX_LOTTI_SICUREZZA sopra):
    // qualunque cosa succeda al conteggio, dopo quel tanti lotti la sessione
    // si ferma comunque.
    offsetLottiPrecedenti += carte.length;
    numeroLottiElaborati++;
    if (stopRequested || offsetLottiPrecedenti >= totaleStimato || numeroLottiElaborati > MAX_LOTTI_SICUREZZA) {
      if (!stopRequested && numeroLottiElaborati > MAX_LOTTI_SICUREZZA && offsetLottiPrecedenti < totaleStimato) {
        console.error('[TRACER controllo-prezzi] fermato dal limite di sicurezza — possibile problema nel conteggio iniziale o in una carta che continua a tornare eleggibile.');
        aggiungiLog(null, '⚠️ Fermato per limite di sicurezza (troppi lotti rispetto al conteggio iniziale) — se ricapita, segnalalo così controlliamo il log.', 'errore');
      }
      carte = [];
    } else {
      carte = await leggiDatiSheet(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI, nomeDisp, ordineId, AZ.leggi);
    }
    } // fine while (carte.length > 0)

    // Ultima rete di sicurezza: se la sessione finisce (per qualunque
    // motivo — fatto, fermato, o limite di sicurezza) con ancora scritture
    // "segnaControllata" in sospeso, le aspettiamo qui prima di proseguire,
    // così anche l'ultimo lotto risulta correttamente segnato.
    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
      chiamateSegnaControllataPendenti = [];
    }

    // ── FINE SESSIONE ────────────────────────────────────────────────────
    if (!stopRequested) {
      setProgress(100);
      const riepilogo = `✅ Fatto! ▲${cUp} ▼${cDown} ➖${cSteady}`;
      setStatus(riepilogo, 'ok');
      aggiungiLog(null, riepilogo, 'ok');
    } else {
      setStatus('🛑 Interrotto. La prossima sessione riprenderà automaticamente dalle carte non ancora controllate.', 'ok');
      aggiungiLog(null, 'Interrotto dall\'utente.', '');
    }

  } catch (err) {
    // FIX v5.17 (C8): lo stack trace ("DEBUG temporaneo") non va più nel
    // messaggio di stato — quel testo finisce in ordini.errore_msg, letto da
    // tutto il gruppo sul sito. Lo stack resta su questo dispositivo: console
    // e log locale dell'estensione.
    const stackBreve = (err.stack || '').split('\n').slice(0, 4).join(' | ');
    console.error('[controllo prezzi] errore:', err);
    setStatus('❌ Errore: ' + err.message, 'errore');
    aggiungiLog(null, '❌ ' + err.message + ' [STACK: ' + stackBreve + ']', 'errore');
  } finally {
    // FIX (Fase 8 — controllo prezzi condiviso): rilascia sempre le
    // prenotazioni di questa sessione, qualunque sia l'esito (fatto,
    // interrotto, errore) — così le carte tornano subito disponibili per
    // gli altri membri del gruppo invece di restare "bloccate" fino alla
    // scadenza naturale di 10 minuti lato server.
    chiamaSupabase(AZ.rilascia, { nomeDispositivo: nomeDisp }).catch(() => {});
    // FIX (troppe tab in sequenza → Cloudflare): chiude la tab riusata per
    // tutta la sessione di controllo prezzi — non serve più tenerla aperta
    // ora che il ciclo è finito, è stato fermato, o è andato in errore. Se
    // era già stata chiusa (es. dal ramo "Stop" in apriTabEAspettaPrezzo),
    // questa chiamata è un no-op innocuo.
    _chiudiTabControlloPrezzi();
    // FIX (sessione si blocca se la tab va in background per ore): ferma
    // l'audio silenzioso avviato da avviaAudioKeepAlive() — vedi commento
    // sul click di #btnAvvia. No-op sicuro se non era mai stato avviato
    // (es. sessione 🧪 Prova, che non lo attiva).
    fermaAudioKeepAlive();
    _segnaleOccupatoFerma(); // v5.17
    // FIX: garantisce sempre il reset dell'UI, anche in caso di eccezione
    resetUiPostSessione();
  }
}

// ── SESSIONE SEALED (controllo prezzi di gruppo) — Fase 1.2, 2026-09-12 ─────
// Funzione a SÉ, non un ramo dentro eseguiSessione() (decisione esplicita di
// Claudio, Regola d'Oro #1: più duplicazione, zero rischio sul flusso carte
// esistente). Avviata SOLO da ordine dal sito (ordini.tipo=
// 'controlla_prezzi_sealed', vedi _avviaAutorunSealedSeRichiesto più sotto)
// — nessun bottone manuale nella UI dell'estensione, quindi niente dry-run
// né lettura da elementi filtroLocation/aiutaGruppo del DOM (quei controlli
// restano quelli del pannello "Aggiorna prezzi" carte, condivisi solo per i
// parametri di RITMO — delay/CF timeout/soglia/pausa ogni N — che sono
// impostazioni generiche anti-bot verso lo stesso sito, non specifiche di
// carte o sealed).
//
// Differenze principali rispetto a eseguiSessione() (carte):
//  - niente lingua/condizione (i sealed non le hanno) — niente
//    costruisciUrlFiltrato/urlHaTuttiParametri/riscrittura URL.
//  - niente verificaCartaNelDom: la pagina /Products/ non ha lo stesso
//    schema di verifica delle /Singles/ — nome riletto solo come rete di
//    sicurezza per aggiornare prodotti_sealed.nome se mancante, MAI usato
//    per scartare la lettura (scelta di scope per la v1, segnalata a
//    Claudio: nessuna verifica anti-carta-sbagliata sui sealed).
//  - lettura prezzo via messaggio a background.js (LEGGI_PREZZO_SEALED_GRUPPO
//    → _leggiPrezzoSealed, chrome.scripting.executeScript con polling) invece
//    di apriTabEAspettaPrezzo/content.js — content.js è scritto per il DOM
//    delle pagine /Singles/ (.article-row con filtri lingua/condizione), non
//    trasferibile alle pagine /Products/.
//  - scrittura prezzo su prezzo_cardmarket (mai su prezzo, il prezzo di
//    vendita manuale) — vedi _supabaseToRigaLeggiSealed in
//    supabase_adapter.js e il commento su sql/39 nel file compilato.
const LOTTO_CONTROLLO_PREZZI_SEALED = 3;

async function contaEleggibiliControlloPrezziSealed(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto) {
  const data = await chiamaSupabase('leggiSealed', { filtroScaffali, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, soloConta: true });
  if (!data.ok) throw new Error(data.errore || 'Errore nel conteggio iniziale dei prodotti sealed da controllare.');
  return data.totale || 0;
}

async function leggiProdottiSealedDaControllare(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, lottoSize, nomeDisp) {
  const data = await chiamaSupabase('leggiSealed', { filtroScaffali, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, lottoSize, nomeDispositivo: nomeDisp });
  if (!data.ok) throw new Error(data.errore || 'Errore nel caricamento dei prodotti sealed.');
  return data.carte; // già mappati da _supabaseToRigaLeggiSealed lato adapter
}

// Equivalente di apriTabEAspettaPrezzo() ma per /Products/ — un solo
// scambio di messaggio con background.js (che gestisce internamente polling,
// Cloudflare, rate limit, worker tab riusata), non un ascolto di eventi
// broadcast come per le /Singles/ (content.js non gira sulle pagine
// /Products/). Ritorna gli stessi sentinel stringa di apriTabEAspettaPrezzo
// ('RateLimit','Cloudflare') o un oggetto {prezzo,nome,immagine} in caso di
// lettura riuscita, 'N/D' se la pagina è stata letta ma senza prezzo.
function apriTabELeggiPrezzoSealed(urlProdotto) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'LEGGI_PREZZO_SEALED_GRUPPO', urlProdotto, usaWorkerTab: true, turnoGiaPreso: true /* v5.26: preso da ritmo.attendi() */ }, (r) => {
      if (chrome.runtime.lastError || !r) { resolve('N/D'); return; }
      if (r.rateLimited)       { resolve('RateLimit');  return; }
      if (r.cloudflareTimeout) { resolve('Cloudflare'); return; }
      if (r.prezzo == null)    { resolve('N/D');        return; }
      resolve({ prezzo: r.prezzo, nome: r.nome, immagine: r.immagine });
    });
  });
}

async function eseguiSessioneSealed(overrides = {}) {
  await _aggiornaMioUserIdSessionePrezzi();
  // Fase 1.3 (2026-09-12, stesso giorno di 1.1/1.2): filtroScaffali al
  // posto di filtroLocation — location è sparita da prodotti_sealed
  // (sql/42), Scaffali (uuid[] di scaffale_id) l'ha sostituita come unico
  // organizzatore.
  const filtroScaffali  = overrides.filtroScaffali !== undefined ? overrides.filtroScaffali : [];
  const soloVariazioni  = document.getElementById('soloVariazioni').checked;
  const soloVecchie     = document.getElementById('soloVecchie').checked;
  const giorniMinimi    = parseInt(document.getElementById('giorniMinimi').value) || 3;
  const aiutaGruppo     = overrides.aiutaGruppo !== undefined ? overrides.aiutaGruppo : document.getElementById('aiutaGruppo').checked;
  const ownerIdRichiesto = overrides.ownerIdRichiesto || null;
  const delayMinSec     = parseInt(document.getElementById('sliderDelayMin').value) || DEFAULTS.sliderDelayMinSec;
  const delayMaxSec     = Math.max(parseInt(document.getElementById('sliderDelayMax').value) || DEFAULTS.sliderDelayMaxSec, delayMinSec);
  const sogliaIdx       = parseInt(document.getElementById('sliderSoglia').value);
  const sogliaEuro      = SOGLIA_VALUES[sogliaIdx] ?? 0.01;

  {
    const { data: _sessCheck } = await supabaseClient.auth.getSession();
    if (!_sessCheck.session) {
      setStatus('⚠️ Non sei loggato su Supabase — ricarica l\'estensione per rifare il login.', 'errore');
      return { ok: false, errore: 'Non loggato.' };
    }
  }

  if (isRunning) {
    setStatus('⚠️ Un\'altra sessione (carte) è già in corso — il controllo prezzi sealed riproverà al prossimo giro ordini.', 'errore');
    return { ok: false, errore: 'Sessione carte già in corso.' };
  }

  cUp = 0; cDown = 0; cSteady = 0; cErrori = 0;
  trendSalitiEntries = []; trendScesiEntries = [];
  isRunning = true; stopRequested = false;

  const nomeDisp = await nomeDispositivo();
  let cfConsecutivi = 0;
  let cfEscalationLevel = 0;
  let rateLimitRetryCorrente = 0;
  let chiamateSegnaControllataPendenti = [];
  const ritmo = creaRitmoCardmarket(delayMinSec, delayMaxSec, 0, () => cfEscalationLevel);
  function _segnaControllataSealedAsync(rigaSheet) {
    chiamateSegnaControllataPendenti.push(
      chiamaSupabase('segnaControllataSealed', { riga: rigaSheet }).catch((e) => {
        console.error('[segnaControllataSealed] errore:', e?.message || e);
      })
    );
  }

  let erroreFinale = null;
  try {
    await _attendiCodaCardmarketLibera(); // v5.29: un lavoro su Cardmarket alla volta
    _segnaleOccupatoAvvia(); // v5.17: vedi commento su CHIAVE_SEGNALE_OCCUPATO
    const filtroScaffaliLabel = Array.isArray(filtroScaffali) ? `${filtroScaffali.length} scaffale/i` : filtroScaffali;
    setStatus((Array.isArray(filtroScaffali) && filtroScaffali.length > 0) ? `📦 Controllo prezzi sealed (${filtroScaffaliLabel})...` : '📦 Controllo prezzi sealed...', 'info');

    const totaleStimato = await contaEleggibiliControlloPrezziSealed(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto);
    let prodotti = await leggiProdottiSealedDaControllare(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI_SEALED, nomeDisp);

    // Stessa rete di sicurezza anti-loop-infinito della versione carte — vedi
    // i commenti estesi su MAX_LOTTI_SICUREZZA dentro eseguiSessione().
    const MAX_LOTTI_SICUREZZA = Math.ceil((totaleStimato || prodotti.length) / LOTTO_CONTROLLO_PREZZI_SEALED) + 5;
    let numeroLottiElaborati = 1;

    if (prodotti.length === 0) {
      throw new Error(
        ((Array.isArray(filtroScaffali) && filtroScaffali.length > 0) ? `Nessun prodotto sealed con URL da controllare per ${filtroScaffaliLabel}.` : 'Nessun prodotto sealed con URL da controllare.')
      );
    }

    document.getElementById('timerContainer').classList.add('visible');
    const elTotale = document.getElementById('tempoTotale');
    const elAttesa = document.getElementById('tempoAttesa');
    let offsetLottiPrecedenti = 0;

    while (prodotti.length > 0) {
    for (let step = 0; step < prodotti.length; step++) {
      if (stopRequested) break;

      const { rigaSheet, urlBase, codice, nome, prezzoPrecedente, ownerId } = prodotti[step];
      _etichetteRiga[rigaSheet] = nome || codice || null;
      const stepGlobale = offsetLottiPrecedenti + step;

      if (!urlBase) {
        _logErroreCarta(rigaSheet, ownerId, `${_etichettaRiga(rigaSheet)}: nessun URL salvato, saltato`, 'err');
        cErrori++;
        _segnaControllataSealedAsync(rigaSheet);
        continue;
      }

      const mediaMs  = ((delayMinSec + delayMaxSec) / 2) * 1000 + 1200;
      const restanti = Math.max(totaleStimato - stepGlobale, prodotti.length - step);
      const stimaSec = restanti * ((15000 + mediaMs) / 1000);
      if (elTotale) elTotale.textContent = formattaTempo(stimaSec);

      setStatus(`📦 Sealed ${stepGlobale + 1}/${totaleStimato || prodotti.length} — ${_etichettaRiga(rigaSheet)}`, 'info');
      setProgress(totaleStimato > 0 ? Math.round((stepGlobale / totaleStimato) * 100) : 0);

      await ritmo.attendi();
      if (stopRequested) break;
      const risultato = await apriTabELeggiPrezzoSealed(urlBase);
      ritmo.fissa();
      const nuovoPrezzo = (risultato && typeof risultato === 'object') ? risultato.prezzo : risultato;

      if (stopRequested) break;

      // ── RATE LIMIT ──────────────────────────────────────────────────────
      if (nuovoPrezzo === 'RateLimit') {
        rateLimitRetryCorrente++;
        aggiungiLog(rigaSheet, 'Error 1015 (rate limited) → pausa 30 min', 'errore');
        setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti...', 'errore');
        await attendiConCountdown(PAUSA_RATE_LIMIT_MS);
        if (stopRequested) break;
        if (rateLimitRetryCorrente >= 3) {
          aggiungiLog(rigaSheet, 'Saltato dopo 3 rate limit consecutivi', 'errore');
          rateLimitRetryCorrente = 0;
          _segnaControllataSealedAsync(rigaSheet);
          continue;
        }
        step--;
        continue;
      }
      rateLimitRetryCorrente = 0;

      if (nuovoPrezzo === 'Cloudflare') {
        cfConsecutivi++;
        cfEscalationLevel = Math.min(cfEscalationLevel + 1, CF_ESCALATION_MAX_LEVEL);
        aggiungiLog(rigaSheet, 'Saltato (Cloudflare non risolto)', 'errore');
        setStatus(`⏭️ ${_etichettaRiga(rigaSheet)}: saltato (Cloudflare).`, 'errore');
        _segnaControllataSealedAsync(rigaSheet);
        if (cfConsecutivi >= 2) {
          cfConsecutivi = 0;
          setStatus('🚫 2 Cloudflare consecutivi → pausa anti-ban 2 min...', 'errore');
          aggiungiLog(null, '2 Cloudflare consecutivi → pausa 2 min', 'errore');
          await attendiConCountdown(120000);
          if (stopRequested) break;
        }
        continue;
      }
      cfConsecutivi = 0;
      if (cfEscalationLevel > 0) cfEscalationLevel--;

      // ── CONFRONTO PREZZI ────────────────────────────────────────────────
      const pV = pulisciPrezzo(prezzoPrecedente);
      const pN = pulisciPrezzo(nuovoPrezzo);
      const diffAss  = Math.abs(pN - pV);
      const varTesto = calcolaVariazione(pV, pN);
      // FIX v5.17 (prezzo sealed mai salvato): nuovoPrezzo qui è già il
      // NUMERO estratto da risultato.prezzo (vedi sopra), mai un oggetto —
      // il vecchio controllo "typeof nuovoPrezzo === 'object'" era quindi
      // sempre falso e la scrittura più sotto non partiva mai. La validità si
      // controlla sull'oggetto restituito da apriTabELeggiPrezzoSealed.
      const prezzoValido = !!risultato && typeof risultato === 'object' && typeof risultato.prezzo === 'number';

      if (pV > 0 && pN > 0) {
        if (diffAss < 0.005) {
          cSteady++;
          aggiungiLog(rigaSheet, `Stabile a ${pN}€`, 'ok');
        } else if (pN > pV) {
          cUp++;
          trendSalitiEntries.push({ riga: rigaSheet, nome: codice || nome || '', testo: `${pV}€ → ${pN}€ ${varTesto}` });
          aggiungiLog(rigaSheet, `Salito: ${pV}€ → ${pN}€ ${varTesto}`, 'up');
        } else {
          cDown++;
          trendScesiEntries.push({ riga: rigaSheet, nome: codice || nome || '', testo: `${pV}€ → ${pN}€ ${varTesto}` });
          aggiungiLog(rigaSheet, `Sceso: ${pV}€ → ${pN}€ ${varTesto}`, 'down');
        }
      } else {
        cSteady++;
        if (nuovoPrezzo === 'N/D') _logErroreCarta(rigaSheet, ownerId, 'N/D');
        else if (prezzoValido) aggiungiLog(rigaSheet, `Nuovo: ${pN}€`, 'ok');
      }
      aggiornaTrend();

      _segnaControllataSealedAsync(rigaSheet);
      registraAiutoGruppo(supabaseClient, rigaSheet, ownerId, 'controllo_prezzi_sealed');

      // ── SCRITTURA PREZZO ─────────────────────────────────────────────────
      const prezzoVariato = pV > 0 && pN > 0 && diffAss >= sogliaEuro;
      const prezzoNuovo   = pV === 0 && prezzoValido;
      if ((!soloVariazioni || prezzoVariato || prezzoNuovo) && prezzoValido) {
        try {
          let immagineDaSalvare = risultato.immagine;
          if (immagineDaSalvare && !immagineDaSalvare.startsWith('data:')) {
            try {
              const rispostaImg = await new Promise((res, rej) => {
                chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineDaSalvare }, (r) => {
                  if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message)); else res(r);
                });
              });
              immagineDaSalvare = rispostaImg?.immagine || immagineDaSalvare;
            } catch (_) { /* fallback silenzioso: salva comunque l'URL grezzo */ }
          }
          // FIX v5.17: prezzo preso dall'oggetto risultato (nuovoPrezzo è un
          // numero, nuovoPrezzo.prezzo era undefined) e esito controllato —
          // chiamaSupabase non lancia eccezioni, restituisce { ok:false } in
          // caso di errore: senza questo controllo un fallimento restava muto.
          const esitoScrittura = await chiamaSupabase('aggiornaPrezzoRigaSealed', { riga: rigaSheet, prezzo: risultato.prezzo, immagine: immagineDaSalvare || undefined });
          if (!esitoScrittura || !esitoScrittura.ok) {
            aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${(esitoScrittura && esitoScrittura.errore) || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
          }
        } catch (eScrittura) {
          aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${eScrittura.message}) — riprova più tardi`, 'errore');
        }
      }

      if (stopRequested) break;
      if (step + 1 >= prodotti.length) break;

      // ── DELAY ANTI-BOT (stessa logica della versione carte) ─────────────
      // Pausa lunga ogni N: la fa il turno Cardmarket comune (vedi carte).
      // Vedi la versione carte (creaRitmoCardmarket): l'attesa vale anche
      // per i "continue" e tra un lotto e l'altro; la micro-pausa si somma.
      ritmo.fissa();
      if ((stepGlobale + 1) % 10 === 0) ritmo.allunga(6000 + Math.floor(Math.random() * 10000));
      // v5.38: tolto il secondo "await ritmo.attendi()" (vedi la versione
      // carte): un solo turno Cardmarket per ogni richiesta.
    }

    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
      chiamateSegnaControllataPendenti = [];
    }
    await chiamaSupabase('rilasciaClaimSealed', { nomeDispositivo: nomeDisp }).catch(() => {});

    offsetLottiPrecedenti += prodotti.length;
    numeroLottiElaborati++;
    if (stopRequested || offsetLottiPrecedenti >= totaleStimato || numeroLottiElaborati > MAX_LOTTI_SICUREZZA) {
      prodotti = [];
    } else {
      prodotti = await leggiProdottiSealedDaControllare(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI_SEALED, nomeDisp);
    }
    } // fine while

    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
    }

    if (!stopRequested) {
      const riepilogo = `✅ Sealed fatto! ▲${cUp} ▼${cDown} ➖${cSteady}`;
      setStatus(riepilogo, 'ok');
      aggiungiLog(null, riepilogo, 'ok');
    } else {
      setStatus('🛑 Controllo prezzi sealed interrotto.', 'ok');
    }
  } catch (err) {
    erroreFinale = err.message;
    setStatus('❌ Errore controllo prezzi sealed: ' + err.message, 'errore');
    aggiungiLog(null, '❌ ' + err.message, 'errore');
  } finally {
    await chiamaSupabase('rilasciaClaimSealed', { nomeDispositivo: nomeDisp }).catch(() => {});
    // v5.17: chiude la worker tab dei sealed usata da LEGGI_PREZZO_SEALED_GRUPPO
    // (usaWorkerTab:true) — prima restava aperta su Cardmarket a fine sessione.
    chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'sealed' });
    _segnaleOccupatoFerma(); // v5.17
    resetUiPostSessione();
  }

  return erroreFinale ? { ok: false, errore: erroreFinale } : { ok: true, salite: cUp, scese: cDown, invariate: cSteady };
}

// Consumato all'avvio, stesso schema di _avviaAutorunSeRichiesto (carte) e
// _avviaAutorunPrezziWishlistSeRichiesto (wishlist) — chiave di storage
// separata (ordinePendenteAutorunSealed) così un ordine sealed e un ordine
// carte pendenti nello stesso momento non si sovrascrivono a vicenda.
async function _avviaAutorunSealedSeRichiesto() {
  const { ordinePendenteAutorunSealed } = await chrome.storage.local.get('ordinePendenteAutorunSealed');
  if (!ordinePendenteAutorunSealed || ordinePendenteAutorunSealed.tipo !== 'controlla_prezzi_sealed') return;

  await chrome.storage.local.remove('ordinePendenteAutorunSealed');
  if (isRunning) {
    // Una sessione (carte o sealed) è già in corso — v5.17: l'ordine torna in
    // attesa invece di restare "in corso" per sempre.
    await _rimettiOrdineInAttesa(ordinePendenteAutorunSealed.id);
    return;
  }

  const ordineId = ordinePendenteAutorunSealed.id;
  const scaffali = ordinePendenteAutorunSealed.parametri?.scaffali;
  const aiutaGruppoOrdine = ordinePendenteAutorunSealed.parametri?.aiutaGruppo;
  const creatoDa = ordinePendenteAutorunSealed.creatoDa;
  await assicuraLoginSupabase();

  setStatus('🤖 Ordine ricevuto dal sito — avvio controllo prezzi sealed...', 'info');
  const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordineId); // v5.22
  let esito;
  try {
    esito = await eseguiSessioneSealed({
      filtroScaffali: Array.isArray(scaffali) ? scaffali : [],
      ...(aiutaGruppoOrdine !== undefined ? { aiutaGruppo: aiutaGruppoOrdine } : {}),
      ...(creatoDa ? { ownerIdRichiesto: creatoDa } : {}),
    });
  } finally {
    if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
  }
  if (_ordineAnnullatoDalSito) return; // v5.22: resta 'annullato'

  try {
    if (!esito.ok) {
      await supabaseClient.from('ordini').update({
        stato: 'errore',
        errore_msg: esito.errore || 'Errore sconosciuto durante il controllo prezzi sealed.',
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'completato',
        risultato: { salite: esito.salite, scese: esito.scese, invariate: esito.invariate },
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    }
  } catch (e) {
    console.error('[ordini sealed] impossibile scrivere l\'esito sull\'ordine:', e);
  }
}

// Helper: con il vecchio Google Sheet teneva traccia di "a che riga
// riprendere" per sessioni interrotte (rigaSheet era un numero progressivo).
// Con Supabase "rigaSheet" è l'ID della carta (una stringa, non un numero) e
// la lettura della collezione non è più paginata per riga — chiamaSupabase
// 'leggi' restituisce sempre tutta la collezione. Questa funzione non ha
// più nulla da fare, ma resta come no-op innocuo per non rompere le
// chiamate esistenti nel resto del file.
function avanzaRiga(rigaSheet) {
  // intenzionalmente vuota
}

// ── APERTURA HUB (app.html) — UNA SOLA TAB PER TUTTE LE SEZIONI ─────────────
// FIX (troppe tab aperte): Carte/Sealed/Wishlist/Anteprima aprivano ciascuna
// la propria tab con chrome.tabs.create — con tutte e 4 aperte insieme si
// finiva con 4 tab aggiuntive oltre a quella su cui si stava già lavorando.
// Ora convergono tutte su un'unica pagina "hub" (app.html), che le ospita
// come iframe con una tab-bar interna per passare dall'una all'altra senza
// aprire nuove tab del browser. Se l'hub è già aperto in una tab, la si porta
// in primo piano e le si manda un messaggio per cambiare sezione, invece di
// aprirne un'altra copia.
function apriApp(sezione) {
  const urlHub = chrome.runtime.getURL('app.html');
  chrome.tabs.query({ url: urlHub + '*' }, (tabs) => {
    if (tabs && tabs.length > 0) {
      const tab = tabs[0];
      chrome.tabs.update(tab.id, { active: true }, () => {
        chrome.windows.update(tab.windowId, { focused: true });
        // runtime.sendMessage (non tabs.sendMessage): raggiunge qualunque
        // contesto dell'estensione con un listener attivo, incluse le
        // pagine dell'estensione aperte come tab (app.html) — tabs.sendMessage
        // è pensato per i content script iniettati in una pagina web, non è
        // garantito raggiungere una pagina dell'estensione stessa.
        chrome.runtime.sendMessage({ type: 'CARDSYNC_APRI_SEZIONE', sezione });
      });
    } else {
      chrome.tabs.create({ url: urlHub + '#' + sezione, active: true });
    }
  });
}

// ── APRI IN UNA TAB (dal popup compatto della toolbar) ───────────────────────
document.getElementById('apriTabLink')?.addEventListener('click', () => {
  apriApp('prezzi');
});

// v5.17: tolti i bottoni del riquadro "Novità?" (Carte/Wishlist/Scambi/
// Vendite) insieme al riquadro in popup.html — vedi il commento lì.

// ── EASTER EGG ────────────────────────────────────────────────────────────────
(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('footer-credit');
  if (!footer) return;
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

// ── PULSANTI ──────────────────────────────────────────────────────────────────
// ── VERIFICA LOGIN CARDMARKET ────────────────────────────────────────────────
// Il controllo "carrello cliccabile" (rigaCarrelloCliccabile in content.js/
// background.js) richiede di essere loggati su Cardmarket nella finestra che
// legge i prezzi — senza login ogni riga viene scartata e ogni carta risulta
// "Esaurita". La verifica qui sotto controlla il login vero prima di ogni
// avvio, bloccando per davvero se risulta chiaramente non loggato.
async function _richiediConfermaLogin(onConferma) {
  setStatus('🔍 Verifico il login su Cardmarket...', 'info');
  let risposta;
  try {
    risposta = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_SILENZIOSA' }, (r) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(r);
      });
    });
  } catch (e) {
    // v5.17: senza login confermato la sessione NON parte più (prima
    // "procedo comunque": senza login ogni carta risultava "Esaurita").
    setStatus('⚠️ Impossibile verificare il login su Cardmarket (' + e.message + ') — riprova tra poco.', 'errore');
    return;
  }

  if (risposta && risposta.loggato === false) {
    setStatus('🔒 Non risulti loggato su Cardmarket — ho aperto una tab per te: accedi e riprova.', 'errore');
    return; // blocca per davvero, non chiama onConferma()
  }
  if (!risposta || risposta.loggato !== true) {
    // v5.17: "non confermato" (pagina lenta, Cloudflare, tab chiusa) blocca
    // come "non loggato" — background.js ha già portato la tab in primo piano.
    setStatus('🔒 Non riesco a confermare il login su Cardmarket — controlla la scheda aperta (login o verifica Cloudflare) e riprova.', 'errore');
    return;
  }
  onConferma();
}

document.getElementById('btnAvvia').addEventListener('click', async () => {
  if (isRunning) {
    stopRequested = true;
    document.getElementById('btnAvvia').disabled    = true;
    document.getElementById('btnAvvia').textContent = '⏱️ Arresto...';
    setStatus('⏳ Finisco la carta attuale e mi fermo...', 'info');
    return;
  }
  // FIX (sessione si blocca se la tab va in background per ore, es. lasciata
  // aperta la notte): avviato qui, PRIMA di qualunque await, per non perdere
  // il gesto utente richiesto dal browser per autorizzare l'audio — vedi
  // avviaAudioKeepAlive() in shared.js. Fermato in eseguiSessione(), nel
  // blocco finally.
  avviaAudioKeepAlive();
  if (!(await verificaAccessoValido())) {
    fermaAudioKeepAlive();
    return; // account bannato/eliminato: overlay già mostrato da auth_ui.js
  }
  _richiediConfermaLogin(async () => {
    await eseguiSessione(false);
  });
});

// ── BUG REPORT ────────────────────────────────────────────────────────────────
// FIX: un link mailto: dentro il popup reale dell'estensione spesso non apre
// il client di posta — Chrome tende a chiudere il popup non appena perde il
// focus, il che capita proprio nell'istante in cui il browser tenta di
// passare la mano al gestore mail di sistema. Aprendo il link in una tab vera
// (chrome.tabs.create) il popup può chiudersi tranquillamente senza
// interrompere l'operazione.
document.getElementById('bugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});

// ── CHANGELOG ─────────────────────────────────────────────────────────────────
document.getElementById('changelogLink').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

// ── ANTEPRIMA FOGLIO ─────────────────────────────────────────────────────────
document.getElementById('anteprimaLink').addEventListener('click', () => {
  apriApp('anteprima');
});
