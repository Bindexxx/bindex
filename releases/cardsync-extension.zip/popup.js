// Pagina "Prezzi" (controllo prezzi), dentro app.html (#prezzi) o aperta da sola.
// Le carte degli altri restano anonime: "del gruppo", mai il nickname.

assicuraLoginSupabase();

const CAMPI = [];

const DEFAULTS = {
  sliderDelayMinSec: 10,
  sliderDelayMaxSec: 20,
  sliderCfTimeout:   3,
  sliderSoglia:      0,
  sliderMaxNd:       5,
  sliderPausaOgni:   2,
  soloVariazioni:    false,
  avvisoSonoro:      true,
};

const DELAY_SEC_MIN = 1;
const DELAY_SEC_MAX = 60;

const PAUSA_OGNI_LABELS  = ['25', '50', '75', '100', 'Mai'];
const CF_LABELS     = ['1 min','2 min','3 min','4 min','5 min','6 min','7 min','8 min','9 min','10 min'];
const SOGLIA_LABELS = ['0,01 €','0,05 €','0,10 €','0,20 €','0,50 €','1,00 €','2,00 €'];
const SOGLIA_VALUES = [0.01, 0.05, 0.10, 0.20, 0.50, 1.00, 2.00];
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];

let isRunning     = false;
let stopRequested = false;
let cUp = 0, cDown = 0, cSteady = 0, cErrori = 0;
let logEntries = [];
let trendSalitiEntries = [];
let trendScesiEntries  = [];

const gearBtn       = document.getElementById('gearBtn');
const settingsPanel = document.getElementById('settingsPanel');

function toggleSettingsPanel() {
  const aperto = settingsPanel.classList.toggle('visible');
  gearBtn.classList.toggle('open', aperto);
  gearBtn.setAttribute('aria-expanded', String(aperto));
}

gearBtn.addEventListener('click', toggleSettingsPanel);
document.getElementById('btnAltreOpzioni').addEventListener('click', () => {
  toggleSettingsPanel();
  document.getElementById('btnAltreOpzioni').setAttribute('aria-expanded', String(settingsPanel.classList.contains('visible')));
});

window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CARDSYNC_TOGGLE_SETTINGS') toggleSettingsPanel();
  if (e.data && e.data.type === 'CARDSYNC_REFRESH_LOCATION') popolaTendinaLocation();
  if (e.data && e.data.type === 'CARDSYNC_ORDINE_ARRIVATO' && _paginaPronta) _avviaAutorunOrdini();
  if (e.data && e.data.type === 'CARDSYNC_FERMA' && e.source === window.parent && window.parent !== window && isRunning && !stopRequested) {
    document.getElementById('btnAvvia').click();
  }
});

const legendaToggle = document.getElementById('legendaToggle');
const legendaBody   = document.getElementById('legendaBody');

legendaToggle.addEventListener('click', () => {
  const aperto = legendaBody.classList.toggle('visible');
  legendaToggle.classList.toggle('open', aperto);
  legendaToggle.setAttribute('aria-expanded', String(aperto));
});

if (!document.body.classList.contains('embedded-in-hub')) {
  legendaBody.classList.add('visible');
  legendaToggle.classList.add('open');
  legendaToggle.setAttribute('aria-expanded', 'true');
}

const SLIDERS = [
  { id: 'sliderCfTimeout', labelId: 'valCfTimeout', fn: v => CF_LABELS[v - 1]          ?? CF_LABELS[2]        },
  { id: 'sliderSoglia',    labelId: 'valSoglia',    fn: v => SOGLIA_LABELS[v]           ?? SOGLIA_LABELS[0]    },
  { id: 'sliderMaxNd',     labelId: 'valMaxNd',     fn: v => String(v)                                         },
  { id: 'sliderPausaOgni', labelId: 'valPausaOgni', fn: v => PAUSA_OGNI_LABELS[v]      ?? PAUSA_OGNI_LABELS[1] },
];

function aggiornaLabelSlider({ labelId, fn }, val) {
  document.getElementById(labelId).textContent = fn(val);
}

SLIDERS.forEach(slider => {
  document.getElementById(slider.id).addEventListener('input', (e) => {
    const v = parseInt(e.target.value);
    aggiornaLabelSlider(slider, v);
    chrome.storage.local.set({ [slider.id]: v });
  });
});

function aggiornaLabelCfTimeout(val) { aggiornaLabelSlider(SLIDERS[0], val); }
function aggiornaLabelSoglia(val)    { aggiornaLabelSlider(SLIDERS[1], val); }
function aggiornaLabelMaxNd(val)     { aggiornaLabelSlider(SLIDERS[2], val); }
function aggiornaLabelPausaOgni(val) { aggiornaLabelSlider(SLIDERS[3], val); }

function aggiornaLabelDelayMinMax() {
  const vMin = document.getElementById('sliderDelayMin').value;
  const vMax = document.getElementById('sliderDelayMax').value;
  document.getElementById('valDelayMin').textContent = vMin + 's';
  document.getElementById('valDelayMax').textContent = vMax + 's';
}

document.getElementById('sliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('sliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelDelayMinMax();
  chrome.storage.local.set({
    sliderDelayMinSec: vMin,
    sliderDelayMaxSec: parseInt(sliderMax.value),
  });
});

document.getElementById('sliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('sliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelDelayMinMax();
  chrome.storage.local.set({
    sliderDelayMinSec: parseInt(sliderMin.value),
    sliderDelayMaxSec: vMax,
  });
});

document.getElementById('btnResetDefaults').addEventListener('click', () => {
  document.getElementById('sliderDelayMin').value   = DEFAULTS.sliderDelayMinSec;
  document.getElementById('sliderDelayMax').value   = DEFAULTS.sliderDelayMaxSec;
  document.getElementById('sliderCfTimeout').value  = DEFAULTS.sliderCfTimeout;
  document.getElementById('sliderSoglia').value     = DEFAULTS.sliderSoglia;
  document.getElementById('sliderMaxNd').value      = DEFAULTS.sliderMaxNd;
  document.getElementById('sliderPausaOgni').value  = DEFAULTS.sliderPausaOgni;
  document.getElementById('soloVariazioni').checked = DEFAULTS.soloVariazioni;
  document.getElementById('avvisoSonoro').checked   = DEFAULTS.avvisoSonoro;
  aggiornaLabelDelayMinMax();
  aggiornaLabelCfTimeout(DEFAULTS.sliderCfTimeout);
  aggiornaLabelSoglia(DEFAULTS.sliderSoglia);
  aggiornaLabelMaxNd(DEFAULTS.sliderMaxNd);
  aggiornaLabelPausaOgni(DEFAULTS.sliderPausaOgni);
  chrome.storage.local.set({
    sliderDelayMinSec: DEFAULTS.sliderDelayMinSec,
    sliderDelayMaxSec: DEFAULTS.sliderDelayMaxSec,
    sliderCfTimeout: DEFAULTS.sliderCfTimeout,
    sliderSoglia:    DEFAULTS.sliderSoglia,
    sliderMaxNd:     DEFAULTS.sliderMaxNd,
    sliderPausaOgni: DEFAULTS.sliderPausaOgni,
    soloVariazioni:  DEFAULTS.soloVariazioni,
    avvisoSonoro:    DEFAULTS.avvisoSonoro,
  });
  setStatus('✅ Impostazioni ripristinate ai valori predefiniti.', 'ok');
});

document.getElementById('soloVariazioni').addEventListener('change', (e) => {
  chrome.storage.local.set({ soloVariazioni: e.target.checked });
});
document.getElementById('soloVecchie').addEventListener('change', (e) => {
  chrome.storage.local.set({ soloVecchie: e.target.checked });
  document.getElementById('giorniMinimi').disabled = !e.target.checked;
});
document.getElementById('giorniMinimi').addEventListener('input', (e) => {
  chrome.storage.local.set({ giorniMinimi: e.target.value });
});
document.getElementById('aiutaGruppo').addEventListener('change', (e) => {
  chrome.storage.local.set({ aiutaGruppo: e.target.checked });
});
document.getElementById('mantieniAccessoEstensione').addEventListener('change', (e) => {
  chrome.storage.local.set({ cardsyncMantieniAccessoEstensione: e.target.checked });
});
document.getElementById('avvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

CAMPI.forEach(id => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('input', () => chrome.storage.local.set({ [id]: el.value }));
});

chrome.storage.local.get(
  [...CAMPI, 'soloVariazioni', 'soloVecchie', 'giorniMinimi', 'aiutaGruppo', 'avvisoSonoro',
   'sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec',
   'sliderCfTimeout', 'sliderSoglia', 'sliderMaxNd', 'sliderPausaOgni', 'ultimoUtilizzo',
   'filtroLocationSelezionata', 'cardsyncMantieniAccessoEstensione'],
  (saved) => {
    CAMPI.forEach(id => {
      const el = document.getElementById(id);
      if (el && saved[id] !== undefined) el.value = saved[id];
    });

    document.getElementById('soloVariazioni').checked = saved.soloVariazioni ?? DEFAULTS.soloVariazioni;
    document.getElementById('soloVecchie').checked    = saved.soloVecchie    ?? false;
    document.getElementById('giorniMinimi').value     = saved.giorniMinimi  ?? 3;
    document.getElementById('giorniMinimi').disabled = !document.getElementById('soloVecchie').checked;
    document.getElementById('aiutaGruppo').checked    = saved.aiutaGruppo   ?? false;
    document.getElementById('avvisoSonoro').checked   = saved.avvisoSonoro   ?? DEFAULTS.avvisoSonoro;
    document.getElementById('mantieniAccessoEstensione').checked = saved.cardsyncMantieniAccessoEstensione ?? true;

    let vDelayMin = saved.sliderDelayMinSec;
    let vDelayMax = saved.sliderDelayMaxSec;
    if (vDelayMin === undefined || vDelayMax === undefined) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        [vDelayMin, vDelayMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      } else {
        vDelayMin = DEFAULTS.sliderDelayMinSec;
        vDelayMax = DEFAULTS.sliderDelayMaxSec;
      }
      chrome.storage.local.set({ sliderDelayMinSec: vDelayMin, sliderDelayMaxSec: vDelayMax });
    }

    const vCf    = saved.sliderCfTimeout ?? DEFAULTS.sliderCfTimeout;
    const vSogl  = saved.sliderSoglia    ?? DEFAULTS.sliderSoglia;
    const vMaxNd     = saved.sliderMaxNd     ?? DEFAULTS.sliderMaxNd;
    const vPausaOgni = saved.sliderPausaOgni ?? DEFAULTS.sliderPausaOgni;

    document.getElementById('sliderDelayMin').value  = vDelayMin;
    document.getElementById('sliderDelayMax').value  = vDelayMax;
    document.getElementById('sliderCfTimeout').value = vCf;
    document.getElementById('sliderSoglia').value    = vSogl;
    document.getElementById('sliderMaxNd').value      = vMaxNd;
    document.getElementById('sliderPausaOgni').value  = vPausaOgni;
    aggiornaLabelDelayMinMax();
    aggiornaLabelCfTimeout(vCf);
    aggiornaLabelSoglia(vSogl);
    aggiornaLabelMaxNd(vMaxNd);
    aggiornaLabelPausaOgni(vPausaOgni);

    const elUU = document.getElementById('ultimoUtilizzo');
    if (elUU) {
      elUU.textContent = saved.ultimoUtilizzo
        ? '🕐 Ultimo utilizzo: ' + formattaDataOra(saved.ultimoUtilizzo)
        : '🕐 Ultimo utilizzo: mai';
    }

    popolaTendinaLocation().then(() => {
      const selectLoc = document.getElementById('filtroLocation');
      if (selectLoc && saved.filtroLocationSelezionata) {
        selectLoc.value = saved.filtroLocationSelezionata;
      }
      _paginaPronta = true;
      _avviaAutorunOrdini().then(async () => {
        const { aiutaGruppo } = await chrome.storage.local.get('aiutaGruppo');
        if (!aiutaGruppo) return;

        if (!isRunning) {
          _unisciteControlloPrezziInCorsoSeCe().then(() => {
            if (!isRunning) _avviaControlloPrezziSeInattivo();
          });
        }
      });
    });
  }
);

async function _unisciteControlloPrezziInCorsoSeCe() {
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    if (!sessionData?.session?.user?.id) return;

    const sogliaIso = new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
    const { data: inCorso } = await supabaseClient
      .from('ordini')
      .select('id, tipo, parametri, creato_da')
      .in('tipo', ['controlla_prezzi', 'controlla_prezzi_wishlist'])
      .eq('stato', 'in_corso')
      .or(`preso_in_carico_il.gt.${sogliaIso},attivo_il.gt.${sogliaIso}`)
      .order('preso_in_carico_il', { ascending: false })
      .limit(1);

    if (!inCorso || inCorso.length === 0) return;
    if (isRunning) return;
    if (await _codaCardmarketOccupataQui()) return;

    if (!(await _loginCardmarketAutomaticoOk())) return;
    if (isRunning) return;

    const ordine = inCorso[0];
    const locations = ordine.parametri?.locations;
    const aiutaGruppoOrdine = ordine.parametri?.aiutaGruppo;

    setStatus(ordine.tipo === 'controlla_prezzi_wishlist'
      ? '🤝 Controllo prezzi wishlist in corso nel gruppo — mi unisco per aiutare...'
      : '🤝 Controllo prezzi già in corso nel gruppo — mi unisco per aiutare...', 'info');
    const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordine.id);
    try {
      if (ordine.tipo === 'controlla_prezzi_wishlist') {
        await eseguiSessione({ dominio: 'wishlist', ordineId: ordine.id, aiutaGruppo: true });
        return;
      }
      await eseguiSessione({
        filtroLocation: Array.isArray(locations) ? locations : [],
        ...(aiutaGruppoOrdine !== undefined ? { aiutaGruppo: aiutaGruppoOrdine } : {}),
        ...(ordine.creato_da ? { ownerIdRichiesto: ordine.creato_da } : {}),
        ordineId: ordine.id,
      });
    } finally {
      if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
    }
  } catch (e) {
    console.error('[unisciti controllo prezzi] errore:', e.message);
  }
}

const GIORNI_MINIMI_INATTIVITA = 7;
const CARTE_CODA_PER_LOTTO_PREZZI = 25;
let _sessioneAutoInattivita = false;

async function _codaCardmarketOccupataQui() {
  try {
    const v = await chrome.storage.local.get(['sessioneCodaAttiva_carte', 'workerAutonomoAttivo']);
    const vivo = (x) => !!x && typeof x.scadenza === 'number' && x.scadenza > Date.now();
    return vivo(v.sessioneCodaAttiva_carte) || vivo(v.workerAutonomoAttivo);
  } catch (_) {
    return false;
  }
}

async function _attendiCodaCardmarketLibera() {
  let avvisato = false;
  while (!stopRequested && (await _codaCardmarketOccupataQui())) {
    if (!avvisato) {
      setStatus('⏳ In attesa: su questo PC la coda "Aggiungi carte" sta lavorando — il controllo prezzi parte appena finisce.', 'info');
      avvisato = true;
    }
    await new Promise((r) => setTimeout(r, 5000));
  }
}

const CHIAVE_SEGNALE_OCCUPATO = 'sessionePrezziAttiva_prezzi';
let _timerSegnaleOccupato = null;

function _segnaleOccupatoAvvia() {
  const scrivi = () => chrome.storage.local.set({ [CHIAVE_SEGNALE_OCCUPATO]: { scadenza: Date.now() + 3 * 60 * 1000 } });
  scrivi();
  chrome.storage.local.remove('prezziInPartenza');
  if (_timerSegnaleOccupato) clearInterval(_timerSegnaleOccupato);
  _timerSegnaleOccupato = setInterval(scrivi, 30000);
}

function _segnaleOccupatoFerma() {
  if (_timerSegnaleOccupato) { clearInterval(_timerSegnaleOccupato); _timerSegnaleOccupato = null; }
  chrome.storage.local.remove(CHIAVE_SEGNALE_OCCUPATO);
}

async function _rimettiOrdineInAttesa(ordineId) {
  try {
    const { error } = await supabaseClient.from('ordini')
      .update({ stato: 'pending', preso_in_carico_da: null, preso_in_carico_il: null })
      .eq('id', ordineId)
      .eq('stato', 'in_corso');
    if (error) console.error('[ordini] impossibile rimettere in attesa:', error.message);
  } catch (e) {
    console.error('[ordini] impossibile rimettere in attesa:', e.message);
  }
}

let _ordineAnnullatoDalSito = false;

function _sorvegliaAnnullamentoOrdine(ordineId) {
  _ordineAnnullatoDalSito = false;
  if (!ordineId) return () => false;
  const timer = setInterval(async () => {
    if (!isRunning || stopRequested) return;
    try {
      const { data } = await supabaseClient.from('ordini').select('stato').eq('id', ordineId).maybeSingle();
      if (data && data.stato === 'annullato') {
        _ordineAnnullatoDalSito = true;
        stopRequested = true;
        setStatus('🛑 Controllo annullato dal sito — finisco la carta attuale e mi fermo...', 'info');
      }
    } catch (_) {   }
  }, 5000);
  return () => { clearInterval(timer); return _ordineAnnullatoDalSito; };
}

function _segnalaAnnullamentoOrdine() {
  setStatus('🛑 Controllo annullato dal sito.', 'ok');
  aggiungiLog(null, 'Controllo annullato dal sito.', '');
}

const _ORE_ORDINI_PREZZI_IN_ATTESA = 2;
async function _contaOrdiniPrezziInAttesa() {
  const soglia = new Date(Date.now() - _ORE_ORDINI_PREZZI_IN_ATTESA * 60 * 60 * 1000).toISOString();
  const { count } = await supabaseClient
    .from('ordini')
    .select('id', { count: 'exact', head: true })
    .eq('stato', 'pending')
    .in('tipo', ['controlla_prezzi', 'controlla_prezzi_sealed', 'controlla_prezzi_wishlist'])
    .gt('creato_il', soglia);
  return count || 0;
}

async function _contaCodaCartePendenti() {
  const { count } = await supabaseClient
    .from('coda_carte')
    .select('id', { count: 'exact', head: true })
    .eq('stato', 'pending');
  return count || 0;
}

function _loginCardmarketAutomaticoOk() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_AUTOMATICA' }, (r) => {
        if (chrome.runtime.lastError) { resolve(false); return; }
        resolve(!!r && r.loggato === true);
      });
    } catch (_) {
      resolve(false);
    }
  });
}

let _avvioInattivitaInCorso = false;

async function _avviaControlloPrezziSeInattivo() {
  if (_avvioInattivitaInCorso) return;
  _avvioInattivitaInCorso = true;
  try {
    const { aiutaGruppo } = await chrome.storage.local.get('aiutaGruppo');
    if (!aiutaGruppo) return;
    if (isRunning) return;
    const { data: sessionData } = await supabaseClient.auth.getSession();
    if (!sessionData?.session?.user?.id) return;

    let lottoConCodaPiena = false;
    if ((await _codaCardmarketOccupataQui()) || (await _contaCodaCartePendenti()) > 0) {
      const { carteCodaDaUltimiPrezzi } = await chrome.storage.local.get('carteCodaDaUltimiPrezzi');
      if (!(carteCodaDaUltimiPrezzi >= CARTE_CODA_PER_LOTTO_PREZZI)) return;
      lottoConCodaPiena = true;
    }
    if ((await _contaOrdiniPrezziInAttesa()) > 0) return;

    const sogliaIso = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { data: giaInCorso } = await supabaseClient
      .from('ordini')
      .select('id')
      .eq('tipo', 'controlla_prezzi')
      .eq('stato', 'in_corso')
      .gt('preso_in_carico_il', sogliaIso)
      .limit(1);
    if (giaInCorso && giaInCorso.length > 0) return;

    const daControllare = await contaEleggibiliControlloPrezzi([], true, GIORNI_MINIMI_INATTIVITA, true, null);
    if (daControllare === 0) return;
    if (!(await _loginCardmarketAutomaticoOk())) return;
    if (isRunning) return;

    if (lottoConCodaPiena) {
      await chrome.storage.local.set({ carteCodaDaUltimiPrezzi: 0 });
      setStatus(`💤 Coda sempre piena — tra una carta e l'altra controllo ${LOTTO_CONTROLLO_PREZZI} prezzi del gruppo non aggiornati da ${GIORNI_MINIMI_INATTIVITA} giorni...`, 'info');
      await eseguiSessione({
        filtroLocation: [],
        aiutaGruppo: true,
        soloVecchie: true,
        giorniMinimi: GIORNI_MINIMI_INATTIVITA,
        silenziosoSeVuoto: true,
        maxLotti: 1,
        saltaAttesaCoda: true,
      });
      return;
    }
    setStatus(`💤 Nessun altro lavoro in coda — controllo i prezzi del gruppo non aggiornati da ${GIORNI_MINIMI_INATTIVITA} giorni...`, 'info');
    _sessioneAutoInattivita = true;
    await chrome.storage.local.set({ carteCodaDaUltimiPrezzi: 0 });
    await eseguiSessione({
      filtroLocation: [],
      aiutaGruppo: true,
      soloVecchie: true,
      giorniMinimi: GIORNI_MINIMI_INATTIVITA,
      silenziosoSeVuoto: true,
    });
  } catch (e) {
    console.error('[controllo prezzi automatico] errore:', e.message);
  } finally {
    _sessioneAutoInattivita = false;
    _avvioInattivitaInCorso = false;
  }
}

setInterval(async () => {
  if (!_sessioneAutoInattivita || !isRunning || stopRequested) return;
  try {
    if ((await _contaCodaCartePendenti()) > 0) {
      console.log('[controllo prezzi automatico] arrivato altro lavoro — mi metto in pausa.');
      stopRequested = true;
    } else if ((await _contaOrdiniPrezziInAttesa()) > 0) {
      console.log('[controllo prezzi automatico] ordine di prezzi in attesa — mi metto in pausa per lasciarlo partire.');
      stopRequested = true;
    }
  } catch (_) {   }
}, 20000);

setInterval(_avviaControlloPrezziSeInattivo, 60000);

let _paginaPronta = false;
let _catenaAutorun = null;
let _catenaAutorunDaRifare = false;
function _avviaAutorunOrdini() {
  if (_catenaAutorun) { _catenaAutorunDaRifare = true; return _catenaAutorun; }
  _catenaAutorun = _avviaAutorunSeRichiesto()
    .then(() => _avviaAutorunSealedSeRichiesto())
    .then(() => _avviaAutorunWishlistSeRichiesto())
    .catch((e) => console.error('[ordini] avvio automatico:', e && e.message))
    .finally(() => {
      _catenaAutorun = null;
      if (_catenaAutorunDaRifare) { _catenaAutorunDaRifare = false; _avviaAutorunOrdini(); }
    });
  return _catenaAutorun;
}

async function _avviaAutorunSeRichiesto() {
  const { ordinePendenteAutorun } = await chrome.storage.local.get('ordinePendenteAutorun');
  if (!ordinePendenteAutorun || ordinePendenteAutorun.tipo !== 'controlla_prezzi') return;

  await chrome.storage.local.remove('ordinePendenteAutorun');
  if (isRunning) {
    await _rimettiOrdineInAttesa(ordinePendenteAutorun.id);
    return;
  }

  const ordineId = ordinePendenteAutorun.id;
  const locations = ordinePendenteAutorun.parametri?.locations;
  const aiutaGruppoOrdine = ordinePendenteAutorun.parametri?.aiutaGruppo;
  const creatoDa = ordinePendenteAutorun.creatoDa;
  await assicuraLoginSupabase();

  setStatus('🤖 Ordine ricevuto dal sito — avvio controllo prezzi...', 'info');
  const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordineId);
  try {
    await eseguiSessione({
      filtroLocation: Array.isArray(locations) ? locations : [],
      ...(aiutaGruppoOrdine !== undefined ? { aiutaGruppo: aiutaGruppoOrdine } : {}),
      ...(creatoDa ? { ownerIdRichiesto: creatoDa } : {}),
      ordineId,
    });
  } finally {
    if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
  }
  if (_ordineAnnullatoDalSito) return;

  try {
    await _scriviEsitoOrdine(ordineId, '[ordini]');
  } catch (e) {
    console.error('[ordini] impossibile scrivere l\'esito sull\'ordine:', e);
  }
}

let _esitoSessione = null;
function _esitoPerOrdine() {
  if (_esitoSessione) {
    if (_esitoSessione.stato === 'errore') return { errore: true, messaggio: _esitoSessione.messaggio };
    return { errore: false, vuoto: _esitoSessione.stato === 'vuoto' };
  }
  const statusEl = document.getElementById('status');
  if (statusEl.className.includes('errore')) return { errore: true, messaggio: statusEl.textContent };
  return { errore: false, vuoto: false };
}

async function _scriviEsitoOrdine(ordineId, etichetta) {
  const esito = _esitoPerOrdine();
  if (esito.errore) {
    await supabaseClient.from('ordini').update({
      stato: 'errore',
      errore_msg: esito.messaggio || 'Errore sconosciuto durante la sessione automatica.',
      completato_il: new Date().toISOString(),
    }).eq('id', ordineId);
    return;
  }
  const risultato = { salite: cUp, scese: cDown, invariate: cSteady };
  if (esito.vuoto) risultato.totale = 0;
  await supabaseClient.from('ordini').update({
    stato: 'completato',
    risultato,
    completato_il: new Date().toISOString(),
  }).eq('id', ordineId);
  console.log(etichetta + ' esito scritto sull\'ordine:', esito.vuoto ? 'nessuna carta da controllare' : 'completato');
}

async function _avviaAutorunWishlistSeRichiesto() {
  const { ordinePendenteAutorunWishlist } = await chrome.storage.local.get('ordinePendenteAutorunWishlist');
  if (!ordinePendenteAutorunWishlist) return;
  await chrome.storage.local.remove('ordinePendenteAutorunWishlist');
  if (isRunning) {
    await _rimettiOrdineInAttesa(ordinePendenteAutorunWishlist.id);
    return;
  }
  const ordineId = ordinePendenteAutorunWishlist.id;
  await assicuraLoginSupabase();
  setStatus('🤖 Ordine ricevuto dal sito — avvio controllo prezzi wishlist...', 'info');
  const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordineId);
  try {
    await eseguiSessione({ dominio: 'wishlist', ordineId, aiutaGruppo: true });
  } finally {
    if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
  }
  if (_ordineAnnullatoDalSito) return;
  try {
    await _scriviEsitoOrdine(ordineId, '[ordini wishlist]');
  } catch (e) {
    console.error('[ordini] impossibile scrivere l\'esito sull\'ordine wishlist:', e);
  }
}

function setStatus(msg, tipo = '') {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = msg ? (tipo ? `${tipo} visible` : 'visible') : '';
}

function setProgress(pct) {
  document.getElementById('progressBar').style.display = 'block';
  document.getElementById('progressFill').style.width  = Math.min(100, Math.max(0, pct)) + '%';
}

function nascondiProgress() {
  document.getElementById('progressBar').style.display = 'none';
  document.getElementById('progressFill').style.width  = '0%';
}

const logPanel   = document.getElementById('logPanel');
const logHeader  = document.getElementById('logHeader');
const logBody    = document.getElementById('logBody');
const logBadge   = document.getElementById('logBadge');
const logEmpty   = document.getElementById('logEmpty');

logHeader.addEventListener('click', () => {
  const aperto = logBody.classList.toggle('visible');
  logHeader.classList.toggle('open', aperto);
});

document.getElementById('logCopy').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const testo = logEntries.map(e => `${_etichettaRiga(e.riga)}\t${e.msg}`).join('\n');
  navigator.clipboard.writeText(testo).then(() => {
    const btn = document.getElementById('logCopy');
    btn.textContent = '✅';
    setTimeout(() => btn.textContent = '📋', 1500);
  });
});

document.getElementById('logCsv').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const righe = ['Riga,Messaggio,Tipo'];
  logEntries.forEach(e => {
    const riga = '"' + _etichettaRiga(e.riga).replace(/"/g, '""') + '"';
    const msg  = '"' + (e.msg  || '').replace(/"/g, '""') + '"';
    const tipo = '"' + (e.tipo || '').replace(/"/g, '""') + '"';
    righe.push(`${riga},${msg},${tipo}`);
  });
  const blob = new Blob([righe.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = 'cardsync_log_' + new Date().toISOString().slice(0,10) + '.csv';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('logClear').addEventListener('click', (e) => {
  e.stopPropagation();
  logEntries = [];
  logBody.innerHTML = '';
  logBody.appendChild(logEmpty);
  logEmpty.style.display = '';
  logBadge.textContent = '0';
});

const _etichetteRiga = {};

function _etichettaRiga(riga) {
  if (riga == null) return '—';
  return _etichetteRiga[riga] || ('ID ' + String(riga).slice(0, 8));
}

function aggiungiLog(riga, msg, tipo = '') {
  logEntries.push({ riga, msg, tipo });
  logEmpty.style.display = 'none';

  const entry  = document.createElement('div');
  entry.className = 'log-entry';

  const rigaEl = document.createElement('span');
  rigaEl.className   = 'log-row';
  rigaEl.textContent = _etichettaRiga(riga);

  const msgEl = document.createElement('span');
  msgEl.className   = 'log-msg' + (tipo ? ` ${tipo}` : '');
  msgEl.textContent = msg;

  entry.appendChild(rigaEl);
  entry.appendChild(msgEl);
  logBody.appendChild(entry);
  logBody.scrollTop = logBody.scrollHeight;

  logBadge.textContent = logEntries.length;
  logPanel.classList.add('visible');
}

function mostraTrendDetail(tipo) {
  const panel = document.getElementById('trendDetailPanel');
  const title = document.getElementById('trendDetailTitle');
  const body  = document.getElementById('trendDetailBody');
  if (!panel || !title || !body) return;

  const lista = tipo === 'up' ? trendSalitiEntries : trendScesiEntries;
  title.textContent = tipo === 'up' ? '🔺 Carte salite' : '🔻 Carte scese';
  body.innerHTML = '';

  if (lista.length === 0) {
    const vuoto = document.createElement('div');
    vuoto.className = 'log-empty';
    vuoto.textContent = tipo === 'up'
      ? 'Nessuna carta salita in questa sessione.'
      : 'Nessuna carta scesa in questa sessione.';
    body.appendChild(vuoto);
  } else {
    lista.forEach(e => {
      const item = document.createElement('div');
      item.className = 'trend-detail-item';

      const rigaEl = document.createElement('span');
      rigaEl.className = 'trend-detail-riga';
      rigaEl.textContent = e.riga != null ? `R${e.riga}` : '—';

      const nomeEl = document.createElement('span');
      nomeEl.className = 'trend-detail-nome';
      nomeEl.textContent = e.nome || '—';
      nomeEl.title = e.nome || '';

      const varEl = document.createElement('span');
      varEl.className = `trend-detail-var ${tipo}`;
      varEl.textContent = e.testo || '';

      item.appendChild(rigaEl);
      item.appendChild(nomeEl);
      item.appendChild(varEl);
      body.appendChild(item);
    });
  }

  panel.style.display = 'flex';
}

const _trendPillUp   = document.querySelector('.trend-pill.up');
const _trendPillDown = document.querySelector('.trend-pill.down');
if (_trendPillUp)   _trendPillUp.addEventListener('click', () => mostraTrendDetail('up'));
if (_trendPillDown) _trendPillDown.addEventListener('click', () => mostraTrendDetail('down'));

const _trendDetailClose = document.getElementById('trendDetailClose');
if (_trendDetailClose) {
  _trendDetailClose.addEventListener('click', () => {
    const panel = document.getElementById('trendDetailPanel');
    if (panel) panel.style.display = 'none';
  });
}

function pulisciPrezzo(prezzoStr) {
  if (prezzoStr === null || prezzoStr === undefined || prezzoStr === '') return 0;
  if (typeof prezzoStr === 'number') return isNaN(prezzoStr) ? 0 : prezzoStr;

  let clean = prezzoStr.toString().trim().replace(/[^0-9,.]/g, '');

  if (clean.includes(',') && clean.includes('.')) {
    if (clean.lastIndexOf(',') > clean.lastIndexOf('.')) {
      clean = clean.replace(/\./g, '').replace(',', '.');
    } else {
      clean = clean.replace(/,/g, '');
    }
  } else if (clean.includes(',')) {
    const decimale = clean.split(',')[1];
    clean = (decimale && decimale.length <= 2)
      ? clean.replace(',', '.')
      : clean.replace(',', '');
  }

  const num = parseFloat(clean);
  return isNaN(num) ? 0 : num;
}

function calcolaVariazione(pV, pN) {
  if (pV <= 0 || pN <= 0) return '➖';
  const diff = pN - pV;
  if (Math.abs(diff) < 0.005) return '➖';
  const pct     = ((diff / pV) * 100).toFixed(1);
  const segno   = diff > 0 ? '+' : '';
  const diffStr = segno + diff.toFixed(2).replace('.', ',') + '€';
  const pctStr  = segno + pct + '%';
  return `${diff > 0 ? '🔺' : '🔻'} ${diffStr} (${pctStr})`;
}

function formattaDataOra(ts) {
  if (!ts) return null;
  const d = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function _urlRicercaControlloPrezzi(testo) {
  const q = encodeURIComponent(String(testo || '').trim().replace(/\s+/g, ' ')).replace(/%20/g, '+');
  return `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${q}`;
}

function _riapplicaVarianti(urlNuovo, urlVecchio) {
  try {
    const vecchio = new URL(urlVecchio);
    const nuovo = new URL(urlNuovo);
    ['isReverseHolo', 'isFirstEd'].forEach(k => { if (vecchio.searchParams.get(k) === 'Y') nuovo.searchParams.set(k, 'Y'); });
    return nuovo.toString();
  } catch (_) {
    return urlNuovo;
  }
}

function costruisciUrlFiltrato(urlBase, lingua, condizioneRaw) {
  return costruisciUrlFiltrato_shared(urlBase, lingua, condizioneRaw);
}

function urlHaTuttiParametri(url, lingua, condizione) {
  let attuale, atteso;
  try {
    attuale = new URL(url);
    atteso = new URL(costruisciUrlFiltrato(url, lingua, condizione));
  } catch (_) {
    return true;
  }
  const lang = (u) => u.searchParams.get('language') || u.searchParams.get('idLanguage') || '';
  return lang(attuale) === lang(atteso)
    && !attuale.searchParams.has('idLanguage')
    && (attuale.searchParams.get('minCondition') || '') === (atteso.searchParams.get('minCondition') || '');
}

function _normCodiceCarta(s) {
  return String(s || '').toUpperCase().replace(/[\s.\-]+/g, '');
}
function _codiciCoincidono(atteso, pagina) {
  const a = _normCodiceCarta(atteso);
  const p = _normCodiceCarta(pagina);
  if (!a || !p) return false;
  if (a === p) return true;
  const ma = a.match(/^(.*?)(\d+)$/);
  const mp = p.match(/^(.*?)(\d+)$/);
  if (ma && mp) {
    if (parseInt(ma[2], 10) !== parseInt(mp[2], 10)) return false;
    return ma[1].includes(mp[1]) || mp[1].includes(ma[1]);
  }
  if (!/\d/.test(a)) return p.includes(a);
  return false;
}

function verificaCartaNelDom(nomePagina, codicePagina, codiceAtteso, nomeAtteso) {
  if (!nomePagina && !codicePagina) return true;

  const nomePaginaUp    = nomePagina.toUpperCase();
  const codicePaginaUp  = codicePagina.toUpperCase();

  if (codiceAtteso) {
    if (_codiciCoincidono(codiceAtteso, codicePaginaUp)) return true;
    if (nomeAtteso) {
      const nomeNorm = nomeAtteso.toUpperCase().replace(/\s+/g, '');
      if (nomePaginaUp.replace(/\s+/g, '').includes(nomeNorm)) return true;
    }
    return false;
  }

  if (nomeAtteso) {
    const nomeNorm = nomeAtteso.toUpperCase().replace(/\s+/g, '');
    return nomePaginaUp.replace(/\s+/g, '').includes(nomeNorm);
  }

  return true;
}

const LOTTO_CONTROLLO_PREZZI = 3;

async function contaEleggibiliControlloPrezzi(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, ordineId = null, azioneLeggi = 'leggi') {
  const data = await chiamaSupabase(azioneLeggi, { filtroLocation, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, ordineId, soloConta: true });
  if (!data.ok) throw new Error(data.errore || 'Errore nel conteggio iniziale delle carte da controllare.');
  return data.totale || 0;
}

async function leggiDatiSheet(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, lottoSize, nomeDisp, ordineId = null, azioneLeggi = 'leggi') {
  const data = await chiamaSupabase(azioneLeggi, { filtroLocation, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, ordineId, lottoSize, nomeDispositivo: nomeDisp });
  if (!data.ok) throw new Error(data.errore || 'Errore nel caricamento dei dati.');

  return data.carte.map(c => ({
    rigaSheet:    c.rigaSheet,
    url:          (c.urlBase && c.urlBase.includes('/Singles/'))
                    ? costruisciUrlFiltrato(c.urlBase, c.lingua, c.condizione)
                    : c.urlBase,
    urlOriginale: c.urlBase,
    lingua:       c.lingua,
    condizione:   c.condizione,
    codice:       c.codice || '',
    nome:         c.nome   || '',
    location:     c.location || '',
    prezzoVecchio: c.prezzoPrecedente ?? c.prezzoCorrente ?? c.prezzo ?? '',
    immagine:     c.immagine || '',
    ownerId:      c.ownerId || null,
  }));
}

async function popolaTendinaLocation() {
  const select = document.getElementById('filtroLocation');
  if (!select) return;

  const valoreAttuale = select.value;
  try {
    const data = await chiamaSupabase('elencaLocation', {});
    if (!data.ok) return;
    select.innerHTML = '<option value="">Tutte le location</option>';
    (data.location || []).forEach(loc => {
      const opt = document.createElement('option');
      opt.value = loc;
      opt.textContent = loc;
      select.appendChild(opt);
    });
    if (valoreAttuale && Array.from(select.options).some(o => o.value === valoreAttuale)) {
      select.value = valoreAttuale;
    }
  } catch (_) {
  }
}

document.getElementById('filtroLocation')?.addEventListener('change', (e) => {
  chrome.storage.local.set({ filtroLocationSelezionata: e.target.value });
});

document.getElementById('btnControllaConnessione')?.addEventListener('click', async () => {
  const btn = document.getElementById('btnControllaConnessione');

  btn.disabled = true;
  btn.textContent = 'Controllo il database…';
  setStatus('⏳ Controllo la connessione al database...', 'info');

  try {
    const data = await chiamaSupabase('elencaLocation', {});
    if (!data.ok) {
      setStatus('❌ ' + (data.errore || 'Risposta inattesa da Supabase.'), 'errore');
      btn.disabled = false;
      btn.textContent = 'Controlla connessione';
      return;
    }
  } catch (e) {
    setStatus('❌ ' + e.message, 'errore');
    btn.disabled = false;
    btn.textContent = 'Controlla connessione';
    return;
  }

  btn.textContent = 'Controllo l\'accesso a Cardmarket…';
  chrome.runtime.sendMessage({ type: 'CM_ACCESSO_CONTROLLA', forza: true }, (risposta) => {
    void chrome.runtime.lastError;
    const stato = risposta && risposta.stato;
    let msgLogin, tipoLogin;
    if (stato === 'ok') {
      msgLogin = '🔓 Sei collegato a Cardmarket.';
      tipoLogin = 'ok';
    } else if (stato === 'cloudflare') {
      msgLogin = '🔒 Cardmarket chiede una verifica "non sono un robot": usa "Apri Cardmarket" nella finestra che è comparsa.';
      tipoLogin = 'errore';
    } else if (stato === 'ko') {
      msgLogin = '🔒 Non sei collegato a Cardmarket: usa "Accedi a Cardmarket" nella finestra che è comparsa.';
      tipoLogin = 'errore';
    } else {
      msgLogin = '❓ Non sono riuscito a confermare l\'accesso a Cardmarket (pagina lenta?): riprova tra poco o usa il pallino "Cardmarket" in alto.';
      tipoLogin = 'info';
    }
    setStatus('✅ Database raggiungibile. ' + msgLogin, tipoLogin);
    btn.disabled = false;
    btn.textContent = 'Controlla connessione';
  });
});

function formattaTempo(secondi) {
  const m = Math.floor(secondi / 60);
  const s = Math.floor(secondi % 60);
  return `${m}m ${s}s`;
}

function _turnoCardmarket(fase) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'TURNO_CARDMARKET', fase }, (r) => {
        if (chrome.runtime.lastError || !r || !r.ok) { resolve(null); return; }
        resolve(r);
      });
    } catch (_) { resolve(null); }
  });
}

function creaRitmoCardmarket(delayMinSec, delayMaxSec) {
  let extraMs = 0;
  return {
    fissa() { _turnoCardmarket('chiudi'); },
    allunga(ms) { extraMs += ms; },
    async attendi() {
      if (extraMs > 0) {
        const quando = await _turnoCardmarket('quando');
        const base = quando && quando.da ? Math.max(0, quando.da - Date.now()) : 0;
        const ms = base + extraMs;
        extraMs = 0;
        await attendiConCountdown(ms);
        if (stopRequested) return;
      }
      const turno = await _turnoCardmarket('prenota');
      if (!turno) {
        const dMin = delayMinSec * 1000;
        const dMax = Math.max(delayMaxSec * 1000, dMin);
        await attendiConCountdown(dMin + Math.floor(Math.random() * (dMax - dMin)) + 1200);
        return;
      }
      if (turno.da && turno.da > Date.now()) {
        if (turno.motivo === 'pausa-lunga') setStatus('☕ Pausa lunga (slider "Pausa lunga ogni N carte")...', 'info');
        await attendiConCountdown(turno.da - Date.now(), turno.motivo === 'pausa-lunga' ? 'Pausa lunga, prossima tra'
          : (turno.livelloCf > 0 ? 'Prossima tra (rallentato)' : 'Prossima tra'));
      }
    },
  };
}

// Un timer unico alla scadenza, non una catena di timer: con la scheda nascosta Chrome fa
// scattare le catene una volta al minuto. Quello di ogni secondo aggiorna solo il numero.
function attendiConCountdown(ms, etichetta) {
  if (ms >= 1000) {
    _attivitaAllaHome({ fase: 'attesa', fino: Date.now() + ms, durataMs: ms, etichetta: etichetta || 'Prossima tra', prossima: _cartaInCorsoHome });
  }
  return new Promise(resolve => {
    const fine = Date.now() + Math.max(0, ms);
    const el = document.getElementById('tempoAttesa');
    let finito = false;
    let iv = null;
    let to = null;
    const chiudi = (testo) => {
      if (finito) return;
      finito = true;
      clearInterval(iv);
      clearTimeout(to);
      if (el && testo != null) el.textContent = testo;
      resolve();
    };
    const mostra = () => { if (el) el.textContent = Math.max(0, Math.ceil((fine - Date.now()) / 1000)) + 's'; };
    mostra();
    to = setTimeout(() => chiudi('0s'), Math.max(0, fine - Date.now()));
    iv = setInterval(() => {
      if (stopRequested) { chiudi('—'); return; }
      if (Date.now() >= fine) { chiudi('0s'); return; }
      mostra();
    }, 1000);
  });
}

let _tabControlloPrezziId = null;

function _apriOAggiornaTabControllo(url, callback) {
  if (_tabControlloPrezziId != null) {
    chrome.tabs.update(_tabControlloPrezziId, { url }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        chrome.tabs.create({ url, active: false }, (nuovaTab) => {
          _tabControlloPrezziId = nuovaTab.id;
          callback(nuovaTab);
        });
      } else {
        callback(tab);
      }
    });
  } else {
    chrome.tabs.create({ url, active: false }, (tab) => {
      _tabControlloPrezziId = tab.id;
      callback(tab);
    });
  }
}

function _chiudiTabControlloPrezzi() {
  if (_tabControlloPrezziId != null) {
    const idDaChiudere = _tabControlloPrezziId;
    _tabControlloPrezziId = null;
    chrome.tabs.remove(idDaChiudere, () => { void chrome.runtime.lastError; });
  }
}

function _iniettaLetturaPrezzo(tabId) {
  try {
    chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({ shared: typeof rigaSoddisfaFiltriShared === 'function', lettura: !!window.__cardsyncLetturaAttiva }),
    }, (r) => {
      if (chrome.runtime.lastError) return;
      const stato = r && r[0] && r[0].result;
      if (!stato || stato.lettura) return;
      const files = stato.shared ? ['content.js'] : ['shared.js', 'content.js'];
      chrome.scripting.executeScript({ target: { tabId }, files }, () => { void chrome.runtime.lastError; });
    });
  } catch (_) {   }
}

function apriTabEAspettaPrezzo(url, cfTimeoutMinuti) {
  _attivitaAllaHome({ fase: 'lettura', carta: _cartaInCorsoHome });
  return new Promise((resolve) => {
    _apriOAggiornaTabControllo(url, (tab) => {
      const tabId = tab.id;
      let normalTimeoutId;
      let stopCheckId;
      let cloudflareRilevato = false;
      let risolto = false;

      function concludi(valore) {
        if (risolto) return;
        risolto = true;
        clearTimeout(normalTimeoutId);
        clearInterval(stopCheckId);
        chrome.runtime.onMessage.removeListener(listener);
        chrome.tabs.onUpdated.removeListener(onCaricata);
        resolve(valore);
      }

      const onCaricata = (id, info) => {
        if (id === tabId && info.status === 'complete') _iniettaLetturaPrezzo(tabId);
      };
      chrome.tabs.onUpdated.addListener(onCaricata);
      chrome.tabs.get(tabId, (t) => {
        if (chrome.runtime.lastError || !t || t.status !== 'complete') return;
        try {
          if (new URL(t.url).pathname === new URL(url).pathname) _iniettaLetturaPrezzo(tabId);
        } catch (_) {   }
      });

      stopCheckId = setInterval(() => {
        if (stopRequested) {
          chrome.runtime.sendMessage({ type: 'FERMA_AVVISO_CLOUDFLARE' });
          _chiudiTabControlloPrezzi();
          concludi('Stop');
        }
      }, 300);

      function fermaAvviso() {
        chrome.runtime.sendMessage({ type: 'FERMA_AVVISO_CLOUDFLARE' });
      }

      const listener = (message, sender) => {
        if (sender.tab && sender.tab.id === tabId) {
          if (message.type === 'PREZZO_TROVATO') {
            fermaAvviso();
            concludi({ prezzo: message.prezzo, nomePagina: message.nomePagina || '', codicePagina: message.codicePagina || '', immagine: message.immagine || null, cloudflareEncountered: cloudflareRilevato });
          } else if (message.type === 'RATE_LIMIT_DETECTED') {
            concludi('RateLimit');
          } else if (message.type === 'CLOUDFLARE_DETECTED' && !cloudflareRilevato) {
            cloudflareRilevato = true;
            clearTimeout(normalTimeoutId);
            setStatus('⚠️ CLOUDFLARE RILEVATO! Risolvi il blocco nella tab aperta...', 'errore');
            chrome.runtime.sendMessage({
              type: 'AVVIA_AVVISO_CLOUDFLARE',
              tabId,
              avvisoSonoro:   document.getElementById('avvisoSonoro').checked,
              timeoutMinuti:  cfTimeoutMinuti,
            });
          }
        }

        if (message.type === 'CLOUDFLARE_TIMEOUT' && message.tabId === tabId) {
          if (_tabControlloPrezziId === tabId) _tabControlloPrezziId = null;
          concludi('Cloudflare');
        }
      };

      chrome.runtime.onMessage.addListener(listener);

      normalTimeoutId = setTimeout(() => {
        concludi('Timeout');
      }, 18000);
    });
  });
}

function aggiornaTrend() {
  document.getElementById('countUp').textContent     = cUp;
  document.getElementById('countDown').textContent   = cDown;
  document.getElementById('countSteady').textContent = cSteady;
  document.getElementById('trendContainer').classList.add('visible');
}

function resetUiPostSessione() {
  isRunning     = false;
  stopRequested = false;
  const btnAvvia  = document.getElementById('btnAvvia');
  btnAvvia.disabled    = false;
  btnAvvia.textContent = 'Avvia controllo';
  btnAvvia.classList.remove('in-corso');
  _attivitaAllaHome({ fase: 'ferma' });
  document.getElementById('timerContainer').classList.remove('visible');
  document.getElementById('tempoAttesa').textContent = '—';
}

let _mioUserIdSessionePrezzi = null;
async function _aggiornaMioUserIdSessionePrezzi() {
  try {
    const { data } = await supabaseClient.auth.getSession();
    _mioUserIdSessionePrezzi = data?.session?.user?.id || null;
  } catch (_) { _mioUserIdSessionePrezzi = null; }
}
function _cartaDiUnAltro(ownerId) {
  return !!(ownerId && _mioUserIdSessionePrezzi && ownerId !== _mioUserIdSessionePrezzi);
}
function _logErroreCarta(rigaSheet, ownerId, msg, tipo = 'errore') {
  if (_cartaDiUnAltro(ownerId)) aggiungiLog(rigaSheet, 'Controllata (carta di un altro utente)', '');
  else aggiungiLog(rigaSheet, msg, tipo);
}

async function eseguiSessione(overrides = {}) {
  _esitoSessione = null;
  await _aggiornaMioUserIdSessionePrezzi();
  const dominio = overrides.dominio === 'wishlist' ? 'wishlist' : 'carte';
  const AZ = dominio === 'wishlist'
    ? { leggi: 'leggiWishlistGruppo', segna: 'segnaControllataWishlistGruppo', nota: null, url: 'aggiornaUrlRigaWishlistGruppo', prezzo: 'aggiornaPrezzoRigaWishlistGruppo', rilascia: 'rilasciaClaimWishlist', tipoAiuto: 'controllo_prezzi_wishlist' }
    : { leggi: 'leggi', segna: 'segnaControllata', nota: 'aggiornaNotaRiga', url: 'aggiornaUrlRiga', prezzo: 'aggiornaPrezzoRiga', rilascia: 'rilasciaClaim', tipoAiuto: 'controllo_prezzi' };
  const _scriviUrlDominio = (riga, u) => chiamaSupabase(AZ.url, { riga, url: u });
  const _scriviPrezzoDominio = (riga, prezzo, immagine) => chiamaSupabase(AZ.prezzo, { riga, prezzo, immagine: immagine || undefined });
  const _scriviEsitoDominio = (riga, nota) => (AZ.nota ? chiamaSupabase(AZ.nota, { riga, nota }) : Promise.resolve({ ok: true }));
  const filtroLocation = dominio === 'wishlist' ? [] : (overrides.filtroLocation !== undefined
    ? overrides.filtroLocation
    : (document.getElementById('filtroLocation')?.value.trim() || ''));
  const soloVariazioni = document.getElementById('soloVariazioni').checked;
  const soloVecchie    = overrides.soloVecchie !== undefined
    ? overrides.soloVecchie
    : document.getElementById('soloVecchie').checked;
  const giorniMinimi   = overrides.giorniMinimi !== undefined
    ? overrides.giorniMinimi
    : (parseInt(document.getElementById('giorniMinimi').value) || 3);
  const aiutaGruppo    = overrides.aiutaGruppo !== undefined
    ? overrides.aiutaGruppo
    : document.getElementById('aiutaGruppo').checked;
  const ownerIdRichiesto = overrides.ownerIdRichiesto || null;
  const ordineId = overrides.ordineId || null;
  const delayMinSec    = parseInt(document.getElementById('sliderDelayMin').value) || DEFAULTS.sliderDelayMinSec;
  const delayMaxSec    = Math.max(parseInt(document.getElementById('sliderDelayMax').value) || DEFAULTS.sliderDelayMaxSec, delayMinSec);
  const cfMinuti       = parseInt(document.getElementById('sliderCfTimeout').value);
  const sogliaIdx      = parseInt(document.getElementById('sliderSoglia').value);
  const sogliaEuro     = SOGLIA_VALUES[sogliaIdx] ?? 0.01;
  const maxNd          = parseInt(document.getElementById('sliderMaxNd').value);

  {
    const { data: _sessCheck } = await supabaseClient.auth.getSession();
    if (!_sessCheck.session) {
      setStatus('⚠️ Non sei loggato su Supabase — ricarica l\'estensione per rifare il login.', 'errore');
      return;
    }
  }

  cUp = 0; cDown = 0; cSteady = 0; cErrori = 0;
  trendSalitiEntries = [];
  trendScesiEntries  = [];
  const _trendDetailPanel = document.getElementById('trendDetailPanel');
  if (_trendDetailPanel) _trendDetailPanel.style.display = 'none';
  let ndConsecutivi = 0;
  let cfConsecutivi = 0;
  let rateLimitRetryCorrente = 0;
  const ritmo = creaRitmoCardmarket(delayMinSec, delayMaxSec);
  let chiamateSegnaControllataPendenti = [];
  function _segnaControllataAsync(rigaSheet) {
    chiamateSegnaControllataPendenti.push(
      chiamaSupabase(AZ.segna, { riga: rigaSheet }).catch((e) => {
        console.error('[segnaControllata] errore:', e?.message || e);
      })
    );
  }
  aggiornaTrend();
  nascondiProgress();

  isRunning     = true;
  stopRequested = false;

  const ora = Date.now();
  chrome.storage.local.set({ ultimoUtilizzo: ora });
  const elUU = document.getElementById('ultimoUtilizzo');
  if (elUU) elUU.textContent = '🕐 Ultimo utilizzo: ' + formattaDataOra(ora);

  const btnAvvia  = document.getElementById('btnAvvia');
  btnAvvia.textContent = 'Ferma';
  btnAvvia.classList.add('in-corso');

  const nomeDisp = await nomeDispositivo();

  try {
    if (!overrides.saltaAttesaCoda) await _attendiCodaCardmarketLibera();
    _segnaleOccupatoAvvia();
    const filtroLocationLabel = ordineId
      ? (Array.isArray(filtroLocation) && filtroLocation.length ? `${filtroLocation.length} location` : '')
      : (Array.isArray(filtroLocation) ? filtroLocation.join(', ') : filtroLocation);
    setStatus(filtroLocationLabel ? `📡 Cerco le carte da controllare (location: ${filtroLocationLabel})...` : '📡 Cerco le carte da controllare...', 'info');

    const totaleStimato = await contaEleggibiliControlloPrezzi(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, ordineId, AZ.leggi);

    let carte = await leggiDatiSheet(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI, nomeDisp, ordineId, AZ.leggi);

    const MAX_LOTTI_SICUREZZA = Math.ceil((totaleStimato || carte.length) / LOTTO_CONTROLLO_PREZZI) + 5;
    let numeroLottiElaborati = 1;

    if (carte.length === 0 && overrides.silenziosoSeVuoto) {
      setStatus('💤 Prezzi del gruppo già aggiornati — niente da controllare per ora.', 'info');
      _esitoSessione = { stato: 'vuoto' };
      return;
    }

    if (carte.length === 0) {
      const nLocation = Array.isArray(filtroLocation) ? filtroLocation.length : (filtroLocation ? 1 : 0);
      const dettagliFiltri = `location filtrate=${nLocation}, aiutaGruppo=${aiutaGruppo}, ownerIdRichiesto=${ownerIdRichiesto}, soloVecchie=${soloVecchie}`;
      console.warn('[controllo prezzi] nessuna carta da controllare:', dettagliFiltri);
      aggiungiLog(null, `Nessuna carta da controllare (${dettagliFiltri})`, '');
      setStatus('✅ Nessuna carta da controllare: sono già tutte aggiornate o i filtri non ne trovano.', 'ok');
      _esitoSessione = { stato: 'vuoto' };
      return;
    }

    document.getElementById('timerContainer').classList.add('visible');
    const elTotale = document.getElementById('tempoTotale');
    const elAttesa = document.getElementById('tempoAttesa');

    let offsetLottiPrecedenti = 0;

    while (carte.length > 0) {
    for (let step = 0; step < carte.length; step++) {
      if (stopRequested) break;

      const { rigaSheet, url, prezzoVecchio, urlOriginale, lingua, condizione, codice, nome, ownerId } = carte[step];
      _etichetteRiga[rigaSheet] = nome || codice || null;
      const stepGlobale = offsetLottiPrecedenti + step;

      if (!urlOriginale) {
        _logErroreCarta(rigaSheet, ownerId, `${_etichettaRiga(rigaSheet)}: nessun URL salvato, saltata`, 'err');
        cErrori++;
        _segnaControllataAsync(rigaSheet);
        continue;
      }

      const mediaMs      = ((delayMinSec + delayMaxSec) / 2) * 1000 + 1200;
      const restanti     = Math.max(totaleStimato - stepGlobale, carte.length - step);
      const stimaSec     = restanti * ((18000 + mediaMs) / 1000);
      if (elTotale) elTotale.textContent = formattaTempo(stimaSec);

      setStatus(`⏳ Carta ${stepGlobale + 1}/${totaleStimato || carte.length} — ${_etichettaRiga(rigaSheet)}`, 'info');
      setProgress(totaleStimato > 0 ? Math.round((stepGlobale / totaleStimato) * 100) : 0);
      _segnaCartaHome({ nome: nome || codice || '', codice: nome ? (codice || '') : '', lingua: lingua || '', cond: condizione || '', di: _diPrezzi(ownerId) },
        stepGlobale + 1, totaleStimato || carte.length);

      let urlDaAprire = url;
      if (urlOriginale.includes('/Products/Search')) {
        await ritmo.attendi();
        if (stopRequested) break;
        setStatus(`⏳ ${_etichettaRiga(rigaSheet)}: risolvo URL ricerca → Singles...`, 'info');
        try {
          const risolto = await Promise.race([
            new Promise((resolve, reject) => {
              chrome.runtime.sendMessage({
                type:      'LEGGI_NOME_CARTA',
                turnoGiaPreso: true,
                urlNome:   urlOriginale,
                lingua,
                condizione,
              }, (r) => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve(r);
              });
            }),
            new Promise((_, reject) =>
              setTimeout(() => reject(new Error('Timeout risoluzione URL (30s)')), 30000)
            ),
          ]).finally(() => ritmo.fissa());
          if (risolto && risolto.rateLimited) {
            rateLimitRetryCorrente++;
            aggiungiLog(rigaSheet, 'Error 1015 (rate limited) durante risoluzione URL → pausa 30 min', 'errore');
            setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti...', 'errore');
            await attendiConCountdown(PAUSA_RATE_LIMIT_MS);
            if (stopRequested) break;
            if (rateLimitRetryCorrente >= 3) {
              aggiungiLog(rigaSheet, 'Saltata dopo 3 rate limit consecutivi', 'errore');
              rateLimitRetryCorrente = 0;
              _segnaControllataAsync(rigaSheet);
              continue;
            }
            step--;
            continue;
          }
          if (risolto && risolto.urlSingles) {
            const urlSinglesConFiltri = costruisciUrlFiltrato(risolto.urlSingles, lingua, condizione);
            aggiungiLog(rigaSheet, `URL /Search risolto: ${risolto.urlSingles}`, 'info');
            const esitoUrlRisolto = await _scriviUrlDominio(rigaSheet, urlSinglesConFiltri);
            if (!esitoUrlRisolto || !esitoUrlRisolto.ok) {
              aggiungiLog(rigaSheet, `⚠️ URL non salvato (${esitoUrlRisolto?.errore || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
            }
            urlDaAprire = urlSinglesConFiltri;
            carte[step].urlOriginale = urlSinglesConFiltri;
          } else {
            aggiungiLog(rigaSheet, 'URL /Search: Singles non trovato, saltata', 'errore');
            _segnaControllataAsync(rigaSheet);
            continue;
          }
        } catch (e) {
          aggiungiLog(rigaSheet, 'Errore risoluzione URL: ' + e.message, 'errore');
          _segnaControllataAsync(rigaSheet);
          continue;
        }
      }

      await ritmo.attendi();
      if (stopRequested) break;
      const risultato   = await apriTabEAspettaPrezzo(urlDaAprire, cfMinuti);
      ritmo.fissa();
      const nuovoPrezzo  = (risultato && typeof risultato === 'object') ? risultato.prezzo : risultato;
      const nomePagina   = (risultato && typeof risultato === 'object') ? risultato.nomePagina  : '';
      const codicePagina = (risultato && typeof risultato === 'object') ? risultato.codicePagina : '';
      const immagineTab  = (risultato && typeof risultato === 'object') ? risultato.immagine : null;
      const cloudflareEncountered = nuovoPrezzo === 'Cloudflare'
        || (risultato && typeof risultato === 'object' && !!risultato.cloudflareEncountered);

      if (nuovoPrezzo === 'Stop' || stopRequested) break;

      if (nuovoPrezzo === 'RateLimit') {
        rateLimitRetryCorrente++;
        aggiungiLog(rigaSheet, `Error 1015 (rate limited) → pausa 30 min`, 'errore');
        setStatus(`🚫 Error 1015: troppi richieste. Pausa di 30 minuti...`, 'errore');
        await attendiConCountdown(PAUSA_RATE_LIMIT_MS);
        if (stopRequested) break;
        if (rateLimitRetryCorrente >= 3) {
          aggiungiLog(rigaSheet, `Saltata dopo 3 rate limit consecutivi`, 'errore');
          rateLimitRetryCorrente = 0;
          _segnaControllataAsync(rigaSheet);
          continue;
        }
        step--;
        continue;
      }
      rateLimitRetryCorrente = 0;

      if (nuovoPrezzo === 'Cloudflare') {
        cfConsecutivi++;
        aggiungiLog(rigaSheet, 'Saltata (Cloudflare non risolto)', 'errore');
        setStatus(`⏭️ ${_etichettaRiga(rigaSheet)}: saltata (Cloudflare).`, 'errore');
        _segnaControllataAsync(rigaSheet);
        if (cfConsecutivi >= 2) {
          cfConsecutivi = 0;
          setStatus('🚫 2 Cloudflare consecutivi → pausa anti-ban 2 min...', 'errore');
          aggiungiLog(null, '2 Cloudflare consecutivi → pausa 2 min', 'errore');
          await attendiConCountdown(120000);
          if (stopRequested) break;
        }
        continue;
      }
      cfConsecutivi = 0;
      if (cloudflareEncountered) {
        aggiungiLog(rigaSheet, '⚠️ Cloudflare incontrato ma risolto — rallento temporaneamente il ritmo', '');
      }

      if (nuovoPrezzo === 'LinkNonValido') {
        let urlRiparato = null;
        const testoRicerca = [nome, codice].filter(Boolean).join(' ').trim();
        if (!carte[step]._linkRiparato && testoRicerca) {
          carte[step]._linkRiparato = true;
          aggiungiLog(rigaSheet, 'Link Cardmarket non più valido → cerco la carta per nome', '');
          await ritmo.attendi();
          if (stopRequested) break;
          try {
            const r = await Promise.race([
              new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({
                  type: 'LEGGI_NOME_CARTA',
                  turnoGiaPreso: true,
                  urlNome: _urlRicercaControlloPrezzi(testoRicerca),
                  lingua,
                  condizione,
                }, (x) => {
                  if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                  else resolve(x);
                });
              }),
              new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout ricerca link (60s)')), 60000)),
            ]).finally(() => ritmo.fissa());
            if (r && r.urlSingles) urlRiparato = _riapplicaVarianti(costruisciUrlFiltrato(r.urlSingles, lingua, condizione), urlOriginale);
          } catch (e) {
            aggiungiLog(rigaSheet, 'Errore nella ricerca del link: ' + e.message, 'errore');
          }
        }
        if (urlRiparato) {
          const esitoUrl = await _scriviUrlDominio(rigaSheet, urlRiparato);
          if (!esitoUrl || !esitoUrl.ok) aggiungiLog(rigaSheet, `⚠️ Link nuovo non salvato (${esitoUrl?.errore || 'errore sconosciuto'})`, 'errore');
          else aggiungiLog(rigaSheet, `Link aggiornato: ${urlRiparato}`, 'info');
          carte[step].url = urlRiparato;
          carte[step].urlOriginale = urlRiparato;
          step--;
          continue;
        }
        _logErroreCarta(rigaSheet, ownerId, 'Link Cardmarket non più valido: da correggere');
        if (!_cartaDiUnAltro(ownerId)) setStatus(`⚠️ ${_etichettaRiga(rigaSheet)}: link Cardmarket non più valido, da correggere.`, 'errore');
        chiamateSegnaControllataPendenti.push(
          _scriviEsitoDominio(rigaSheet, 'Link Cardmarket non più valido: da correggere').catch(() => {})
        );
        _segnaControllataAsync(rigaSheet);
        continue;
      }

      if (!verificaCartaNelDom(nomePagina, codicePagina, codice, nome)) {
        const checker = codice || nome;
        _logErroreCarta(rigaSheet, ownerId, `"${checker}" non trovato nella pagina`);
        if (!_cartaDiUnAltro(ownerId)) setStatus(`⚠️ ${_etichettaRiga(rigaSheet)}: "${checker}" non nella pagina, saltata.`, 'errore');
        _segnaControllataAsync(rigaSheet);
        continue;
      }

      const pV          = pulisciPrezzo(prezzoVecchio);
      const pN          = pulisciPrezzo(nuovoPrezzo);
      const diffAss     = Math.abs(pN - pV);
      const varTesto    = calcolaVariazione(pV, pN);
      const prezzoValido = typeof nuovoPrezzo === 'number' ||
        (typeof nuovoPrezzo === 'string' &&
          !['N/D','Timeout','Esaurita','Cloudflare'].includes(nuovoPrezzo));
      _registraControllata(ownerId, pV, pN, nuovoPrezzo);

      if (pV > 0 && pN > 0) {
        if (diffAss < 0.005) {
          cSteady++;
          setStatus(`➖ ${_etichettaRiga(rigaSheet)}: stabile (${pN}€)`, 'info');
          aggiungiLog(rigaSheet, `Stabile a ${pN}€`, 'ok');
        } else if (pN > pV) {
          cUp++;
          trendSalitiEntries.push({
            riga: rigaSheet,
            nome: codice || nome || '',
            testo: `${pV}€ → ${pN}€ ${varTesto}`,
          });
          setStatus(`🔺 ${_etichettaRiga(rigaSheet)}: salito ${pV}€ → ${pN}€`, 'ok');
          aggiungiLog(rigaSheet, `Salito: ${pV}€ → ${pN}€ ${varTesto}`, 'up');
        } else {
          cDown++;
          trendScesiEntries.push({
            riga: rigaSheet,
            nome: codice || nome || '',
            testo: `${pV}€ → ${pN}€ ${varTesto}`,
          });
          setStatus(`🔻 ${_etichettaRiga(rigaSheet)}: sceso ${pV}€ → ${pN}€`, 'errore');
          aggiungiLog(rigaSheet, `Sceso: ${pV}€ → ${pN}€ ${varTesto}`, 'down');
        }
        ndConsecutivi = 0;
      } else {
        cSteady++;
        if (['N/D','Timeout','Esaurita'].includes(nuovoPrezzo)) {
          ndConsecutivi++;
          _logErroreCarta(rigaSheet, ownerId, String(nuovoPrezzo));
          const _motivoMancante = {
            'Esaurita': 'Prezzo non trovato per lingua e/o condizione',
            'N/D':      'Prezzo non trovato (pagina non caricata correttamente)',
            'Timeout':  'Timeout: pagina troppo lenta a rispondere',
          }[nuovoPrezzo];
          if (_motivoMancante) {
            chiamateSegnaControllataPendenti.push(
              _scriviEsitoDominio(rigaSheet, _motivoMancante).catch(() => {})
            );
          }
        } else {
          ndConsecutivi = 0;
          if (prezzoValido) aggiungiLog(rigaSheet, `Nuovo: ${pN}€`, 'ok');
        }
      }
      if (prezzoValido) {
        chiamateSegnaControllataPendenti.push(
          _scriviEsitoDominio(rigaSheet, null).catch(() => {})
        );
      }
      aggiornaTrend();

      _segnaControllataAsync(rigaSheet);

      registraAiutoGruppo(supabaseClient, rigaSheet, ownerId, AZ.tipoAiuto);

      if (ndConsecutivi >= maxNd) {
        ndConsecutivi = 0;
        setStatus(`⚠️ ${maxNd} N/D di fila! Pausa anti-bot 30s...`, 'errore');
        aggiungiLog(null, `${maxNd} N/D consecutivi → pausa 30s`, 'errore');
        await attendiConCountdown(30000);
        if (stopRequested) break;
      }

      if (urlOriginale && !urlHaTuttiParametri(urlOriginale, lingua, condizione)) {
        const _pVecchi   = new URLSearchParams(urlOriginale.includes('?') ? urlOriginale.split('?')[1] : '');
        const _langPre   = _pVecchi.get('language') || _pVecchi.get('idLanguage') || 'assente';
        const _condPre   = _pVecchi.get('minCondition') || 'assente';
        const _pNuovi    = new URLSearchParams(url.includes('?') ? url.split('?')[1] : '');
        const _langPost  = _pNuovi.get('language') || 'assente';
        const _condPost  = _pNuovi.get('minCondition') || 'assente';
        aggiungiLog(rigaSheet, `URL riscritto: lang ${_langPre}->${_langPost}, cond ${_condPre}->${_condPost} (in collezione: "${lingua}"→id:${LINGUA_MAP_SHARED[(lingua||'').toUpperCase().trim()]||'?'}/${condizione})`, 'info');
        try {
          const esitoUrl = await _scriviUrlDominio(rigaSheet, url);
          if (!esitoUrl || !esitoUrl.ok) {
            aggiungiLog(rigaSheet, `⚠️ URL non riscritto (${esitoUrl?.errore || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
          }
        } catch (eScrittura) {
          aggiungiLog(rigaSheet, `⚠️ URL non riscritto (${eScrittura.message}) — riprova più tardi`, 'errore');
        }
      }

      const prezzoVariato = pV > 0 && pN > 0 && diffAss >= sogliaEuro;
      const prezzoNuovo   = pV === 0 && prezzoValido;

      if (!soloVariazioni || prezzoVariato || prezzoNuovo) {
        if (prezzoValido) {
          try {
            let immagineDaSalvare = immagineTab;
            if (immagineTab && !immagineTab.startsWith('data:')) {
              try {
                const rispostaImg = await new Promise((res, rej) => {
                  chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineTab }, (r) => {
                    if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message)); else res(r);
                  });
                });
                immagineDaSalvare = rispostaImg?.immagine || immagineTab;
              } catch (_) {
              }
            }
            const esitoPrezzo = await _scriviPrezzoDominio(rigaSheet, nuovoPrezzo, immagineDaSalvare);
            if (!esitoPrezzo || !esitoPrezzo.ok) {
              aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${esitoPrezzo?.errore || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
            }
          } catch (eScrittura) {
            aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${eScrittura.message}) — riprova più tardi`, 'errore');
          }
        }
      } else {
        setStatus(`⏭️ ${_etichettaRiga(rigaSheet)}: Δ < ${sogliaEuro}€, saltata.`, 'info');
        aggiungiLog(rigaSheet, `Saltata (Δ < ${sogliaEuro}€)`, '');
        if (immagineTab && !immagineTab.startsWith('data:')) {
          try {
            const rispostaImg = await new Promise((res, rej) => {
              chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineTab }, (r) => {
                if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message)); else res(r);
              });
            });
            const immagineConvertita = rispostaImg?.immagine || null;
            if (immagineConvertita) await _scriviPrezzoDominio(rigaSheet, pV, immagineConvertita);
          } catch (_) {
          }
        }
      }

      if (stopRequested) break;
      if (step + 1 >= carte.length) break;

      ritmo.fissa();
      if ((stepGlobale + 1) % 10 === 0) {
        ritmo.allunga(6000 + Math.floor(Math.random() * 10000));
        setStatus('☕ Pausa anti-bot...', 'info');
      }
    }

    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
      chiamateSegnaControllataPendenti = [];
    }

    await chiamaSupabase(AZ.rilascia, { nomeDispositivo: nomeDisp }).catch(() => {});

    offsetLottiPrecedenti += carte.length;
    numeroLottiElaborati++;
    const _maxLottiRaggiunto = !!overrides.maxLotti && numeroLottiElaborati > overrides.maxLotti;
    if (stopRequested || offsetLottiPrecedenti >= totaleStimato || numeroLottiElaborati > MAX_LOTTI_SICUREZZA || _maxLottiRaggiunto) {
      if (!stopRequested && numeroLottiElaborati > MAX_LOTTI_SICUREZZA && offsetLottiPrecedenti < totaleStimato) {
        console.error('[TRACER controllo-prezzi] fermato dal limite di sicurezza — possibile problema nel conteggio iniziale o in una carta che continua a tornare eleggibile.');
        aggiungiLog(null, '⚠️ Fermato per limite di sicurezza (troppi lotti rispetto al conteggio iniziale) — se ricapita, segnalalo così controlliamo il log.', 'errore');
      }
      carte = [];
    } else {
      carte = await leggiDatiSheet(filtroLocation, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI, nomeDisp, ordineId, AZ.leggi);
    }
    }

    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
      chiamateSegnaControllataPendenti = [];
    }

    if (!stopRequested) {
      setProgress(100);
      const riepilogo = `✅ Fatto! ▲${cUp} ▼${cDown} ➖${cSteady}`;
      setStatus(riepilogo, 'ok');
      aggiungiLog(null, riepilogo, 'ok');
      _esitoSessione = { stato: 'ok' };
    } else {
      setStatus('🛑 Interrotto. La prossima sessione riprenderà automaticamente dalle carte non ancora controllate.', 'ok');
      aggiungiLog(null, 'Interrotto dall\'utente.', '');
      _esitoSessione = { stato: 'interrotto' };
    }

  } catch (err) {
    const stackBreve = (err.stack || '').split('\n').slice(0, 4).join(' | ');
    console.error('[controllo prezzi] errore:', err);
    setStatus('❌ Errore: ' + err.message, 'errore');
    aggiungiLog(null, '❌ ' + err.message + ' [STACK: ' + stackBreve + ']', 'errore');
    _esitoSessione = { stato: 'errore', messaggio: '❌ Errore: ' + err.message };
  } finally {
    chiamaSupabase(AZ.rilascia, { nomeDispositivo: nomeDisp }).catch(() => {});
    _chiudiTabControlloPrezzi();
    _segnaleOccupatoFerma();
    resetUiPostSessione();
  }
}

const LOTTO_CONTROLLO_PREZZI_SEALED = 3;

async function contaEleggibiliControlloPrezziSealed(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto) {
  const data = await chiamaSupabase('leggiSealed', { filtroScaffali, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, soloConta: true });
  if (!data.ok) throw new Error(data.errore || 'Errore nel conteggio iniziale dei prodotti sealed da controllare.');
  return data.totale || 0;
}

async function leggiProdottiSealedDaControllare(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, lottoSize, nomeDisp) {
  const data = await chiamaSupabase('leggiSealed', { filtroScaffali, soloVecchie, giorniMinimi, soloProprie: !aiutaGruppo, ownerIdRichiesto, lottoSize, nomeDispositivo: nomeDisp });
  if (!data.ok) throw new Error(data.errore || 'Errore nel caricamento dei prodotti sealed.');
  return data.carte;
}

function apriTabELeggiPrezzoSealed(urlProdotto) {
  _attivitaAllaHome({ fase: 'lettura', carta: _cartaInCorsoHome });
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'LEGGI_PREZZO_SEALED_GRUPPO', urlProdotto, usaWorkerTab: true, turnoGiaPreso: true   }, (r) => {
      if (chrome.runtime.lastError || !r) { resolve('N/D'); return; }
      if (r.rateLimited)       { resolve('RateLimit');  return; }
      if (r.cloudflareTimeout) { resolve('Cloudflare'); return; }
      if (r.prezzo == null)    { resolve('N/D');        return; }
      resolve({ prezzo: r.prezzo, nome: r.nome, immagine: r.immagine });
    });
  });
}

async function eseguiSessioneSealed(overrides = {}) {
  await _aggiornaMioUserIdSessionePrezzi();
  const filtroScaffali  = overrides.filtroScaffali !== undefined ? overrides.filtroScaffali : [];
  const soloVariazioni  = document.getElementById('soloVariazioni').checked;
  const soloVecchie     = document.getElementById('soloVecchie').checked;
  const giorniMinimi    = parseInt(document.getElementById('giorniMinimi').value) || 3;
  const aiutaGruppo     = overrides.aiutaGruppo !== undefined ? overrides.aiutaGruppo : document.getElementById('aiutaGruppo').checked;
  const ownerIdRichiesto = overrides.ownerIdRichiesto || null;
  const delayMinSec     = parseInt(document.getElementById('sliderDelayMin').value) || DEFAULTS.sliderDelayMinSec;
  const delayMaxSec     = Math.max(parseInt(document.getElementById('sliderDelayMax').value) || DEFAULTS.sliderDelayMaxSec, delayMinSec);
  const sogliaIdx       = parseInt(document.getElementById('sliderSoglia').value);
  const sogliaEuro      = SOGLIA_VALUES[sogliaIdx] ?? 0.01;

  {
    const { data: _sessCheck } = await supabaseClient.auth.getSession();
    if (!_sessCheck.session) {
      setStatus('⚠️ Non sei loggato su Supabase — ricarica l\'estensione per rifare il login.', 'errore');
      return { ok: false, errore: 'Non loggato.' };
    }
  }

  if (isRunning) {
    setStatus('⚠️ Un\'altra sessione (carte) è già in corso — il controllo prezzi sealed riproverà al prossimo giro ordini.', 'errore');
    return { ok: false, errore: 'Sessione carte già in corso.' };
  }

  cUp = 0; cDown = 0; cSteady = 0; cErrori = 0;
  trendSalitiEntries = []; trendScesiEntries = [];
  isRunning = true; stopRequested = false;

  const nomeDisp = await nomeDispositivo();
  let cfConsecutivi = 0;
  let rateLimitRetryCorrente = 0;
  let chiamateSegnaControllataPendenti = [];
  const ritmo = creaRitmoCardmarket(delayMinSec, delayMaxSec);
  function _segnaControllataSealedAsync(rigaSheet) {
    chiamateSegnaControllataPendenti.push(
      chiamaSupabase('segnaControllataSealed', { riga: rigaSheet }).catch((e) => {
        console.error('[segnaControllataSealed] errore:', e?.message || e);
      })
    );
  }

  let erroreFinale = null;
  try {
    await _attendiCodaCardmarketLibera();
    _segnaleOccupatoAvvia();
    const filtroScaffaliLabel = Array.isArray(filtroScaffali) ? `${filtroScaffali.length} scaffale/i` : filtroScaffali;
    setStatus((Array.isArray(filtroScaffali) && filtroScaffali.length > 0) ? `📦 Controllo prezzi sealed (${filtroScaffaliLabel})...` : '📦 Controllo prezzi sealed...', 'info');

    const totaleStimato = await contaEleggibiliControlloPrezziSealed(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto);
    let prodotti = await leggiProdottiSealedDaControllare(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI_SEALED, nomeDisp);

    const MAX_LOTTI_SICUREZZA = Math.ceil((totaleStimato || prodotti.length) / LOTTO_CONTROLLO_PREZZI_SEALED) + 5;
    let numeroLottiElaborati = 1;

    if (prodotti.length === 0) {
      throw new Error(
        ((Array.isArray(filtroScaffali) && filtroScaffali.length > 0) ? `Nessun prodotto sealed con URL da controllare per ${filtroScaffaliLabel}.` : 'Nessun prodotto sealed con URL da controllare.')
      );
    }

    document.getElementById('timerContainer').classList.add('visible');
    const elTotale = document.getElementById('tempoTotale');
    const elAttesa = document.getElementById('tempoAttesa');
    let offsetLottiPrecedenti = 0;

    while (prodotti.length > 0) {
    for (let step = 0; step < prodotti.length; step++) {
      if (stopRequested) break;

      const { rigaSheet, urlBase, codice, nome, prezzoPrecedente, ownerId } = prodotti[step];
      _etichetteRiga[rigaSheet] = nome || codice || null;
      const stepGlobale = offsetLottiPrecedenti + step;

      if (!urlBase) {
        _logErroreCarta(rigaSheet, ownerId, `${_etichettaRiga(rigaSheet)}: nessun URL salvato, saltato`, 'err');
        cErrori++;
        _segnaControllataSealedAsync(rigaSheet);
        continue;
      }

      const mediaMs  = ((delayMinSec + delayMaxSec) / 2) * 1000 + 1200;
      const restanti = Math.max(totaleStimato - stepGlobale, prodotti.length - step);
      const stimaSec = restanti * ((15000 + mediaMs) / 1000);
      if (elTotale) elTotale.textContent = formattaTempo(stimaSec);

      setStatus(`📦 Sealed ${stepGlobale + 1}/${totaleStimato || prodotti.length} — ${_etichettaRiga(rigaSheet)}`, 'info');
      setProgress(totaleStimato > 0 ? Math.round((stepGlobale / totaleStimato) * 100) : 0);
      _segnaCartaHome({ nome: nome || codice || '', codice: '', lingua: '', cond: '', di: _diPrezzi(ownerId) },
        stepGlobale + 1, totaleStimato || prodotti.length);

      await ritmo.attendi();
      if (stopRequested) break;
      const risultato = await apriTabELeggiPrezzoSealed(urlBase);
      ritmo.fissa();
      const nuovoPrezzo = (risultato && typeof risultato === 'object') ? risultato.prezzo : risultato;

      if (stopRequested) break;

      if (nuovoPrezzo === 'RateLimit') {
        rateLimitRetryCorrente++;
        aggiungiLog(rigaSheet, 'Error 1015 (rate limited) → pausa 30 min', 'errore');
        setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti...', 'errore');
        await attendiConCountdown(PAUSA_RATE_LIMIT_MS);
        if (stopRequested) break;
        if (rateLimitRetryCorrente >= 3) {
          aggiungiLog(rigaSheet, 'Saltato dopo 3 rate limit consecutivi', 'errore');
          rateLimitRetryCorrente = 0;
          _segnaControllataSealedAsync(rigaSheet);
          continue;
        }
        step--;
        continue;
      }
      rateLimitRetryCorrente = 0;

      if (nuovoPrezzo === 'Cloudflare') {
        cfConsecutivi++;
        aggiungiLog(rigaSheet, 'Saltato (Cloudflare non risolto)', 'errore');
        setStatus(`⏭️ ${_etichettaRiga(rigaSheet)}: saltato (Cloudflare).`, 'errore');
        _segnaControllataSealedAsync(rigaSheet);
        if (cfConsecutivi >= 2) {
          cfConsecutivi = 0;
          setStatus('🚫 2 Cloudflare consecutivi → pausa anti-ban 2 min...', 'errore');
          aggiungiLog(null, '2 Cloudflare consecutivi → pausa 2 min', 'errore');
          await attendiConCountdown(120000);
          if (stopRequested) break;
        }
        continue;
      }
      cfConsecutivi = 0;

      const pV = pulisciPrezzo(prezzoPrecedente);
      const pN = pulisciPrezzo(nuovoPrezzo);
      const diffAss  = Math.abs(pN - pV);
      const varTesto = calcolaVariazione(pV, pN);
      const prezzoValido = !!risultato && typeof risultato === 'object' && typeof risultato.prezzo === 'number';
      _registraControllata(ownerId, pV, pN, nuovoPrezzo);

      if (pV > 0 && pN > 0) {
        if (diffAss < 0.005) {
          cSteady++;
          aggiungiLog(rigaSheet, `Stabile a ${pN}€`, 'ok');
        } else if (pN > pV) {
          cUp++;
          trendSalitiEntries.push({ riga: rigaSheet, nome: codice || nome || '', testo: `${pV}€ → ${pN}€ ${varTesto}` });
          aggiungiLog(rigaSheet, `Salito: ${pV}€ → ${pN}€ ${varTesto}`, 'up');
        } else {
          cDown++;
          trendScesiEntries.push({ riga: rigaSheet, nome: codice || nome || '', testo: `${pV}€ → ${pN}€ ${varTesto}` });
          aggiungiLog(rigaSheet, `Sceso: ${pV}€ → ${pN}€ ${varTesto}`, 'down');
        }
      } else {
        cSteady++;
        if (nuovoPrezzo === 'N/D') _logErroreCarta(rigaSheet, ownerId, 'N/D');
        else if (prezzoValido) aggiungiLog(rigaSheet, `Nuovo: ${pN}€`, 'ok');
      }
      aggiornaTrend();

      _segnaControllataSealedAsync(rigaSheet);
      registraAiutoGruppo(supabaseClient, rigaSheet, ownerId, 'controllo_prezzi_sealed');

      const prezzoVariato = pV > 0 && pN > 0 && diffAss >= sogliaEuro;
      const prezzoNuovo   = pV === 0 && prezzoValido;
      if ((!soloVariazioni || prezzoVariato || prezzoNuovo) && prezzoValido) {
        try {
          let immagineDaSalvare = risultato.immagine;
          if (immagineDaSalvare && !immagineDaSalvare.startsWith('data:')) {
            try {
              const rispostaImg = await new Promise((res, rej) => {
                chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: immagineDaSalvare }, (r) => {
                  if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message)); else res(r);
                });
              });
              immagineDaSalvare = rispostaImg?.immagine || immagineDaSalvare;
            } catch (_) {   }
          }
          const esitoScrittura = await chiamaSupabase('aggiornaPrezzoRigaSealed', { riga: rigaSheet, prezzo: risultato.prezzo, immagine: immagineDaSalvare || undefined });
          if (!esitoScrittura || !esitoScrittura.ok) {
            aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${(esitoScrittura && esitoScrittura.errore) || 'errore sconosciuto'}) — riprova più tardi`, 'errore');
          }
        } catch (eScrittura) {
          aggiungiLog(rigaSheet, `⚠️ Prezzo non scritto (${eScrittura.message}) — riprova più tardi`, 'errore');
        }
      }

      if (stopRequested) break;
      if (step + 1 >= prodotti.length) break;

      ritmo.fissa();
      if ((stepGlobale + 1) % 10 === 0) ritmo.allunga(6000 + Math.floor(Math.random() * 10000));
    }

    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
      chiamateSegnaControllataPendenti = [];
    }
    await chiamaSupabase('rilasciaClaimSealed', { nomeDispositivo: nomeDisp }).catch(() => {});

    offsetLottiPrecedenti += prodotti.length;
    numeroLottiElaborati++;
    if (stopRequested || offsetLottiPrecedenti >= totaleStimato || numeroLottiElaborati > MAX_LOTTI_SICUREZZA) {
      prodotti = [];
    } else {
      prodotti = await leggiProdottiSealedDaControllare(filtroScaffali, soloVecchie, giorniMinimi, aiutaGruppo, ownerIdRichiesto, LOTTO_CONTROLLO_PREZZI_SEALED, nomeDisp);
    }
    }

    if (chiamateSegnaControllataPendenti.length > 0) {
      await Promise.allSettled(chiamateSegnaControllataPendenti);
    }

    if (!stopRequested) {
      const riepilogo = `✅ Sealed fatto! ▲${cUp} ▼${cDown} ➖${cSteady}`;
      setStatus(riepilogo, 'ok');
      aggiungiLog(null, riepilogo, 'ok');
    } else {
      setStatus('🛑 Controllo prezzi sealed interrotto.', 'ok');
    }
  } catch (err) {
    erroreFinale = err.message;
    setStatus('❌ Errore controllo prezzi sealed: ' + err.message, 'errore');
    aggiungiLog(null, '❌ ' + err.message, 'errore');
  } finally {
    await chiamaSupabase('rilasciaClaimSealed', { nomeDispositivo: nomeDisp }).catch(() => {});
    chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'sealed' });
    _segnaleOccupatoFerma();
    resetUiPostSessione();
  }

  return erroreFinale ? { ok: false, errore: erroreFinale } : { ok: true, salite: cUp, scese: cDown, invariate: cSteady };
}

async function _avviaAutorunSealedSeRichiesto() {
  const { ordinePendenteAutorunSealed } = await chrome.storage.local.get('ordinePendenteAutorunSealed');
  if (!ordinePendenteAutorunSealed || ordinePendenteAutorunSealed.tipo !== 'controlla_prezzi_sealed') return;

  await chrome.storage.local.remove('ordinePendenteAutorunSealed');
  if (isRunning) {
    await _rimettiOrdineInAttesa(ordinePendenteAutorunSealed.id);
    return;
  }

  const ordineId = ordinePendenteAutorunSealed.id;
  const scaffali = ordinePendenteAutorunSealed.parametri?.scaffali;
  const aiutaGruppoOrdine = ordinePendenteAutorunSealed.parametri?.aiutaGruppo;
  const creatoDa = ordinePendenteAutorunSealed.creatoDa;
  await assicuraLoginSupabase();

  setStatus('🤖 Ordine ricevuto dal sito — avvio controllo prezzi sealed...', 'info');
  const fermaSorveglianza = _sorvegliaAnnullamentoOrdine(ordineId);
  let esito;
  try {
    esito = await eseguiSessioneSealed({
      filtroScaffali: Array.isArray(scaffali) ? scaffali : [],
      ...(aiutaGruppoOrdine !== undefined ? { aiutaGruppo: aiutaGruppoOrdine } : {}),
      ...(creatoDa ? { ownerIdRichiesto: creatoDa } : {}),
    });
  } finally {
    if (fermaSorveglianza()) _segnalaAnnullamentoOrdine();
  }
  if (_ordineAnnullatoDalSito) return;

  try {
    if (!esito.ok) {
      await supabaseClient.from('ordini').update({
        stato: 'errore',
        errore_msg: esito.errore || 'Errore sconosciuto durante il controllo prezzi sealed.',
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'completato',
        risultato: { salite: esito.salite, scese: esito.scese, invariate: esito.invariate },
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    }
  } catch (e) {
    console.error('[ordini sealed] impossibile scrivere l\'esito sull\'ordine:', e);
  }
}

(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('footer-credit');
  if (!footer) return;
  footer.textContent = 'Bindex · estensione v' + chrome.runtime.getManifest().version + ' · © Lunachiara';
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

// Senza accesso a Cardmarket: apre la scheda per accedere e aspetta (fino a 20 minuti) che l'accesso
// si veda, poi si riparte da soli. Lo stato arriva dal background in storage (statoLoginCardmarket).
function _attendiAccessoCardmarket(minuti = 20) {
  return new Promise((resolve) => {
    let finito = false;
    const fine = (ok) => {
      if (finito) return;
      finito = true;
      clearTimeout(timer);
      chrome.storage.onChanged.removeListener(suCambio);
      resolve(ok);
    };
    const suCambio = (c) => {
      const nuovo = c.statoLoginCardmarket && c.statoLoginCardmarket.newValue;
      if (nuovo && nuovo.loggato === true) fine(true);
    };
    const timer = setTimeout(() => fine(false), minuti * 60 * 1000);
    chrome.storage.onChanged.addListener(suCambio);
    chrome.runtime.sendMessage({ type: 'CM_ACCESSO_APRI' }, () => { void chrome.runtime.lastError; });
  });
}

async function _accessoCardmarketPronto() {
  setStatus('🔍 Controllo l\'accesso a Cardmarket...', 'info');
  let risposta;
  try {
    risposta = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_SILENZIOSA' }, (r) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(r);
      });
    });
  } catch (e) {
    setStatus('⚠️ Non riesco a controllare l\'accesso a Cardmarket (' + e.message + ') — riprova tra poco.', 'errore');
    return false;
  }
  if (risposta && risposta.loggato === true) return true;
  setStatus(risposta && risposta.cloudflare
    ? '🔒 Cardmarket chiede una verifica: completala nella scheda che ho aperto (e accedi con l\'account secondario se serve). Parto da solo appena hai fatto.'
    : '🔒 Accedi a Cardmarket nella scheda che ho aperto, con l\'account secondario. Parto da solo appena hai fatto.', 'info');
  const ok = await _attendiAccessoCardmarket();
  if (!ok) {
    setStatus('⏹ Non ho visto l\'accesso a Cardmarket in 20 minuti: premi di nuovo Avvia quando sei pronto.', 'errore');
    return false;
  }
  setStatus('🔓 Collegato a Cardmarket: parto.', 'ok');
  return true;
}

document.getElementById('btnAvvia').addEventListener('click', async () => {
  if (isRunning) {
    stopRequested = true;
    document.getElementById('btnAvvia').disabled    = true;
    document.getElementById('btnAvvia').textContent = 'Arresto…';
    _attivitaAllaHome({ fase: 'in-arresto' });
    setStatus('⏳ Finisco la carta attuale e mi fermo...', 'info');
    return;
  }
  if (!(await verificaAccessoValido())) {
    return;
  }
  if (!(await _accessoCardmarketPronto())) return;
  if (isRunning) return;
  await eseguiSessione();
});

document.getElementById('bugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});

document.getElementById('changelogLink').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

let _cartaInCorsoHome = null;
let _avanzamentoHome = { n: 0, totale: 0 };
const _ultimeControllate = [];
const _formatoEuroPrezzi = new Intl.NumberFormat('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function _attivitaAllaHome(dati) {
  if (window.parent === window) return;
  const origine = location.origin && location.origin !== 'null' ? location.origin : '*';
  try {
    window.parent.postMessage({ type: 'CARDSYNC_ATTIVITA', chi: 'prezzi', n: _avanzamentoHome.n, totale: _avanzamentoHome.totale, ...dati }, origine);
  } catch (_) {   }
}

function _segnaCartaHome(carta, n, totale) {
  _cartaInCorsoHome = carta;
  _avanzamentoHome = { n, totale };
}

function _diPrezzi(ownerId) {
  return _cartaDiUnAltro(ownerId) ? 'del gruppo' : 'tua';
}

function _euroPrezzi(v) {
  return Number.isFinite(v) && v > 0 ? _formatoEuroPrezzi.format(v) + ' €' : '—';
}

function _registraControllata(ownerId, prima, ora, grezzo) {
  const altro = _cartaDiUnAltro(ownerId);
  const voce = {
    carta: _cartaInCorsoHome || {},
    ownerId: ownerId || null,
    prima: prima > 0 ? prima : null,
    ora: ora > 0 ? ora : null,
    testo: ora > 0 ? null : (altro ? 'senza prezzo' : ({ 'Esaurita': 'nessuna offerta', 'N/D': 'non letto', 'Timeout': 'troppo lenta', 'Cloudflare': 'Cloudflare' }[grezzo] || 'senza prezzo')),
    quando: Date.now(),
  };
  _ultimeControllate.unshift(voce);
  if (_ultimeControllate.length > 15) _ultimeControllate.length = 15;
  _disegnaUltimeControllate();
  _attivitaAllaHome({ fase: 'fatta', carta: voce.carta, esito: { ok: true, prezzo: voce.ora, prezzoPrima: voce.prima } });
}

function _disegnaUltimeControllate() {
  const corpo = document.getElementById('ultimeControllateBody');
  const vuoto = document.getElementById('ultimeControllateVuoto');
  if (!corpo) return;
  if (vuoto) vuoto.hidden = _ultimeControllate.length > 0;
  corpo.innerHTML = '';
  _ultimeControllate.forEach((v) => {
    const riga = document.createElement('div');
    riga.className = 'ultime-riga';
    const cella = (testo, classe) => {
      const el = document.createElement('span');
      if (classe) el.className = classe;
      el.textContent = testo;
      riga.appendChild(el);
      return el;
    };
    const tdCarta = cella('', 'ultime-carta');
    const nome = document.createElement('b');
    nome.textContent = v.carta.nome || '—';
    tdCarta.appendChild(nome);
    if (v.carta.codice) {
      const codice = document.createElement('span');
      codice.className = 'mono';
      codice.textContent = v.carta.codice;
      tdCarta.appendChild(codice);
    }
    cella(_diPrezzi(v.ownerId) === 'tua' ? 'tu' : 'gruppo', 'ultime-di');
    cella(_euroPrezzi(v.prima), 'mono destra tenue');
    cella(v.ora != null ? _euroPrezzi(v.ora) : v.testo, 'mono destra forte');
    let variazione = '—';
    let classe = 'mono destra tenue';
    if (v.prima != null && v.ora != null) {
      const diff = v.ora - v.prima;
      if (Math.abs(diff) < 0.005) variazione = '=';
      else {
        variazione = (diff > 0 ? '▲ +' : '▼ −') + _formatoEuroPrezzi.format(Math.abs(diff)) + ' €';
        classe = 'mono destra forte ' + (diff > 0 ? 'su' : 'giu');
      }
    }
    cella(variazione, classe);
    cella(new Date(v.quando).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }), 'destra tenue');
    corpo.appendChild(riga);
  });
}

let _ultimoSottotitoloPrezzi = 0;
async function _aggiornaSottotitoloPrezzi(forza) {
  const el = document.getElementById('prezziSottotitolo');
  if (!el) return;
  if (!forza && (window.innerWidth === 0 || document.visibilityState === 'hidden')) return;
  _ultimoSottotitoloPrezzi = Date.now();
  try {
    const giorni = parseInt(document.getElementById('giorniMinimi').value, 10) || 3;
    const base = { p_owner_id_richiesto: null, p_solo_proprie: true, p_filtro_location: null, p_giorni_minimi: giorni };
    const [vecchie, tutte] = await Promise.all([
      supabaseClient.rpc('conta_carte_da_controllare_gruppo', { ...base, p_solo_vecchie: true }),
      supabaseClient.rpc('conta_carte_da_controllare_gruppo', { ...base, p_solo_vecchie: false }),
    ]);
    if (vecchie.error || tutte.error) return;
    let f;
    try { f = new Intl.NumberFormat('it-IT', { useGrouping: 'always' }); } catch (_) { f = new Intl.NumberFormat('it-IT'); }
    el.textContent = `${f.format(vecchie.data || 0)} tue carte non controllate da ${giorni} giorn${giorni === 1 ? 'o' : 'i'}, su ${f.format(tutte.data || 0)}`;
  } catch (_) {   }
}
setInterval(() => _aggiornaSottotitoloPrezzi(false), 60000);
window.addEventListener('resize', () => {
  if (window.innerWidth > 0 && Date.now() - _ultimoSottotitoloPrezzi > 10000) _aggiornaSottotitoloPrezzi(false);
});
document.getElementById('giorniMinimi').addEventListener('change', () => _aggiornaSottotitoloPrezzi(true));
setTimeout(() => _aggiornaSottotitoloPrezzi(true), 600);
_disegnaUltimeControllate();
