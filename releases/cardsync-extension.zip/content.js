// Lettura del prezzo nella scheda aperta dal controllo prezzi: la inietta popup.js insieme a
// shared.js, una volta per pagina. Non è un content script del manifest: non deve girare sulle
// pagine di Cardmarket aperte a mano.

(function () {
  if (window.__cardsyncLetturaAttiva) return;
  window.__cardsyncLetturaAttiva = true;

  try {
    // dentro o fuori da Cardmarket, visto dalla pagina che l'estensione sta già leggendo
    if (document.getElementById('account-dropdown')) {
      chrome.runtime.sendMessage({ type: 'STATO_LOGIN_CARDMARKET', loggato: true }, () => { void chrome.runtime.lastError; });
    } else if (document.getElementById('login-signup')) {
      chrome.runtime.sendMessage({ type: 'STATO_LOGIN_CARDMARKET', loggato: false }, () => { void chrome.runtime.lastError; });
    }
  } catch (_) {   }

  let inviato = false;
  let cloudflareSegnalatO = false;
  let fallbackTimeoutId = null;

  const CF_TITLES = [
    'just a moment', 'un attimo', 'ci siamo quasi', 'almost there',
    'checking your', 'einen moment', 'por favor', 'verifique', 'patikrinimas',
  ];

  const RATE_LIMIT_MARKERS = ['error 1015', 'you are being rate limited'];

  function isRateLimited() {
    const testo = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
    return RATE_LIMIT_MARKERS.some(m => testo.includes(m));
  }

  let rateLimitSegnalato = false;
  function segnalaRateLimit() {
    if (!rateLimitSegnalato) {
      rateLimitSegnalato = true;
      if (fallbackTimeoutId) clearTimeout(fallbackTimeoutId);
      chrome.runtime.sendMessage({ type: 'RATE_LIMIT_DETECTED' });
    }
  }

  function _paginaConContenuto() {
    if (document.querySelector('.article-row')) return true;
    const h1 = document.querySelector('h1');
    return !!h1 && /\(.+\)/.test(h1.textContent || '');
  }
  function isCloudflare() {
    const title = document.title.toLowerCase();
    if (CF_TITLES.some(t => title.includes(t))) return true;
    if (
      document.getElementById('challenge-running') ||
      document.querySelector('[class*="cf-challenge"]') ||
      document.querySelector('#challenge-form') ||
      document.querySelector('#cf-challenge-running')
    ) return true;
    if (
      document.querySelector('.cf-turnstile') ||
      document.querySelector('[class*="cf-chl-widget"]') ||
      document.querySelector('[id*="cf-chl-widget"]')
    ) return !_paginaConContenuto();
    return false;
  }

  function segnalaCloudflare() {
    if (!cloudflareSegnalatO) {
      cloudflareSegnalatO = true;
      if (fallbackTimeoutId) clearTimeout(fallbackTimeoutId);
      chrome.runtime.sendMessage({ type: 'CLOUDFLARE_DETECTED' });
    }
  }

  function rigaSoddisfaFiltri(riga, idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti) {
    if (typeof rigaSoddisfaFiltriShared === 'function') {
      return rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
    }
    console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile (shared.js non caricato?) — nessun filtro applicato a questa riga');
    return true;
  }

  function leggiParametriUrl() {
    const params = new URLSearchParams(window.location.search);
    return {
      idLanguage: params.get('language') || params.get('idLanguage') || null,
      minCondition: (params.get('minCondition') || '').toLowerCase() || null,
      isReverseHolo: params.get('isReverseHolo') === 'Y',
      isFirstEd: params.get('isFirstEd') === 'Y',
    };
  }

  function leggiNomeECodiceDaH1() {
    const h1 = document.querySelector('h1');
    if (!h1) return { nome: null, codice: null };
    const clone = h1.cloneNode(true);
    clone.querySelectorAll('span').forEach(s => s.remove());
    const testo = clone.textContent.trim();
    const ultimaParentesiIdx = testo.lastIndexOf('(');
    if (ultimaParentesiIdx === -1) return { nome: testo.toUpperCase() || null, codice: null };
    const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')')).trim().toUpperCase();
    const codice = codiceRaw || null;
    const nomePre = testo.slice(0, ultimaParentesiIdx).trim().toUpperCase();
    if (nomePre) return { nome: nomePre, codice };
    const chiusaIdx = testo.lastIndexOf(')');
    const nomePost = chiusaIdx !== -1 ? (testo.slice(chiusaIdx + 1).trim().toUpperCase() || null) : null;
    if (nomePost) return { nome: nomePost, codice };
    const primaP = testo.indexOf('(');
    const nomeAnte = primaP > 0 ? (testo.slice(0, primaP).trim().toUpperCase() || null) : null;
    return { nome: nomeAnte, codice };
  }

  function estraiImmagineReale() {
    const metaImg = document.querySelector('meta[property="og:image"]');
    let immagine = metaImg ? metaImg.getAttribute('content') : null;
    if (immagine && !immagine.includes('product-images')) immagine = null;
    if (!immagine) {
      const imgReale = Array.from(document.querySelectorAll('img'))
        .map(img => img.src)
        .find(src => src && src.includes('product-images'));
      immagine = imgReale || null;
    }
    return immagine;
  }

  function estraiPrezzo() {
    if (isRateLimited()) { segnalaRateLimit(); return false; }
    if (isCloudflare()) { segnalaCloudflare(); return false; }
    if (cloudflareSegnalatO && !inviato) cloudflareSegnalatO = false;

    const { idLanguage, minCondition, isReverseHolo, isFirstEd } = leggiParametriUrl();
    const righe = Array.from(document.querySelectorAll('.article-row'));
    if (righe.length === 0) return false;

    let righeFiltrate = righe.filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, isReverseHolo, isFirstEd));
    if (righeFiltrate.length === 0) {
      const righeSenzaEsclusioneVarianti = righe.filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, true, true));
      if (righeSenzaEsclusioneVarianti.length > 0) righeFiltrate = righeSenzaEsclusioneVarianti;
    }
    if (righeFiltrate.length === 0) return false;

    for (const riga of righeFiltrate) {
      const selettori = [
        '.price-container .fw-bold',
        '.col-offer-price .fw-bold',
        '[class*="price"] .fw-bold',
        '.color-primary.fw-bold',
        '.price',
      ];
      let prezzoTesto = null;
      for (const sel of selettori) {
        const el = riga.querySelector(sel);
        if (el && el.textContent.includes('€')) { prezzoTesto = el.textContent.trim(); break; }
      }
      if (!prezzoTesto) {
        for (const el of riga.querySelectorAll('span, div')) {
          const txt = el.textContent.trim();
          if (/^\d[\d.,]*\s*€$/.test(txt)) { prezzoTesto = txt; break; }
        }
      }
      if (prezzoTesto) {
        const match = prezzoTesto.match(/([\d,.]+)\s*€/);
        if (match) {
          const pulito = match[1].replace(/\./g, '').replace(',', '.');
          const prezzo = parseFloat(pulito);
          if (!inviato) {
            inviato = true;
            const _immagine = estraiImmagineReale();
            const { nome: _nomePagina, codice: _codicePagina } = leggiNomeECodiceDaH1();
            chrome.runtime.sendMessage({
              type: 'PREZZO_TROVATO',
              prezzo: isNaN(prezzo) ? 'N/D' : prezzo,
              immagine: _immagine,
              nomePagina: _nomePagina,
              codicePagina: _codicePagina,
            });
          }
          return true;
        }
      }
    }
    return false;
  }

  const _RE_H1_LISTA_CONTENT = /^(?:singole|singles|einzelkarten|cartas sueltas|cartes à l'unité|cartas avulsas)(?:\s|$)|\s(?:singole|singles|einzelkarten)$/i;
  function _ePaginaListaEspansione() {
    const path = window.location.pathname;
    const i = path.indexOf('/Singles/');
    if (i === -1) return false;
    if (path.slice(i + '/Singles/'.length).split('/').filter(Boolean).length < 2) return true;
    const h1 = document.querySelector('h1');
    if (!h1) return false;
    const clone = h1.cloneNode(true);
    clone.querySelectorAll('span').forEach(s => s.remove());
    return _RE_H1_LISTA_CONTENT.test(clone.textContent.replace(/\s+/g, ' ').trim());
  }
  if (!isRateLimited() && !isCloudflare() && _ePaginaListaEspansione()) {
    inviato = true;
    chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'LinkNonValido', nomePagina: '', codicePagina: '' }, () => { void chrome.runtime.lastError; });
    return;
  }

  if (estraiPrezzo()) return;

  let debounceEstraiPrezzoId = null;
  const observer = new MutationObserver(() => {
    if (debounceEstraiPrezzoId) return;
    debounceEstraiPrezzoId = setTimeout(() => {
      debounceEstraiPrezzoId = null;
      if (isRateLimited()) { segnalaRateLimit(); return; }
      if (isCloudflare()) { segnalaCloudflare(); return; }
      if (estraiPrezzo()) { observer.disconnect(); titleObserver.disconnect(); }
    }, 150);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  const titleObserver = new MutationObserver(() => {
    if (isRateLimited()) { segnalaRateLimit(); return; }
    if (isCloudflare()) segnalaCloudflare();
  });
  const titleEl = document.querySelector('title');
  if (titleEl) titleObserver.observe(titleEl, { childList: true, characterData: true, subtree: true });

  const _fineAttesaPrezzo = () => {
    observer.disconnect();
    titleObserver.disconnect();
    if (rateLimitSegnalato) return;
    if (!inviato) {
      inviato = true;
      const { idLanguage, minCondition, isReverseHolo, isFirstEd } = leggiParametriUrl();
      const tutteLeRighe = document.querySelectorAll('.article-row');
      let righeFiltrate = Array.from(tutteLeRighe).filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, isReverseHolo, isFirstEd));
      if (righeFiltrate.length === 0) {
        const righeSenzaEsclusioneVarianti = Array.from(tutteLeRighe).filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, true, true));
        if (righeSenzaEsclusioneVarianti.length > 0) righeFiltrate = righeSenzaEsclusioneVarianti;
      }
      const { nome: _nomePagina, codice: _codicePagina } = leggiNomeECodiceDaH1();
      if (tutteLeRighe.length > 0 && righeFiltrate.length === 0) {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'Esaurita', nomePagina: _nomePagina, codicePagina: _codicePagina });
        return;
      }
      if (tutteLeRighe.length === 0 && _nomePagina) {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'Esaurita', nomePagina: _nomePagina, codicePagina: _codicePagina });
        return;
      }
      const testo = document.body.innerText.toLowerCase();
      if (testo.includes('no result') || testo.includes('nessun risultato') || testo.includes('esaurito')) {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'Esaurita', nomePagina: _nomePagina, codicePagina: _codicePagina });
      } else {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'N/D', nomePagina: _nomePagina, codicePagina: _codicePagina });
      }
    }
  };
  fallbackTimeoutId = setTimeout(() => {
    if (document.readyState !== 'complete') {
      fallbackTimeoutId = setTimeout(_fineAttesaPrezzo, TEMPO_EXTRA_LETTURA_MS);
      return;
    }
    _fineAttesaPrezzo();
  }, TEMPO_MAX_LETTURA_MS);
})();
