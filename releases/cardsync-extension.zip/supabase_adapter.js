// Le chiamate a Supabase delle pagine: chiamaSupabase(azione, dati).
// Le funzioni di gruppo del database toccano solo carte prenotate da chi chiama o proprie.

const SUPABASE_URL = 'https://xpfibrzsffurdlypxnrw.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhwZmlicnpzZmZ1cmRseXB4bnJ3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODczOTU0MzYsImV4cCI6MjEwMjk3MTQzNn0.k5eELxNA3HkWdslxoqIL_IR8qFZ1W0j_IWZugE2GVCg';

function _archiviSessione() {
  return new Promise((resolve) => {
    const sessione = chrome.storage.session || null;
    try {
      chrome.storage.local.get(['cardsyncMantieniAccessoEstensione'], (r) => {
        const mantieni = !r || r.cardsyncMantieniAccessoEstensione !== false;
        if (!sessione) { resolve({ scelto: chrome.storage.local, altro: null }); return; }
        resolve(mantieni ? { scelto: chrome.storage.local, altro: sessione } : { scelto: sessione, altro: chrome.storage.local });
      });
    } catch (_) {
      resolve({ scelto: chrome.storage.local, altro: null });
    }
  });
}

async function _spostaSessioneNellArchivioScelto() {
  const { scelto, altro } = await _archiviSessione();
  if (!altro) return;
  const tutto = await altro.get(null);
  const chiavi = Object.keys(tutto || {}).filter(k => k.startsWith('sb-'));
  for (const k of chiavi) {
    await scelto.set({ [k]: tutto[k] });
    await altro.remove(k);
  }
}

try {
  chrome.storage.onChanged.addListener((cambi, area) => {
    if (area === 'local' && cambi.cardsyncMantieniAccessoEstensione) {
      _spostaSessioneNellArchivioScelto().catch(() => {});
    }
  });
} catch (_) {   }

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: {
      getItem: async (key) => {
        const { scelto, altro } = await _archiviSessione();
        const r = await scelto.get([key]);
        if (r && r[key] != null) return r[key];
        if (!altro) return null;
        const r2 = await altro.get([key]);
        if (!r2 || r2[key] == null) return null;
        await scelto.set({ [key]: r2[key] });
        await altro.remove([key]);
        return r2[key];
      },
      setItem: async (key, value) => {
        const { scelto, altro } = await _archiviSessione();
        await scelto.set({ [key]: value });
        if (altro) await altro.remove([key]);
      },
      removeItem: async (key) => {
        await chrome.storage.local.remove([key]);
        if (chrome.storage.session) await chrome.storage.session.remove([key]);
      },
    },
    autoRefreshToken: true,
    persistSession: true,
  },
});

const URL_ULTIMA_VERSIONE_ADAPTER = 'https://bindexxx.github.io/bindex/releases/latest-version.txt';
let _ultimoControlloVersioneMs = 0;
let _versioneAggiornataCache = true;

function _versioneMaggioreAdapter(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0, nb = pb[i] || 0;
    if (na > nb) return true;
    if (na < nb) return false;
  }
  return false;
}

async function _verificaVersioneAggiornata() {
  const ora = Date.now();
  if (ora - _ultimoControlloVersioneMs < 3 * 60 * 1000) return _versioneAggiornataCache;
  _ultimoControlloVersioneMs = ora;

  let clientOk = true;
  try {
    const resp = await fetch(URL_ULTIMA_VERSIONE_ADAPTER + '?t=' + ora, { cache: 'no-store' });
    if (resp.ok) {
      const ultima = (await resp.text()).trim();
      const locale = chrome.runtime.getManifest().version;
      clientOk = !ultima || !_versioneMaggioreAdapter(ultima, locale);
    }
  } catch (_) {   }

  let dbOk = true;
  try {
    const { error } = await supabaseClient.rpc('verifica_versione_minima', { p_versione_client: chrome.runtime.getManifest().version });
    if (error && String(error.message || '').includes('ESTENSIONE_NON_AGGIORNATA')) dbOk = false;
  } catch (_) {
  }

  _versioneAggiornataCache = clientOk && dbOk;
  return _versioneAggiornataCache;
}

async function chiamaSupabase(azione, payload) {
  const { data: sessionData } = await supabaseClient.auth.getSession();
  const userId = sessionData?.session?.user?.id;
  if (!userId) return { ok: false, errore: 'Non sei loggato — apri il popover account.' };

  if (!(await _verificaVersioneAggiornata())) {
    return { ok: false, errore: 'Estensione non aggiornata — aggiorna prima di continuare (vedi il sito per le istruzioni).' };
  }

  switch (azione) {

    case 'aggiungi': {
      const riga = _rigaDatiToSupabase(payload.rigaDati, payload.statoOverride);
      if (payload.dbRigaId) {
        const { data: nuovoId, error } = await supabaseClient.rpc('completa_riga_coda_carte', {
          p_riga_coda_id: payload.dbRigaId,
          p_nome: riga.nome, p_codice: riga.codice, p_location: riga.location,
          p_qty: riga.qty, p_lingua: riga.lingua, p_condizione: riga.condizione,
          p_url: riga.url, p_prezzo: riga.prezzo, p_note: riga.note,
          p_immagine: riga.immagine, p_tipo: payload.tipoOverride || 'carta',
          p_destinazione: payload.destinazione || 'collezione',
          p_prezzo_obiettivo: riga.prezzo_obiettivo,
          p_sigillata_originale: riga.sigillata_originale,
        });
        if (error) return { ok: false, errore: error.message };
        return { ok: true, riga: nuovoId };
      }
      riga.owner_id = userId;
      riga.tipo = payload.tipoOverride || 'carta';
      const { data, error } = await supabaseClient.from('carte').insert(riga).select().single();
      if (error) return { ok: false, errore: error.message };
      try {
        const qtyMov = Number(riga.qty) || 1;
        const prezzoMov = riga.prezzo != null ? Number(riga.prezzo) : null;
        const { error: errMov } = await supabaseClient.from('movimenti_collezione').insert({
          owner_id: userId, tipo_evento: 'aggiunta', oggetto_tipo: 'carta', oggetto_id: data.id,
          nome_snapshot: riga.nome || riga.codice || '—', quantita_delta: qtyMov,
          prezzo_unitario: (prezzoMov != null && !isNaN(prezzoMov)) ? prezzoMov : null,
          valore_delta: (prezzoMov != null && !isNaN(prezzoMov)) ? prezzoMov * qtyMov : null,
          fonte: 'estensione',
        });
        if (errMov) console.error('[movimenti] aggiunta a mano non registrata in Variazione valore:', errMov.message);
      } catch (eMov) {
        console.error('[movimenti] aggiunta a mano non registrata in Variazione valore:', eMov && eMov.message);
      }
      return { ok: true, riga: data.id };
    }

    case 'aggiungiWishlist': {
      const riga = _rigaDatiToWishlist(payload.rigaDati);
      if (payload.dbRigaId) {
        const { data: nuovoId, error } = await supabaseClient.rpc('completa_riga_coda_carte', {
          p_riga_coda_id: payload.dbRigaId,
          p_nome: riga.nome, p_codice: riga.codice, p_location: riga.location,
          p_qty: riga.qty, p_lingua: riga.lingua, p_condizione: riga.condizione,
          p_url: riga.url, p_prezzo: riga.prezzo, p_note: riga.note,
          p_immagine: riga.immagine, p_tipo: payload.tipo || null,
          p_destinazione: 'wishlist',
          p_prezzo_obiettivo: riga.prezzo_obiettivo,
        });
        if (error) return { ok: false, errore: error.message };
        return { ok: true, riga: nuovoId };
      }
      riga.owner_id = userId;
      if (payload.tipo) riga.tipo = payload.tipo;
      const { data, error } = await supabaseClient.from('wishlist').insert(riga).select().single();
      if (error) return { ok: false, errore: error.message };
      return { ok: true, riga: data.id };
    }

    case 'leggi': {
      const haFiltroLocation = payload.filtroLocation
        && (!Array.isArray(payload.filtroLocation) || payload.filtroLocation.length > 0);

      const parametroOrdine = payload.ordineId ? { p_ordine_id: payload.ordineId } : {};

      if (payload.soloConta) {
        const { data: totale, error: errConta } = await supabaseClient.rpc('conta_carte_da_controllare_gruppo', {
          p_owner_id_richiesto: payload.ownerIdRichiesto || null,
          p_solo_proprie: payload.soloProprie !== false,
          p_filtro_location: haFiltroLocation ? (Array.isArray(payload.filtroLocation) ? payload.filtroLocation : [payload.filtroLocation]) : null,
          p_solo_vecchie: !!payload.soloVecchie,
          p_giorni_minimi: payload.giorniMinimi || 3,
          ...parametroOrdine,
        });
        if (errConta) return { ok: false, errore: errConta.message };
        return { ok: true, totale: totale || 0 };
      }

      const { data, error } = await supabaseClient.rpc('reclama_carte_per_controllo_prezzi', {
        p_user_id: userId,
        p_owner_id_richiesto: payload.ownerIdRichiesto || null,
        p_solo_proprie: payload.soloProprie !== false,
        p_filtro_location: haFiltroLocation ? (Array.isArray(payload.filtroLocation) ? payload.filtroLocation : [payload.filtroLocation]) : null,
        p_solo_vecchie: !!payload.soloVecchie,
        p_giorni_minimi: payload.giorniMinimi || 3,
        p_lotto_size: payload.lottoSize || 3,
        ...parametroOrdine,
      });
      if (error) return { ok: false, errore: error.message };
      const righeReclamate = data || [];

      if (righeReclamate.length > 0 && payload.nomeDispositivo) {
        const idsReclamati = righeReclamate.map((r) => r.id);
        try {
          await supabaseClient.rpc('tagga_dispositivo_claim_gruppo', {
            p_ids: idsReclamati,
            p_dispositivo: payload.nomeDispositivo,
          });
        } catch (_) {
        }
      }

      return { ok: true, carte: righeReclamate.map(_supabaseToRigaLeggi) };
    }

    case 'rilasciaClaim': {
      const { error } = await supabaseClient.rpc('rilascia_claim_controllo_prezzi', {
        p_dispositivo: payload.nomeDispositivo || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'elencaLocation': {
      const { data, error } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).eq('tipo', 'carta').order('nome');
      if (error) return { ok: false, errore: error.message };
      return { ok: true, location: (data || []).map(r => r.nome) };
    }

    case 'aggiornaPrezzoRiga': {
      const { error } = await supabaseClient.rpc('aggiorna_prezzo_controllo_gruppo', {
        p_id: payload.riga,
        p_prezzo: payload.prezzo,
        p_immagine: payload.immagine || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaUrlRiga': {
      const { error } = await supabaseClient.rpc('aggiorna_url_controllo_gruppo', {
        p_id: payload.riga,
        p_url: payload.url,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaNotaRiga': {
      const { error } = await supabaseClient.rpc('aggiorna_nota_controllo_gruppo', {
        p_id: payload.riga,
        p_nota: payload.nota,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'segnaControllata': {
      const { error } = await supabaseClient.rpc('segna_controllata_gruppo', { p_id: payload.riga });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'elencaLocationTab': {
      const { data, error } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).order('nome');
      if (error) return { ok: false, errore: error.message };
      return { ok: true, location: (data || []).map(r => r.nome) };
    }

    case 'aggiungiLocationTab': {
      const tipoLoc = payload.tipo === 'sealed' ? 'sealed' : 'carta';
      const nomeLoc = String(payload.nome || '').trim();
      if (!nomeLoc) return { ok: false, errore: 'Nome location vuoto.' };
      const { data: esistenti, error: errLista } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).eq('tipo', tipoLoc);
      if (errLista) return { ok: false, errore: errLista.message };
      const uguale = (esistenti || []).find(l => String(l.nome).toLowerCase() === nomeLoc.toLowerCase());
      if (uguale) return { ok: true, giaEsistente: true, nome: uguale.nome };
      const { error } = await supabaseClient.from('location').insert({ owner_id: userId, nome: nomeLoc, tipo: tipoLoc });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, giaEsistente: false, nome: nomeLoc };
    }

    case 'leggiSealed': {
      const haFiltroScaffali = payload.filtroScaffali
        && (!Array.isArray(payload.filtroScaffali) || payload.filtroScaffali.length > 0);

      if (payload.soloConta) {
        const { data: totale, error: errConta } = await supabaseClient.rpc('conta_prodotti_sealed_da_controllare_gruppo', {
          p_owner_id_richiesto: payload.ownerIdRichiesto || null,
          p_solo_proprie: payload.soloProprie !== false,
          p_filtro_scaffali: haFiltroScaffali ? (Array.isArray(payload.filtroScaffali) ? payload.filtroScaffali : [payload.filtroScaffali]) : null,
          p_solo_vecchie: !!payload.soloVecchie,
          p_giorni_minimi: payload.giorniMinimi || 3,
        });
        if (errConta) return { ok: false, errore: errConta.message };
        return { ok: true, totale: totale || 0 };
      }

      const { data, error } = await supabaseClient.rpc('reclama_prodotti_sealed_per_controllo_prezzi', {
        p_user_id: userId,
        p_owner_id_richiesto: payload.ownerIdRichiesto || null,
        p_solo_proprie: payload.soloProprie !== false,
        p_filtro_scaffali: haFiltroScaffali ? (Array.isArray(payload.filtroScaffali) ? payload.filtroScaffali : [payload.filtroScaffali]) : null,
        p_solo_vecchie: !!payload.soloVecchie,
        p_giorni_minimi: payload.giorniMinimi || 3,
        p_lotto_size: payload.lottoSize || 3,
      });
      if (error) return { ok: false, errore: error.message };
      const righeReclamate = data || [];

      if (righeReclamate.length > 0 && payload.nomeDispositivo) {
        const idsReclamati = righeReclamate.map((r) => r.id);
        try {
          await supabaseClient.rpc('tagga_dispositivo_claim_gruppo_sealed', {
            p_ids: idsReclamati,
            p_dispositivo: payload.nomeDispositivo,
          });
        } catch (_) {
        }
      }

      return { ok: true, carte: righeReclamate.map(_supabaseToRigaLeggiSealed) };
    }

    case 'rilasciaClaimSealed': {
      const { error } = await supabaseClient.rpc('rilascia_claim_controllo_prezzi_sealed', {
        p_dispositivo: payload.nomeDispositivo || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'aggiornaPrezzoRigaSealed': {
      const { error } = await supabaseClient.rpc('aggiorna_prezzo_controllo_gruppo_sealed', {
        p_id: payload.riga,
        p_prezzo: payload.prezzo,
        p_immagine: payload.immagine || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'segnaControllataSealed': {
      const { error } = await supabaseClient.rpc('segna_controllata_gruppo_sealed', { p_id: payload.riga });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'leggiWishlistGruppo': {
      if (payload.soloConta) {
        const { data: totale, error: errConta } = await supabaseClient.rpc('conta_wishlist_da_controllare_gruppo', {
          p_ordine_id: payload.ordineId || null,
        });
        if (errConta) return { ok: false, errore: errConta.message };
        return { ok: true, totale: totale || 0 };
      }
      const { data, error } = await supabaseClient.rpc('reclama_wishlist_per_controllo_prezzi', {
        p_ordine_id: payload.ordineId || null,
        p_lotto_size: payload.lottoSize || 3,
      });
      if (error) return { ok: false, errore: error.message };
      const righeReclamate = data || [];
      if (righeReclamate.length > 0 && payload.nomeDispositivo) {
        try {
          await supabaseClient.rpc('tagga_dispositivo_claim_gruppo_wishlist', {
            p_ids: righeReclamate.map((r) => r.id),
            p_dispositivo: payload.nomeDispositivo,
          });
        } catch (_) {
        }
      }
      return { ok: true, carte: righeReclamate.map(_supabaseToRigaLeggi) };
    }

    case 'rilasciaClaimWishlist': {
      const { error } = await supabaseClient.rpc('rilascia_claim_controllo_prezzi_wishlist', {
        p_dispositivo: payload.nomeDispositivo || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'aggiornaPrezzoRigaWishlistGruppo': {
      const { error } = await supabaseClient.rpc('aggiorna_prezzo_controllo_gruppo_wishlist', {
        p_id: payload.riga,
        p_prezzo: payload.prezzo,
        p_immagine: payload.immagine || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaUrlRigaWishlistGruppo': {
      const { error } = await supabaseClient.rpc('aggiorna_url_controllo_gruppo_wishlist', {
        p_id: payload.riga,
        p_url: payload.url,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'segnaControllataWishlistGruppo': {
      const { error } = await supabaseClient.rpc('segna_controllata_gruppo_wishlist', { p_id: payload.riga });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    default:
      return { ok: false, errore: `Azione "${azione}" non ancora implementata nell'adapter Supabase.` };
  }
}

function _rigaDatiToSupabase(rigaDati, statoOverride) {
  return {
    nome:             rigaDati['B'] || null,
    codice:           rigaDati['C'] || null,
    location:         rigaDati['D'] || null,
    qty:              rigaDati['E'] || 1,
    lingua:           rigaDati['F'] || 'IT',
    condizione:       rigaDati['G'] || 'NM',
    url:              rigaDati['H'] || null,
    prezzo:           (rigaDati['I'] !== '' && rigaDati['I'] != null) ? rigaDati['I'] : null,
    prezzo_obiettivo: (rigaDati['J'] !== '' && rigaDati['J'] != null) ? rigaDati['J'] : null,
    note:             rigaDati['K'] || null,
    immagine:         rigaDati['L'] || null,
    sigillata_originale: !!rigaDati['M'],
    stato:            statoOverride || 'collezione',
  };
}

function _rigaDatiToWishlist(rigaDati) {
  return {
    nome:             rigaDati['B'] || null,
    codice:           rigaDati['C'] || null,
    location:         rigaDati['D'] || null,
    qty:              rigaDati['E'] || 1,
    lingua:           rigaDati['F'] || 'IT',
    condizione:       rigaDati['G'] || 'NM',
    url:              rigaDati['H'] || null,
    prezzo:           (rigaDati['I'] !== '' && rigaDati['I'] != null) ? rigaDati['I'] : null,
    prezzo_obiettivo: (rigaDati['J'] !== '' && rigaDati['J'] != null) ? rigaDati['J'] : null,
    note:             rigaDati['K'] || null,
    immagine:         rigaDati['L'] || null,
  };
}

function _supabaseToRigaLeggi(r) {
  return {
    rigaSheet: r.id, urlBase: r.url, lingua: r.lingua, condizione: r.condizione,
    codice: r.codice, nome: r.nome, location: r.location, prezzoPrecedente: r.prezzo,
    ownerId: r.owner_id,
  };
}

function _supabaseToRigaLeggiSealed(r) {
  return {
    rigaSheet: r.id, urlBase: r.url, codice: r.codice, nome: r.nome,
    prezzoPrecedente: r.prezzo_cardmarket,
    ownerId: r.owner_id,
  };
}
