// ── supabase_adapter.js ──────────────────────────────────────────────────────
const SUPABASE_URL = 'https://xpfibrzsffurdlypxnrw.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhwZmlicnpzZmZ1cmRseXB4bnJ3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODczOTU0MzYsImV4cCI6MjEwMjk3MTQzNn0.k5eELxNA3HkWdslxoqIL_IR8qFZ1W0j_IWZugE2GVCg';

// ── v5.42 (Fase 5.4, D7) — DOVE STA LA SESSIONE ───────────────────────────────
// Interruttore "Mantienimi loggato" (cardsyncMantieniAccessoEstensione,
// pagina Prezzi; assente = acceso):
//   - acceso  → chrome.storage.local: resta dopo la chiusura di Chrome;
//   - spento  → chrome.storage.session: Chrome la svuota quando si chiude,
//               quindi alla riapertura serve di nuovo il login.
// Prima, da spento, background.js faceva signOut a ogni sospensione del
// service worker (dopo 30 s senza eventi), non alla chiusura di Chrome.
// Cambiando l'interruttore la sessione passa da un archivio all'altro
// (subito, con onChanged qui sotto, e comunque alla prima lettura).
function _archiviSessione() {
  return new Promise((resolve) => {
    const sessione = chrome.storage.session || null;
    try {
      chrome.storage.local.get(['cardsyncMantieniAccessoEstensione'], (r) => {
        const mantieni = !r || r.cardsyncMantieniAccessoEstensione !== false;
        if (!sessione) { resolve({ scelto: chrome.storage.local, altro: null }); return; }
        resolve(mantieni ? { scelto: chrome.storage.local, altro: sessione } : { scelto: sessione, altro: chrome.storage.local });
      });
    } catch (_) {
      resolve({ scelto: chrome.storage.local, altro: null });
    }
  });
}

async function _spostaSessioneNellArchivioScelto() {
  const { scelto, altro } = await _archiviSessione();
  if (!altro) return;
  const tutto = await altro.get(null);
  const chiavi = Object.keys(tutto || {}).filter(k => k.startsWith('sb-'));
  for (const k of chiavi) {
    await scelto.set({ [k]: tutto[k] });
    await altro.remove(k);
  }
}

try {
  chrome.storage.onChanged.addListener((cambi, area) => {
    if (area === 'local' && cambi.cardsyncMantieniAccessoEstensione) {
      _spostaSessioneNellArchivioScelto().catch(() => {});
    }
  });
} catch (_) { /* contesto senza storage.onChanged */ }

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: {
      getItem: async (key) => {
        const { scelto, altro } = await _archiviSessione();
        const r = await scelto.get([key]);
        if (r && r[key] != null) return r[key];
        if (!altro) return null;
        const r2 = await altro.get([key]);
        if (!r2 || r2[key] == null) return null;
        // interruttore cambiato da poco: la sessione passa nell'archivio giusto
        await scelto.set({ [key]: r2[key] });
        await altro.remove([key]);
        return r2[key];
      },
      setItem: async (key, value) => {
        const { scelto, altro } = await _archiviSessione();
        await scelto.set({ [key]: value });
        if (altro) await altro.remove([key]);
      },
      removeItem: async (key) => {
        await chrome.storage.local.remove([key]);
        if (chrome.storage.session) await chrome.storage.session.remove([key]);
      },
    },
    autoRefreshToken: true,
    persistSession: true,
  },
});

// ── CONTROLLO VERSIONE PRIMA DI OGNI SCRITTURA ────────────────────────────────
// Richiesta esplicita: un'estensione con una versione vecchia in giro
// potrebbe scrivere dati nel formato sbagliato o con una logica superata,
// rischiando di danneggiare il database condiviso da tutto il gruppo. Prima
// di QUALUNQUE azione (lettura o scrittura, per sicurezza — non solo le
// scritture) si verifica di essere aggiornati.
//
// Il controllo è messo in CACHE per 3 minuti (non ad ogni singola chiamata)
// per non rallentare il lavoro con una richiesta di rete continua — un
// controllo ogni 3 minuti è più che sufficiente per intercettare in tempo
// utile un'estensione rimasta indietro, senza appesantire nulla.
//
// Fallisce in modo PERMISSIVO se il controllo stesso non riesce (es.
// offline): meglio lasciar lavorare qualcuno senza internet in quel momento
// che bloccarlo per un controllo che non può nemmeno completarsi.
const URL_ULTIMA_VERSIONE_ADAPTER = 'https://bindexxx.github.io/bindex/releases/latest-version.txt';
let _ultimoControlloVersioneMs = 0;
let _versioneAggiornataCache = true;

function _versioneMaggioreAdapter(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0, nb = pb[i] || 0;
    if (na > nb) return true;
    if (na < nb) return false;
  }
  return false;
}

async function _verificaVersioneAggiornata() {
  const ora = Date.now();
  if (ora - _ultimoControlloVersioneMs < 3 * 60 * 1000) return _versioneAggiornataCache;
  _ultimoControlloVersioneMs = ora;

  // Controllo 1 — lato CLIENT: confronta con il file di testo sul sito.
  // Veloce, ma un'estensione manomessa potrebbe teoricamente aggirarlo.
  let clientOk = true;
  try {
    const resp = await fetch(URL_ULTIMA_VERSIONE_ADAPTER + '?t=' + ora, { cache: 'no-store' });
    if (resp.ok) {
      const ultima = (await resp.text()).trim();
      const locale = chrome.runtime.getManifest().version;
      clientOk = !ultima || !_versioneMaggioreAdapter(ultima, locale);
    }
  } catch (_) { /* offline — non blocca su questo controllo da solo */ }

  // Controllo 2 — lato DATABASE: confronta la versione con quella minima
  // impostata in configurazione_app (chiave 'versione_minima', modificabile
  // solo da SQL). Utile se il file di testo sul sito non è raggiungibile ma
  // Supabase sì. NON è una protezione contro un'estensione manomessa (è
  // l'estensione stessa a chiamarlo): serve a fermare per tempo una versione
  // rimasta indietro.
  //
  // FIX v5.17: supabase-js NON lancia eccezioni quando una RPC fallisce —
  // restituisce { error }. Prima l'errore ESTENSIONE_NON_AGGIORNATA veniva
  // cercato solo nel catch, quindi questo controllo non scattava mai.
  let dbOk = true;
  try {
    const { error } = await supabaseClient.rpc('verifica_versione_minima', { p_versione_client: chrome.runtime.getManifest().version });
    if (error && String(error.message || '').includes('ESTENSIONE_NON_AGGIORNATA')) dbOk = false;
    // altri errori (es. offline, funzione non ancora creata) non bloccano —
    // permissivo per non impedire il lavoro per un controllo che non è
    // nemmeno riuscito a completarsi.
  } catch (_) {
    // eccezione di rete/imprevista: stesso principio permissivo
  }

  _versioneAggiornataCache = clientOk && dbOk;
  return _versioneAggiornataCache;
}

// ── FUNZIONE PRINCIPALE — traduce ogni "azione" in un comando Supabase ─────
async function chiamaSupabase(azione, payload) {
  const { data: sessionData } = await supabaseClient.auth.getSession();
  const userId = sessionData?.session?.user?.id;
  if (!userId) return { ok: false, errore: 'Non sei loggato — apri il popover account.' };

  if (!(await _verificaVersioneAggiornata())) {
    return { ok: false, errore: 'Estensione non aggiornata — aggiorna prima di continuare (vedi il sito per le istruzioni).' };
  }

  switch (azione) {

    case 'aggiungi': {
      const riga = _rigaDatiToSupabase(payload.rigaDati, payload.statoOverride);
      // FIX (bug "carte di un altro finite nel mio database"): se questa
      // riga viene dalla coda condivisa (coda_carte, dbRigaId presente),
      // usa la RPC che scrive col proprietario REALE della richiesta —
      // letto dalla riga di coda stessa, non da chi sta materialmente
      // elaborando in questo momento. Solo l'aggiunta manuale (senza
      // dbRigaId) resta attribuita a chi è loggato qui.
      if (payload.dbRigaId) {
        const { data: nuovoId, error } = await supabaseClient.rpc('completa_riga_coda_carte', {
          p_riga_coda_id: payload.dbRigaId,
          p_nome: riga.nome, p_codice: riga.codice, p_location: riga.location,
          p_qty: riga.qty, p_lingua: riga.lingua, p_condizione: riga.condizione,
          p_url: riga.url, p_prezzo: riga.prezzo, p_note: riga.note,
          // v5.39 (Fase 3.4, D14): 'carta' quando non è un sealed — null
          // scavalcava il valore predefinito della tabella (643 carte senza tipo).
          p_immagine: riga.immagine, p_tipo: payload.tipoOverride || 'carta',
          p_destinazione: payload.destinazione || 'collezione',
          p_prezzo_obiettivo: riga.prezzo_obiettivo,
          p_sigillata_originale: riga.sigillata_originale, // Fase 1 (2026-09-12)
        });
        if (error) return { ok: false, errore: error.message };
        return { ok: true, riga: nuovoId };
      }
      riga.owner_id = userId;
      riga.tipo = payload.tipoOverride || 'carta';
      const { data, error } = await supabaseClient.from('carte').insert(riga).select().single();
      if (error) return { ok: false, errore: error.message };
      // v5.39 (Fase 3.7): una carta scritta a mano (senza riga di coda) entrava
      // senza movimento, quindi non compariva in "Variazione valore" sul
      // sito (le carte della coda lo hanno da completa_riga_coda_carte).
      // Stesso blocco di "Comprata" (spostaWishlistInCollezione, più sotto),
      // copiato qui: non bloccante, la carta è già salvata.
      try {
        const qtyMov = Number(riga.qty) || 1;
        const prezzoMov = riga.prezzo != null ? Number(riga.prezzo) : null;
        const { error: errMov } = await supabaseClient.from('movimenti_collezione').insert({
          owner_id: userId, tipo_evento: 'aggiunta', oggetto_tipo: 'carta', oggetto_id: data.id,
          nome_snapshot: riga.nome || riga.codice || '—', quantita_delta: qtyMov,
          prezzo_unitario: (prezzoMov != null && !isNaN(prezzoMov)) ? prezzoMov : null,
          valore_delta: (prezzoMov != null && !isNaN(prezzoMov)) ? prezzoMov * qtyMov : null,
          fonte: 'estensione',
        });
        if (errMov) console.error('[movimenti] aggiunta a mano non registrata in Variazione valore:', errMov.message);
      } catch (eMov) {
        console.error('[movimenti] aggiunta a mano non registrata in Variazione valore:', eMov && eMov.message);
      }
      return { ok: true, riga: data.id };
    }

    // ── WISHLIST (tabella separata da 'carte', vedi wishlist_tabella_separata.sql) ─
    case 'aggiungiWishlist': {
      const riga = _rigaDatiToWishlist(payload.rigaDati);
      // FIX: stesso bug/stessa soluzione del case 'aggiungi' qui sopra —
      // vedi quei commenti per il perché.
      if (payload.dbRigaId) {
        const { data: nuovoId, error } = await supabaseClient.rpc('completa_riga_coda_carte', {
          p_riga_coda_id: payload.dbRigaId,
          p_nome: riga.nome, p_codice: riga.codice, p_location: riga.location,
          p_qty: riga.qty, p_lingua: riga.lingua, p_condizione: riga.condizione,
          p_url: riga.url, p_prezzo: riga.prezzo, p_note: riga.note,
          p_immagine: riga.immagine, p_tipo: payload.tipo || null,
          p_destinazione: 'wishlist',
          p_prezzo_obiettivo: riga.prezzo_obiettivo,
        });
        if (error) return { ok: false, errore: error.message };
        return { ok: true, riga: nuovoId };
      }
      riga.owner_id = userId;
      if (payload.tipo) riga.tipo = payload.tipo; // 'sealed' per ETB/UPC/box, altrimenti carta singola
      const { data, error } = await supabaseClient.from('wishlist').insert(riga).select().single();
      if (error) return { ok: false, errore: error.message };
      return { ok: true, riga: data.id };
    }

    // ── LETTURA COLLEZIONE (pagina "Aggiorna prezzi") ──────────────────────
    case 'leggi': {
      // FIX (Fase 8 — controllo prezzi condiviso): niente più filtro
      // owner_id FISSO — la collezione (stato 'collezione') è visibile a
      // tutto il gruppo grazie alla policy RLS "collezione condivisa
      // gruppo", ma di default (soloProprie=true, valore inviato dal popup
      // quando "🤝 Aiuta anche il gruppo" è SPENTO — il default) ogni
      // sessione filtra comunque solo le proprie carte: nessuno deve
      // ritrovarsi ad "aiutare" gli altri senza averlo attivato lui stesso.
      // FIX (controllo prezzi eseguito da un dispositivo diverso da chi
      // l'ha richiesto): "solo le mie" deve riferirsi al PROPRIETARIO
      // DELLA RICHIESTA (payload.ownerIdRichiesto, presente per gli ordini
      // creati dal sito), non a chi sta materialmente eseguendo in questo
      // momento — altrimenti un dispositivo che esegue per conto di
      // qualcun altro finiva per controllare le proprie carte al posto di
      // quelle richieste.
      // FIX: un array vuoto ([]) è "truthy" in JavaScript — senza questo
      // controllo, filtroLocation:[] finiva comunque nel ramo "applica
      // filtro" qui sotto, e un IN su un elenco vuoto restituirebbe SEMPRE
      // zero righe. "Nessuna location scelta" deve sempre significare
      // "tutte", mai "nessuna".
      const haFiltroLocation = payload.filtroLocation
        && (!Array.isArray(payload.filtroLocation) || payload.filtroLocation.length > 0);

      // FIX (controllo prezzi non diviso tra dispositivi, come già successo
      // per l'aggiunta carte): prima questa chiamata reclamava TUTTE le
      // carte eleggibili in un colpo solo — chi partiva per primo si
      // prendeva tutto, lasciando l'altro dispositivo a zero. payload.soloConta
      // fa un conteggio veloce senza reclamare nulla (usato solo per la
      // stima a schermo); altrimenti il lotto è limitato a poche carte per
      // volta (payload.lottoSize, default 3) — il chiamante (popup.js) ne
      // richiede altre quando questo lotto finisce, lasciando periodicamente
      // spazio ad altri dispositivi per reclamare la loro parte.
      //
      // RISOLTO (Problema #1, ultimo punto): questo conteggio, quando "Aiuta
      // il gruppo" è attivo, doveva leggere righe di altri owner — prima si
      // appoggiava alla stessa policy larga già rimossa dagli altri punti
      // (query diretta con select('*') eseguita solo in modalità count/head,
      // quindi nessun dato reale usciva comunque, ma la policy restava
      // necessaria per il conteggio stesso). Ora passa dalla RPC dedicata
      // conta_carte_da_controllare_gruppo (SECURITY DEFINER), stessa identica
      // logica di filtro replicata lato database, restituisce solo un
      // numero.
      // v5.20 (punto 26, sql/108): per un ordine dal sito si passa anche il
      // suo id — il database legge proprietario e location dalla tabella
      // privata ordini_parametri_privati (il client non vede i nomi). Solo
      // quando c'è un ordine: il controllo manuale e quello in inattività
      // mandano gli stessi parametri di prima.
      const parametroOrdine = payload.ordineId ? { p_ordine_id: payload.ordineId } : {};

      if (payload.soloConta) {
        const { data: totale, error: errConta } = await supabaseClient.rpc('conta_carte_da_controllare_gruppo', {
          p_owner_id_richiesto: payload.ownerIdRichiesto || null,
          p_solo_proprie: payload.soloProprie !== false,
          p_filtro_location: haFiltroLocation ? (Array.isArray(payload.filtroLocation) ? payload.filtroLocation : [payload.filtroLocation]) : null,
          p_solo_vecchie: !!payload.soloVecchie,
          p_giorni_minimi: payload.giorniMinimi || 3,
          ...parametroOrdine,
        });
        if (errConta) return { ok: false, errore: errConta.message };
        return { ok: true, totale: totale || 0 };
      }

      // FIX (due dispositivi finivano per controllare le STESSE carte):
      // prima la prenotazione avveniva in due passaggi separati — prima si
      // LEGGEVANO le carte libere, poi si SCRIVEVA la prenotazione. Tra
      // questi due passaggi c'era una finestra in cui un secondo
      // dispositivo, chiedendo lavoro quasi nello stesso istante, poteva
      // leggere le STESSE carte (ancora non risultavano prenotate) prima
      // che la scrittura del primo si registrasse — una race condition
      // classica. Ora una funzione sul database fa lettura+prenotazione in
      // un solo passaggio indivisibile (FOR UPDATE SKIP LOCKED), che
      // Postgres garantisce non poter mai assegnare due volte.
      const { data, error } = await supabaseClient.rpc('reclama_carte_per_controllo_prezzi', {
        p_user_id: userId,
        p_owner_id_richiesto: payload.ownerIdRichiesto || null,
        p_solo_proprie: payload.soloProprie !== false,
        p_filtro_location: haFiltroLocation ? (Array.isArray(payload.filtroLocation) ? payload.filtroLocation : [payload.filtroLocation]) : null,
        p_solo_vecchie: !!payload.soloVecchie,
        p_giorni_minimi: payload.giorniMinimi || 3,
        p_lotto_size: payload.lottoSize || 3,
        ...parametroOrdine,
      });
      if (error) return { ok: false, errore: error.message };
      const righeReclamate = data || [];

      // FIX (claim del controllo prezzi confuso tra più PC con lo stesso
      // account): la funzione sul database (reclama_carte_per_controllo_prezzi)
      // prenota le righe con claimed_by=userId, MA userId è l'ACCOUNT, non il
      // singolo PC — due dispositivi loggati con lo stesso account (es.
      // desktop + portatile) finivano indistinguibili agli occhi del claim, e
      // 'rilasciaClaim' (sotto) liberava le prenotazioni di ENTRAMBI insieme,
      // anche se uno dei due stava ancora lavorando. Qui, subito dopo il claim
      // atomico già fatto dalla funzione database, marchiamo in più le stesse
      // righe con il nome di QUESTO dispositivo (stesso campo 'dispositivo'
      // già usato per coda_carte, vedi nomeDispositivo() in shared.js) — un
      // solo aggiornamento per l'intero lotto (non uno a carta), quindi non
      // rallenta la sessione. Se questa scrittura extra fallisse per un
      // motivo qualunque, non blocchiamo comunque la sessione: le carte
      // restano prenotate lo stesso (claimed_by è già a posto), semplicemente
      // 'rilasciaClaim' a fine sessione sarà un po' più "generoso" quella
      // volta sola.
      //
      // RISOLTO (Problema #1, parte UPDATE): prima scriveva direttamente su
      // 'carte' appoggiandosi alla policy larga "aggiornamento condiviso per
      // controllo prezzi gruppo". Ora passa dalla RPC dedicata
      // tagga_dispositivo_claim_gruppo (SECURITY DEFINER) — stesso identico
      // comportamento (stesso filtro claimed_by=chi chiama, stesso batch su
      // tutto il lotto in un colpo solo), solo senza più bisogno della
      // policy larga.
      if (righeReclamate.length > 0 && payload.nomeDispositivo) {
        const idsReclamati = righeReclamate.map((r) => r.id);
        try {
          await supabaseClient.rpc('tagga_dispositivo_claim_gruppo', {
            p_ids: idsReclamati,
            p_dispositivo: payload.nomeDispositivo,
          });
        } catch (_) {
          // Silenzioso di proposito — vedi commento sopra: le carte restano
          // comunque prenotate (claimed_by), solo senza il tag dispositivo.
        }
      }

      return { ok: true, carte: righeReclamate.map(_supabaseToRigaLeggi) };
    }

    case 'rilasciaClaim': {
      // Chiamata a fine sessione (completata o interrotta): libera le
      // prenotazioni ancora attive fatte da QUESTO dispositivo — non tutte
      // quelle dell'utente. FIX (vedi commento sopra in 'leggi'): prima
      // filtrava solo su claimed_by=userId, quindi con due PC sullo stesso
      // account il primo che finiva liberava anche le carte che l'altro
      // stava ancora controllando in quel momento. Se per qualche motivo la
      // colonna 'dispositivo' non fosse valorizzata su una riga (vecchia
      // sessione prima di questo fix, o scrittura extra fallita sopra), il
      // secondo filtro .eq('dispositivo', ...) la escluderebbe per errore —
      // per questo il rilascio "di sicurezza" resta anche quello per solo
      // userId, ma SOLO se non è stato possibile identificare il dispositivo.
      //
      // RISOLTO (Problema #1, parte UPDATE): prima scriveva direttamente su
      // 'carte' appoggiandosi alla policy larga. Ora passa dalla RPC
      // rilascia_claim_controllo_prezzi (SECURITY DEFINER) — stesso identico
      // filtro (claimed_by=chi chiama, + dispositivo se noto).
      const { error } = await supabaseClient.rpc('rilascia_claim_controllo_prezzi', {
        p_dispositivo: payload.nomeDispositivo || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'elencaLocation': {
      // v5.39 (Fase 3.3): un solo elenco di location, quello del sito
      // (tabella 'location', come elencaLocationTab). Prima la tendina di
      // Prezzi leggeva i nomi scritti sulle carte, comprese le location che
      // sul sito non esistono.
      const { data, error } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).eq('tipo', 'carta').order('nome');
      if (error) return { ok: false, errore: error.message };
      return { ok: true, location: (data || []).map(r => r.nome) };
    }

    // ── AGGIORNAMENTO PREZZO / URL (usate da "Aggiorna prezzi") ────────────
    case 'aggiornaPrezzoRiga': {
      // FIX: l'estensione recuperava già l'immagine durante ogni controllo
      // prezzi ma non la scriveva mai — le carte aggiunte prima di avere la
      // colonna 'immagine' restavano senza miniatura per sempre, anche
      // ricontrollando il prezzo cento volte. Ora, se la pagina ne ha
      // trovata una, la registriamo qui — le miniature si popolano da sole
      // col tempo, man mano che ricontrolli i prezzi.
      //
      // FIX (loop infinito sulle stesse 2-3 carte): 'ultimo_controllo'
      // mancava del tutto da questo aggiornamento — la carta restava per
      // sempre "mai controllata" agli occhi dell'ordinamento (ultimo_controllo
      // ASC NULLS FIRST in 'leggi'), quindi ogni nuovo lotto ripescava le
      // STESSE carte all'infinito invece di avanzare verso le altre.
      //
      // FIX (aggiornamento silenziosamente ignorato quando si controllano
      // le carte di un altro membro): '.eq(owner_id, userId)' filtrava
      // sull'utente che sta ESEGUENDO, non sul proprietario reale della
      // carta — un dispositivo che aiuta il gruppo scriveva su righe che
      // non esistevano per lui (0 righe toccate, nessun errore). L'id
      // della riga (già specifico e univoco) basta da solo a individuarla
      // — la sicurezza reale è comunque garantita dalla regola RLS che
      // permette la scrittura solo su carte con stato='collezione'.
      //
      // RISOLTO (Problema #1, parte UPDATE): la RLS di cui sopra ("collezione
      // condivisa"/"aggiornamento condiviso") esponeva TUTTE le colonne di
      // TUTTI gli owner, non solo prezzo/ultimo_controllo/immagine. Ora passa
      // dalla RPC dedicata aggiorna_prezzo_controllo_gruppo (SECURITY
      // DEFINER) — stesso comportamento esatto (nessun controllo su chi ha
      // claimato la carta, scelta esplicita confermata da Claudio il
      // 18/08/2026 per non introdurre complessità/rischi non necessari nel
      // flusso reale), ma senza più bisogno della policy larga.
      const { error } = await supabaseClient.rpc('aggiorna_prezzo_controllo_gruppo', {
        p_id: payload.riga,
        p_prezzo: payload.prezzo,
        p_immagine: payload.immagine || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaUrlRiga': {
      // RISOLTO (bug [9], stesso schema di aggiornaPrezzoRiga sopra): prima
      // '.eq(owner_id, userId)' filtrava sull'utente che ESEGUE l'azione,
      // non sul proprietario reale della carta — con "Aiuta il gruppo"
      // attivo su carte di un altro utente, 0 righe toccate, nessun errore
      // visibile. Ora passa dalla RPC dedicata aggiorna_url_controllo_gruppo
      // (SECURITY DEFINER, verificata su DB reale il 20/08/2026).
      const { error } = await supabaseClient.rpc('aggiorna_url_controllo_gruppo', {
        p_id: payload.riga,
        p_url: payload.url,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaNotaRiga': {
      // RISOLTO (bug [9]): stesso fix di aggiornaUrlRiga sopra, stesso
      // giorno di verifica.
      const { error } = await supabaseClient.rpc('aggiorna_nota_controllo_gruppo', {
        p_id: payload.riga,
        p_nota: payload.nota,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'segnaControllata': {
      // Aggiorna SOLO la data di ultimo controllo, senza toccare nessun
      // altro campo — chiamata ad ogni carta effettivamente controllata
      // durante "Aggiorna prezzi", scriva o no il prezzo (vedi soloVariazioni
      // in popup.js: il prezzo non sempre viene riscritto, ma la carta va
      // comunque considerata "vista" ai fini dell'ordinamento in 'leggi'.
      //
      // FIX (stesso bug di aggiornaPrezzoRiga qui sopra): '.eq(owner_id,
      // userId)' bloccava silenziosamente questo aggiornamento quando si
      // controllano le carte di un altro membro del gruppo — la carta
      // restava "mai controllata" e veniva ripescata all'infinito.
      //
      // RISOLTO (Problema #1, parte UPDATE): come sopra, ora passa dalla RPC
      // dedicata segna_controllata_gruppo (SECURITY DEFINER) invece di
      // appoggiarsi alla policy larga.
      const { error } = await supabaseClient.rpc('segna_controllata_gruppo', { p_id: payload.riga });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    // ── AGGIORNAMENTO PREZZO / QUANTITA' (usate da "Aggiungi carta") ───────
    // v5.39 (Fase 3.2): tolta l'azione 'aggiornaPrezzo' (ricontrollo del
    // prezzo DOPO il salvataggio, scriveva solo sulle proprie carte): il
    // prezzo mancante ora si rilegge prima di salvare (aggiungi_carta_popup.js).

    // ── RICERCA (usate per capire se una carta è già in collezione) ────────
    // ── LOCATION (tendina + gestione hub) ───────────────────────────────────
    case 'elencaLocationTab': {
      const { data, error } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).order('nome');
      if (error) return { ok: false, errore: error.message };
      return { ok: true, location: (data || []).map(r => r.nome) };
    }

    case 'aggiungiLocationTab': {
      // v5.39 (Fase 3.3): stesse regole dell'import CSV del sito — tipo
      // 'carta' o 'sealed'; se esiste già con maiuscole diverse si usa
      // quella (restituita in "nome"), così non nascono doppioni.
      const tipoLoc = payload.tipo === 'sealed' ? 'sealed' : 'carta';
      const nomeLoc = String(payload.nome || '').trim();
      if (!nomeLoc) return { ok: false, errore: 'Nome location vuoto.' };
      const { data: esistenti, error: errLista } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).eq('tipo', tipoLoc);
      if (errLista) return { ok: false, errore: errLista.message };
      const uguale = (esistenti || []).find(l => String(l.nome).toLowerCase() === nomeLoc.toLowerCase());
      if (uguale) return { ok: true, giaEsistente: true, nome: uguale.nome };
      const { error } = await supabaseClient.from('location').insert({ owner_id: userId, nome: nomeLoc, tipo: tipoLoc });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, giaEsistente: false, nome: nomeLoc };
    }

    // ── CONTROLLO PREZZI DI GRUPPO — SEALED (Fase 1.2, 2026-09-12; filtro
    // per scaffale invece che location dalla Fase 1.3, stesso giorno —
    // location è sparita da prodotti_sealed, sql/42) ────────────────────
    // Gemelle intenzionali dei case 'leggi'/'rilasciaClaim'/
    // 'aggiornaPrezzoRiga'/'aggiornaUrlRiga'/'segnaControllata' sopra, ma
    // puntate su prodotti_sealed tramite le RPC di sql/39/42 (Regola d'Oro
    // #1: duplicazione intenzionale, nessuna modifica ai case 'carte'
    // esistenti). Differenze rispetto alla versione 'carte', non solo il
    // nome tabella: niente filtro lingua/condizione (i sealed non ne
    // hanno), filtro per scaffale invece che per location (concetto che i
    // sealed non hanno più), e la scrittura prezzo va su prezzo_cardmarket
    // (mai su prezzo, il prezzo di vendita manuale — vedi commento su
    // sql/39 nel file compilato).
    case 'leggiSealed': {
      const haFiltroScaffali = payload.filtroScaffali
        && (!Array.isArray(payload.filtroScaffali) || payload.filtroScaffali.length > 0);

      if (payload.soloConta) {
        const { data: totale, error: errConta } = await supabaseClient.rpc('conta_prodotti_sealed_da_controllare_gruppo', {
          p_owner_id_richiesto: payload.ownerIdRichiesto || null,
          p_solo_proprie: payload.soloProprie !== false,
          p_filtro_scaffali: haFiltroScaffali ? (Array.isArray(payload.filtroScaffali) ? payload.filtroScaffali : [payload.filtroScaffali]) : null,
          p_solo_vecchie: !!payload.soloVecchie,
          p_giorni_minimi: payload.giorniMinimi || 3,
        });
        if (errConta) return { ok: false, errore: errConta.message };
        return { ok: true, totale: totale || 0 };
      }

      const { data, error } = await supabaseClient.rpc('reclama_prodotti_sealed_per_controllo_prezzi', {
        p_user_id: userId,
        p_owner_id_richiesto: payload.ownerIdRichiesto || null,
        p_solo_proprie: payload.soloProprie !== false,
        p_filtro_scaffali: haFiltroScaffali ? (Array.isArray(payload.filtroScaffali) ? payload.filtroScaffali : [payload.filtroScaffali]) : null,
        p_solo_vecchie: !!payload.soloVecchie,
        p_giorni_minimi: payload.giorniMinimi || 3,
        p_lotto_size: payload.lottoSize || 3,
      });
      if (error) return { ok: false, errore: error.message };
      const righeReclamate = data || [];

      if (righeReclamate.length > 0 && payload.nomeDispositivo) {
        const idsReclamati = righeReclamate.map((r) => r.id);
        try {
          await supabaseClient.rpc('tagga_dispositivo_claim_gruppo_sealed', {
            p_ids: idsReclamati,
            p_dispositivo: payload.nomeDispositivo,
          });
        } catch (_) {
          // Silenzioso di proposito — stesso motivo del gemello 'leggi' sopra.
        }
      }

      return { ok: true, carte: righeReclamate.map(_supabaseToRigaLeggiSealed) };
    }

    case 'rilasciaClaimSealed': {
      const { error } = await supabaseClient.rpc('rilascia_claim_controllo_prezzi_sealed', {
        p_dispositivo: payload.nomeDispositivo || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'aggiornaPrezzoRigaSealed': {
      const { error } = await supabaseClient.rpc('aggiorna_prezzo_controllo_gruppo_sealed', {
        p_id: payload.riga,
        p_prezzo: payload.prezzo,
        p_immagine: payload.immagine || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'segnaControllataSealed': {
      const { error } = await supabaseClient.rpc('segna_controllata_gruppo_sealed', { p_id: payload.riga });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    // ── CONTROLLO PREZZI DI GRUPPO — WISHLIST (v5.37, sql/118) ─────────────
    // Gemelle dei case carte/sealed qui sopra, per la wishlist. Prima il
    // controllo wishlist leggeva e scriveva solo la wishlist di chi eseguiva
    // l'ordine (policy "solo proprietario"): l'ordine di Francesco preso dal
    // PC di Ire controllava la wishlist di Ire. Ora il proprietario lo legge
    // il database dall'ordine (ordini.creato_da), mai il client; le scritture
    // valgono solo su righe prenotate da chi chiama o proprie.
    // Nomi con "Gruppo": 'leggiWishlist' & co. esistono già per la vecchia
    // pagina Wishlist.
    case 'leggiWishlistGruppo': {
      if (payload.soloConta) {
        const { data: totale, error: errConta } = await supabaseClient.rpc('conta_wishlist_da_controllare_gruppo', {
          p_ordine_id: payload.ordineId || null,
        });
        if (errConta) return { ok: false, errore: errConta.message };
        return { ok: true, totale: totale || 0 };
      }
      const { data, error } = await supabaseClient.rpc('reclama_wishlist_per_controllo_prezzi', {
        p_ordine_id: payload.ordineId || null,
        p_lotto_size: payload.lottoSize || 3,
      });
      if (error) return { ok: false, errore: error.message };
      const righeReclamate = data || [];
      if (righeReclamate.length > 0 && payload.nomeDispositivo) {
        try {
          await supabaseClient.rpc('tagga_dispositivo_claim_gruppo_wishlist', {
            p_ids: righeReclamate.map((r) => r.id),
            p_dispositivo: payload.nomeDispositivo,
          });
        } catch (_) {
          // Silenzioso, come per le carte: le righe restano prenotate lo stesso.
        }
      }
      // Stessa forma delle carte (id, url, lingua, condizione, codice, nome,
      // prezzo, owner_id): la sessione di popup.js è la stessa.
      return { ok: true, carte: righeReclamate.map(_supabaseToRigaLeggi) };
    }

    case 'rilasciaClaimWishlist': {
      const { error } = await supabaseClient.rpc('rilascia_claim_controllo_prezzi_wishlist', {
        p_dispositivo: payload.nomeDispositivo || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'aggiornaPrezzoRigaWishlistGruppo': {
      const { error } = await supabaseClient.rpc('aggiorna_prezzo_controllo_gruppo_wishlist', {
        p_id: payload.riga,
        p_prezzo: payload.prezzo,
        p_immagine: payload.immagine || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaUrlRigaWishlistGruppo': {
      const { error } = await supabaseClient.rpc('aggiorna_url_controllo_gruppo_wishlist', {
        p_id: payload.riga,
        p_url: payload.url,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'segnaControllataWishlistGruppo': {
      const { error } = await supabaseClient.rpc('segna_controllata_gruppo_wishlist', { p_id: payload.riga });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    default:
      return { ok: false, errore: `Azione "${azione}" non ancora implementata nell'adapter Supabase.` };
  }
}

// ── HELPER DI CONVERSIONE ────────────────────────────────────────────────────
function _rigaDatiToSupabase(rigaDati, statoOverride) {
  return {
    nome:             rigaDati['B'] || null,
    codice:           rigaDati['C'] || null,
    location:         rigaDati['D'] || null,
    qty:              rigaDati['E'] || 1,
    lingua:           rigaDati['F'] || 'IT',
    condizione:       rigaDati['G'] || 'NM',
    url:              rigaDati['H'] || null,
    prezzo:           (rigaDati['I'] !== '' && rigaDati['I'] != null) ? rigaDati['I'] : null,
    prezzo_obiettivo: (rigaDati['J'] !== '' && rigaDati['J'] != null) ? rigaDati['J'] : null,
    note:             rigaDati['K'] || null,
    immagine:         rigaDati['L'] || null,
    sigillata_originale: !!rigaDati['M'], // Fase 1 (2026-09-12)
    stato:            statoOverride || 'collezione',
  };
}

// Analoga a _rigaDatiToSupabase ma per la tabella 'wishlist' separata.
// A differenza delle carte in collezione, qui la location è per ora sempre
// un valore unico fisso (vedi impostaModalitaInserimento sul sito) — il
// campo esiste comunque già in tabella, pronto per quando/se servissero
// location diverse anche per la wishlist.
function _rigaDatiToWishlist(rigaDati) {
  return {
    nome:             rigaDati['B'] || null,
    codice:           rigaDati['C'] || null,
    location:         rigaDati['D'] || null,
    qty:              rigaDati['E'] || 1,
    lingua:           rigaDati['F'] || 'IT',
    condizione:       rigaDati['G'] || 'NM',
    url:              rigaDati['H'] || null,
    prezzo:           (rigaDati['I'] !== '' && rigaDati['I'] != null) ? rigaDati['I'] : null,
    prezzo_obiettivo: (rigaDati['J'] !== '' && rigaDati['J'] != null) ? rigaDati['J'] : null,
    note:             rigaDati['K'] || null,
    immagine:         rigaDati['L'] || null,
  };
}

function _supabaseToRigaLeggi(r) {
  return {
    rigaSheet: r.id, urlBase: r.url, lingua: r.lingua, condizione: r.condizione,
    codice: r.codice, nome: r.nome, location: r.location, prezzoPrecedente: r.prezzo,
    // ownerId serve SOLO ai contributi al gruppo (migration 37): senza, in
    // eseguiSessione() non si sa di chi sia la carta appena controllata e il
    // secondo percorso dell'aiuto (controllo prezzi condiviso) non e'
    // registrabile. Il dato arriva gia' qui — reclama_carte_per_controllo_prezzi
    // e' RETURNS SETOF carte con `returning c.*` — e veniva soltanto scartato
    // da questa mappatura.
    // Non e' un dato sensibile in piu' di quelli gia' presenti: chi esegue il
    // controllo prezzi condiviso sta gia' leggendo le carte di quella persona.
    // v5.17 (sql/105 nel repo del sito): per le carte degli ALTRI la funzione
    // restituisce solo i campi del controllo prezzi — location, note ecc.
    // arrivano vuoti (location qui sotto diventa '' in popup.js, che non la
    // usa comunque).
    ownerId: r.owner_id,
  };
}

// Gemella di _supabaseToRigaLeggi sopra, per prodotti_sealed (Fase 1.2,
// 2026-09-12). Differenza chiave: prezzoPrecedente legge da
// prezzo_cardmarket (il prezzo automatico), MAI da prezzo (il prezzo di
// vendita manuale del proprietario) — stesso motivo per cui le RPC di
// scrittura (sql/39) scrivono solo su prezzo_cardmarket. Niente
// lingua/condizione: i prodotti sealed non li hanno. Niente location
// (Fase 1.3, sql/42: la colonna non esiste più, sostituita da scaffale).
function _supabaseToRigaLeggiSealed(r) {
  return {
    rigaSheet: r.id, urlBase: r.url, codice: r.codice, nome: r.nome,
    prezzoPrecedente: r.prezzo_cardmarket,
    ownerId: r.owner_id,
  };
}
