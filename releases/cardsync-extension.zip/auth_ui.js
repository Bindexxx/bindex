// Login all'estensione, uguale in tutte le pagine: assicuraLoginSupabase().
// Va caricato dopo supabase.bundle.js e supabase_adapter.js (usa supabaseClient).

(function () {
  const STILE_ID = 'cardsync-auth-ui-style';

  function iniettaStile() {
    if (document.getElementById(STILE_ID)) return;
    const style = document.createElement('style');
    style.id = STILE_ID;
    style.textContent = `
      #cardsync-auth-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: rgba(20, 16, 32, 0.72);
        display: flex; align-items: center; justify-content: center;
        font-family: 'Space Grotesk', system-ui, -apple-system, 'Segoe UI', sans-serif;
      }
      #cardsync-auth-card {
        background: #ffffff; color: #1a1625;
        width: min(340px, 90vw);
        border-radius: 16px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      #cardsync-auth-card h2 {
        margin: 0 0 4px; font-size: 18px; font-weight: 700;
      }
      #cardsync-auth-card p.sub {
        margin: 0 0 20px; font-size: 12.5px; color: #6b6478;
      }
      #cardsync-auth-card label {
        display: block; font-size: 12px; font-weight: 600;
        color: #4a4458; margin: 12px 0 5px;
      }
      #cardsync-auth-card input {
        width: 100%; box-sizing: border-box;
        padding: 9px 11px; border-radius: 9px;
        border: 1.5px solid #e0dce8; font-size: 14px;
        font-family: inherit;
      }
      #cardsync-auth-card input:focus {
        outline: none; border-color: #7c4dff;
      }
      #cardsync-auth-error {
        display: none; margin-top: 12px; padding: 9px 11px;
        background: #fdeaea; color: #b3261e; border-radius: 8px;
        font-size: 12.5px; line-height: 1.4;
      }
      #cardsync-auth-submit {
        width: 100%; margin-top: 18px; padding: 10px;
        border: none; border-radius: 10px;
        background: #7c4dff; color: #fff;
        font-size: 14px; font-weight: 700; cursor: pointer;
        font-family: inherit;
      }
      #cardsync-auth-submit:disabled {
        opacity: 0.6; cursor: default;
      }
      #cardsync-auth-submit:not(:disabled):hover {
        background: #6a3fe0;
      }
      #cardsync-logout-btn {
        position: fixed; bottom: 14px; right: 14px; z-index: 999998;
        background: rgba(20, 16, 32, 0.55); color: #fff;
        border: none; border-radius: 20px;
        padding: 6px 12px; font-size: 11.5px; font-weight: 600;
        font-family: 'Space Grotesk', system-ui, -apple-system, 'Segoe UI', sans-serif;
        cursor: pointer; display: flex; align-items: center; gap: 5px;
        opacity: 0.55; transition: opacity 0.15s;
      }
      #cardsync-logout-btn:hover { opacity: 1; }

      /* ── WIZARD AGGIORNAMENTO OBBLIGATORIO ────────────────────────────── */
      #cardsync-update-card {
        background: #ffffff; color: #1a1625;
        width: min(420px, 92vw);
        border-radius: 18px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      #cardsync-update-dots { display: flex; gap: 6px; justify-content: center; margin-bottom: 18px; }
      .cardsync-update-dot { width: 7px; height: 7px; border-radius: 50%; background: #e0dce8; transition: background .2s; }
      .cardsync-update-dot.attivo { background: #7c4dff; }
      .cardsync-update-slide h2 { margin: 0 0 10px; font-size: 17px; font-weight: 800; }
      .cardsync-update-slide p { margin: 0 0 8px; font-size: 13px; color: #6b6478; line-height: 1.5; }
      .cardsync-update-tasto {
        font-weight: 800; font-size: 14px; background: #f6f4fb;
        border: 1px solid #e0dce8; border-bottom-width: 3px; border-radius: 8px;
        padding: 7px 13px; color: #1a1625;
      }
      #cardsync-update-comando {
        display: flex; align-items: center; gap: 8px;
        background: #f6f4fb; border: 1px solid #e0dce8; border-radius: 8px;
        padding: 9px 11px; margin: 10px 0;
      }
      #cardsync-update-comando code { flex: 1; font-size: 11px; word-break: break-all; user-select: all; }
      #cardsync-update-copia {
        flex-shrink: 0; border: none; background: #7c4dff; color: #fff;
        border-radius: 6px; padding: 7px 9px; cursor: pointer; font-size: 13px;
      }
      #cardsync-update-nav { display: flex; gap: 10px; margin-top: 18px; }
      #cardsync-update-nav button {
        flex: 1; padding: 10px; border-radius: 10px; border: none;
        font-size: 13px; font-weight: 700; cursor: pointer; font-family: inherit;
      }
      #cardsync-update-indietro { background: #f0eefb; color: #4a4458; }
      #cardsync-update-avanti { background: #7c4dff; color: #fff; }

      /* Toast "tutto ok" — piccolo, in un angolo, non bloccante (a
         differenza di #cardsync-auth-overlay che copre tutto lo schermo). */
      #cardsync-toast-ok {
        position: fixed; bottom: 16px; right: 16px; z-index: 999999998;
        background: #ffffff; color: #1a1625;
        border: 1px solid #e0dce8; border-radius: 12px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.18);
        padding: 14px 34px 14px 16px;
        max-width: 260px; font-family: inherit;
        animation: cardsync-toast-in 0.25s ease-out;
      }
      @keyframes cardsync-toast-in {
        from { opacity: 0; transform: translateY(8px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      #cardsync-toast-ok-chiudi {
        position: absolute; top: 8px; right: 8px;
        border: none; background: none; cursor: pointer;
        font-size: 13px; color: #9f95b5; padding: 4px;
      }

      /* ── BLOCCO BAN / ACCOUNT DISATTIVATO ─────────────────────────────── */
      #cardsync-auth-card p.blocco-msg {
        margin: 0 0 18px; font-size: 13.5px; color: #4a4458; line-height: 1.5;
      }
    `;
    document.head.appendChild(style);
  }

  function versioneMaggiore(a, b) {
    const pa = String(a).split('.').map(Number);
    const pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const na = pa[i] || 0, nb = pb[i] || 0;
      if (na > nb) return true;
      if (na < nb) return false;
    }
    return false;
  }

  const URL_SITO = 'https://bindexxx.github.io/bindex/';

  const URL_ULTIMA_VERSIONE = 'https://bindexxx.github.io/bindex/releases/latest-version.txt';

  function iniettaStileWizard() { iniettaStile(); }

  function costruisciWizardAggiornamento() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    const card = document.createElement('div');
    card.id = 'cardsync-update-card';
    card.innerHTML = `
      <div class="cardsync-update-slide" style="text-align:center;">
        <h2>⚡ Aggiornamento obbligatorio</h2>
        <p>Non è possibile usare questa versione dell'estensione — <strong>clicca qui per scaricare l'ultima versione</strong>, sorry not sorry.</p>
      </div>
      <div id="cardsync-update-nav">
        <button id="cardsync-update-vai-al-sito" style="flex:1; background:#7c4dff; color:#fff;">Apri il sito →</button>
      </div>
    `;
    overlay.appendChild(card);
    card.querySelector('#cardsync-update-vai-al-sito').addEventListener('click', () => {
      window.open(URL_SITO, '_blank');
    });
    return overlay;
  }

  function costruisciToastTuttoOk() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-toast-ok';
    overlay.innerHTML = `
      <button id="cardsync-toast-ok-chiudi" title="Chiudi">✕</button>
      <div style="font-size:22px; margin-bottom:6px;">🎉</div>
      <div style="font-weight:800; margin-bottom:4px;">Hai l'estensione aggiornata!</div>
      <div style="font-size:12px; color:#6b6478;">Valuta di attivare "Aiuta anche gli altri" — Bill ti ringrazia. 🙏</div>
    `;
    const chiudi = () => overlay.remove();
    overlay.querySelector('#cardsync-toast-ok-chiudi').addEventListener('click', chiudi);
    setTimeout(chiudi, 3000);
    return overlay;
  }

  function controllaVersioneObbligatoria() {
    return new Promise((resolve) => {
      if (window.self !== window.top) { resolve(false); return; }

      const versioneLocale = chrome.runtime.getManifest().version;
      fetch(URL_ULTIMA_VERSIONE + '?t=' + Date.now(), { cache: 'no-store' })
        .then((r) => (r.ok ? r.text() : null))
        .then((testo) => {
          const versioneRemota = (testo || '').trim();
          if (!versioneRemota) {
            resolve(false);
            return;
          }
          if (!versioneMaggiore(versioneRemota, versioneLocale)) {
            chrome.storage.local.get('toastAggiornataVersione', (salvato) => {
              if (salvato && salvato.toastAggiornataVersione === versioneLocale) return;
              chrome.storage.local.set({ toastAggiornataVersione: versioneLocale });
              iniettaStileWizard();
              document.body.appendChild(costruisciToastTuttoOk());
            });
            resolve(false);
            return;
          }
          iniettaStileWizard();
          const overlay = costruisciWizardAggiornamento();
          document.body.appendChild(overlay);
          resolve(true);
        })
        .catch((err) => { console.error('[CardSync] Controllo versione fallito:', err.message); resolve(false); });
    });
  }

  function costruisciOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    overlay.innerHTML = `
      <div id="cardsync-auth-card">
        <h2>Accedi a Bindex</h2>
        <p class="sub">Usa l'account che ti è stato assegnato per la tua collezione.</p>
        <label for="cardsync-auth-email">Nome utente</label>
        <input type="text" id="cardsync-auth-email" autocomplete="username" placeholder="es. irene" />
        <label for="cardsync-auth-password">Password</label>
        <input type="password" id="cardsync-auth-password" autocomplete="current-password" />
        <div id="cardsync-auth-error"></div>
        <button id="cardsync-auth-submit">Accedi</button>
      </div>
    `;
    return overlay;
  }

  function mostraBottoneLogout(email) {
    if (window.self !== window.top) return;
    if (document.getElementById('menuEsci')) return;

    if (document.getElementById('cardsync-logout-btn')) return;
    iniettaStile();
    const nomeUtente = String(email || '').split('@')[0] || 'account';
    const btn = document.createElement('button');
    btn.id = 'cardsync-logout-btn';
    btn.title = 'Esci da Bindex (' + nomeUtente + ')';
    btn.innerHTML = '🚪 Esci';
    btn.addEventListener('click', async () => {
      if (!confirm('Uscire da Bindex (' + nomeUtente + ')?\n\nDovrai rifare il login per usare l\'estensione.')) return;
      await supabaseClient.auth.signOut({ scope: 'local' });
      location.reload();
    });
    document.body.appendChild(btn);
  }

  window.logoutSupabase = async function () {
    await supabaseClient.auth.signOut({ scope: 'local' });
    location.reload();
  };

  const INTERVALLO_CONTROLLO_BAN_MS = 3 * 60 * 1000;
  const TTL_CACHE_VERIFICA_MS = 20 * 1000;
  let _cacheVerificaAccesso = { scadenza: 0, esito: true };

  async function interrogaStatoBan(userId) {
    const { data, error } = await supabaseClient
      .from('profiles')
      .select('banned_until, deleted_at')
      .eq('id', userId)
      .single();
    if (error || !data) return null;
    return data;
  }

  function calcolaMessaggioBlocco(profilo) {
    if (!profilo) return null;
    if (profilo.deleted_at) {
      return 'Il tuo account è stato disattivato da un amministratore.';
    }
    if (profilo.banned_until && new Date(profilo.banned_until) > new Date()) {
      const perma = profilo.banned_until.startsWith('9999') || profilo.banned_until === 'infinity';
      if (perma) return 'Il tuo account è stato sospeso a tempo indeterminato.';
      const dataFmt = new Date(profilo.banned_until).toLocaleString('it-IT', {
        day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
      });
      return 'Il tuo account è sospeso fino al ' + dataFmt + '.';
    }
    return null;
  }

  function costruisciOverlayBloccato(messaggio) {
    iniettaStile();
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    overlay.innerHTML = `
      <div id="cardsync-auth-card">
        <h2>🚫 Accesso non consentito</h2>
        <p class="blocco-msg">${messaggio}</p>
        <button id="cardsync-auth-submit">Accedi con un altro utente</button>
      </div>
    `;
    overlay.querySelector('#cardsync-auth-submit').addEventListener('click', () => location.reload());
    return overlay;
  }

  async function bloccaSeNecessario(session) {
    if (!session || !session.user) return false;
    const profilo = await interrogaStatoBan(session.user.id);
    const messaggio = calcolaMessaggioBlocco(profilo);
    if (!messaggio) return false;

    await supabaseClient.auth.signOut();
    const overlayEsistente = document.getElementById('cardsync-auth-overlay');
    if (overlayEsistente) overlayEsistente.remove();
    document.body.appendChild(costruisciOverlayBloccato(messaggio));
    return true;
  }

  function avviaControlloPeriodicoBan(session) {
    setInterval(() => { bloccaSeNecessario(session); }, INTERVALLO_CONTROLLO_BAN_MS);
  }

  window.verificaAccessoValido = async function () {
    const ora = Date.now();
    if (ora < _cacheVerificaAccesso.scadenza) return _cacheVerificaAccesso.esito;

    const { data } = await supabaseClient.auth.getSession();
    if (!data.session) {
      _cacheVerificaAccesso = { scadenza: ora + TTL_CACHE_VERIFICA_MS, esito: false };
      return false;
    }
    const bloccato = await bloccaSeNecessario(data.session);
    const esito = !bloccato;
    _cacheVerificaAccesso = { scadenza: ora + TTL_CACHE_VERIFICA_MS, esito };
    return esito;
  };

  window.assicuraLoginSupabase = function () {
    return new Promise(async (resolve) => {
      const bloccatoDaAggiornamento = await controllaVersioneObbligatoria();
      if (bloccatoDaAggiornamento) return;

      const { data } = await supabaseClient.auth.getSession();
      if (data.session) {
        const bloccato = await bloccaSeNecessario(data.session);
        if (bloccato) return;
        mostraBottoneLogout(data.session.user.email);
        avviaControlloPeriodicoBan(data.session);
        resolve(data.session);
        return;
      }

      if (window.self !== window.top) {
        const attendiSessione = setInterval(async () => {
          const { data: nuovoTentativo } = await supabaseClient.auth.getSession();
          if (nuovoTentativo.session) {
            clearInterval(attendiSessione);
            const bloccato = await bloccaSeNecessario(nuovoTentativo.session);
            if (bloccato) return;
            avviaControlloPeriodicoBan(nuovoTentativo.session);
            resolve(nuovoTentativo.session);
          }
        }, 500);
        return;
      }

      iniettaStile();
      const overlay = costruisciOverlay();
      document.body.appendChild(overlay);

      const elEmail    = overlay.querySelector('#cardsync-auth-email');
      const elPassword = overlay.querySelector('#cardsync-auth-password');
      const elErrore    = overlay.querySelector('#cardsync-auth-error');
      const elSubmit    = overlay.querySelector('#cardsync-auth-submit');

      async function tentaLogin() {
        const inputUtente = elEmail.value.trim();
        const password = elPassword.value;
        if (!inputUtente || !password) {
          elErrore.textContent = 'Inserisci nome utente e password.';
          elErrore.style.display = 'block';
          return;
        }
        // AMBIENTE DI TEST: il nome da solo si completa con @test.local. In produzione
        // '@cardsyncpro.local', insieme a ui/auth.ui.js, ui/admin-shell.ui.js,
        // utils/shared-public.js del sito e sql/110_..._ROLLBACK.sql.
        const email = inputUtente.includes('@') ? inputUtente : inputUtente.toLowerCase() + '@test.local';
        elSubmit.disabled = true;
        elSubmit.textContent = 'Accesso in corso…';
        elErrore.style.display = 'none';

        const { data: loginData, error } = await supabaseClient.auth.signInWithPassword({ email, password });
        if (error) {
          elErrore.textContent = '❌ ' + (error.message === 'Invalid login credentials'
            ? 'Nome utente o password errati.'
            : error.message);
          elErrore.style.display = 'block';
          elSubmit.disabled = false;
          elSubmit.textContent = 'Accedi';
          return;
        }

        const bloccato = await bloccaSeNecessario(loginData.session);
        if (bloccato) return;

        overlay.remove();
        mostraBottoneLogout(loginData.session.user.email);
        avviaControlloPeriodicoBan(loginData.session);
        resolve(loginData.session);
      }

      elSubmit.addEventListener('click', tentaLogin);
      [elEmail, elPassword].forEach((el) => {
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter') tentaLogin(); });
      });
      elEmail.focus();
    });
  };
})();
