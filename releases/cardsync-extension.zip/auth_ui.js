// Login all'estensione, uguale in tutte le pagine: assicuraLoginSupabase().
// Va caricato dopo supabase.bundle.js e supabase_adapter.js (usa supabaseClient).

(function () {
  const STILE_ID = 'cardsync-auth-ui-style';

  function iniettaStile() {
    if (document.getElementById(STILE_ID)) return;
    const style = document.createElement('style');
    style.id = STILE_ID;
    style.textContent = `
      #cardsync-auth-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: rgba(14, 11, 22, 0.72);
        backdrop-filter: blur(3px);
        display: flex; align-items: center; justify-content: center;
        padding: 16px; box-sizing: border-box;
        font-family: 'Space Grotesk', system-ui, -apple-system, 'Segoe UI', sans-serif;
      }
      #cardsync-auth-card {
        width: min(380px, 100%); box-sizing: border-box;
        background: linear-gradient(180deg, #7c4dff 0%, #4a2d9c 100%);
        border-radius: 30px 30px 26px 26px;
        padding: 14px 14px 12px;
        box-shadow: 0 18px 40px rgba(60, 30, 140, 0.35);
        color: var(--text, #2a2438);
      }
      .cs-pdx-top { display: flex; align-items: center; gap: 10px; padding: 0 4px 10px; }
      .cs-pdx-lente {
        width: 34px; height: 34px; border-radius: 50%; flex-shrink: 0; box-sizing: border-box;
        background: radial-gradient(circle at 35% 30%, #aee3ff, #1c7fd1 70%);
        border: 3px solid #fff; box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.12);
      }
      .cs-pdx-led { width: 11px; height: 11px; border-radius: 50%; box-shadow: inset 0 -2px 3px rgba(0, 0, 0, 0.25); }
      .cs-pdx-led.r { background: #d93a3a; } .cs-pdx-led.g { background: #f0b429; } .cs-pdx-led.v { background: #34b45a; }
      .cs-pdx-nome {
        margin-left: auto; font-weight: 800; letter-spacing: 0.28em; font-size: 12px;
        color: rgba(255, 255, 255, 0.85); text-shadow: 0 1px 0 rgba(0, 0, 0, 0.3);
      }
      .cs-pdx-schermo {
        background: var(--card, #ffffff); color: var(--text, #2a2438);
        border: 3px solid #e6e6ea; border-radius: 18px;
        padding: 22px 20px 20px;
      }
      .cs-pdx-fondo { display: flex; align-items: center; padding: 10px 6px 0; }
      .cs-pdx-croce { position: relative; width: 30px; height: 30px; margin-right: auto; }
      .cs-pdx-croce::before, .cs-pdx-croce::after { content: ''; position: absolute; background: #1f1f24; border-radius: 3px; }
      .cs-pdx-croce::before { left: 10px; top: 0; width: 10px; height: 30px; }
      .cs-pdx-croce::after { left: 0; top: 10px; width: 30px; height: 10px; }
      .cs-pdx-pill { width: 30px; height: 7px; border-radius: 999px; background: rgba(20, 10, 60, 0.45); margin-left: 7px; }

      #cardsync-auth-card h2 {
        margin: 0 0 6px; font-size: 22px; font-weight: 800; color: var(--text, #2a2438);
      }
      #cardsync-auth-card p.sub {
        margin: 0 0 18px; font-size: 13.5px; line-height: 1.45; color: var(--muted, #6d6282);
      }
      #cardsync-auth-card label {
        display: block; font-size: 12px; font-weight: 700;
        color: var(--muted, #6d6282); margin: 12px 0 5px;
      }
      .cs-campo { position: relative; }
      .cs-campo svg.cs-ico {
        position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
        width: 14px; height: 14px; fill: var(--muted, #6d6282); pointer-events: none;
      }
      #cardsync-auth-card input {
        width: 100%; box-sizing: border-box;
        padding: 11px 12px 11px 37px; border-radius: 14px;
        border: 1px solid var(--border, #e2d9f3);
        background: color-mix(in srgb, var(--primary, #7c4dff) 6%, var(--card, #ffffff));
        color: var(--text, #2a2438);
        font-size: 14px; font-weight: 600; font-family: inherit;
        transition: border-color 0.15s, box-shadow 0.15s;
      }
      #cardsync-auth-card input[type="password"], #cardsync-auth-card input.cs-pw-visibile { padding-right: 42px; }
      #cardsync-auth-card input::placeholder { color: var(--muted, #6d6282); opacity: 0.7; font-weight: 500; }
      #cardsync-auth-card input:focus {
        outline: none; border-color: var(--primary, #7c4dff);
        box-shadow: 0 0 0 3px var(--primary-light, #ede7ff);
      }
      #cardsync-auth-card input:-webkit-autofill,
      #cardsync-auth-card input:-webkit-autofill:hover,
      #cardsync-auth-card input:-webkit-autofill:focus {
        -webkit-text-fill-color: var(--text, #2a2438);
        caret-color: var(--text, #2a2438);
        box-shadow: 0 0 0 1000px color-mix(in srgb, var(--primary, #7c4dff) 6%, var(--card, #ffffff)) inset;
        transition: background-color 9999s ease-out 0s;
      }
      .cs-occhio {
        position: absolute; right: 5px; top: 50%; transform: translateY(-50%);
        background: none; border: 0; cursor: pointer; padding: 7px 8px; line-height: 0;
      }
      .cs-occhio svg { width: 16px; height: 16px; fill: var(--muted, #6d6282); }
      .cs-occhio:hover svg { fill: var(--primary-text, #7c4dff); }
      #cardsync-auth-error {
        display: none; margin-top: 12px; padding: 9px 11px;
        background: var(--ko-bg, #ffebee); color: var(--ko, #c62828); border-radius: 10px;
        font-size: 12.5px; font-weight: 600; line-height: 1.4;
      }
      #cardsync-auth-submit {
        width: 100%; margin-top: 18px; padding: 13px;
        border: none; border-radius: 14px;
        background: var(--primary, #7c4dff); color: #fff;
        font-size: 15px; font-weight: 800; cursor: pointer;
        font-family: inherit;
      }
      #cardsync-auth-submit:disabled {
        opacity: 0.6; cursor: default;
      }
      #cardsync-auth-submit:not(:disabled):hover {
        background: #6a3fe0;
      }
      #cardsync-logout-btn {
        position: fixed; bottom: 14px; right: 14px; z-index: 999998;
        background: rgba(20, 16, 32, 0.55); color: #fff;
        border: none; border-radius: 20px;
        padding: 6px 12px; font-size: 11.5px; font-weight: 600;
        font-family: 'Space Grotesk', system-ui, -apple-system, 'Segoe UI', sans-serif;
        cursor: pointer; display: flex; align-items: center; gap: 5px;
        opacity: 0.55; transition: opacity 0.15s;
      }
      #cardsync-logout-btn:hover { opacity: 1; }

      #cardsync-update-card {
        background: var(--card, #ffffff); color: var(--text, #2a2438);
        border: 1px solid var(--border, #e2d9f3);
        width: min(420px, 92vw);
        border-radius: 18px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      .cardsync-update-slide h2 { margin: 0 0 10px; font-size: 17px; font-weight: 800; }
      .cardsync-update-slide p { margin: 0 0 8px; font-size: 13px; color: var(--muted, #6d6282); line-height: 1.5; }
      #cardsync-update-nav { display: flex; gap: 10px; margin-top: 18px; }
      #cardsync-update-nav button {
        flex: 1; padding: 10px; border-radius: 12px; border: none;
        font-size: 13px; font-weight: 700; cursor: pointer; font-family: inherit;
      }

      #cardsync-toast-ok {
        position: fixed; bottom: 16px; right: 16px; z-index: 999999998;
        background: var(--card, #ffffff); color: var(--text, #2a2438);
        border: 1px solid var(--border, #e2d9f3); border-radius: 12px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.18);
        padding: 14px 34px 14px 16px;
        max-width: 260px; font-family: inherit;
        animation: cardsync-toast-in 0.25s ease-out;
      }
      #cardsync-toast-ok .cs-toast-sub { font-size: 12px; color: var(--muted, #6d6282); }
      @keyframes cardsync-toast-in {
        from { opacity: 0; transform: translateY(8px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      #cardsync-toast-ok-chiudi {
        position: absolute; top: 8px; right: 8px;
        border: none; background: none; cursor: pointer;
        font-size: 13px; color: var(--muted, #9f95b5); padding: 4px;
      }

      #cardsync-auth-card p.blocco-msg {
        margin: 0 0 18px; font-size: 13.5px; color: var(--muted, #6d6282); line-height: 1.5;
      }
    `;
    document.head.appendChild(style);
  }

  function versioneMaggiore(a, b) {
    const pa = String(a).split('.').map(Number);
    const pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const na = pa[i] || 0, nb = pb[i] || 0;
      if (na > nb) return true;
      if (na < nb) return false;
    }
    return false;
  }

  const URL_SITO = 'https://bindexxx.github.io/bindex/';

  const URL_ULTIMA_VERSIONE = 'https://bindexxx.github.io/bindex/releases/latest-version.txt';

  const ICONA_UTENTE = '<svg class="cs-ico" viewBox="0 0 448 512" aria-hidden="true"><path d="M224 256a128 128 0 1 0 0-256 128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3 0 498.7 13.3 512 29.7 512h388.6c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304h-91.4z"/></svg>';
  const ICONA_LUCCHETTO = '<svg class="cs-ico" viewBox="0 0 448 512" aria-hidden="true"><path d="M144 144v48h160v-48a80 80 0 0 0-160 0zm-64 48v-48a144 144 0 0 1 288 0v48h16c35.3 0 64 28.7 64 64v192c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V256c0-35.3 28.7-64 64-64h16z"/></svg>';
  const ICONA_OCCHIO = '<svg viewBox="0 0 576 512" aria-hidden="true"><path d="M288 32c-80.8 0-145.5 36.8-192.6 80.6C48.6 156 17.3 208 2.5 243.7c-3.3 7.9-3.3 16.7 0 24.6C17.3 304 48.6 356 95.4 399.4 142.5 443.2 207.2 480 288 480s145.5-36.8 192.6-80.6c46.8-43.5 78.1-95.4 93-131.1 3.3-7.9 3.3-16.7 0-24.6-14.9-35.7-46.2-87.7-93-131.1C433.5 68.8 368.8 32 288 32zM144 256a144 144 0 1 1 288 0 144 144 0 1 1-288 0zm144-64a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"/></svg>';
  const ICONA_OCCHIO_CHIUSO = '<svg viewBox="0 0 640 512" aria-hidden="true"><path d="M38.8 5.1C28.4-3.1 13.3-1.2 5.1 9.2s-6.3 25.5 4.1 33.7l592 464c10.4 8.2 25.5 6.3 33.7-4.1s6.3-25.5-4.1-33.7L525.6 386.7c39.6-40.6 66.4-86.1 79.9-118.4 3.3-7.9 3.3-16.7 0-24.6-14.9-35.7-46.2-87.7-93-131.1C465.5 68.8 400.8 32 320 32c-68.2 0-125 26.3-169.3 60.8L38.8 5.1zm151 118.3C226 97.7 269.5 80 320 80c65.2 0 118.8 29.6 159.9 67.7 38.5 35.7 65.1 78 78.6 108.3-13.6 30.3-40.2 72.6-78.6 108.3-3.1 2.9-6.3 5.7-9.6 8.5l-45.6-35.7A143.4 143.4 0 0 0 464 256c0-79.5-64.5-144-144-144-41 0-78 17.1-104.2 44.6l-26-20.2zM320 176a80 80 0 0 1 75.4 106.6L311.8 217c2.4-5.4 3.7-11.4 3.7-17.6 0-8.1-2.2-15.6-6-22.1 3.4-.9 6.9-1.3 10.5-1.3zM208.4 278.8 160.8 241.3c-.5 4.8-.8 9.7-.8 14.7 0 88.4 71.6 160 160 160 23.6 0 46-5.1 66.2-14.3l-42.1-33A80 80 0 0 1 208.4 278.8zM94.4 168.1 56.7 138.6C38.4 160.3 24.4 183.6 14.5 204.5c-3.3 7.9-3.3 16.7 0 24.6 14.9 35.7 46.2 87.7 93 131.1C154.5 403.2 219.2 440 300 440c26.6 0 51.4-4 74.3-11.2l-47.9-37.5c-2.1.1-4.2.2-6.4.2-65.2 0-118.8-29.6-159.9-67.7-38.5-35.7-65.1-78-78.6-108.3 3.8-8.5 8.7-18 14.9-27.4z"/></svg>';

  function cornicePokedex(contenuto) {
    return `
      <div id="cardsync-auth-card">
        <div class="cs-pdx-top">
          <span class="cs-pdx-lente"></span>
          <span class="cs-pdx-led r"></span><span class="cs-pdx-led g"></span><span class="cs-pdx-led v"></span>
          <span class="cs-pdx-nome">BINDEX</span>
        </div>
        <div class="cs-pdx-schermo">${contenuto}</div>
        <div class="cs-pdx-fondo"><span class="cs-pdx-croce"></span><span class="cs-pdx-pill"></span><span class="cs-pdx-pill"></span></div>
      </div>
    `;
  }

  function iniettaStileWizard() { iniettaStile(); }

  function costruisciWizardAggiornamento() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    const card = document.createElement('div');
    card.id = 'cardsync-update-card';
    card.innerHTML = `
      <div class="cardsync-update-slide" style="text-align:center;">
        <h2>⚡ Aggiornamento obbligatorio</h2>
        <p>Non è possibile usare questa versione dell'estensione — <strong>clicca qui per scaricare l'ultima versione</strong>, sorry not sorry.</p>
      </div>
      <div id="cardsync-update-nav">
        <button id="cardsync-update-vai-al-sito" style="flex:1; background:#7c4dff; color:#fff;">Apri il sito →</button>
      </div>
    `;
    overlay.appendChild(card);
    card.querySelector('#cardsync-update-vai-al-sito').addEventListener('click', () => {
      window.open(URL_SITO, '_blank');
    });
    return overlay;
  }

  function costruisciToastTuttoOk() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-toast-ok';
    overlay.innerHTML = `
      <button id="cardsync-toast-ok-chiudi" title="Chiudi">✕</button>
      <div style="font-size:22px; margin-bottom:6px;">🎉</div>
      <div style="font-weight:800; margin-bottom:4px;">Hai l'estensione aggiornata!</div>
      <div class="cs-toast-sub">Valuta di attivare "Aiuta anche gli altri" — Bill ti ringrazia. 🙏</div>
    `;
    const chiudi = () => overlay.remove();
    overlay.querySelector('#cardsync-toast-ok-chiudi').addEventListener('click', chiudi);
    setTimeout(chiudi, 3000);
    return overlay;
  }

  function controllaVersioneObbligatoria() {
    return new Promise((resolve) => {
      if (window.self !== window.top) { resolve(false); return; }

      const versioneLocale = chrome.runtime.getManifest().version;
      fetch(URL_ULTIMA_VERSIONE + '?t=' + Date.now(), { cache: 'no-store' })
        .then((r) => (r.ok ? r.text() : null))
        .then((testo) => {
          const versioneRemota = (testo || '').trim();
          if (!versioneRemota) {
            resolve(false);
            return;
          }
          if (!versioneMaggiore(versioneRemota, versioneLocale)) {
            chrome.storage.local.get('toastAggiornataVersione', (salvato) => {
              if (salvato && salvato.toastAggiornataVersione === versioneLocale) return;
              chrome.storage.local.set({ toastAggiornataVersione: versioneLocale });
              iniettaStileWizard();
              document.body.appendChild(costruisciToastTuttoOk());
            });
            resolve(false);
            return;
          }
          iniettaStileWizard();
          const overlay = costruisciWizardAggiornamento();
          document.body.appendChild(overlay);
          resolve(true);
        })
        .catch((err) => { console.error('[CardSync] Controllo versione fallito:', err.message); resolve(false); });
    });
  }

  function costruisciOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    overlay.innerHTML = cornicePokedex(`
        <h2>Accedi a Bindex</h2>
        <p class="sub">Usa l'account che ti è stato assegnato per la tua collezione.</p>
        <label for="cardsync-auth-email">Nome utente</label>
        <div class="cs-campo">
          ${ICONA_UTENTE}
          <input type="text" id="cardsync-auth-email" autocomplete="username" placeholder="es. irene" />
        </div>
        <label for="cardsync-auth-password">Password</label>
        <div class="cs-campo">
          ${ICONA_LUCCHETTO}
          <input type="password" id="cardsync-auth-password" autocomplete="current-password" placeholder="••••••••" />
          <button type="button" class="cs-occhio" aria-label="Mostra o nascondi la password" aria-pressed="false">${ICONA_OCCHIO}</button>
        </div>
        <div id="cardsync-auth-error"></div>
        <button id="cardsync-auth-submit">Accedi</button>
    `);
    const occhio = overlay.querySelector('.cs-occhio');
    const campoPw = overlay.querySelector('#cardsync-auth-password');
    occhio.addEventListener('click', () => {
      const visibile = campoPw.type === 'password';
      campoPw.type = visibile ? 'text' : 'password';
      campoPw.classList.toggle('cs-pw-visibile', visibile);
      occhio.setAttribute('aria-pressed', String(visibile));
      occhio.innerHTML = visibile ? ICONA_OCCHIO_CHIUSO : ICONA_OCCHIO;
      campoPw.focus();
    });
    return overlay;
  }

  function mostraBottoneLogout(email) {
    if (window.self !== window.top) return;
    if (document.getElementById('menuEsci')) return;

    if (document.getElementById('cardsync-logout-btn')) return;
    iniettaStile();
    const nomeUtente = String(email || '').split('@')[0] || 'account';
    const btn = document.createElement('button');
    btn.id = 'cardsync-logout-btn';
    btn.title = 'Esci da Bindex (' + nomeUtente + ')';
    btn.innerHTML = '🚪 Esci';
    btn.addEventListener('click', async () => {
      if (!confirm('Uscire da Bindex (' + nomeUtente + ')?\n\nDovrai rifare il login per usare l\'estensione.')) return;
      await supabaseClient.auth.signOut({ scope: 'local' });
      location.reload();
    });
    document.body.appendChild(btn);
  }

  window.logoutSupabase = async function () {
    await supabaseClient.auth.signOut({ scope: 'local' });
    location.reload();
  };

  const INTERVALLO_CONTROLLO_BAN_MS = 3 * 60 * 1000;
  const TTL_CACHE_VERIFICA_MS = 20 * 1000;
  let _cacheVerificaAccesso = { scadenza: 0, esito: true };

  async function interrogaStatoBan(userId) {
    const { data, error } = await supabaseClient
      .from('profiles')
      .select('banned_until, deleted_at')
      .eq('id', userId)
      .single();
    if (error || !data) return null;
    return data;
  }

  function calcolaMessaggioBlocco(profilo) {
    if (!profilo) return null;
    if (profilo.deleted_at) {
      return 'Il tuo account è stato disattivato da un amministratore.';
    }
    if (profilo.banned_until && new Date(profilo.banned_until) > new Date()) {
      const perma = profilo.banned_until.startsWith('9999') || profilo.banned_until === 'infinity';
      if (perma) return 'Il tuo account è stato sospeso a tempo indeterminato.';
      const dataFmt = new Date(profilo.banned_until).toLocaleString('it-IT', {
        day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
      });
      return 'Il tuo account è sospeso fino al ' + dataFmt + '.';
    }
    return null;
  }

  function costruisciOverlayBloccato(messaggio) {
    iniettaStile();
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    overlay.innerHTML = cornicePokedex(`
        <h2>🚫 Accesso non consentito</h2>
        <p class="blocco-msg">${messaggio}</p>
        <button id="cardsync-auth-submit">Accedi con un altro utente</button>
    `);
    overlay.querySelector('#cardsync-auth-submit').addEventListener('click', () => location.reload());
    return overlay;
  }

  async function bloccaSeNecessario(session) {
    if (!session || !session.user) return false;
    const profilo = await interrogaStatoBan(session.user.id);
    const messaggio = calcolaMessaggioBlocco(profilo);
    if (!messaggio) return false;

    await supabaseClient.auth.signOut();
    const overlayEsistente = document.getElementById('cardsync-auth-overlay');
    if (overlayEsistente) overlayEsistente.remove();
    document.body.appendChild(costruisciOverlayBloccato(messaggio));
    return true;
  }

  function avviaControlloPeriodicoBan(session) {
    setInterval(() => { bloccaSeNecessario(session); }, INTERVALLO_CONTROLLO_BAN_MS);
  }

  window.verificaAccessoValido = async function () {
    const ora = Date.now();
    if (ora < _cacheVerificaAccesso.scadenza) return _cacheVerificaAccesso.esito;

    const { data } = await supabaseClient.auth.getSession();
    if (!data.session) {
      _cacheVerificaAccesso = { scadenza: ora + TTL_CACHE_VERIFICA_MS, esito: false };
      return false;
    }
    const bloccato = await bloccaSeNecessario(data.session);
    const esito = !bloccato;
    _cacheVerificaAccesso = { scadenza: ora + TTL_CACHE_VERIFICA_MS, esito };
    return esito;
  };

  window.assicuraLoginSupabase = function () {
    return new Promise(async (resolve) => {
      const bloccatoDaAggiornamento = await controllaVersioneObbligatoria();
      if (bloccatoDaAggiornamento) return;

      const { data } = await supabaseClient.auth.getSession();
      if (data.session) {
        const bloccato = await bloccaSeNecessario(data.session);
        if (bloccato) return;
        mostraBottoneLogout(data.session.user.email);
        avviaControlloPeriodicoBan(data.session);
        resolve(data.session);
        return;
      }

      if (window.self !== window.top) {
        const attendiSessione = setInterval(async () => {
          const { data: nuovoTentativo } = await supabaseClient.auth.getSession();
          if (nuovoTentativo.session) {
            clearInterval(attendiSessione);
            const bloccato = await bloccaSeNecessario(nuovoTentativo.session);
            if (bloccato) return;
            avviaControlloPeriodicoBan(nuovoTentativo.session);
            resolve(nuovoTentativo.session);
          }
        }, 500);
        return;
      }

      iniettaStile();
      const overlay = costruisciOverlay();
      document.body.appendChild(overlay);

      const elEmail    = overlay.querySelector('#cardsync-auth-email');
      const elPassword = overlay.querySelector('#cardsync-auth-password');
      const elErrore    = overlay.querySelector('#cardsync-auth-error');
      const elSubmit    = overlay.querySelector('#cardsync-auth-submit');

      async function tentaLogin() {
        const inputUtente = elEmail.value.trim();
        const password = elPassword.value;
        if (!inputUtente || !password) {
          elErrore.textContent = 'Inserisci nome utente e password.';
          elErrore.style.display = 'block';
          return;
        }
        // AMBIENTE DI TEST: il nome da solo si completa con @test.local. In produzione
        // '@cardsyncpro.local', insieme a ui/auth.ui.js, ui/admin-shell.ui.js,
        // utils/shared-public.js del sito e sql/110_..._ROLLBACK.sql.
        const email = inputUtente.includes('@') ? inputUtente : inputUtente.toLowerCase() + '@test.local';
        elSubmit.disabled = true;
        elSubmit.textContent = 'Accesso in corso…';
        elErrore.style.display = 'none';

        const { data: loginData, error } = await supabaseClient.auth.signInWithPassword({ email, password });
        if (error) {
          elErrore.textContent = '❌ ' + (error.message === 'Invalid login credentials'
            ? 'Nome utente o password errati.'
            : error.message);
          elErrore.style.display = 'block';
          elSubmit.disabled = false;
          elSubmit.textContent = 'Accedi';
          return;
        }

        const bloccato = await bloccaSeNecessario(loginData.session);
        if (bloccato) return;

        overlay.remove();
        mostraBottoneLogout(loginData.session.user.email);
        avviaControlloPeriodicoBan(loginData.session);
        resolve(loginData.session);
      }

      elSubmit.addEventListener('click', tentaLogin);
      [elEmail, elPassword].forEach((el) => {
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter') tentaLogin(); });
      });
      elEmail.focus();
    });
  };
})();
