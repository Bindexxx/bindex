// ── shared.js ─────────────────────────────────────────────────────────────────
// Unica fonte di verità per mappe e funzioni usate in background.js,
// popup.js e aggiungi_carta_popup.js.
//
// Caricamento:
//   - background.js (service worker):  importScripts('shared.js')
//   - popup.html:                      <script src="shared.js"></script>
//   - aggiungi_carta_popup.html:       <script src="shared.js"></script>
//   - app.html:                        <script src="shared.js"></script>
//   - schede Cardmarket aperte dall'estensione (v5.42, non più content
//     script del manifest): chrome.scripting.executeScript da popup.js e
//     background.js

// Mappa sigla lingua → idLanguage Cardmarket.
// v5.39 (Fase 3.5, B10): UNA sola mappa per tutta l'estensione, con gli
// alias che prima stavano solo in popup.js (LINGUA_MAP, tolta): prima l'URL
// si costruiva con questa mappa corta e si controllava con quella lunga, e
// una lingua come "CIN" faceva riscrivere l'URL a ogni controllo prezzi.
const LINGUA_MAP_SHARED = {
  'IT':'5','ITA':'5','ITALIANO':'5',
  'EN':'1','ENG':'1','ING':'1','INGLESE':'1',
  'DE':'3','GER':'3','TED':'3','TEDESCO':'3',
  'FR':'2','FRA':'2','FRANCESE':'2',
  'ES':'4','SPA':'4','SP':'4','SPAGNOLO':'4',
  'PT':'8','POR':'8','PORTOGHESE':'8',
  'JA':'7','JP':'7','JAP':'7','GIAP':'7','GIAPPONESE':'7',
  'KOR':'10','KO':'10','COR':'10','COREANO':'10',
  'CHN':'6','CHN-S':'6','CIN':'6','CIN-S':'6','CINESE-S':'6',
  'CHN-T':'11','CIN-T':'11','CINESE-T':'11',
  'IND':'16','INDONESIANO':'16',
  'THAI':'17','TAI':'17','TAILANDESE':'17','THAILANDESE':'17',
  'RU':'9','RUS':'9','RUSSO':'9',
};

// Mappa sigla condizione → numero minCondition Cardmarket.
// v5.39 (Fase 3.5): con gli alias (prima in popup.js, COND_MAP, tolta) più
// EXC (= EX) e POOR (= PO) trovati sul DB. "?" e valori sconosciuti: nessun
// filtro condizione.
const COND_NUM_MAP_SHARED = {
  'MT':1,'MINT':1,
  'NM':2,'NEAR MINT':2,
  'EX':3,'EXC':3,'EXCELLENT':3,
  'GD':4,'GOOD':4,
  'LP':5,'LIGHT PLAYED':5,
  'PL':6,'PLAYED':6,
  'PO':7,'POOR':7,
};

// v5.40 (Fase 4.8, D12): tempo massimo per leggere una pagina di Cardmarket
// (nome, link, prezzo). Prima 15 s scritti in dieci punti di background.js e
// content.js; ora in un posto solo. Se allo scadere la pagina sta ancora
// caricando (connessione lenta) si aspetta una volta sola altri 10 s, invece
// di dare la carta per non letta mentre la pagina sta per arrivare.
const TEMPO_MAX_LETTURA_MS = 15000;
const TEMPO_EXTRA_LETTURA_MS = 10000;

/**
 * Costruisce un URL /Singles/ con i parametri language= e minCondition= corretti.
 * Rimuove eventuali valori preesistenti prima di aggiungere i nuovi.
 *
 * Sintassi condizione supportata:
 *   NM   → minCondition=2  (NM o peggio)
 *   NM+  → minCondition=1  (solo MT, ovvero migliore di NM)
 *   NM-  → minCondition=3  (EX o peggio, ovvero peggiore di NM)
 *
 * FIX (bug "Dedenne-V1-DAA78" e ogni altra carta Reverse Holo/Prima Edizione
 * con URL già salvato in H): la versione precedente rimuoveva i parametri
 * con una regex tipo replace(pattern-che-include-"?&"-e-il-nome-parametro)
 * su stringa grezza. Su un URL come
 * "...?language=5&minCondition=2&isReverseHolo=Y", il replace toglie anche
 * il "?" (perché il pattern include [?&]), lasciando "...&isReverseHolo=Y"
 * SENZA alcun "?" residuo. Il controllo successivo url.includes('?') risultava
 * quindi falso, e la funzione ne aggiungeva uno NUOVO dopo isReverseHolo=Y:
 *   ".../Dedenne-V1-DAA78&isReverseHolo=Y?language=5&minCondition=2"
 * "&isReverseHolo=Y" finiva così a far parte del PATH invece che della query
 * string — Cardmarket non trova nessuno slug con quel nome e reindirizza
 * alla pagina dell'espansione (sintomo: link tagliato solo in fase di
 * apertura automatica, mai copiando/incollando l'URL originale a mano).
 * Riscritta con l'API URL/URLSearchParams: qualunque parametro extra già
 * presente (isReverseHolo, isFirstEd, o altri in futuro) resta intatto e il
 * "?" non si perde mai, indipendentemente dall'ordine o dal numero di
 * parametri nell'URL di partenza.
 */
function costruisciUrlFiltrato(urlBase, lingua, condizioneRaw) {
  let u;
  try {
    u = new URL(urlBase);
  } catch (_) {
    return urlBase; // URL non valido/relativo: non tocchiamo nulla
  }

  u.searchParams.delete('idLanguage');
  u.searchParams.delete('language');
  u.searchParams.delete('minCondition');

  const idLingua = LINGUA_MAP_SHARED[(lingua || '').toUpperCase().trim()];
  if (idLingua) u.searchParams.set('language', idLingua);

  condizioneRaw = (condizioneRaw || '').toUpperCase().trim();
  const haPiu      = condizioneRaw.endsWith('+');
  const haMeno     = condizioneRaw.endsWith('-');
  const condizione = (haPiu || haMeno) ? condizioneRaw.slice(0, -1).trim() : condizioneRaw;
  const rank       = COND_NUM_MAP_SHARED[condizione] || 0;

  if (rank > 0) {
    // FIX: haPiu (es. "EX+") deve restringere la soglia a una condizione
    // MIGLIORE di quella base (rank-1, verso MT) — prima il codice usava
    // "rankFinale = rank" anche per haPiu, cioè IDENTICO alla condizione
    // base senza suffisso: "EX+" si comportava esattamente come "EX" sul
    // filtro reale, contraddicendo la sintassi documentata qui sopra
    // (NM+ → minCondition=1, solo MT) e la legenda mostrata all'utente.
    // haMeno (es. "NM-") allarga la soglia verso una condizione peggiore
    // (rank+1, verso PO) — quel ramo era già corretto.
    const rankFinale = haMeno ? Math.min(rank + 1, 7) : (haPiu ? Math.max(rank - 1, 1) : rank);
    u.searchParams.set('minCondition', String(rankFinale));
  }

  // isReverseHolo / isFirstEd (o qualsiasi altro parametro già presente
  // nell'URL) non vengono mai toccati qui: restano intatti automaticamente
  // perché operiamo su u.searchParams invece che su replace() di stringa.
  return u.toString();
}

// Alias esplicito per popup.js, che mantiene il nome locale costruisciUrlFiltrato
// per compatibilità con le chiamate interne.
const costruisciUrlFiltrato_shared = costruisciUrlFiltrato;

// ── RILEVAMENTO RATE LIMIT (Error 1015) ──────────────────────────────────────
// Cloudflare/Cardmarket mostrano questa pagina quando le richieste sono troppo
// frequenti: "Error 1015 — You are being rate limited". A differenza del
// challenge anti-bot classico ("Just a moment…"), qui non c'è nulla da
// risolvere manualmente: serve solo aspettare. Usata sia su testo HTML grezzo
// (fetch) sia su DOM renderizzato (tab).
const RATE_LIMIT_MARKERS = ['error 1015', 'you are being rate limited'];

function isPaginaRateLimit(testo) {
  if (!testo) return false;
  const t = testo.toLowerCase();
  return RATE_LIMIT_MARKERS.some(m => t.includes(m));
}

// Durata standard della pausa anti-rate-limit, in millisecondi (30 minuti).
const PAUSA_RATE_LIMIT_MS = 30 * 60 * 1000;

// ── FILTRO RIGHE OFFERTA (DOM Cardmarket) — UNICA FONTE DI VERITÀ ────────────
//
// Questa logica leggeva/scriveva IDENTICA (o quasi) in tre punti diversi:
// content.js e due copie inline dentro chrome.scripting.executeScript in
// background.js. Le copie inline erano necessarie perché il codice eseguito
// via executeScript gira in un contesto isolato che non può referenziare
// funzioni esterne dell'estensione — tutto ciò che serve va scritto
// letteralmente dentro la func iniettata.
//
// Fix: queste funzioni vivono ora QUI, in shared.js. v5.42 (Fase 5.2): non è
// più un content script dichiarato nel manifest (girava su ogni pagina di
// Cardmarket, anche aperta a mano): lo iniettano con
// chrome.scripting.executeScript solo le schede aperte dall'estensione —
// popup.js insieme a content.js (_iniettaLetturaPrezzo), background.js prima
// delle letture del prezzo (_assicuraSharedInScheda). Le iniezioni della
// stessa estensione nella stessa scheda condividono lo stesso "mondo
// isolato", quindi il codice iniettato dopo trova queste funzioni come
// globali (window.rigaSoddisfaFiltriShared, ecc.) e content.js le usa
// direttamente.
//
// Ogni chiamante mantiene comunque un fallback fail-open (nessun filtro
// invece di bloccare tutto) nell'improbabile caso in cui questa funzione non
// sia ancora disponibile — vedi commenti nei chiamanti.

// LINGUA: Cardmarket usa aria-label="<lingua>" sul primo span[aria-label]
// dentro .product-attributes (icona bandiera). I valori sono nella lingua
// dell'interfaccia utente — con interfaccia italiana Cardmarket scrive
// "Italiano", "Inglese", ecc. Verificato dal DOM reale il 2025-06. Il secondo
// alias (en/fr/...) copre eventuali utenti con interfaccia in inglese.
//
// Corrispondenze codici foglio → idLanguage:
//   IT/ITA → 5 Italiano · EN → 1 Inglese · FR → 2 Francese · DE → 3 Tedesco
//   ES → 4 Spagnolo · PT → 8 Portoghese · JA/JAP → 7 Giapponese
//   KOR → 10 Coreano · CHN → 6 Cinese-S + 11 Cinese-T · RU → 9 Russo
//   IND → 16 Indonesiano · THAI → 17 Tailandese
const LANGUAGE_ARIA_MAP_SHARED = {
  '1':  ['inglese', 'english'],
  '2':  ['francese', 'french'],
  '3':  ['tedesco', 'german'],
  '4':  ['spagnolo', 'spanish'],
  '5':  ['italiano', 'italian'],
  '6':  ['cinese-s', 'chinese-s', 'simplified chinese', 'cinese s'],
  '7':  ['giapponese', 'japanese'],
  '8':  ['portoghese', 'portuguese'],
  '9':  ['russo', 'russian'],
  '10': ['coreano', 'korean'],
  '11': ['cinese-t', 'chinese-t', 'traditional chinese', 'cinese t'],
  '16': ['indonesiano', 'indonesian'],
  '17': ['tailandese', 'thai'],
};

// CONDIZIONE: Cardmarket usa la classe CSS "condition-nm", "condition-ex",
// ecc. sull'elemento <a class="article-condition condition-XX"> dentro
// .product-attributes. Rank: più basso = condizione migliore.
const CONDITION_RANK_SHARED = { mt: 1, nm: 2, ex: 3, gd: 4, lp: 5, pl: 6, po: 7 };

// L'URL contiene minCondition come numero (es. "2"), non come sigla testuale
// — questa mappa converte il valore numerico stringa nella chiave testuale
// usata da CONDITION_RANK_SHARED.
const COND_NUM_TO_KEY_SHARED = { '1': 'mt', '2': 'nm', '3': 'ex', '4': 'gd', '5': 'lp', '6': 'pl', '7': 'po' };

// REVERSE HOLO / PRIMA EDIZIONE: Cardmarket marca la riga con un'icona
// aggiuntiva (span[aria-label]) DOPO quella della lingua, dentro
// .product-attributes. Verificato dal DOM reale (2026-07): l'aria-label è
// sempre "Reverse Holo" / "First Edition" in inglese fisso, indipendentemente
// dalla lingua dell'interfaccia. Le altre varianti restano come fallback
// difensivo.
const REVERSE_HOLO_ARIA_MARKERS_SHARED = [
  'reverse holo', 'reverse-holo', 'reverseholo', 'holo reverse',
  'olografia inversa', 'inversa',
];
const FIRST_ED_ARIA_MARKERS_SHARED = [
  'first edition', 'firstedition', '1st edition', '1sted',
  'prima edizione', 'primaedizione', 'prima ed', '1a edizione',
];

function rigaHaIconaVarianteShared(riga, markers) {
  const attributi = riga.querySelector('.product-attributes');
  if (!attributi) return false;
  // Il primo span[aria-label] è la bandiera-lingua — le icone successive
  // (foil/speciali, tra cui Reverse Holo/First Edition) vengono dopo.
  const icone = Array.from(attributi.querySelectorAll('span[aria-label]')).slice(1);
  return icone.some(el => {
    const label = (el.getAttribute('aria-label') || '').toLowerCase();
    return markers.some(m => label.includes(m));
  });
}

// CARRELLO NON CLICCABILE (prezzo non attendibile): alcuni venditori
// mostrano un prezzo ma l'offerta non è davvero acquistabile da noi (il
// venditore non spedisce nella nostra zona, blacklist reciproca, ecc.) —
// Cardmarket in quel caso NON mostra il normale bottone "Aggiungi al
// carrello" ma un elemento diverso, non cliccabile. Verificato dal DOM
// reale (2026-07, utente loggato):
//   - Cliccabile:     <button class="btn btn-primary ..." data-id-amount="...">
//   - Non cliccabile: <a class="btn btn-grey" role="button"> (nessun data-id-amount)
//
// FIX (bug "tutte le carte risultano Esaurita"): una versione precedente
// era un'ALLOWLIST — richiedeva ESATTAMENTE <button data-id-amount>,
// bloccando ogni riga che non combaciava perfettamente (es. tab non ancora
// autenticata su Cardmarket al momento della lettura, o markup leggermente
// diverso da quello osservato). Risultato: ogni riga veniva scartata e ogni
// carta risultava "Esaurita". Ora si esclude SOLO il pattern esplicito "non
// cliccabile" osservato nel DOM reale — <a class="btn-grey" role="button">
// senza data-id-amount — e qualunque altro markup non blocca la riga:
// fail-safe invece di allowlist rigida.
//
// v5.36 (D15): verificato di nuovo sul DOM reale il 23/10/2026 (utente
// loggato, 150 offerte su 3 pagine): oggi il carrello comprabile è
// <a class="btn btn-sm btn-primary"> SENZA data-id-amount — il markup
// "cliccabile" descritto sopra non esiste più. Il filtro reggeva solo perché
// esclude il grigio invece di richiedere quello buono. Ora "non comprabile"
// si riconosce da più segnali: btn-grey, disabled, aria-disabled="true".
function rigaCarrelloCliccabileShared(riga) {
  const cartIcon = riga.querySelector('.fonticon-cart');
  const cartEl = cartIcon ? cartIcon.closest('a, button') : null;
  if (!cartEl) return true; // elemento non trovato: non blocchiamo
  if (cartEl.classList.contains('btn-grey') && !cartEl.hasAttribute('data-id-amount')) return false;
  if (cartEl.disabled === true || cartEl.hasAttribute('disabled')) return false;
  if ((cartEl.getAttribute('aria-disabled') || '').toLowerCase() === 'true') return false;
  return true;
}

// Filtro completo su una singola riga d'offerta (.article-row). opts:
//   idLanguage    — idLanguage atteso (stringa numerica, es. "5"), o null
//   minCondition  — minCondition atteso (stringa, numerica o già chiave tipo
//                   "nm"), o null
//   isReverseHolo / isFirstEd — Y/true se la variante è quella richiesta
//   ignoraVarianti — true per disattivare SOLO l'esclusione badge RH/1ED
//                    (fallback quando la carta esiste solo in quella
//                    variante — es. molte espansioni cinesi — vedi
//                    chiamanti). Lingua/condizione/carrello restano filtrati.
function rigaSoddisfaFiltriShared(riga, opts) {
  opts = opts || {};
  const { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti } = opts;

  // Il controllo carrello è SEMPRE applicato, indipendentemente dagli altri
  // filtri: un'offerta non acquistabile non deve mai essere scelta come
  // fonte del prezzo, a differenza dei filtri RH/1ED che ignoraVarianti
  // rilassa volutamente in alcuni casi.
  if (!rigaCarrelloCliccabileShared(riga)) return false;

  const attributi = riga.querySelector('.product-attributes');
  if (!attributi) return true; // struttura inattesa → non bloccare

  // ── Filtro lingua ──
  if (idLanguage) {
    const accettate = LANGUAGE_ARIA_MAP_SHARED[idLanguage] || [];
    const iconaBandiera = attributi.querySelector('span[aria-label]');
    const label = (iconaBandiera?.getAttribute('aria-label') || '').toLowerCase();
    if (!accettate.some(a => label.includes(a))) return false;
  }

  // ── Filtro condizione ──
  if (minCondition) {
    const condKey = COND_NUM_TO_KEY_SHARED[minCondition] || minCondition; // fallback: già testuale
    const rankMinimo = CONDITION_RANK_SHARED[condKey];
    if (rankMinimo) {
      const elCond = attributi.querySelector('a.article-condition');
      if (elCond) {
        const match = elCond.className.match(/condition-([a-z]+)/);
        if (match) {
          const rankRiga = CONDITION_RANK_SHARED[match[1]] ?? null;
          if (rankRiga !== null && rankRiga > rankMinimo) return false;
        }
      }
    }
  }

  // ── Filtro Reverse Holo / Prima Edizione ──
  // FIX (bug "Esaurita" su ogni carta RH/1ED): isReverseHolo=Y e isFirstEd=Y
  // sono filtri NATIVI di Cardmarket — quando presenti nell'URL, Cardmarket
  // ha GIÀ ristretto le righe alla variante richiesta, e in quel contesto il
  // badge per-riga può essere assente (ridondante). Ci fidiamo del filtro
  // nativo per l'INCLUSIONE; il badge serve solo per l'ESCLUSIONE quando la
  // variante NON è richiesta (offerte miste in pagina). ignoraVarianti
  // disattiva anche l'esclusione badge: usato come fallback quando la carta
  // esiste SOLO in RH/1ED (es. molte espansioni cinesi).
  if (!ignoraVarianti) {
    if (!isReverseHolo && rigaHaIconaVarianteShared(riga, REVERSE_HOLO_ARIA_MARKERS_SHARED)) return false;
    if (!isFirstEd && rigaHaIconaVarianteShared(riga, FIRST_ED_ARIA_MARKERS_SHARED)) return false;
  }

  return true;
}

// Espone le funzioni sul global object esplicitamente: nel mondo isolato dei
// content script, dichiarazioni `function`/`const` di primo livello sono già
// visibili come proprietà implicite dell'ambiente globale condiviso, ma
// l'assegnazione esplicita rende il contratto (cosa background.js si aspetta
// di trovare via window.___) leggibile e a prova di refactor futuro.
if (typeof window !== 'undefined') {
  window.rigaSoddisfaFiltriShared = rigaSoddisfaFiltriShared;
  window.rigaCarrelloCliccabileShared = rigaCarrelloCliccabileShared;
}

// ── AUDIO KEEP-ALIVE (fix "sessione si blocca se la tab va in background") ───
// FIX: una sessione lunga (▶ Avvia / 📋📦🗂️ bulk) lasciata per ore in una tab
// NON in primo piano (finestra minimizzata, coperta da altre, cambio di
// desktop virtuale...) rallenta drasticamente o si blocca del tutto fino a
// quando la tab non torna in focus (es. muovendo il mouse). Causa: il
// "background tab timer throttling" di Chrome — setTimeout/setInterval in
// una tab non visibile/non attiva vengono rallentati fino a girare anche
// solo una volta al minuto dopo pochi minuti in background, e tutta la
// logica di attesa (_attendiConCountdown, i vari delay tra una carta e
// l'altra) si basa proprio su questi timer. chrome.power (usato per evitare
// la sospensione del PC) non c'entra: agisce sul sistema operativo, non sul
// throttling per-tab di Chrome.
//
// Chrome esclude dal throttling intensivo le tab che stanno riproducendo
// audio ("audible tab") — trucco noto e usato da diverse web app per tenere
// vivi i propri timer in background. Basta un audio in loop a volume quasi
// impercettibile (non zero: volume 0 non viene considerato "audio in
// riproduzione" da Chrome) per tutta la durata della sessione. Nessun file
// esterno necessario: un WAV silenzioso di 1 campione codificato come data
// URI, generato una volta sola e riusato.
//
// Avviato SEMPRE come primissima istruzione sincrona del click handler che
// avvia una sessione (prima di qualunque await) — l'autorizzazione del
// browser a riprodurre audio richiede un gesto utente "fresco"; chiamarlo
// dopo una await (es. dopo una verifica di rete) rischia di perdere quel
// gesto e far fallire play() silenziosamente.
const _AUDIO_KEEPALIVE_SRC =
  'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';
let _audioKeepAlive = null;

// FIX (freeze totale di Chrome/sistema su "Avvia"): l'audio keep-alive
// introdotto in v3.0 per evitare il "background tab timer throttling" di
// Chrome (vedi commento sopra) causa su questo specifico PC un blocco
// totale del sistema operativo quando Chrome avvia la riproduzione audio —
// molto probabilmente un problema del driver audio del PC (non del codice
// dell'estensione in sé: creare/avviare un elemento <audio> richiede che
// Chrome passi la mano al sottosistema audio di Windows, e se quel
// passaggio si blocca lì, blocca tutto il sistema, non solo la tab).
// Confermato con un test isolato: disattivando SOLO questa funzione il
// freeze sparisce completamente, con tutto il resto del codice invariato.
//
// Disattivata quindi in modo permanente. Contropartita accettata: una
// sessione molto lunga (▶ Avvia su centinaia di carte) potrebbe rallentare
// o mettersi in pausa da sola se la tab resta a lungo fuori dal primo piano
// (finestra minimizzata per ore, ecc.) — molto meglio di un freeze totale
// del sistema. Se in futuro serve recuperare la protezione dal throttling
// con un meccanismo diverso dall'audio (es. chrome.alarms lato service
// worker invece di setTimeout lato tab), è un lavoro a parte.
function avviaAudioKeepAlive() {
  return; // disattivata — vedi commento sopra
}

function fermaAudioKeepAlive() {
  if (!_audioKeepAlive) return;
  try { _audioKeepAlive.pause(); } catch (_) {}
  _audioKeepAlive = null;
}

// ── NOME DISPOSITIVO ──────────────────────────────────────────────────────────
// Ogni PC/estensione ha un nome persistente, generato una sola volta e
// salvato in chrome.storage.local — serve per capire, quando più dispositivi
// sono online insieme (es. "un portatile sempre acceso" + il tuo PC
// principale), CHI ha preso in carico ogni riga della coda unificata
// (coda_carte.dispositivo). Non serve configurarlo: la prima volta che
// questa funzione viene chiamata su un'estensione ne genera uno e lo
// riusa sempre per quel browser/profilo da quel momento in poi.
// FIX 2026-09-03 — globalThis al posto di window.
// shared.js viene caricato in DUE ambienti: le pagine dei popup (dove
// 'window' esiste) e il service worker di background.js, via
// importScripts. In un service worker MV3 'window' NON ESISTE: leggere
// window._nomeDispositivoCache lanciava un ReferenceError.
// Conseguenza, ed e' grossa: _lavoroAutonomo() chiama nomeDispositivo()
// PRIMA di prendere in carico la riga (background.js, riga ~330), dentro un
// try/catch che inghiottiva l'errore in console. Il worker autonomo
// falliva quindi a ogni giro, sempre nello stesso punto, senza mai
// claimare niente — cioe' "Aiuta il gruppo" non stava lavorando le righe
// altrui. Trovato mentre si aggiungeva la registrazione dei contributi:
// senza questa correzione il contatore sarebbe rimasto a zero per sempre e
// avremmo dato la colpa al contatore.
// Il resto del file usa gia' 'typeof window !== undefined' per questo
// motivo (vedi in fondo); qui la guardia mancava.
function nomeDispositivo() {
  return new Promise((resolve) => {
    const ambiente = globalThis;
    if (ambiente._nomeDispositivoCache) { resolve(ambiente._nomeDispositivoCache); return; }
    chrome.storage.local.get('nomeDispositivo', (saved) => {
      let nome = saved.nomeDispositivo;
      if (!nome) {
        nome = 'PC-' + Math.random().toString(36).slice(2, 7).toUpperCase();
        chrome.storage.local.set({ nomeDispositivo: nome });
      }
      ambiente._nomeDispositivoCache = nome;
      resolve(nome);
    });
  });
}

// ── CONTRIBUTI AL GRUPPO (migration 37, 2026-09-03) ─────────────────────
// Registra "ho completato il lavoro di qualcun altro". Sta qui e non in
// background.js perche' i percorsi che aiutano il gruppo sono due: il
// worker autonomo (background.js) e il controllo prezzi condiviso
// (popup.js). shared.js e' caricato da entrambi.
//
// Il client viene passato come argomento invece di essere cercato fra le
// variabili globali: nel worker e nei popup si chiama uguale ma non e' lo
// stesso oggetto, e dipendere da un nome globale qui renderebbe questa
// funzione utilizzabile solo per caso.
//
// CHI DECIDE COSA CONTA NON E' QUESTO CODICE: la RPC scarta da sola le
// righe di cui sei gia' proprietario (lavorare le proprie carte non e' un
// contributo) e prende l'autore da auth.uid(), non da qui. Il client puo'
// solo dire "e' successo questo", mai "e' stato lui".
//
// Fire-and-forget: un errore nel contatore non deve mai far fallire il
// lavoro vero, che a quel punto e' gia' stato completato.
async function registraAiutoGruppo(client, rigaId, ownerRiga, tipo) {
  try {
    if (!client || !ownerRiga) return;
    const { error } = await client.rpc('registra_aiuto_gruppo', {
      p_riga_id: String(rigaId ?? ''),
      p_owner_riga: ownerRiga,
      p_tipo: tipo || 'coda_carte',
    });
    if (error) console.warn('[contributi] registrazione non riuscita:', error.message);
  } catch (e) {
    console.warn('[contributi] registrazione non riuscita:', e.message);
  }
}