// Mappe e funzioni comuni a background.js, popup.js, aggiungi_carta_popup.js e app.html.
// Si inietta anche nelle schede di Cardmarket aperte dall'estensione, una volta sola per pagina:
// una seconda iniezione darebbe errore sulle const.

const LINGUA_MAP_SHARED = {
  'IT':'5','ITA':'5','ITALIANO':'5',
  'EN':'1','ENG':'1','ING':'1','INGLESE':'1',
  'DE':'3','GER':'3','TED':'3','TEDESCO':'3',
  'FR':'2','FRA':'2','FRANCESE':'2',
  'ES':'4','SPA':'4','SP':'4','SPAGNOLO':'4',
  'PT':'8','POR':'8','PORTOGHESE':'8',
  'JA':'7','JP':'7','JAP':'7','GIAP':'7','GIAPPONESE':'7',
  'KOR':'10','KO':'10','COR':'10','COREANO':'10',
  'CHN':'6','CHN-S':'6','CIN':'6','CIN-S':'6','CINESE-S':'6',
  'CHN-T':'11','CIN-T':'11','CINESE-T':'11',
  'IND':'16','INDONESIANO':'16',
  'THAI':'17','TAI':'17','TAILANDESE':'17','THAILANDESE':'17',
  'RU':'9','RUS':'9','RUSSO':'9',
};

const COND_NUM_MAP_SHARED = {
  'MT':1,'MINT':1,
  'NM':2,'NEAR MINT':2,
  'EX':3,'EXC':3,'EXCELLENT':3,
  'GD':4,'GOOD':4,
  'LP':5,'LIGHT PLAYED':5,
  'PL':6,'PLAYED':6,
  'PO':7,'POOR':7,
};

const TEMPO_MAX_LETTURA_MS = 15000;
const TEMPO_EXTRA_LETTURA_MS = 10000;

function costruisciUrlFiltrato(urlBase, lingua, condizioneRaw) {
  let u;
  try {
    u = new URL(urlBase);
  } catch (_) {
    return urlBase;
  }

  u.searchParams.delete('idLanguage');
  u.searchParams.delete('language');
  u.searchParams.delete('minCondition');

  const idLingua = LINGUA_MAP_SHARED[(lingua || '').toUpperCase().trim()];
  if (idLingua) u.searchParams.set('language', idLingua);

  condizioneRaw = (condizioneRaw || '').toUpperCase().trim();
  const haPiu      = condizioneRaw.endsWith('+');
  const haMeno     = condizioneRaw.endsWith('-');
  const condizione = (haPiu || haMeno) ? condizioneRaw.slice(0, -1).trim() : condizioneRaw;
  const rank       = COND_NUM_MAP_SHARED[condizione] || 0;

  if (rank > 0) {
    const rankFinale = haMeno ? Math.min(rank + 1, 7) : (haPiu ? Math.max(rank - 1, 1) : rank);
    u.searchParams.set('minCondition', String(rankFinale));
  }

  return u.toString();
}

const costruisciUrlFiltrato_shared = costruisciUrlFiltrato;

const RATE_LIMIT_MARKERS = ['error 1015', 'you are being rate limited'];

function isPaginaRateLimit(testo) {
  if (!testo) return false;
  const t = testo.toLowerCase();
  return RATE_LIMIT_MARKERS.some(m => t.includes(m));
}

const PAUSA_RATE_LIMIT_MS = 30 * 60 * 1000;

const LANGUAGE_ARIA_MAP_SHARED = {
  '1':  ['inglese', 'english'],
  '2':  ['francese', 'french'],
  '3':  ['tedesco', 'german'],
  '4':  ['spagnolo', 'spanish'],
  '5':  ['italiano', 'italian'],
  '6':  ['cinese-s', 'chinese-s', 'simplified chinese', 'cinese s'],
  '7':  ['giapponese', 'japanese'],
  '8':  ['portoghese', 'portuguese'],
  '9':  ['russo', 'russian'],
  '10': ['coreano', 'korean'],
  '11': ['cinese-t', 'chinese-t', 'traditional chinese', 'cinese t'],
  '16': ['indonesiano', 'indonesian'],
  '17': ['tailandese', 'thai'],
};

const CONDITION_RANK_SHARED = { mt: 1, nm: 2, ex: 3, gd: 4, lp: 5, pl: 6, po: 7 };

const COND_NUM_TO_KEY_SHARED = { '1': 'mt', '2': 'nm', '3': 'ex', '4': 'gd', '5': 'lp', '6': 'pl', '7': 'po' };

const REVERSE_HOLO_ARIA_MARKERS_SHARED = [
  'reverse holo', 'reverse-holo', 'reverseholo', 'holo reverse',
  'olografia inversa', 'inversa',
];
const FIRST_ED_ARIA_MARKERS_SHARED = [
  'first edition', 'firstedition', '1st edition', '1sted',
  'prima edizione', 'primaedizione', 'prima ed', '1a edizione',
];

function rigaHaIconaVarianteShared(riga, markers) {
  const attributi = riga.querySelector('.product-attributes');
  if (!attributi) return false;
  const icone = Array.from(attributi.querySelectorAll('span[aria-label]')).slice(1);
  return icone.some(el => {
    const label = (el.getAttribute('aria-label') || '').toLowerCase();
    return markers.some(m => label.includes(m));
  });
}

function rigaCarrelloCliccabileShared(riga) {
  const cartIcon = riga.querySelector('.fonticon-cart');
  const cartEl = cartIcon ? cartIcon.closest('a, button') : null;
  if (!cartEl) return true;
  if (cartEl.classList.contains('btn-grey') && !cartEl.hasAttribute('data-id-amount')) return false;
  if (cartEl.disabled === true || cartEl.hasAttribute('disabled')) return false;
  if ((cartEl.getAttribute('aria-disabled') || '').toLowerCase() === 'true') return false;
  return true;
}

function rigaSoddisfaFiltriShared(riga, opts) {
  opts = opts || {};
  const { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti } = opts;

  if (!rigaCarrelloCliccabileShared(riga)) return false;

  const attributi = riga.querySelector('.product-attributes');
  if (!attributi) return true;

  if (idLanguage) {
    const accettate = LANGUAGE_ARIA_MAP_SHARED[idLanguage] || [];
    const iconaBandiera = attributi.querySelector('span[aria-label]');
    const label = (iconaBandiera?.getAttribute('aria-label') || '').toLowerCase();
    if (!accettate.some(a => label.includes(a))) return false;
  }

  if (minCondition) {
    const condKey = COND_NUM_TO_KEY_SHARED[minCondition] || minCondition;
    const rankMinimo = CONDITION_RANK_SHARED[condKey];
    if (rankMinimo) {
      const elCond = attributi.querySelector('a.article-condition');
      if (elCond) {
        const match = elCond.className.match(/condition-([a-z]+)/);
        if (match) {
          const rankRiga = CONDITION_RANK_SHARED[match[1]] ?? null;
          if (rankRiga !== null && rankRiga > rankMinimo) return false;
        }
      }
    }
  }

  if (!ignoraVarianti) {
    if (!isReverseHolo && rigaHaIconaVarianteShared(riga, REVERSE_HOLO_ARIA_MARKERS_SHARED)) return false;
    if (!isFirstEd && rigaHaIconaVarianteShared(riga, FIRST_ED_ARIA_MARKERS_SHARED)) return false;
  }

  return true;
}

if (typeof window !== 'undefined') {
  window.rigaSoddisfaFiltriShared = rigaSoddisfaFiltriShared;
  window.rigaCarrelloCliccabileShared = rigaCarrelloCliccabileShared;
}

// Le carte BOO (Trick or Trade) esistono solo in inglese: "mismagius boo 059", "BOO24PAL054",
// "boo23 sit 103". Non "Pumpkaboo" né "Booster": BOO deve essere l'inizio di una parola,
// da solo, con l'anno o seguito da set + numero.
function codiceEBooShared(testo) {
  return String(testo || '').split(/[\s,]+/).some(t => /^BOO(?:\d{2})?(?:[A-Z]{2,4}-?\d{1,3})?$/i.test(t));
}

function linguaPerCartaShared(testo, lingua) {
  return codiceEBooShared(testo) ? 'EN' : (lingua || 'IT');
}

function nomeDispositivo() {
  return new Promise((resolve) => {
    const ambiente = globalThis;
    if (ambiente._nomeDispositivoCache) { resolve(ambiente._nomeDispositivoCache); return; }
    chrome.storage.local.get('nomeDispositivo', (saved) => {
      let nome = saved.nomeDispositivo;
      if (!nome) {
        nome = 'PC-' + Math.random().toString(36).slice(2, 7).toUpperCase();
        chrome.storage.local.set({ nomeDispositivo: nome });
      }
      ambiente._nomeDispositivoCache = nome;
      resolve(nome);
    });
  });
}

async function registraAiutoGruppo(client, rigaId, ownerRiga, tipo) {
  try {
    if (!client || !ownerRiga) return;
    const { error } = await client.rpc('registra_aiuto_gruppo', {
      p_riga_id: String(rigaId ?? ''),
      p_owner_riga: ownerRiga,
      p_tipo: tipo || 'coda_carte',
    });
    if (error) console.warn('[contributi] registrazione non riuscita:', error.message);
  } catch (e) {
    console.warn('[contributi] registrazione non riuscita:', e.message);
  }
}
