// Pagina aperta come scheda (?modo=tab) o come popup dell'estensione.
// File esterno perché la CSP delle estensioni MV3 blocca gli script inline.

(function () {
  const modalitaTab = new URLSearchParams(location.search).get('modo') === 'tab';
  if (modalitaTab) {
    document.body.classList.add('modalita-tab');
  } else if (chrome.tabs && chrome.tabs.getCurrent) {
    chrome.tabs.getCurrent((tab) => {
      if (tab) document.body.classList.add('modalita-tab');
    });
  }

  if (window.self !== window.top) {
    document.body.classList.add('embedded-in-hub');
  }
})();
