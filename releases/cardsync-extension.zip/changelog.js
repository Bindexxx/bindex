// Pagina delle novità: mostra CHANGELOG.md formattato.

const _crediti = document.getElementById('footer-credit');
if (_crediti) _crediti.textContent = 'Bindex · estensione v' + chrome.runtime.getManifest().version + ' · © Lunachiara';

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function formattaInline(testo) {
  let t = escapeHtml(testo);
  t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
  t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  return t;
}

function renderMarkdown(md) {
  const righe = md.split('\n');
  let html = '';
  let inList = false;
  let i = 0;

  function chiudiListaSeAperta() {
    if (inList) { html += '</ul>'; inList = false; }
  }

  while (i < righe.length) {
    const riga = righe[i];

    if (riga.trim() === '') { i++; continue; }

    if (/^\s*---\s*$/.test(riga)) {
      chiudiListaSeAperta();
      html += '<hr>';
      i++;
      continue;
    }

    const h3 = riga.match(/^###\s+(.*)/);
    const h2 = riga.match(/^##\s+(.*)/);
    const h1 = riga.match(/^#\s+(.*)/);
    const li = riga.match(/^-\s+(.*)/);

    if (h3) { chiudiListaSeAperta(); html += `<h3>${formattaInline(h3[1])}</h3>`; i++; continue; }
    if (h2) { chiudiListaSeAperta(); html += `<h2>${formattaInline(h2[1])}</h2>`; i++; continue; }
    if (h1) { chiudiListaSeAperta(); html += `<h1>${formattaInline(h1[1])}</h1>`; i++; continue; }

    if (li) {
      if (!inList) { html += '<ul>'; inList = true; }
      let buffer = li[1];
      i++;
      while (i < righe.length && righe[i].trim() !== '' && /^\s+\S/.test(righe[i])
             && !/^\s*-\s+/.test(righe[i]) && !/^#{1,3}\s+/.test(righe[i].trim()) && !/^---\s*$/.test(righe[i].trim())) {
        buffer += ' ' + righe[i].trim();
        i++;
      }
      html += `<li>${formattaInline(buffer)}</li>`;
      continue;
    }

    chiudiListaSeAperta();
    let buffer = riga.trim();
    i++;
    while (i < righe.length && righe[i].trim() !== ''
           && !/^\s*-\s+/.test(righe[i]) && !/^#{1,3}\s+/.test(righe[i].trim()) && !/^---\s*$/.test(righe[i].trim())) {
      buffer += ' ' + righe[i].trim();
      i++;
    }
    html += `<p>${formattaInline(buffer)}</p>`;
  }

  chiudiListaSeAperta();
  return html;
}

async function caricaChangelog() {
  const el = document.getElementById('changelogContent');
  try {
    const res = await fetch(chrome.runtime.getURL('CHANGELOG.md'));
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const testo = await res.text();
    el.innerHTML = renderMarkdown(testo);
  } catch (e) {
    el.innerHTML = '<p>Impossibile caricare le novità (' + escapeHtml(e.message) + ').</p>';
  }
}

caricaChangelog();
