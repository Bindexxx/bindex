// ── changelog.js ──────────────────────────────────────────────────────────────
// Pagina standalone (aperta in una tab con chrome.tabs.create, mai come popup)
// che mostra il contenuto di CHANGELOG.md formattato. Applica lo stesso tema
// scelto nel popup principale (sincronizzato via chrome.storage.onChanged,
// stesso pattern già usato dalle pagine bulk carte/sealed).

const LISTA_TEMI = ['purple', 'green', 'blue', 'contrast', 'dark', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];

function applicaTema(nome) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nome !== 'purple') document.body.classList.add(`theme-${nome}`);
}

chrome.storage.local.get(['selectedTheme'], (saved) => {
  applicaTema(saved.selectedTheme || 'purple');
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.selectedTheme) applicaTema(changes.selectedTheme.newValue || 'purple');
});

// ── PARSER MARKDOWN MINIMALE ──────────────────────────────────────────────────
// Copre solo la sintassi usata in CHANGELOG.md: #/##/### per i titoli, "- " per
// gli elenchi puntati (con continuazione su righe successive non marcate,
// tipico del testo "a capo" scritto a mano), "**testo**" per il grassetto,
// `testo` per il codice inline, "---" per il separatore orizzontale, righe
// vuote per separare i paragrafi. Non è un parser Markdown completo — è
// sufficiente e controllato perché il file sorgente è scritto da noi.
function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function formattaInline(testo) {
  let t = escapeHtml(testo);
  t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
  t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  return t;
}

function renderMarkdown(md) {
  const righe = md.split('\n');
  let html = '';
  let inList = false;
  let i = 0;

  function chiudiListaSeAperta() {
    if (inList) { html += '</ul>'; inList = false; }
  }

  while (i < righe.length) {
    const riga = righe[i];

    if (riga.trim() === '') { i++; continue; }

    if (/^\s*---\s*$/.test(riga)) {
      chiudiListaSeAperta();
      html += '<hr>';
      i++;
      continue;
    }

    const h3 = riga.match(/^###\s+(.*)/);
    const h2 = riga.match(/^##\s+(.*)/);
    const h1 = riga.match(/^#\s+(.*)/);
    const li = riga.match(/^-\s+(.*)/);

    if (h3) { chiudiListaSeAperta(); html += `<h3>${formattaInline(h3[1])}</h3>`; i++; continue; }
    if (h2) { chiudiListaSeAperta(); html += `<h2>${formattaInline(h2[1])}</h2>`; i++; continue; }
    if (h1) { chiudiListaSeAperta(); html += `<h1>${formattaInline(h1[1])}</h1>`; i++; continue; }

    if (li) {
      if (!inList) { html += '<ul>'; inList = true; }
      let buffer = li[1];
      i++;
      // Righe di continuazione: indentate, non vuote, non un nuovo elemento
      // di lista né un titolo/separatore — vengono unite allo stesso <li>.
      while (i < righe.length && righe[i].trim() !== '' && /^\s+\S/.test(righe[i])
             && !/^\s*-\s+/.test(righe[i]) && !/^#{1,3}\s+/.test(righe[i].trim()) && !/^---\s*$/.test(righe[i].trim())) {
        buffer += ' ' + righe[i].trim();
        i++;
      }
      html += `<li>${formattaInline(buffer)}</li>`;
      continue;
    }

    // Paragrafo normale, con eventuali righe di continuazione a seguire.
    chiudiListaSeAperta();
    let buffer = riga.trim();
    i++;
    while (i < righe.length && righe[i].trim() !== ''
           && !/^\s*-\s+/.test(righe[i]) && !/^#{1,3}\s+/.test(righe[i].trim()) && !/^---\s*$/.test(righe[i].trim())) {
      buffer += ' ' + righe[i].trim();
      i++;
    }
    html += `<p>${formattaInline(buffer)}</p>`;
  }

  chiudiListaSeAperta();
  return html;
}

async function caricaChangelog() {
  const el = document.getElementById('changelogContent');
  try {
    const res = await fetch(chrome.runtime.getURL('CHANGELOG.md'));
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const testo = await res.text();
    el.innerHTML = renderMarkdown(testo);
  } catch (e) {
    el.innerHTML = '<p>⚠️ Impossibile caricare CHANGELOG.md (' + e.message + ').</p>';
  }
}

caricaChangelog();
