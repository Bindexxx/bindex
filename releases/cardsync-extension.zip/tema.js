// ── tema.js — chiaro/scuro di tutte le pagine (v5.46, Fase 8b) ───────────────
// Lo scuro segue il sito: cardsyncDarkMode in chrome.storage.local, scritto da
// background.js quando il sito apre l'app (CARDSYNC_OPEN_APP) e a ogni cambio
// di tema sul sito (CARDSYNC_SET_TEMA, mandato dal sito dalla stessa
// versione). Finché il sito non l'ha mai mandato, si segue il sistema.
// Cambia al volo, senza ricaricare la pagina (prima ogni pagina si
// ricaricava: con la coda o un controllo prezzi in corso si interrompevano).
// Mette le classi 'modo-scuro' (CSS delle pagine e tema.css) e 'dark-mode'
// (stessa classe del sito) sul <body>. Prima di ogni altro script della
// pagina: le pagine non toccano più queste classi.
(function () {
  const sistema = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  let dalSito; // true/false se il sito l'ha mandato, undefined altrimenti

  function applica() {
    const scuro = typeof dalSito === 'boolean' ? dalSito : !!(sistema && sistema.matches);
    if (typeof document === 'undefined' || !document) return; // pagina già chiusa
    const metti = () => {
      if (!document.body) return;
      document.body.classList.toggle('modo-scuro', scuro);
      document.body.classList.toggle('dark-mode', scuro);
      document.documentElement.style.colorScheme = scuro ? 'dark' : 'light';
    };
    if (document.body) metti();
    else document.addEventListener('DOMContentLoaded', metti, { once: true });
  }

  try {
    chrome.storage.local.get(['cardsyncDarkMode'], (salvato) => {
      dalSito = salvato && typeof salvato.cardsyncDarkMode === 'boolean' ? salvato.cardsyncDarkMode : undefined;
      applica();
    });
    chrome.storage.onChanged.addListener((cambi) => {
      if (!cambi.cardsyncDarkMode) return;
      const v = cambi.cardsyncDarkMode.newValue;
      dalSito = typeof v === 'boolean' ? v : undefined;
      applica();
    });
  } catch (_) {
    applica();
  }
  if (sistema && sistema.addEventListener) sistema.addEventListener('change', applica);
  applica();
})();
