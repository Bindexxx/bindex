// Chiaro/scuro di tutte le pagine: segue il sito (cardsyncDarkMode), altrimenti il sistema.
// Va caricato prima di ogni altro script della pagina.

(function () {
  const sistema = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  let dalSito;

  function applica() {
    const scuro = typeof dalSito === 'boolean' ? dalSito : !!(sistema && sistema.matches);
    if (typeof document === 'undefined' || !document) return;
    const metti = () => {
      if (!document.body) return;
      document.body.classList.toggle('modo-scuro', scuro);
      document.body.classList.toggle('dark-mode', scuro);
      document.documentElement.style.colorScheme = scuro ? 'dark' : 'light';
    };
    if (document.body) metti();
    else document.addEventListener('DOMContentLoaded', metti, { once: true });
  }

  try {
    chrome.storage.local.get(['cardsyncDarkMode'], (salvato) => {
      dalSito = salvato && typeof salvato.cardsyncDarkMode === 'boolean' ? salvato.cardsyncDarkMode : undefined;
      applica();
    });
    chrome.storage.onChanged.addListener((cambi) => {
      if (!cambi.cardsyncDarkMode) return;
      const v = cambi.cardsyncDarkMode.newValue;
      dalSito = typeof v === 'boolean' ? v : undefined;
      applica();
    });
  } catch (_) {
    applica();
  }
  if (sistema && sistema.addEventListener) sistema.addEventListener('change', applica);
  applica();
})();
