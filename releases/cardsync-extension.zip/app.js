// Pagina dell'app (app.html): barra in alto, Home "Adesso", sezioni Coda e Prezzi come iframe.
// Gli iframe restano sempre caricati: cambiare sezione non deve fermare coda e controlli prezzi.
// CARDSYNC_ATTIVITA si accetta solo dai propri iframe; Ferma/Riprendi vanno solo a loro.

const _loginSupabasePronto = assicuraLoginSupabase();

const SEZIONI = ['prezzi', 'carte', 'coda', 'coda-dettaglio'];

function _iframeDi(sezione) {
  const colonna = document.querySelector(`.column[data-sezione="${sezione}"]`);
  return colonna ? colonna.querySelector('iframe') : null;
}

const _btnUtente = document.getElementById('btnUtente');
const _menuUtente = document.getElementById('menuUtente');
function _apriMenuUtente(apri) {
  _menuUtente.hidden = !apri;
  _btnUtente.setAttribute('aria-expanded', String(apri));
  if (apri) _aggiornaSottotitoloMenu();
}
_btnUtente.addEventListener('click', (e) => {
  e.stopPropagation();
  _apriMenuUtente(_menuUtente.hidden);
});
document.addEventListener('click', (e) => {
  if (!_menuUtente.hidden && !_menuUtente.contains(e.target)) _apriMenuUtente(false);
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  _apriMenuUtente(false);
  impPopover.classList.remove('visible');
});

async function _aggiornaSottotitoloMenu() {
  const el = document.getElementById('menuUtenteSotto');
  try {
    const [disp, { aiutaGruppo }] = await Promise.all([nomeDispositivo(), chrome.storage.local.get('aiutaGruppo')]);
    el.textContent = disp + ' · aiuta il gruppo: ' + (aiutaGruppo ? 'sì' : 'no');
  } catch (_) { el.textContent = ''; }
}

document.getElementById('menuEsci').addEventListener('click', async () => {
  _apriMenuUtente(false);
  const nome = document.getElementById('accountNome').textContent || 'account';
  if (!confirm('Uscire da Bindex (' + nome + ') su questo PC?\n\nDovrai rifare il login per usare l\'estensione.')) return;
  if (typeof window.logoutSupabase === 'function') await window.logoutSupabase();
});

const impBtn = document.getElementById('navImpostazioniAvanzate');
const impPopover = document.getElementById('impostazioniAvanzatePopover');
const impChiudiBtn = document.getElementById('chiudiImpostazioniAvanzate');
impBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  _apriMenuUtente(false);
  impPopover.classList.add('visible');
});
impChiudiBtn.addEventListener('click', () => impPopover.classList.remove('visible'));
impPopover.addEventListener('click', (e) => {
  if (e.target === impPopover) impPopover.classList.remove('visible');
});

function _rinfrescaLocationOvunque() {
  ['prezzi', 'carte'].forEach((sezione) => {
    const iframe = _iframeDi(sezione);
    if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_REFRESH_LOCATION' }, '*');
  });
}

const CF_LABELS = ['1 min', '2 min', '3 min', '4 min', '5 min', '6 min', '7 min', '8 min', '9 min', '10 min'];
const PAUSA_OGNI_LABELS = ['25', '50', '75', '100', 'Mai'];
const RICONTROLLO_LABELS = ['Mai', '10s', '20s', '30s', '60s'];
const COMPORTAMENTO_DEFAULT = {
  sliderDelayMinSec: 10,
  sliderDelayMaxSec: 20,
  sliderCfTimeout: 3,
  sliderPausaOgni: 2,
  sliderRicontrollo: 2,
  avvisoSonoro: true,
};
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];

function aggiornaLabelComportamento() {
  const vMin = document.getElementById('hubSliderDelayMin').value;
  const vMax = document.getElementById('hubSliderDelayMax').value;
  document.getElementById('hubValDelayMin').textContent = vMin + 's';
  document.getElementById('hubValDelayMax').textContent = vMax + 's';
  document.getElementById('hubValCfTimeout').textContent = CF_LABELS[document.getElementById('hubSliderCfTimeout').value - 1] || CF_LABELS[2];
  document.getElementById('hubValPausaOgni').textContent = PAUSA_OGNI_LABELS[document.getElementById('hubSliderPausaOgni').value] ?? PAUSA_OGNI_LABELS[2];
  document.getElementById('hubValRicontrollo').textContent = RICONTROLLO_LABELS[document.getElementById('hubSliderRicontrollo').value] ?? RICONTROLLO_LABELS[2];
}

document.getElementById('hubSliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('hubSliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: parseInt(sliderMax.value) });
});
document.getElementById('hubSliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('hubSliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: parseInt(sliderMin.value), sliderDelayMaxSec: vMax });
});
document.getElementById('hubSliderCfTimeout').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderCfTimeout: parseInt(e.target.value) });
});
document.getElementById('hubSliderPausaOgni').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderPausaOgni: parseInt(e.target.value) });
});
document.getElementById('hubSliderRicontrollo').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderRicontrollo: parseInt(e.target.value) });
});
document.getElementById('hubAvvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

document.getElementById('hubBtnResetComportamento').addEventListener('click', () => {
  document.getElementById('hubSliderDelayMin').value   = COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
  document.getElementById('hubSliderDelayMax').value   = COMPORTAMENTO_DEFAULT.sliderDelayMaxSec;
  document.getElementById('hubSliderCfTimeout').value  = COMPORTAMENTO_DEFAULT.sliderCfTimeout;
  document.getElementById('hubSliderPausaOgni').value  = COMPORTAMENTO_DEFAULT.sliderPausaOgni;
  document.getElementById('hubSliderRicontrollo').value = COMPORTAMENTO_DEFAULT.sliderRicontrollo;
  document.getElementById('hubAvvisoSonoro').checked   = COMPORTAMENTO_DEFAULT.avvisoSonoro;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ ...COMPORTAMENTO_DEFAULT });
});
chrome.storage.local.get(
  ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderCfTimeout', 'sliderPausaOgni', 'sliderRicontrollo', 'avvisoSonoro'],
  (saved) => {
    let vMin = saved.sliderDelayMinSec;
    let vMax = saved.sliderDelayMaxSec;
    if (vMin === undefined || vMax === undefined) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        [vMin, vMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      } else {
        vMin = COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
        vMax = COMPORTAMENTO_DEFAULT.sliderDelayMaxSec;
      }
      chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: vMax });
    }
    document.getElementById('hubSliderDelayMin').value = vMin;
    document.getElementById('hubSliderDelayMax').value = vMax;
    document.getElementById('hubSliderCfTimeout').value = saved.sliderCfTimeout ?? COMPORTAMENTO_DEFAULT.sliderCfTimeout;
    document.getElementById('hubSliderPausaOgni').value = saved.sliderPausaOgni ?? COMPORTAMENTO_DEFAULT.sliderPausaOgni;
    document.getElementById('hubSliderRicontrollo').value = saved.sliderRicontrollo ?? COMPORTAMENTO_DEFAULT.sliderRicontrollo;
    document.getElementById('hubAvvisoSonoro').checked = saved.avvisoSonoro !== false;
    aggiornaLabelComportamento();
  }
);

chrome.storage.onChanged.addListener((changes) => {
  if (changes.sliderDelayMinSec) document.getElementById('hubSliderDelayMin').value = changes.sliderDelayMinSec.newValue ?? 10;
  if (changes.sliderDelayMaxSec) document.getElementById('hubSliderDelayMax').value = changes.sliderDelayMaxSec.newValue ?? 20;
  if (changes.sliderCfTimeout) document.getElementById('hubSliderCfTimeout').value = changes.sliderCfTimeout.newValue ?? 3;
  if (changes.sliderPausaOgni) document.getElementById('hubSliderPausaOgni').value = changes.sliderPausaOgni.newValue ?? 2;
  if (changes.sliderRicontrollo) document.getElementById('hubSliderRicontrollo').value = changes.sliderRicontrollo.newValue ?? 2;
  if (changes.sliderDelayMinSec || changes.sliderDelayMaxSec || changes.sliderCfTimeout || changes.sliderPausaOgni || changes.sliderRicontrollo) aggiornaLabelComportamento();
  if (changes.avvisoSonoro !== undefined) document.getElementById('hubAvvisoSonoro').checked = changes.avvisoSonoro.newValue !== false;
});

const _hubLavoraAChiuso = document.getElementById('hubLavoraAChiuso');
chrome.storage.local.get(['lavoraAChiuso'], (saved) => {
  _hubLavoraAChiuso.checked = saved.lavoraAChiuso !== false;
});
_hubLavoraAChiuso.addEventListener('change', (e) => {
  chrome.storage.local.set({ lavoraAChiuso: e.target.checked });
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.lavoraAChiuso) _hubLavoraAChiuso.checked = changes.lavoraAChiuso.newValue !== false;
});

const _hubRiapriApp = document.getElementById('hubRiapriApp');
chrome.storage.local.get(['riapriAppSeChiusa'], (saved) => {
  _hubRiapriApp.checked = saved.riapriAppSeChiusa === true;
});
_hubRiapriApp.addEventListener('change', (e) => {
  chrome.storage.local.set({ riapriAppSeChiusa: e.target.checked });
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.riapriAppSeChiusa) _hubRiapriApp.checked = changes.riapriAppSeChiusa.newValue === true;
});

function aggiornaAccountChip(nome) {
  const avatarEl = document.getElementById('accountChipAvatar');
  const nomeEl = document.getElementById('accountNome');
  const menuNomeEl = document.getElementById('menuUtenteNome');
  const testo = (nome || '').trim();
  avatarEl.textContent = testo ? testo.charAt(0).toUpperCase() : '?';
  nomeEl.textContent = testo || 'account';
  menuNomeEl.textContent = testo || 'account';
  _btnUtente.title = testo ? 'Connesso come ' + testo : 'Account';
}

async function _aggiornaAccountChipDaSessione() {
  const { data } = await supabaseClient.auth.getSession();
  const utente = data.session?.user;
  const email = utente?.email || '';
  aggiornaAccountChip(email.split('@')[0]);
  if (!utente) return;
  try {
    const { data: nick, error } = await supabaseClient.rpc('ottieni_nicknames', { p_owner_ids: [utente.id] });
    const proprio = !error && Array.isArray(nick) ? nick.find((r) => r && r.owner_id === utente.id && r.nickname) : null;
    if (proprio) aggiornaAccountChip(proprio.nickname);
  } catch (_) {   }
}
_aggiornaAccountChipDaSessione();
_loginSupabasePronto.then(_aggiornaAccountChipDaSessione, () => {});

// ── Accesso a Cardmarket ──────────────────────────────────────────────────────────
// Pallino in alto (cliccabile, con pannello) + blocco a tutto schermo: senza accesso a Cardmarket
// l'estensione non si usa. Le uniche scelte sono "Accedi a Cardmarket" o "Chiudi l'estensione".
// Lo stato lo scrive il background in storage (statoLoginCardmarket): qui si legge e basta.
const _cmPill = document.getElementById('statoCardmarket');
const _cmPannello = document.getElementById('cmPannello');
const _cmBlocco = document.getElementById('cmBlocco');
let _cmSchedaAperta = false;
let _cmControlloInCorso = false;
// "da verificare" blocca solo se viene dal controllo fatto dall'app (apertura o "Controlla adesso"),
// non da un controllo lento fatto in background durante il lavoro
let _cmIgnotoDaApp = false;

function _cmStatoDaSalvato(salvato) {
  if (!salvato || typeof salvato.quando !== 'number') return 'ignoto';
  if (salvato.loggato === true) return 'ok';
  if (salvato.cloudflare === true) return 'cloudflare';
  if (salvato.loggato === false && salvato.nonConfermato !== true) return 'ko';
  return 'ignoto';
}

function _cmOra(quando) {
  return quando ? new Date(quando).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) : null;
}

const _CM_TESTI = {
  ok: { pill: 'Cardmarket connesso', titolo: 'Sei collegato a Cardmarket' },
  ko: { pill: 'Cardmarket: accedi', titolo: 'Non sei collegato a Cardmarket' },
  cloudflare: { pill: 'Cardmarket: verifica', titolo: 'Cardmarket chiede una verifica' },
  ignoto: { pill: 'Cardmarket da verificare', titolo: 'Accesso a Cardmarket da verificare' },
};

function _cmScriviPill(stato, quando) {
  const ora = _cmOra(quando);
  _cmPill.classList.remove('ok', 'ko', 'cf');
  if (stato === 'ok') _cmPill.classList.add('ok');
  if (stato === 'ko') _cmPill.classList.add('ko');
  if (stato === 'cloudflare') _cmPill.classList.add('cf');
  _cmPill.querySelector('span').textContent = _CM_TESTI[stato].pill;
  _cmPill.title = _CM_TESTI[stato].titolo + (ora ? ' (ultima verifica alle ' + ora + ')' : '');
  document.getElementById('cmPannelloTitolo').textContent = _CM_TESTI[stato].titolo;
  document.getElementById('cmPannelloSotto').textContent = ora ? 'Ultima verifica su questo PC alle ' + ora : 'Non ancora verificato su questo PC';
  document.getElementById('cmPannelloAccedi').hidden = stato === 'ok';
}

function _cmScriviBlocco(stato) {
  const titolo = document.getElementById('cmBloccoTitolo');
  const testo = document.getElementById('cmBloccoTesto');
  const accedi = document.getElementById('cmBloccoAccedi');
  if (stato === 'ok') { _cmBlocco.hidden = true; _cmSchedaAperta = false; _cmIgnotoDaApp = false; return; }
  if (stato === 'ignoto' && !_cmIgnotoDaApp && !_cmControlloInCorso && !_cmSchedaAperta) { _cmBlocco.hidden = true; return; }
  _cmBlocco.hidden = false;
  if (_cmControlloInCorso) {
    titolo.textContent = 'Controllo l\'accesso a Cardmarket…';
    testo.textContent = 'Un attimo: apro Cardmarket in una scheda nascosta e guardo se sei collegato.';
    accedi.hidden = true;
    return;
  }
  accedi.hidden = false;
  if (_cmSchedaAperta) {
    titolo.textContent = 'Accedi nella scheda di Cardmarket';
    testo.innerHTML = 'Ho aperto Cardmarket: fai l\'accesso con l\'<strong>account secondario</strong>' +
      (stato === 'cloudflare' ? ' (prima completa la verifica "non sono un robot")' : '') +
      '.<br>Appena hai fatto la scheda si chiude e torni qui da solo.';
    accedi.textContent = 'Riapri la scheda di Cardmarket';
    return;
  }
  if (stato === 'cloudflare') {
    titolo.textContent = 'Cardmarket chiede una verifica';
    testo.innerHTML = 'Cardmarket vuole controllare che tu non sia un robot. Apri Cardmarket, completa la verifica e, se serve, accedi con l\'<strong>account secondario</strong>.<br>Senza, l\'estensione non può lavorare.';
    accedi.textContent = 'Apri Cardmarket';
  } else {
    titolo.textContent = 'Accedi a Cardmarket per usare l\'estensione';
    testo.innerHTML = (stato === 'ko' ? 'Su questo PC non sei collegato a Cardmarket.' : 'Non sono riuscito a confermare che sei collegato a Cardmarket.') +
      '<br><br>Accedi con un <strong>account secondario</strong>, non con quello personale che usi tu ogni giorno.<br>Senza accesso l\'estensione non può lavorare.';
    accedi.textContent = 'Accedi a Cardmarket';
  }
}

let _cmUltimoSalvato = null;
function _cmAggiorna(salvato) {
  _cmUltimoSalvato = salvato || null;
  const stato = _cmStatoDaSalvato(salvato);
  _cmScriviPill(stato, salvato && salvato.quando);
  _cmScriviBlocco(stato);
}

function _cmApriScheda() {
  _cmSchedaAperta = true;
  _cmAggiorna(_cmUltimoSalvato);
  chrome.runtime.sendMessage({ type: 'CM_ACCESSO_APRI' }, () => { void chrome.runtime.lastError; });
}

function _cmControlla(forza) {
  if (_cmControlloInCorso) return;
  _cmControlloInCorso = true;
  const btn = document.getElementById('cmPannelloControlla');
  btn.disabled = true;
  btn.textContent = 'Controllo…';
  _cmAggiorna(_cmUltimoSalvato);
  chrome.runtime.sendMessage({ type: 'CM_ACCESSO_CONTROLLA', forza: !!forza }, () => {
    void chrome.runtime.lastError;
    _cmControlloInCorso = false;
    btn.disabled = false;
    btn.textContent = 'Controlla adesso';
    chrome.storage.local.get('statoLoginCardmarket', (s) => {
      _cmIgnotoDaApp = _cmStatoDaSalvato(s.statoLoginCardmarket) === 'ignoto';
      _cmAggiorna(s.statoLoginCardmarket);
    });
  });
}

function _cmApriPannello(apri) {
  _cmPannello.hidden = !apri;
  _cmPill.setAttribute('aria-expanded', String(apri));
}
_cmPill.addEventListener('click', (e) => { e.stopPropagation(); _cmApriPannello(_cmPannello.hidden); });
document.addEventListener('click', (e) => { if (!_cmPannello.hidden && !_cmPannello.contains(e.target)) _cmApriPannello(false); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') _cmApriPannello(false); });
document.getElementById('cmPannelloAccedi').addEventListener('click', () => { _cmApriPannello(false); _cmApriScheda(); });
document.getElementById('cmPannelloControlla').addEventListener('click', () => _cmControlla(true));
document.getElementById('cmBloccoAccedi').addEventListener('click', _cmApriScheda);
document.getElementById('cmBloccoChiudi').addEventListener('click', () => {
  chrome.tabs.getCurrent((tab) => {
    if (tab && tab.id != null) chrome.tabs.remove(tab.id, () => { void chrome.runtime.lastError; });
    else window.close();
  });
});

chrome.storage.onChanged.addListener((c) => { if (c.statoLoginCardmarket) _cmAggiorna(c.statoLoginCardmarket.newValue); });
// all'apertura: dopo l'accesso a Bindex si controlla Cardmarket (stato ricordato o scheda nascosta)
chrome.storage.local.get('statoLoginCardmarket', (s) => {
  _cmScriviPill(_cmStatoDaSalvato(s.statoLoginCardmarket), s.statoLoginCardmarket && s.statoLoginCardmarket.quando);
  _cmUltimoSalvato = s.statoLoginCardmarket || null;
});
_loginSupabasePronto.then(() => _cmControlla(false), () => {});

function _oggiLocale() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function _scriviNumeriLocali() {
  chrome.storage.local.get(['sliderDelayMinSec', 'sliderDelayMaxSec', 'turnoCardmarketLivelloCf', 'cloudflareOggi'], (s) => {
    const dMin = s.sliderDelayMinSec ?? COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
    const dMax = Math.max(s.sliderDelayMaxSec ?? COMPORTAMENTO_DEFAULT.sliderDelayMaxSec, dMin);
    const livello = s.turnoCardmarketLivelloCf || 0;
    document.getElementById('numAttesa').innerHTML = 'attesa tra due carte <b>' + (dMin === dMax ? dMin : dMin + '–' + dMax) + ' s</b>'
      + (livello > 0 ? ' + <b>' + (livello * 3) + ' s</b> dopo Cloudflare' : '');
    const cf = s.cloudflareOggi && s.cloudflareOggi.giorno === _oggiLocale() ? (s.cloudflareOggi.n || 0) : 0;
    const elCf = document.getElementById('numCloudflare');
    elCf.classList.toggle('ko', cf > 0);
    elCf.innerHTML = cf === 0 ? 'nessun Cloudflare oggi' : '<b>' + cf + '</b> Cloudflare oggi';
  });
}
_scriviNumeriLocali();
chrome.storage.onChanged.addListener((c) => {
  if (c.sliderDelayMinSec || c.sliderDelayMaxSec || c.turnoCardmarketLivelloCf || c.cloudflareOggi) _scriviNumeriLocali();
});
setInterval(_scriviNumeriLocali, 60000);

const _attivita = { coda: null, prezzi: null };
const _ultimaFatta = { coda: null, prezzi: null };
const _FASI_IN_CORSO = ['lettura', 'attesa', 'fatta', 'in-arresto'];
const _MAX_SILENZIO_MS = 4 * 60 * 1000;

const _ICONE = {
  coda: '<path d="M8 6h13M8 12h13M3.5 6h.01M3.5 12h.01"/>',
  prezzi: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  fermo: '<path d="M9 6v12M15 6v12"/>',
  fatto: '<path d="M5 12l5 5 9-10"/>',
};

function _esc(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
const _formatoEuro = new Intl.NumberFormat('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
function _euro(v) {
  const x = typeof v === 'string' ? parseFloat(v.replace(',', '.')) : v;
  return Number.isFinite(x) ? _formatoEuro.format(x) + ' €' : null;
}
function _durata(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  if (s < 60) return s + '\u202fs';
  return Math.floor(s / 60) + '\u202fmin ' + String(s % 60).padStart(2, '0') + '\u202fs';
}

function _htmlCarta(carta, etichetta) {
  if (!carta) return '';
  const nome = carta.nome || carta.codice || '';
  const codice = carta.nome && carta.codice && carta.codice !== carta.nome ? carta.codice : '';
  const lingua = [carta.lingua, carta.cond].filter(Boolean).join(' · ');
  return (etichetta ? `<span class="etichetta">${_esc(etichetta)}</span>` : '')
    + `<span class="nome">${_esc(nome)}</span>`
    + (codice ? `<span class="chip-codice mono">${_esc(codice)}</span>` : '')
    + (lingua ? `<span class="chip-lingua">${_esc(lingua)}</span>` : '')
    + (carta.di ? `<span class="di">${_esc(carta.di)}</span>` : '');
}

function _htmlUltima(f) {
  if (!f || !f.esito) return '';
  const c = f.carta || {};
  const chi = [c.nome, c.codice && c.codice !== c.nome ? c.codice : null].filter(Boolean).join(' · ') || 'carta';
  const spunta = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ok)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>';
  const croce = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ko)" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  if (!f.esito.ok) {
    return croce + `Non riuscita: <b>${_esc(chi)}</b> ${_esc(f.esito.testo || '')}`;
  }
  const prezzo = _euro(f.esito.prezzo);
  if (f.chi === 'prezzi') {
    const prima = _euro(f.esito.prezzoPrima);
    return spunta + `Appena controllata: <b>${_esc(chi)}</b>`
      + (prezzo ? ` <span class="mono">${prima && prima !== prezzo ? _esc(prima) + ' → ' : ''}${_esc(prezzo)}</span>` : ' senza prezzo');
  }
  return spunta + `Appena salvata: <b>${_esc(chi)}</b>` + (prezzo ? ` a <span class="mono">${_esc(prezzo)}</span>` : ' senza prezzo (lo legge il controllo prezzi)');
}

function _attivitaInCorso() {
  const ora = Date.now();
  const valide = ['coda', 'prezzi'].map((chi) => _attivita[chi]).filter((a) => {
    if (!a || !_FASI_IN_CORSO.includes(a.fase)) return false;
    if (a.fase === 'attesa' && a.fino) return a.fino > ora - 60000;
    return ora - a.ts < _MAX_SILENZIO_MS;
  });
  valide.sort((a, b) => b.ts - a.ts);
  return valide[0] || null;
}

let _fermaChiestoPer = null;

function _scriviAdesso() {
  const titolo = document.getElementById('adessoTitolo');
  const elCarta = document.getElementById('adessoCarta');
  const elSpiega = document.getElementById('adessoSpiega');
  const elUltima = document.getElementById('adessoUltima');
  const elAzione = document.getElementById('adessoAzione');
  const elEtichetta = document.getElementById('adessoEtichettaTempo');
  const elTempo = document.getElementById('adessoTempo');
  const elBarraWrap = document.getElementById('adessoBarraWrap');
  const elBarra = document.getElementById('adessoBarra');
  const btnFerma = document.getElementById('btnFermaAdesso');
  const btnRiprendi = document.getElementById('btnRiprendiAdesso');
  const icona = document.getElementById('adessoIcona');
  const a = _attivitaInCorso();

  const mostra = (elemento, html) => {
    elemento.hidden = !html;
    if (html && elemento.innerHTML !== html) elemento.innerHTML = html;
  };

  if (a) {
    const inArresto = a.fase === 'in-arresto' || _fermaChiestoPer === a.chi;
    icona.innerHTML = _ICONE[a.chi];
    titolo.textContent = inArresto ? 'Mi fermo dopo questa carta'
      : (a.chi === 'coda' ? 'Lavoro la coda' : 'Controllo i prezzi');
    let cartaHtml = '';
    if (a.fase === 'lettura') cartaHtml = _htmlCarta(a.carta, 'Sto leggendo');
    else if (a.fase === 'attesa' && a.prossima) cartaHtml = _htmlCarta(a.prossima, 'Prossima carta');
    mostra(elCarta, cartaHtml);
    let spiega = '';
    if (a.chi === 'prezzi' && a.totale) spiega = 'Carta ' + Math.min(a.n || 0, a.totale) + ' di ' + a.totale + ' in questo giro.';
    if (a.fase === 'attesa' && !a.fino && a.testo) spiega = a.testo;
    mostra(elSpiega, spiega ? _esc(spiega) : '');
    const ultima = _ultimaFatta[a.chi];
    mostra(elUltima, ultima && Date.now() - ultima.ts < 30 * 60000 ? _htmlUltima(ultima) : '');
    elUltima.classList.toggle('ko', !!(ultima && ultima.esito && !ultima.esito.ok));

    elAzione.hidden = false;
    btnRiprendi.hidden = true;
    btnFerma.hidden = false;
    btnFerma.disabled = inArresto;
    btnFerma.querySelector('span').textContent = inArresto ? 'In arresto…' : 'Ferma';
    if (a.fase === 'attesa' && a.fino) {
      const resta = a.fino - Date.now();
      elEtichetta.textContent = a.etichetta || 'Parte tra';
      elTempo.textContent = _durata(resta);
      elTempo.classList.remove('piccolo');
      elBarraWrap.classList.remove('indeterminata');
      elBarraWrap.hidden = false;
      const tot = a.durataMs || Math.max(resta, 1);
      elBarra.style.width = Math.max(0, Math.min(100, 100 - (resta / tot) * 100)) + '%';
    } else {
      elEtichetta.textContent = a.fase === 'lettura' ? 'Su Cardmarket' : (a.fase === 'fatta' ? 'Carta finita' : 'In attesa');
      elTempo.textContent = a.fase === 'lettura' ? 'sto leggendo' : (a.fase === 'fatta' ? 'prossima a breve' : 'del turno');
      elTempo.classList.add('piccolo');
      elBarraWrap.hidden = a.fase !== 'lettura';
      elBarraWrap.classList.add('indeterminata');
      elBarra.style.width = '';
    }
    return;
  }

  _fermaChiestoPer = null;
  const coda = _attivita.coda;
  const rimaste = coda && coda.fase === 'ferma' ? (coda.rimaste || 0) : 0;
  mostra(elCarta, '');
  const ultima = [_ultimaFatta.coda, _ultimaFatta.prezzi].filter(Boolean).sort((x, y) => y.ts - x.ts)[0];
  mostra(elUltima, ultima && Date.now() - ultima.ts < 30 * 60000 ? _htmlUltima(ultima) : '');
  elUltima.classList.toggle('ko', !!(ultima && ultima.esito && !ultima.esito.ok));
  if (rimaste > 0) {
    icona.innerHTML = _ICONE.fermo;
    titolo.textContent = 'Coda ferma';
    mostra(elSpiega, _esc(rimaste + (rimaste === 1 ? ' carta aspetta' : ' carte aspettano') + ' su questo PC.'));
    elAzione.hidden = false;
    elEtichetta.textContent = '';
    elTempo.textContent = '';
    elBarraWrap.hidden = true;
    btnFerma.hidden = true;
    btnRiprendi.hidden = false;
    return;
  }
  icona.innerHTML = _ICONE.fatto;
  titolo.textContent = 'Niente da fare adesso';
  mostra(elSpiega, _esc('Quando arrivano carte in coda o un controllo prezzi dal sito, questo PC parte da solo.'));
  elAzione.hidden = true;
}

window.addEventListener('message', (e) => {
  const dati = e.data;
  if (!dati || typeof dati !== 'object') return;
  if (dati.type === 'CARDSYNC_LOCATION_ADDED') { _rinfrescaLocationOvunque(); return; }
  if (dati.type !== 'CARDSYNC_ATTIVITA') return;
  const chi = dati.chi === 'coda' || dati.chi === 'prezzi' ? dati.chi : null;
  const iframe = chi ? _iframeDi(chi === 'coda' ? 'carte' : 'prezzi') : null;
  if (!iframe || e.source !== iframe.contentWindow) return;
  const msg = { ...dati, chi, ts: Date.now() };
  if (msg.fase === 'fatta') _ultimaFatta[chi] = msg;
  if (msg.fase === 'ferma' && _fermaChiestoPer === chi) _fermaChiestoPer = null;
  _attivita[chi] = msg;
  _scriviAdesso();
});

document.getElementById('btnFermaAdesso').addEventListener('click', () => {
  const a = _attivitaInCorso();
  if (!a) return;
  const iframe = _iframeDi(a.chi === 'coda' ? 'carte' : 'prezzi');
  if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_FERMA' }, '*');
  _fermaChiestoPer = a.chi;
  _scriviAdesso();
});
document.getElementById('btnRiprendiAdesso').addEventListener('click', () => {
  const iframe = _iframeDi('carte');
  if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_RIPRENDI' }, '*');
});

setInterval(_scriviAdesso, 1000);
_scriviAdesso();

document.getElementById('changelogLink').addEventListener('click', (e) => {
  e.preventDefault();
  _apriMenuUtente(false);
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

function sezioneValida(s) {
  return SEZIONI.includes(s) ? s : null;
}

function sezioneDaHash() {
  return sezioneValida((location.hash || '').replace('#', ''));
}

function attivaSezione(sezione, { aggiornaHash = true } = {}) {
  sezione = sezioneValida(sezione) || 'coda';

  document.querySelectorAll('.column').forEach((colonna) => {
    colonna.classList.toggle('tab-attiva', colonna.dataset.sezione === sezione);
  });
  const voceAttiva = sezione === 'coda-dettaglio' ? 'carte' : sezione;
  document.querySelectorAll('.nav-voce').forEach((voce) => {
    const attiva = voce.dataset.nav === voceAttiva;
    voce.classList.toggle('attiva', attiva);
    if (attiva) voce.setAttribute('aria-current', 'page'); else voce.removeAttribute('aria-current');
  });
  if (aggiornaHash && location.hash !== '#' + sezione) {
    history.replaceState(null, '', '#' + sezione);
  }
}

document.querySelectorAll('[data-vai-a]').forEach((el) => {
  el.addEventListener('click', () => attivaSezione(el.dataset.vaiA));
});

window.addEventListener('hashchange', () => attivaSezione(sezioneDaHash()));

chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'CARDSYNC_APRI_SEZIONE' && message.sezione) {
    attivaSezione(message.sezione);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'CARDSYNC_APRI_SEZIONE_ORDINE' || !sezioneValida(message.sezione)) return false;
  chrome.tabs.getCurrent((tab) => {
    void chrome.runtime.lastError;
    if (!tab || tab.id !== message.tabId) return;
    attivaSezione(message.sezione);
    const iframe = _iframeDi(message.sezione);
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ type: 'CARDSYNC_ORDINE_ARRIVATO', ordineId: message.ordineId || null }, '*');
    }
    sendResponse({ ok: true });
  });
  return true;
});

const _versione = chrome.runtime.getManifest().version;
document.getElementById('versioneApp').textContent = 'v' + _versione;
document.getElementById('appFooterCredit').textContent = 'Bindex · estensione v' + _versione + ' · © Lunachiara';

document.getElementById('appBugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  _apriMenuUtente(false);
  chrome.tabs.create({ url: e.currentTarget.href });
});

(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('appFooterCredit');
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

function _versioneMotoreInUso() {
  return new Promise((resolve) => {
    let fatto = false;
    const fine = (v) => { if (!fatto) { fatto = true; resolve(v); } };
    setTimeout(() => fine(null), 3000);
    try {
      chrome.runtime.sendMessage({ type: 'CARDSYNC_VERSIONE_MOTORE' }, (r) => {
        void chrome.runtime.lastError;
        fine(r && r.motore ? String(r.motore) : 'nessuna risposta');
      });
    } catch (_) {
      fine(null);
    }
  });
}

async function _ricaricaSeMotoreVecchio() {
  const manifest = chrome.runtime.getManifest().version;
  const motore = await _versioneMotoreInUso();
  if (motore === null || motore === manifest) return false;
  const { ricaricaMotoreDaApp } = await chrome.storage.local.get('ricaricaMotoreDaApp');
  if (ricaricaMotoreDaApp === manifest) {
    console.warn('[CardSync] motore ' + motore + ' con manifest ' + manifest + ' anche dopo la ricarica: niente altre ricariche.');
    return false;
  }
  await chrome.storage.local.set({ ricaricaMotoreDaApp: manifest });
  console.warn('[CardSync] motore ' + motore + ' con manifest ' + manifest + ': ricarico l\'estensione.');
  chrome.runtime.reload();
  return true;
}

_ricaricaSeMotoreVecchio().catch(() => false).then((ricarica) => {
  if (ricarica) return;
  document.querySelectorAll('.column iframe[data-src]').forEach((iframe) => {
    if (!iframe.src) iframe.src = iframe.dataset.src;
  });
});
attivaSezione(sezioneDaHash(), { aggiornaHash: false });
