// ── app.js ────────────────────────────────────────────────────────────────────
// Pagina dell'app (app.html). v5.46 (Fase 8b): barra in alto (Home · Coda ·
// Prezzi, stato di Cardmarket, versione, utente con il menu) al posto della
// barra laterale, e Home "Adesso": cosa sta facendo QUESTO PC, raccontato
// dalle due pagine al lavoro (Coda = aggiungi_carta_popup.html, Prezzi =
// popup.html) con il messaggio CARDSYNC_ATTIVITA; da qui partono Ferma e
// Riprendi (CARDSYNC_FERMA, CARDSYNC_RIPRENDI). I numeri del database
// (tessere, carte fatte oggi, coda del gruppo) li scrive coda_pendente.js.
//
// Le sezioni sono sempre le stesse colonne, tutte caricate all'avvio ANCHE
// se non visibili: la coda e i controlli prezzi automatici devono girare a
// prescindere da quale sezione si guarda — cambiare sezione nasconde/mostra
// solo il markup, non ricarica mai gli iframe.

// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
// v5.17: la Promise viene tenuta per il popup "Verifica login Cardmarket"
// più sotto, che compare solo DOPO il login (vedi _mostraModaleLoginCheck).
const _loginSupabasePronto = assicuraLoginSupabase();

// v5.17: 'sealed' tolta, v5.37: 'wishlist' tolta — un vecchio link "#sealed"
// o "#wishlist" ricade sulla home ('coda').
// 'coda' = Home, 'carte' = Coda (aggiungi carte), 'prezzi' = Prezzi,
// 'coda-dettaglio' = Coda del gruppo.
const SEZIONI = ['prezzi', 'carte', 'coda', 'coda-dettaglio'];

function _iframeDi(sezione) {
  const colonna = document.querySelector(`.column[data-sezione="${sezione}"]`);
  return colonna ? colonna.querySelector('iframe') : null;
}

// ── MENU UTENTE ───────────────────────────────────────────────────────────────
const _btnUtente = document.getElementById('btnUtente');
const _menuUtente = document.getElementById('menuUtente');
function _apriMenuUtente(apri) {
  _menuUtente.hidden = !apri;
  _btnUtente.setAttribute('aria-expanded', String(apri));
  if (apri) _aggiornaSottotitoloMenu();
}
_btnUtente.addEventListener('click', (e) => {
  e.stopPropagation();
  _apriMenuUtente(_menuUtente.hidden);
});
document.addEventListener('click', (e) => {
  if (!_menuUtente.hidden && !_menuUtente.contains(e.target)) _apriMenuUtente(false);
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  _apriMenuUtente(false);
  impPopover.classList.remove('visible');
});

async function _aggiornaSottotitoloMenu() {
  const el = document.getElementById('menuUtenteSotto');
  try {
    const [disp, { aiutaGruppo }] = await Promise.all([nomeDispositivo(), chrome.storage.local.get('aiutaGruppo')]);
    el.textContent = disp + ' · aiuta il gruppo: ' + (aiutaGruppo ? 'sì' : 'no');
  } catch (_) { el.textContent = ''; }
}

// Esci: dalla 5.46 sta nel menu (prima era un bottone fisso in basso,
// aggiunto da auth_ui.js). Solo questo PC, come il sito (scope 'local').
document.getElementById('menuEsci').addEventListener('click', async () => {
  _apriMenuUtente(false);
  const nome = document.getElementById('accountNome').textContent || 'account';
  if (!confirm('Uscire da Bindex (' + nome + ') su questo PC?\n\nDovrai rifare il login per usare l\'estensione.')) return;
  if (typeof window.logoutSupabase === 'function') await window.logoutSupabase();
});

// ── RITMO E CLOUDFLARE (finestra) ─────────────────────────────────────────────
const impBtn = document.getElementById('navImpostazioniAvanzate');
const impPopover = document.getElementById('impostazioniAvanzatePopover');
const impChiudiBtn = document.getElementById('chiudiImpostazioniAvanzate');
impBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  _apriMenuUtente(false);
  impPopover.classList.add('visible');
});
impChiudiBtn.addEventListener('click', () => impPopover.classList.remove('visible'));
// Click sullo sfondo scuro (fuori dal pannello) chiude la finestra.
impPopover.addEventListener('click', (e) => {
  if (e.target === impPopover) impPopover.classList.remove('visible');
});

// ── PROPAGAZIONE LOCATION NUOVE ───────────────────────────────────────────────
// Una location nuova scritta in una sezione (Coda) va riletta anche dalle
// altre (il filtro di Prezzi), senza bottoni manuali.
function _rinfrescaLocationOvunque() {
  ['prezzi', 'carte'].forEach((sezione) => {
    const iframe = _iframeDi(sezione);
    if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_REFRESH_LOCATION' }, '*');
  });
}

// ── COMPORTAMENTO (Ritmo e Cloudflare) ────────────────────────────────────────
// Ritardo min/max, Timeout Cloudflare, Pausa ogni N carte, Avviso sonoro e
// (dalla 5.46) Rileggi prezzo mancante: stesse chiavi storage di sempre,
// lette dalle pagine e da background.js al momento dell'uso.
const CF_LABELS = ['1 min', '2 min', '3 min', '4 min', '5 min', '6 min', '7 min', '8 min', '9 min', '10 min'];
const PAUSA_OGNI_LABELS = ['25', '50', '75', '100', 'Mai'];
const RICONTROLLO_LABELS = ['Mai', '10s', '20s', '30s', '60s']; // stessi indici di aggiungi_carta_popup.js
const COMPORTAMENTO_DEFAULT = {
  sliderDelayMinSec: 10,
  sliderDelayMaxSec: 20,
  sliderCfTimeout: 3,
  sliderPausaOgni: 2,
  sliderRicontrollo: 2,
  avvisoSonoro: true,
};
// Migrazione dal vecchio slider unico a preset (indice 0–7, "sliderDelay").
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];

function aggiornaLabelComportamento() {
  const vMin = document.getElementById('hubSliderDelayMin').value;
  const vMax = document.getElementById('hubSliderDelayMax').value;
  document.getElementById('hubValDelayMin').textContent = vMin + 's';
  document.getElementById('hubValDelayMax').textContent = vMax + 's';
  document.getElementById('hubValCfTimeout').textContent = CF_LABELS[document.getElementById('hubSliderCfTimeout').value - 1] || CF_LABELS[2];
  document.getElementById('hubValPausaOgni').textContent = PAUSA_OGNI_LABELS[document.getElementById('hubSliderPausaOgni').value] ?? PAUSA_OGNI_LABELS[2];
  document.getElementById('hubValRicontrollo').textContent = RICONTROLLO_LABELS[document.getElementById('hubSliderRicontrollo').value] ?? RICONTROLLO_LABELS[2];
}

document.getElementById('hubSliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('hubSliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: parseInt(sliderMax.value) });
});
document.getElementById('hubSliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('hubSliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: parseInt(sliderMin.value), sliderDelayMaxSec: vMax });
});
document.getElementById('hubSliderCfTimeout').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderCfTimeout: parseInt(e.target.value) });
});
document.getElementById('hubSliderPausaOgni').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderPausaOgni: parseInt(e.target.value) });
});
document.getElementById('hubSliderRicontrollo').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderRicontrollo: parseInt(e.target.value) });
});
document.getElementById('hubAvvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

document.getElementById('hubBtnResetComportamento').addEventListener('click', () => {
  document.getElementById('hubSliderDelayMin').value   = COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
  document.getElementById('hubSliderDelayMax').value   = COMPORTAMENTO_DEFAULT.sliderDelayMaxSec;
  document.getElementById('hubSliderCfTimeout').value  = COMPORTAMENTO_DEFAULT.sliderCfTimeout;
  document.getElementById('hubSliderPausaOgni').value  = COMPORTAMENTO_DEFAULT.sliderPausaOgni;
  document.getElementById('hubSliderRicontrollo').value = COMPORTAMENTO_DEFAULT.sliderRicontrollo;
  document.getElementById('hubAvvisoSonoro').checked   = COMPORTAMENTO_DEFAULT.avvisoSonoro;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ ...COMPORTAMENTO_DEFAULT });
});
chrome.storage.local.get(
  ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderCfTimeout', 'sliderPausaOgni', 'sliderRicontrollo', 'avvisoSonoro'],
  (saved) => {
    let vMin = saved.sliderDelayMinSec;
    let vMax = saved.sliderDelayMaxSec;
    if (vMin === undefined || vMax === undefined) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        [vMin, vMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      } else {
        vMin = COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
        vMax = COMPORTAMENTO_DEFAULT.sliderDelayMaxSec;
      }
      chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: vMax });
    }
    document.getElementById('hubSliderDelayMin').value = vMin;
    document.getElementById('hubSliderDelayMax').value = vMax;
    document.getElementById('hubSliderCfTimeout').value = saved.sliderCfTimeout ?? COMPORTAMENTO_DEFAULT.sliderCfTimeout;
    document.getElementById('hubSliderPausaOgni').value = saved.sliderPausaOgni ?? COMPORTAMENTO_DEFAULT.sliderPausaOgni;
    document.getElementById('hubSliderRicontrollo').value = saved.sliderRicontrollo ?? COMPORTAMENTO_DEFAULT.sliderRicontrollo;
    document.getElementById('hubAvvisoSonoro').checked = saved.avvisoSonoro !== false;
    aggiornaLabelComportamento();
  }
);

chrome.storage.onChanged.addListener((changes) => {
  if (changes.sliderDelayMinSec) document.getElementById('hubSliderDelayMin').value = changes.sliderDelayMinSec.newValue ?? 10;
  if (changes.sliderDelayMaxSec) document.getElementById('hubSliderDelayMax').value = changes.sliderDelayMaxSec.newValue ?? 20;
  if (changes.sliderCfTimeout) document.getElementById('hubSliderCfTimeout').value = changes.sliderCfTimeout.newValue ?? 3;
  if (changes.sliderPausaOgni) document.getElementById('hubSliderPausaOgni').value = changes.sliderPausaOgni.newValue ?? 2;
  if (changes.sliderRicontrollo) document.getElementById('hubSliderRicontrollo').value = changes.sliderRicontrollo.newValue ?? 2;
  if (changes.sliderDelayMinSec || changes.sliderDelayMaxSec || changes.sliderCfTimeout || changes.sliderPausaOgni || changes.sliderRicontrollo) aggiornaLabelComportamento();
  if (changes.avvisoSonoro !== undefined) document.getElementById('hubAvvisoSonoro').checked = changes.avvisoSonoro.newValue !== false;
});

// v5.25 — "Lavora anche a estensione chiusa" (la stessa preferenza si cambia
// anche dal sito, Impostazioni). Assente = acceso.
const _hubLavoraAChiuso = document.getElementById('hubLavoraAChiuso');
chrome.storage.local.get(['lavoraAChiuso'], (saved) => {
  _hubLavoraAChiuso.checked = saved.lavoraAChiuso !== false;
});
_hubLavoraAChiuso.addEventListener('change', (e) => {
  chrome.storage.local.set({ lavoraAChiuso: e.target.checked });
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.lavoraAChiuso) _hubLavoraAChiuso.checked = changes.lavoraAChiuso.newValue !== false;
});

// v5.32 — "Riapri l'app se viene chiusa" (per-dispositivo). Assente = spento.
// La riapertura la fa background.js (_riapriAppSeChiusa): qui solo
// l'interruttore.
const _hubRiapriApp = document.getElementById('hubRiapriApp');
chrome.storage.local.get(['riapriAppSeChiusa'], (saved) => {
  _hubRiapriApp.checked = saved.riapriAppSeChiusa === true;
});
_hubRiapriApp.addEventListener('change', (e) => {
  chrome.storage.local.set({ riapriAppSeChiusa: e.target.checked });
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.riapriAppSeChiusa) _hubRiapriApp.checked = changes.riapriAppSeChiusa.newValue === true;
});

// Chiaro/scuro: dalla 5.46 lo applica tema.js (stesso del sito, senza
// ricaricare la pagina). Prima ogni cambio ricaricava l'app e interrompeva
// la coda o il controllo prezzi in corso.

// ── POPUP "STO PER APRIRE CARDMARKET" ────────────────────────────────────────
// Il sito scrive un timestamp in questa chiave ad ogni apertura dell'app
// (vedi CARDSYNC_OPEN_APP in background.js): popup BLOCCANTE, l'ack al
// service worker (CARDSYNC_LOGIN_CHECK_ACK) parte solo al click su "Ho
// capito" — solo allora si apre la scheda Cardmarket per controllare il
// login. Il controllo "< 5 s" evita di mostrarlo su una riapertura normale.
function _mostraModaleLoginCheck() {
  if (document.getElementById('cardsync-login-check-overlay')) return; // già visibile, non sovrapporre
  const overlay = document.createElement('div');
  overlay.id = 'cardsync-login-check-overlay';
  overlay.style.cssText = 'position:fixed; inset:0; z-index:999999; background:#1a1625; display:flex; align-items:center; justify-content:center; font-family:"Space Grotesk", system-ui, sans-serif; padding:32px; box-sizing:border-box;';
  overlay.innerHTML = `
    <div style="color:#fff; max-width:680px; width:100%; text-align:center;">
      <div style="font-weight:700; font-size:38px; margin-bottom:24px; line-height:1.25;">Verifica login Cardmarket</div>
      <div style="color:#e4e0ee; font-size:22px; line-height:1.6; margin-bottom:36px;">
        Sto per aprire una pagina di Cardmarket per controllare il login.<br><br>
        <strong>Importante:</strong> se non risulti già loggato, fai il login con un <strong>account secondario</strong> — non quello personale che usi tu ogni giorno.<br><br>
        Al termine la pagina si chiude da sola e torni automaticamente sul sito.
      </div>
      <button id="cardsync-login-check-ok" style="border:none; border-radius:14px; padding:20px 48px; background:#7c4dff; color:#fff; font-weight:700; font-size:22px; cursor:pointer; font-family:inherit;">Ho capito</button>
    </div>`;
  document.body.appendChild(overlay);
  document.getElementById('cardsync-login-check-ok').addEventListener('click', () => {
    overlay.remove();
    chrome.runtime.sendMessage({ type: 'CARDSYNC_LOGIN_CHECK_ACK' });
  });
}
// v5.17: il popup Cardmarket aspetta che il login dell'estensione sia fatto.
chrome.storage.local.get(['cardsyncLoginCheckToast'], (saved) => {
  if (saved.cardsyncLoginCheckToast && Date.now() - saved.cardsyncLoginCheckToast < 5000) _loginSupabasePronto.then(_mostraModaleLoginCheck);
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.cardsyncLoginCheckToast) _loginSupabasePronto.then(_mostraModaleLoginCheck);
});

// ── UTENTE (identità Supabase reale) ─────────────────────────────────────────
// Il nome è la parte prima della @: è il nome utente con cui si fa login,
// mai l'email intera (regola "nickname, mai email").
function aggiornaAccountChip(nome) {
  const avatarEl = document.getElementById('accountChipAvatar');
  const nomeEl = document.getElementById('accountNome');
  const menuNomeEl = document.getElementById('menuUtenteNome');
  const testo = (nome || '').trim();
  avatarEl.textContent = testo ? testo.charAt(0).toUpperCase() : '?';
  nomeEl.textContent = testo || 'account';
  menuNomeEl.textContent = testo || 'account';
  _btnUtente.title = testo ? 'Connesso come ' + testo : 'Account';
}

// Prima il nome utente del login, poi (se c'è) il nickname scelto sul sito,
// come lo vedono gli altri (ottieni_nicknames).
async function _aggiornaAccountChipDaSessione() {
  const { data } = await supabaseClient.auth.getSession();
  const utente = data.session?.user;
  const email = utente?.email || '';
  aggiornaAccountChip(email.split('@')[0]);
  if (!utente) return;
  try {
    const { data: nick, error } = await supabaseClient.rpc('ottieni_nicknames', { p_owner_ids: [utente.id] });
    const proprio = !error && Array.isArray(nick) ? nick.find((r) => r && r.owner_id === utente.id && r.nickname) : null;
    if (proprio) aggiornaAccountChip(proprio.nickname);
  } catch (_) { /* resta il nome utente */ }
}
_aggiornaAccountChipDaSessione();
_loginSupabasePronto.then(_aggiornaAccountChipDaSessione, () => {});

// ── STATO DI CARDMARKET (pillola nella barra) ─────────────────────────────────
// L'ultimo esito ricordato da background.js (statoLoginCardmarket): lo
// aggiornano la verifica automatica, il login dall'app e ogni pagina di
// Cardmarket che mostra l'account. Nessuna richiesta a Cardmarket da qui.
function _scriviStatoCardmarket(stato) {
  const el = document.getElementById('statoCardmarket');
  const testo = el.querySelector('span');
  el.classList.remove('ok', 'ko');
  const ora = stato && stato.quando ? new Date(stato.quando).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) : null;
  if (stato && stato.loggato === true) {
    el.classList.add('ok');
    testo.textContent = 'Cardmarket connesso';
    el.title = 'Login su Cardmarket visto alle ' + ora;
  } else if (stato && stato.loggato === false && stato.nonConfermato !== true) {
    el.classList.add('ko');
    testo.textContent = 'Cardmarket: accedi';
    el.title = 'Alle ' + ora + ' Cardmarket non risultava loggato su questo PC: accedi con l\'account secondario.';
  } else {
    testo.textContent = 'Cardmarket da verificare';
    el.title = ora ? 'Alle ' + ora + ' non è stato possibile confermare il login (pagina lenta o verifica Cloudflare).' : 'Login su Cardmarket non ancora verificato su questo PC.';
  }
}
chrome.storage.local.get('statoLoginCardmarket', (s) => _scriviStatoCardmarket(s.statoLoginCardmarket));
chrome.storage.onChanged.addListener((c) => { if (c.statoLoginCardmarket) _scriviStatoCardmarket(c.statoLoginCardmarket.newValue); });

// ── NUMERI DI "ADESSO" CHE VENGONO DA QUESTO PC ───────────────────────────────
// Attesa tra due carte (slider + rallentamento dopo Cloudflare del turno
// comune) e Cloudflare di oggi (contati da background.js, cloudflareOggi).
function _oggiLocale() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function _scriviNumeriLocali() {
  chrome.storage.local.get(['sliderDelayMinSec', 'sliderDelayMaxSec', 'turnoCardmarketLivelloCf', 'cloudflareOggi'], (s) => {
    const dMin = s.sliderDelayMinSec ?? COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
    const dMax = Math.max(s.sliderDelayMaxSec ?? COMPORTAMENTO_DEFAULT.sliderDelayMaxSec, dMin);
    const livello = s.turnoCardmarketLivelloCf || 0;
    document.getElementById('numAttesa').innerHTML = 'attesa tra due carte <b>' + (dMin === dMax ? dMin : dMin + '–' + dMax) + ' s</b>'
      + (livello > 0 ? ' + <b>' + (livello * 3) + ' s</b> dopo Cloudflare' : '');
    const cf = s.cloudflareOggi && s.cloudflareOggi.giorno === _oggiLocale() ? (s.cloudflareOggi.n || 0) : 0;
    const elCf = document.getElementById('numCloudflare');
    elCf.classList.toggle('ko', cf > 0);
    elCf.innerHTML = cf === 0 ? 'nessun Cloudflare oggi' : '<b>' + cf + '</b> Cloudflare oggi';
  });
}
_scriviNumeriLocali();
chrome.storage.onChanged.addListener((c) => {
  if (c.sliderDelayMinSec || c.sliderDelayMaxSec || c.turnoCardmarketLivelloCf || c.cloudflareOggi) _scriviNumeriLocali();
});
setInterval(_scriviNumeriLocali, 60000); // a mezzanotte "oggi" cambia

// ── ADESSO SU QUESTO PC ───────────────────────────────────────────────────────
// Le due pagine al lavoro mandano CARDSYNC_ATTIVITA:
//   { chi: 'coda' | 'prezzi', fase: 'lettura' | 'attesa' | 'fatta' | 'in-arresto' | 'ferma',
//     carta: { nome, codice, lingua, cond, di }, prossima: { … }, fino, durataMs,
//     etichetta, testo, esito: { ok, testo, prezzo, prezzoPrima }, n, totale, rimaste }
// La home tiene l'ultimo messaggio di ognuna e mostra quella che sta
// lavorando (la più recente). Niente messaggi = niente in corso.
const _attivita = { coda: null, prezzi: null };
const _ultimaFatta = { coda: null, prezzi: null };
const _FASI_IN_CORSO = ['lettura', 'attesa', 'fatta', 'in-arresto'];
const _MAX_SILENZIO_MS = 4 * 60 * 1000; // lettura senza notizie da così tanto = pagina ferma o chiusa

const _ICONE = {
  coda: '<path d="M8 6h13M8 12h13M3.5 6h.01M3.5 12h.01"/>',
  prezzi: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  fermo: '<path d="M9 6v12M15 6v12"/>',
  fatto: '<path d="M5 12l5 5 9-10"/>',
};

function _esc(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : String(t);
  return d.innerHTML;
}
const _formatoEuro = new Intl.NumberFormat('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
function _euro(v) {
  const x = typeof v === 'string' ? parseFloat(v.replace(',', '.')) : v;
  return Number.isFinite(x) ? _formatoEuro.format(x) + ' €' : null;
}
function _durata(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  if (s < 60) return s + '\u202fs';
  return Math.floor(s / 60) + '\u202fmin ' + String(s % 60).padStart(2, '0') + '\u202fs';
}

function _htmlCarta(carta, etichetta) {
  if (!carta) return '';
  const nome = carta.nome || carta.codice || '';
  const codice = carta.nome && carta.codice && carta.codice !== carta.nome ? carta.codice : '';
  const lingua = [carta.lingua, carta.cond].filter(Boolean).join(' · ');
  return (etichetta ? `<span class="etichetta">${_esc(etichetta)}</span>` : '')
    + `<span class="nome">${_esc(nome)}</span>`
    + (codice ? `<span class="chip-codice mono">${_esc(codice)}</span>` : '')
    + (lingua ? `<span class="chip-lingua">${_esc(lingua)}</span>` : '')
    + (carta.di ? `<span class="di">${_esc(carta.di)}</span>` : '');
}

function _htmlUltima(f) {
  if (!f || !f.esito) return '';
  const c = f.carta || {};
  const chi = [c.nome, c.codice && c.codice !== c.nome ? c.codice : null].filter(Boolean).join(' · ') || 'carta';
  const spunta = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ok)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5 9-10"/></svg>';
  const croce = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ko)" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  if (!f.esito.ok) {
    return croce + `Non riuscita: <b>${_esc(chi)}</b> ${_esc(f.esito.testo || '')}`;
  }
  const prezzo = _euro(f.esito.prezzo);
  if (f.chi === 'prezzi') {
    const prima = _euro(f.esito.prezzoPrima);
    return spunta + `Appena controllata: <b>${_esc(chi)}</b>`
      + (prezzo ? ` <span class="mono">${prima && prima !== prezzo ? _esc(prima) + ' → ' : ''}${_esc(prezzo)}</span>` : ' senza prezzo');
  }
  return spunta + `Appena salvata: <b>${_esc(chi)}</b>` + (prezzo ? ` a <span class="mono">${_esc(prezzo)}</span>` : ' senza prezzo (lo legge il controllo prezzi)');
}

function _attivitaInCorso() {
  const ora = Date.now();
  const valide = ['coda', 'prezzi'].map((chi) => _attivita[chi]).filter((a) => {
    if (!a || !_FASI_IN_CORSO.includes(a.fase)) return false;
    if (a.fase === 'attesa' && a.fino) return a.fino > ora - 60000;
    return ora - a.ts < _MAX_SILENZIO_MS;
  });
  valide.sort((a, b) => b.ts - a.ts);
  return valide[0] || null;
}

let _fermaChiestoPer = null; // chi ha ricevuto Ferma, finché la pagina non risponde

function _scriviAdesso() {
  const titolo = document.getElementById('adessoTitolo');
  const elCarta = document.getElementById('adessoCarta');
  const elSpiega = document.getElementById('adessoSpiega');
  const elUltima = document.getElementById('adessoUltima');
  const elAzione = document.getElementById('adessoAzione');
  const elEtichetta = document.getElementById('adessoEtichettaTempo');
  const elTempo = document.getElementById('adessoTempo');
  const elBarraWrap = document.getElementById('adessoBarraWrap');
  const elBarra = document.getElementById('adessoBarra');
  const btnFerma = document.getElementById('btnFermaAdesso');
  const btnRiprendi = document.getElementById('btnRiprendiAdesso');
  const icona = document.getElementById('adessoIcona');
  const a = _attivitaInCorso();

  const mostra = (elemento, html) => {
    elemento.hidden = !html;
    if (html && elemento.innerHTML !== html) elemento.innerHTML = html;
  };

  if (a) {
    const inArresto = a.fase === 'in-arresto' || _fermaChiestoPer === a.chi;
    icona.innerHTML = _ICONE[a.chi];
    titolo.textContent = inArresto ? 'Mi fermo dopo questa carta'
      : (a.chi === 'coda' ? 'Lavoro la coda' : 'Controllo i prezzi');
    let cartaHtml = '';
    if (a.fase === 'lettura') cartaHtml = _htmlCarta(a.carta, 'Sto leggendo');
    else if (a.fase === 'attesa' && a.prossima) cartaHtml = _htmlCarta(a.prossima, 'Prossima carta');
    mostra(elCarta, cartaHtml);
    let spiega = '';
    if (a.chi === 'prezzi' && a.totale) spiega = 'Carta ' + Math.min(a.n || 0, a.totale) + ' di ' + a.totale + ' in questo giro.';
    if (a.fase === 'attesa' && !a.fino && a.testo) spiega = a.testo;
    mostra(elSpiega, spiega ? _esc(spiega) : '');
    const ultima = _ultimaFatta[a.chi];
    mostra(elUltima, ultima && Date.now() - ultima.ts < 30 * 60000 ? _htmlUltima(ultima) : '');
    elUltima.classList.toggle('ko', !!(ultima && ultima.esito && !ultima.esito.ok));

    elAzione.hidden = false;
    btnRiprendi.hidden = true;
    btnFerma.hidden = false;
    btnFerma.disabled = inArresto;
    btnFerma.querySelector('span').textContent = inArresto ? 'In arresto…' : 'Ferma';
    if (a.fase === 'attesa' && a.fino) {
      const resta = a.fino - Date.now();
      elEtichetta.textContent = a.etichetta || 'Parte tra';
      elTempo.textContent = _durata(resta);
      elTempo.classList.remove('piccolo');
      elBarraWrap.classList.remove('indeterminata');
      elBarraWrap.hidden = false;
      const tot = a.durataMs || Math.max(resta, 1);
      elBarra.style.width = Math.max(0, Math.min(100, 100 - (resta / tot) * 100)) + '%';
    } else {
      elEtichetta.textContent = a.fase === 'lettura' ? 'Su Cardmarket' : (a.fase === 'fatta' ? 'Carta finita' : 'In attesa');
      elTempo.textContent = a.fase === 'lettura' ? 'sto leggendo' : (a.fase === 'fatta' ? 'prossima a breve' : 'del turno');
      elTempo.classList.add('piccolo');
      elBarraWrap.hidden = a.fase !== 'lettura';
      elBarraWrap.classList.add('indeterminata');
      elBarra.style.width = '';
    }
    return;
  }

  // Niente in corso.
  _fermaChiestoPer = null;
  const coda = _attivita.coda;
  const rimaste = coda && coda.fase === 'ferma' ? (coda.rimaste || 0) : 0;
  mostra(elCarta, '');
  const ultima = [_ultimaFatta.coda, _ultimaFatta.prezzi].filter(Boolean).sort((x, y) => y.ts - x.ts)[0];
  mostra(elUltima, ultima && Date.now() - ultima.ts < 30 * 60000 ? _htmlUltima(ultima) : '');
  elUltima.classList.toggle('ko', !!(ultima && ultima.esito && !ultima.esito.ok));
  if (rimaste > 0) {
    icona.innerHTML = _ICONE.fermo;
    titolo.textContent = 'Coda ferma';
    mostra(elSpiega, _esc(rimaste + (rimaste === 1 ? ' carta aspetta' : ' carte aspettano') + ' su questo PC.'));
    elAzione.hidden = false;
    elEtichetta.textContent = '';
    elTempo.textContent = '';
    elBarraWrap.hidden = true;
    btnFerma.hidden = true;
    btnRiprendi.hidden = false;
    return;
  }
  icona.innerHTML = _ICONE.fatto;
  titolo.textContent = 'Niente da fare adesso';
  mostra(elSpiega, _esc('Quando arrivano carte in coda o un controllo prezzi dal sito, questo PC parte da solo.'));
  elAzione.hidden = true;
}

window.addEventListener('message', (e) => {
  const dati = e.data;
  if (!dati || typeof dati !== 'object') return;
  // Una pagina "aggiungi" (Coda), scrivendo una location nuova mai vista
  // prima, chiede all'app di propagarla alle altre sezioni.
  if (dati.type === 'CARDSYNC_LOCATION_ADDED') { _rinfrescaLocationOvunque(); return; }
  if (dati.type !== 'CARDSYNC_ATTIVITA') return;
  // Solo dalle due pagine dell'app, ognuna per sé.
  const chi = dati.chi === 'coda' || dati.chi === 'prezzi' ? dati.chi : null;
  const iframe = chi ? _iframeDi(chi === 'coda' ? 'carte' : 'prezzi') : null;
  if (!iframe || e.source !== iframe.contentWindow) return;
  const msg = { ...dati, chi, ts: Date.now() };
  if (msg.fase === 'fatta') _ultimaFatta[chi] = msg;
  if (msg.fase === 'ferma' && _fermaChiestoPer === chi) _fermaChiestoPer = null;
  _attivita[chi] = msg;
  _scriviAdesso();
});

document.getElementById('btnFermaAdesso').addEventListener('click', () => {
  const a = _attivitaInCorso();
  if (!a) return;
  const iframe = _iframeDi(a.chi === 'coda' ? 'carte' : 'prezzi');
  if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_FERMA' }, '*');
  _fermaChiestoPer = a.chi;
  _scriviAdesso();
});
document.getElementById('btnRiprendiAdesso').addEventListener('click', () => {
  const iframe = _iframeDi('carte');
  if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_RIPRENDI' }, '*');
});

setInterval(_scriviAdesso, 1000);
_scriviAdesso();

// ── NOVITÀ DELLA VERSIONE ─────────────────────────────────────────────────────
document.getElementById('changelogLink').addEventListener('click', (e) => {
  e.preventDefault();
  _apriMenuUtente(false);
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

// ── SEZIONI: UNA VISIBILE ALLA VOLTA ──────────────────────────────────────────
// Solo CSS (display): gli iframe restano caricati. All'apertura senza #hash
// si parte SEMPRE dalla home.
function sezioneValida(s) {
  return SEZIONI.includes(s) ? s : null;
}

function sezioneDaHash() {
  return sezioneValida((location.hash || '').replace('#', ''));
}

function attivaSezione(sezione, { aggiornaHash = true } = {}) {
  sezione = sezioneValida(sezione) || 'coda'; // prima pagina di default

  document.querySelectorAll('.column').forEach((colonna) => {
    colonna.classList.toggle('tab-attiva', colonna.dataset.sezione === sezione);
  });
  // "Coda del gruppo" appartiene alla Coda nella barra in alto.
  const voceAttiva = sezione === 'coda-dettaglio' ? 'carte' : sezione;
  document.querySelectorAll('.nav-voce').forEach((voce) => {
    const attiva = voce.dataset.nav === voceAttiva;
    voce.classList.toggle('attiva', attiva);
    if (attiva) voce.setAttribute('aria-current', 'page'); else voce.removeAttribute('aria-current');
  });
  if (aggiornaHash && location.hash !== '#' + sezione) {
    history.replaceState(null, '', '#' + sezione);
  }
}

document.querySelectorAll('[data-vai-a]').forEach((el) => {
  el.addEventListener('click', () => attivaSezione(el.dataset.vaiA));
});

window.addEventListener('hashchange', () => attivaSezione(sezioneDaHash()));

// ── MESSAGGI DA background.js ─────────────────────────────────────────────────
// Con l'app già aperta, un'apertura dal sito o dal popup porta in primo
// piano la sezione giusta.
chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'CARDSYNC_APRI_SEZIONE' && message.sezione) {
    attivaSezione(message.sezione);
  }
});

// ── v5.40 (Fase 4.1) — ORDINE DAL SITO CON L'APP GIÀ APERTA ───────────────────
// Si cambia sezione e si avvisa la sezione (Prezzi), che legge l'ordine
// dallo storage come fa all'apertura. Risponde solo la scheda indicata (con
// due schede dell'app aperte, background.js ne sceglie una). Nessuna
// risposta entro 3 s → background.js ricarica la scheda come prima.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'CARDSYNC_APRI_SEZIONE_ORDINE' || !sezioneValida(message.sezione)) return false;
  chrome.tabs.getCurrent((tab) => {
    void chrome.runtime.lastError;
    if (!tab || tab.id !== message.tabId) return; // un'altra scheda dell'app: risponde quella giusta
    attivaSezione(message.sezione);
    const iframe = _iframeDi(message.sezione);
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ type: 'CARDSYNC_ORDINE_ARRIVATO', ordineId: message.ordineId || null }, '*');
    }
    sendResponse({ ok: true });
  });
  return true;
});

// ── VERSIONE E CREDITI ────────────────────────────────────────────────────────
// Versione letta dal manifest, mai scritta a mano.
const _versione = chrome.runtime.getManifest().version;
document.getElementById('versioneApp').textContent = 'v' + _versione;
document.getElementById('appFooterCredit').textContent = 'Bindex · estensione v' + _versione + ' · © Lunachiara';

document.getElementById('appBugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  _apriMenuUtente(false);
  chrome.tabs.create({ url: e.currentTarget.href });
});

// Easter egg (tre click sui crediti).
(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('appFooterCredit');
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

// ── v5.41 — MOTORE VECCHIO CON I FILE NUOVI ───────────────────────────────────
// All'apertura si chiede al motore (background.js) la sua versione
// (CARDSYNC_VERSIONE_MOTORE): se è diversa dal manifest, o se il motore non
// conosce la domanda, si ricarica l'estensione come il bottone ↻ di
// chrome://extensions. Al massimo una volta per versione
// (ricaricaMotoreDaApp). Nessuna risposta entro 3 s: non si decide nulla.
function _versioneMotoreInUso() {
  return new Promise((resolve) => {
    let fatto = false;
    const fine = (v) => { if (!fatto) { fatto = true; resolve(v); } };
    setTimeout(() => fine(null), 3000);
    try {
      chrome.runtime.sendMessage({ type: 'CARDSYNC_VERSIONE_MOTORE' }, (r) => {
        void chrome.runtime.lastError; // "port closed": motore che non conosce la domanda
        fine(r && r.motore ? String(r.motore) : 'nessuna risposta');
      });
    } catch (_) {
      fine(null);
    }
  });
}

async function _ricaricaSeMotoreVecchio() {
  const manifest = chrome.runtime.getManifest().version;
  const motore = await _versioneMotoreInUso();
  if (motore === null || motore === manifest) return false;
  const { ricaricaMotoreDaApp } = await chrome.storage.local.get('ricaricaMotoreDaApp');
  if (ricaricaMotoreDaApp === manifest) {
    console.warn('[CardSync] motore ' + motore + ' con manifest ' + manifest + ' anche dopo la ricarica: niente altre ricariche.');
    return false;
  }
  await chrome.storage.local.set({ ricaricaMotoreDaApp: manifest });
  console.warn('[CardSync] motore ' + motore + ' con manifest ' + manifest + ': ricarico l\'estensione.');
  chrome.runtime.reload();
  return true;
}

// ── BOOT ──────────────────────────────────────────────────────────────────────
// Ogni iframe carica il proprio src SUBITO all'avvio, anche se la sua
// sezione non è quella mostrata. v5.41: dopo il controllo del motore (di
// solito pochi millisecondi, al massimo 3 s).
_ricaricaSeMotoreVecchio().catch(() => false).then((ricarica) => {
  if (ricarica) return;
  document.querySelectorAll('.column iframe[data-src]').forEach((iframe) => {
    if (!iframe.src) iframe.src = iframe.dataset.src;
  });
});
attivaSezione(sezioneDaHash(), { aggiornaHash: false });
